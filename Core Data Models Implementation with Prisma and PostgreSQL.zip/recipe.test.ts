import { PrismaClient, UserRole, Difficulty } from '@prisma/client';
import { prisma } from './setup';

describe('Recipe and SubRecipe CRUD Operations', () => {
  let testOrg: any;
  let testUser: any;
  let testIngredient: any;

  beforeEach(async () => {
    testOrg = await prisma.org.create({
      data: {
        name: 'Test Organization for Recipes',
        description: 'Organization for recipe testing',
      },
    });

    testUser = await prisma.user.create({
      data: {
        email: 'chef@test.com',
        name: 'Test Chef',
        role: UserRole.CHEF,
        orgId: testOrg.id,
      },
    });

    testIngredient = await prisma.ingredient.create({
      data: {
        name: 'Test Ingredient for Recipes',
        unit: 'kg',
        category: 'test',
      },
    });
  });

  describe('Recipe CRUD Operations', () => {
    describe('Create Recipe', () => {
      it('should create a new recipe', async () => {
        const recipeData = {
          name: 'Test Recipe',
          description: 'A delicious test recipe',
          instructions: [
            'Step 1: Prepare ingredients',
            'Step 2: Cook ingredients',
            'Step 3: Serve hot',
          ],
          prepTime: 15,
          cookTime: 30,
          servings: 4,
          difficulty: Difficulty.MEDIUM,
          tags: ['test', 'delicious'],
          isPublic: true,
          orgId: testOrg.id,
          createdById: testUser.id,
        };

        const recipe = await prisma.recipe.create({
          data: recipeData,
        });

        expect(recipe).toBeDefined();
        expect(recipe.id).toBeDefined();
        expect(recipe.name).toBe(recipeData.name);
        expect(recipe.description).toBe(recipeData.description);
        expect(recipe.instructions).toEqual(recipeData.instructions);
        expect(recipe.prepTime).toBe(recipeData.prepTime);
        expect(recipe.cookTime).toBe(recipeData.cookTime);
        expect(recipe.servings).toBe(recipeData.servings);
        expect(recipe.difficulty).toBe(recipeData.difficulty);
        expect(recipe.tags).toEqual(recipeData.tags);
        expect(recipe.isPublic).toBe(recipeData.isPublic);
        expect(recipe.orgId).toBe(recipeData.orgId);
        expect(recipe.createdById).toBe(recipeData.createdById);
      });

      it('should fail to create recipe with duplicate name in same org', async () => {
        const recipeData = {
          name: 'Duplicate Recipe',
          orgId: testOrg.id,
          createdById: testUser.id,
        };

        await prisma.recipe.create({ data: recipeData });

        await expect(
          prisma.recipe.create({ data: recipeData })
        ).rejects.toThrow();
      });

      it('should create recipes with different difficulties', async () => {
        const difficulties = [Difficulty.EASY, Difficulty.MEDIUM, Difficulty.HARD, Difficulty.EXPERT];

        for (let i = 0; i < difficulties.length; i++) {
          const recipe = await prisma.recipe.create({
            data: {
              name: `Recipe ${i}`,
              difficulty: difficulties[i],
              orgId: testOrg.id,
              createdById: testUser.id,
            },
          });

          expect(recipe.difficulty).toBe(difficulties[i]);
        }
      });
    });

    describe('Read Recipe', () => {
      it('should find recipe by id with relations', async () => {
        const recipe = await prisma.recipe.create({
          data: {
            name: 'Find Test Recipe',
            orgId: testOrg.id,
            createdById: testUser.id,
          },
        });

        const foundRecipe = await prisma.recipe.findUnique({
          where: { id: recipe.id },
          include: {
            org: true,
            createdBy: true,
            ingredients: {
              include: {
                ingredient: true,
              },
            },
          },
        });

        expect(foundRecipe).toBeDefined();
        expect(foundRecipe?.org.id).toBe(testOrg.id);
        expect(foundRecipe?.createdBy.id).toBe(testUser.id);
      });

      it('should find recipes by organization', async () => {
        await prisma.recipe.createMany({
          data: [
            { name: 'Recipe 1', orgId: testOrg.id, createdById: testUser.id },
            { name: 'Recipe 2', orgId: testOrg.id, createdById: testUser.id },
          ],
        });

        const recipes = await prisma.recipe.findMany({
          where: { orgId: testOrg.id },
        });

        expect(recipes).toHaveLength(2);
      });

      it('should find public recipes', async () => {
        await prisma.recipe.createMany({
          data: [
            { name: 'Public Recipe', isPublic: true, orgId: testOrg.id, createdById: testUser.id },
            { name: 'Private Recipe', isPublic: false, orgId: testOrg.id, createdById: testUser.id },
          ],
        });

        const publicRecipes = await prisma.recipe.findMany({
          where: { isPublic: true },
        });

        expect(publicRecipes).toHaveLength(1);
        expect(publicRecipes[0].name).toBe('Public Recipe');
      });
    });

    describe('Update Recipe', () => {
      it('should update recipe instructions', async () => {
        const recipe = await prisma.recipe.create({
          data: {
            name: 'Update Test Recipe',
            instructions: ['Old step 1', 'Old step 2'],
            orgId: testOrg.id,
            createdById: testUser.id,
          },
        });

        const updatedRecipe = await prisma.recipe.update({
          where: { id: recipe.id },
          data: {
            instructions: ['New step 1', 'New step 2', 'New step 3'],
          },
        });

        expect(updatedRecipe.instructions).toEqual(['New step 1', 'New step 2', 'New step 3']);
      });

      it('should update recipe tags', async () => {
        const recipe = await prisma.recipe.create({
          data: {
            name: 'Tags Test Recipe',
            tags: ['old', 'tags'],
            orgId: testOrg.id,
            createdById: testUser.id,
          },
        });

        const updatedRecipe = await prisma.recipe.update({
          where: { id: recipe.id },
          data: { tags: ['new', 'updated', 'tags'] },
        });

        expect(updatedRecipe.tags).toEqual(['new', 'updated', 'tags']);
      });
    });

    describe('Delete Recipe', () => {
      it('should delete recipe', async () => {
        const recipe = await prisma.recipe.create({
          data: {
            name: 'Delete Test Recipe',
            orgId: testOrg.id,
            createdById: testUser.id,
          },
        });

        await prisma.recipe.delete({
          where: { id: recipe.id },
        });

        const foundRecipe = await prisma.recipe.findUnique({
          where: { id: recipe.id },
        });

        expect(foundRecipe).toBeNull();
      });
    });
  });

  describe('RecipeIngredient CRUD Operations', () => {
    let testRecipe: any;

    beforeEach(async () => {
      testRecipe = await prisma.recipe.create({
        data: {
          name: 'Test Recipe for Ingredients',
          orgId: testOrg.id,
          createdById: testUser.id,
        },
      });
    });

    describe('Create RecipeIngredient', () => {
      it('should add ingredient to recipe', async () => {
        const recipeIngredientData = {
          quantity: 2.5,
          unit: 'kg',
          notes: 'finely chopped',
          recipeId: testRecipe.id,
          ingredientId: testIngredient.id,
        };

        const recipeIngredient = await prisma.recipeIngredient.create({
          data: recipeIngredientData,
        });

        expect(recipeIngredient).toBeDefined();
        expect(recipeIngredient.quantity).toBe(2.5);
        expect(recipeIngredient.unit).toBe('kg');
        expect(recipeIngredient.notes).toBe('finely chopped');
        expect(recipeIngredient.recipeId).toBe(testRecipe.id);
        expect(recipeIngredient.ingredientId).toBe(testIngredient.id);
      });

      it('should fail to add duplicate ingredient to recipe', async () => {
        const data = {
          quantity: 1.0,
          unit: 'kg',
          recipeId: testRecipe.id,
          ingredientId: testIngredient.id,
        };

        await prisma.recipeIngredient.create({ data });

        await expect(
          prisma.recipeIngredient.create({ data })
        ).rejects.toThrow();
      });
    });

    describe('Read RecipeIngredient', () => {
      it('should find recipe ingredients with relations', async () => {
        await prisma.recipeIngredient.create({
          data: {
            quantity: 1.5,
            unit: 'kg',
            recipeId: testRecipe.id,
            ingredientId: testIngredient.id,
          },
        });

        const recipeIngredients = await prisma.recipeIngredient.findMany({
          where: { recipeId: testRecipe.id },
          include: {
            recipe: true,
            ingredient: true,
          },
        });

        expect(recipeIngredients).toHaveLength(1);
        expect(recipeIngredients[0].recipe.id).toBe(testRecipe.id);
        expect(recipeIngredients[0].ingredient.id).toBe(testIngredient.id);
      });
    });

    describe('Update RecipeIngredient', () => {
      it('should update ingredient quantity', async () => {
        const recipeIngredient = await prisma.recipeIngredient.create({
          data: {
            quantity: 1.0,
            unit: 'kg',
            recipeId: testRecipe.id,
            ingredientId: testIngredient.id,
          },
        });

        const updated = await prisma.recipeIngredient.update({
          where: { id: recipeIngredient.id },
          data: { quantity: 2.0 },
        });

        expect(updated.quantity).toBe(2.0);
      });
    });

    describe('Delete RecipeIngredient', () => {
      it('should remove ingredient from recipe', async () => {
        const recipeIngredient = await prisma.recipeIngredient.create({
          data: {
            quantity: 1.0,
            unit: 'kg',
            recipeId: testRecipe.id,
            ingredientId: testIngredient.id,
          },
        });

        await prisma.recipeIngredient.delete({
          where: { id: recipeIngredient.id },
        });

        const found = await prisma.recipeIngredient.findUnique({
          where: { id: recipeIngredient.id },
        });

        expect(found).toBeNull();
      });
    });
  });

  describe('SubRecipe CRUD Operations', () => {
    let parentRecipe: any;
    let childRecipe: any;

    beforeEach(async () => {
      parentRecipe = await prisma.recipe.create({
        data: {
          name: 'Parent Recipe',
          orgId: testOrg.id,
          createdById: testUser.id,
        },
      });

      childRecipe = await prisma.recipe.create({
        data: {
          name: 'Child Recipe',
          orgId: testOrg.id,
          createdById: testUser.id,
        },
      });
    });

    describe('Create SubRecipe', () => {
      it('should create sub-recipe relationship', async () => {
        const subRecipeData = {
          quantity: 2.0,
          notes: 'Use as base',
          parentRecipeId: parentRecipe.id,
          childRecipeId: childRecipe.id,
        };

        const subRecipe = await prisma.subRecipe.create({
          data: subRecipeData,
        });

        expect(subRecipe).toBeDefined();
        expect(subRecipe.quantity).toBe(2.0);
        expect(subRecipe.notes).toBe('Use as base');
        expect(subRecipe.parentRecipeId).toBe(parentRecipe.id);
        expect(subRecipe.childRecipeId).toBe(childRecipe.id);
      });

      it('should fail to create duplicate sub-recipe relationship', async () => {
        const data = {
          quantity: 1.0,
          parentRecipeId: parentRecipe.id,
          childRecipeId: childRecipe.id,
        };

        await prisma.subRecipe.create({ data });

        await expect(
          prisma.subRecipe.create({ data })
        ).rejects.toThrow();
      });
    });

    describe('Read SubRecipe', () => {
      it('should find sub-recipes with relations', async () => {
        await prisma.subRecipe.create({
          data: {
            quantity: 1.5,
            parentRecipeId: parentRecipe.id,
            childRecipeId: childRecipe.id,
          },
        });

        const subRecipes = await prisma.subRecipe.findMany({
          where: { parentRecipeId: parentRecipe.id },
          include: {
            parentRecipe: true,
            childRecipe: true,
          },
        });

        expect(subRecipes).toHaveLength(1);
        expect(subRecipes[0].parentRecipe.id).toBe(parentRecipe.id);
        expect(subRecipes[0].childRecipe.id).toBe(childRecipe.id);
      });
    });

    describe('Update SubRecipe', () => {
      it('should update sub-recipe quantity', async () => {
        const subRecipe = await prisma.subRecipe.create({
          data: {
            quantity: 1.0,
            parentRecipeId: parentRecipe.id,
            childRecipeId: childRecipe.id,
          },
        });

        const updated = await prisma.subRecipe.update({
          where: { id: subRecipe.id },
          data: { quantity: 3.0 },
        });

        expect(updated.quantity).toBe(3.0);
      });
    });

    describe('Delete SubRecipe', () => {
      it('should delete sub-recipe relationship', async () => {
        const subRecipe = await prisma.subRecipe.create({
          data: {
            quantity: 1.0,
            parentRecipeId: parentRecipe.id,
            childRecipeId: childRecipe.id,
          },
        });

        await prisma.subRecipe.delete({
          where: { id: subRecipe.id },
        });

        const found = await prisma.subRecipe.findUnique({
          where: { id: subRecipe.id },
        });

        expect(found).toBeNull();
      });
    });
  });
});

