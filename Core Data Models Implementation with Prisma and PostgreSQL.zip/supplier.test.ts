import { PrismaClient } from '@prisma/client';
import { prisma } from './setup';
import { encrypt, decrypt } from '../src/encryption';

describe('Supplier and SupplierIngredient CRUD Operations', () => {
  let testOrg: any;
  let testIngredient: any;

  beforeEach(async () => {
    testOrg = await prisma.org.create({
      data: {
        name: 'Test Organization for Suppliers',
        description: 'Organization for supplier testing',
      },
    });

    testIngredient = await prisma.ingredient.create({
      data: {
        name: 'Test Ingredient for Suppliers',
        unit: 'kg',
        category: 'test',
      },
    });
  });

  describe('Supplier CRUD Operations', () => {
    describe('Create Supplier', () => {
      it('should create a new supplier', async () => {
        const supplierData = {
          name: 'Test Supplier',
          email: 'supplier@test.com',
          phone: '+1-555-0123',
          address: '123 Test Street',
          contactPerson: 'John Doe',
          orgId: testOrg.id,
        };

        const supplier = await prisma.supplier.create({
          data: supplierData,
        });

        expect(supplier).toBeDefined();
        expect(supplier.id).toBeDefined();
        expect(supplier.name).toBe(supplierData.name);
        expect(supplier.email).toBe(supplierData.email);
        expect(supplier.phone).toBe(supplierData.phone);
        expect(supplier.address).toBe(supplierData.address);
        expect(supplier.contactPerson).toBe(supplierData.contactPerson);
        expect(supplier.orgId).toBe(supplierData.orgId);
        expect(supplier.isActive).toBe(true);
      });

      it('should fail to create supplier with duplicate name in same org', async () => {
        const supplierData = {
          name: 'Duplicate Supplier',
          orgId: testOrg.id,
        };

        await prisma.supplier.create({ data: supplierData });

        await expect(
          prisma.supplier.create({
            data: supplierData,
          })
        ).rejects.toThrow();
      });
    });

    describe('Read Supplier', () => {
      it('should find supplier by id with organization', async () => {
        const supplier = await prisma.supplier.create({
          data: {
            name: 'Find Test Supplier',
            orgId: testOrg.id,
          },
        });

        const foundSupplier = await prisma.supplier.findUnique({
          where: { id: supplier.id },
          include: { org: true },
        });

        expect(foundSupplier).toBeDefined();
        expect(foundSupplier?.org.id).toBe(testOrg.id);
      });

      it('should find suppliers by organization', async () => {
        await prisma.supplier.createMany({
          data: [
            { name: 'Supplier 1', orgId: testOrg.id },
            { name: 'Supplier 2', orgId: testOrg.id },
          ],
        });

        const suppliers = await prisma.supplier.findMany({
          where: { orgId: testOrg.id },
        });

        expect(suppliers).toHaveLength(2);
      });
    });

    describe('Update Supplier', () => {
      it('should update supplier contact information', async () => {
        const supplier = await prisma.supplier.create({
          data: {
            name: 'Update Test Supplier',
            email: 'old@email.com',
            orgId: testOrg.id,
          },
        });

        const updatedSupplier = await prisma.supplier.update({
          where: { id: supplier.id },
          data: { email: 'new@email.com' },
        });

        expect(updatedSupplier.email).toBe('new@email.com');
      });

      it('should deactivate supplier', async () => {
        const supplier = await prisma.supplier.create({
          data: {
            name: 'Deactivate Test Supplier',
            orgId: testOrg.id,
          },
        });

        const updatedSupplier = await prisma.supplier.update({
          where: { id: supplier.id },
          data: { isActive: false },
        });

        expect(updatedSupplier.isActive).toBe(false);
      });
    });

    describe('Delete Supplier', () => {
      it('should delete supplier', async () => {
        const supplier = await prisma.supplier.create({
          data: {
            name: 'Delete Test Supplier',
            orgId: testOrg.id,
          },
        });

        await prisma.supplier.delete({
          where: { id: supplier.id },
        });

        const foundSupplier = await prisma.supplier.findUnique({
          where: { id: supplier.id },
        });

        expect(foundSupplier).toBeNull();
      });
    });
  });

  describe('SupplierIngredient CRUD Operations with Encryption', () => {
    let testSupplier: any;

    beforeEach(async () => {
      testSupplier = await prisma.supplier.create({
        data: {
          name: 'Test Supplier for Ingredients',
          orgId: testOrg.id,
        },
      });
    });

    describe('Create SupplierIngredient', () => {
      it('should create supplier ingredient with encrypted cost', async () => {
        const supplierIngredientData = {
          cost: '25.50',
          currency: 'USD',
          minimumOrder: 10,
          leadTimeDays: 3,
          supplierId: testSupplier.id,
          ingredientId: testIngredient.id,
        };

        const supplierIngredient = await prisma.supplierIngredient.create({
          data: supplierIngredientData,
        });

        expect(supplierIngredient).toBeDefined();
        expect(supplierIngredient.cost).toBe('25.50'); // Should be decrypted by middleware
        expect(supplierIngredient.currency).toBe('USD');
        expect(supplierIngredient.minimumOrder).toBe(10);
        expect(supplierIngredient.leadTimeDays).toBe(3);
      });

      it('should fail to create duplicate supplier-ingredient relationship', async () => {
        const data = {
          cost: '20.00',
          supplierId: testSupplier.id,
          ingredientId: testIngredient.id,
        };

        await prisma.supplierIngredient.create({ data });

        await expect(
          prisma.supplierIngredient.create({ data })
        ).rejects.toThrow();
      });
    });

    describe('Read SupplierIngredient', () => {
      it('should find supplier ingredient with decrypted cost', async () => {
        const supplierIngredient = await prisma.supplierIngredient.create({
          data: {
            cost: '30.75',
            supplierId: testSupplier.id,
            ingredientId: testIngredient.id,
          },
        });

        const found = await prisma.supplierIngredient.findUnique({
          where: { id: supplierIngredient.id },
          include: {
            supplier: true,
            ingredient: true,
          },
        });

        expect(found).toBeDefined();
        expect(found?.cost).toBe('30.75'); // Should be decrypted
        expect(found?.supplier.id).toBe(testSupplier.id);
        expect(found?.ingredient.id).toBe(testIngredient.id);
      });

      it('should find all supplier ingredients for a supplier', async () => {
        const ingredient2 = await prisma.ingredient.create({
          data: {
            name: 'Second Test Ingredient',
            unit: 'kg',
          },
        });

        await prisma.supplierIngredient.createMany({
          data: [
            {
              cost: '15.00',
              supplierId: testSupplier.id,
              ingredientId: testIngredient.id,
            },
            {
              cost: '22.50',
              supplierId: testSupplier.id,
              ingredientId: ingredient2.id,
            },
          ],
        });

        const supplierIngredients = await prisma.supplierIngredient.findMany({
          where: { supplierId: testSupplier.id },
        });

        expect(supplierIngredients).toHaveLength(2);
        expect(supplierIngredients[0].cost).toBe('15.00');
        expect(supplierIngredients[1].cost).toBe('22.50');
      });
    });

    describe('Update SupplierIngredient', () => {
      it('should update cost with encryption', async () => {
        const supplierIngredient = await prisma.supplierIngredient.create({
          data: {
            cost: '20.00',
            supplierId: testSupplier.id,
            ingredientId: testIngredient.id,
          },
        });

        const updated = await prisma.supplierIngredient.update({
          where: { id: supplierIngredient.id },
          data: { cost: '25.00' },
        });

        expect(updated.cost).toBe('25.00'); // Should be decrypted
      });

      it('should update availability', async () => {
        const supplierIngredient = await prisma.supplierIngredient.create({
          data: {
            cost: '20.00',
            supplierId: testSupplier.id,
            ingredientId: testIngredient.id,
          },
        });

        const updated = await prisma.supplierIngredient.update({
          where: { id: supplierIngredient.id },
          data: { isAvailable: false },
        });

        expect(updated.isAvailable).toBe(false);
      });
    });

    describe('Delete SupplierIngredient', () => {
      it('should delete supplier ingredient', async () => {
        const supplierIngredient = await prisma.supplierIngredient.create({
          data: {
            cost: '20.00',
            supplierId: testSupplier.id,
            ingredientId: testIngredient.id,
          },
        });

        await prisma.supplierIngredient.delete({
          where: { id: supplierIngredient.id },
        });

        const found = await prisma.supplierIngredient.findUnique({
          where: { id: supplierIngredient.id },
        });

        expect(found).toBeNull();
      });
    });
  });

  describe('Encryption Functions', () => {
    it('should encrypt and decrypt text correctly', () => {
      const originalText = '42.50';
      const encrypted = encrypt(originalText);
      const decrypted = decrypt(encrypted);

      expect(encrypted).not.toBe(originalText);
      expect(encrypted).toContain(':'); // Should contain IV separator
      expect(decrypted).toBe(originalText);
    });

    it('should handle decryption of invalid data', () => {
      const invalidEncrypted = 'invalid:encrypted:data';
      const decrypted = decrypt(invalidEncrypted);

      expect(decrypted).toBe(''); // Should return empty string for invalid data
    });
  });
});

