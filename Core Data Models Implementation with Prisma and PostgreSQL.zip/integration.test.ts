import { PrismaClient } from '@prisma/client';
import { createPrismaClient } from '../src/encryption';

describe('Core Data Models Integration Tests', () => {
  let prisma: PrismaClient;

  beforeAll(async () => {
    // Use test database
    const testDbUrl = 'postgresql://postgres:password@localhost:5432/core_data_models_test?schema=public';
    process.env.DATABASE_URL = testDbUrl;
    
    prisma = createPrismaClient();
    await prisma.$connect();
  });

  beforeEach(async () => {
    // Clean up database before each test
    await prisma.event.deleteMany();
    await prisma.menuItem.deleteMany();
    await prisma.menu.deleteMany();
    await prisma.subRecipe.deleteMany();
    await prisma.recipeIngredient.deleteMany();
    await prisma.recipe.deleteMany();
    await prisma.supplierIngredient.deleteMany();
    await prisma.supplier.deleteMany();
    await prisma.ingredient.deleteMany();
    await prisma.user.deleteMany();
    await prisma.org.deleteMany();
  });

  afterAll(async () => {
    await prisma.$disconnect();
  });

  describe('Basic CRUD Operations', () => {
    it('should create and read organization', async () => {
      const org = await prisma.org.create({
        data: {
          name: 'Test Restaurant',
          description: 'A test restaurant',
        },
      });

      expect(org).toBeDefined();
      expect(org.name).toBe('Test Restaurant');

      const foundOrg = await prisma.org.findUnique({
        where: { id: org.id },
      });

      expect(foundOrg).toBeDefined();
      expect(foundOrg?.name).toBe('Test Restaurant');
    });

    it('should create user with organization relationship', async () => {
      const org = await prisma.org.create({
        data: {
          name: 'Test Org',
          description: 'Test organization',
        },
      });

      const user = await prisma.user.create({
        data: {
          email: 'test@example.com',
          name: 'Test User',
          orgId: org.id,
        },
      });

      expect(user).toBeDefined();
      expect(user.orgId).toBe(org.id);

      const userWithOrg = await prisma.user.findUnique({
        where: { id: user.id },
        include: { org: true },
      });

      expect(userWithOrg?.org.name).toBe('Test Org');
    });

    it('should create ingredient', async () => {
      const ingredient = await prisma.ingredient.create({
        data: {
          name: 'Test Tomato',
          unit: 'kg',
          category: 'vegetables',
          allergens: [],
        },
      });

      expect(ingredient).toBeDefined();
      expect(ingredient.name).toBe('Test Tomato');
      expect(ingredient.unit).toBe('kg');
    });

    it('should create supplier with encrypted cost', async () => {
      const org = await prisma.org.create({
        data: { name: 'Test Org' },
      });

      const ingredient = await prisma.ingredient.create({
        data: {
          name: 'Test Ingredient',
          unit: 'kg',
        },
      });

      const supplier = await prisma.supplier.create({
        data: {
          name: 'Test Supplier',
          orgId: org.id,
        },
      });

      const supplierIngredient = await prisma.supplierIngredient.create({
        data: {
          cost: '25.50',
          supplierId: supplier.id,
          ingredientId: ingredient.id,
        },
      });

      expect(supplierIngredient).toBeDefined();
      expect(supplierIngredient.cost).toBe('25.50'); // Should be decrypted by middleware
    });

    it('should create recipe with ingredients', async () => {
      const org = await prisma.org.create({
        data: { name: 'Test Org' },
      });

      const user = await prisma.user.create({
        data: {
          email: 'chef@test.com',
          name: 'Test Chef',
          orgId: org.id,
        },
      });

      const ingredient = await prisma.ingredient.create({
        data: {
          name: 'Test Ingredient',
          unit: 'kg',
        },
      });

      const recipe = await prisma.recipe.create({
        data: {
          name: 'Test Recipe',
          orgId: org.id,
          createdById: user.id,
        },
      });

      const recipeIngredient = await prisma.recipeIngredient.create({
        data: {
          quantity: 2.5,
          unit: 'kg',
          recipeId: recipe.id,
          ingredientId: ingredient.id,
        },
      });

      expect(recipeIngredient).toBeDefined();
      expect(recipeIngredient.quantity).toBe(2.5);

      const recipeWithIngredients = await prisma.recipe.findUnique({
        where: { id: recipe.id },
        include: {
          ingredients: {
            include: {
              ingredient: true,
            },
          },
        },
      });

      expect(recipeWithIngredients?.ingredients).toHaveLength(1);
      expect(recipeWithIngredients?.ingredients[0].ingredient.name).toBe('Test Ingredient');
    });

    it('should create menu with items', async () => {
      const org = await prisma.org.create({
        data: { name: 'Test Org' },
      });

      const user = await prisma.user.create({
        data: {
          email: 'chef@test.com',
          name: 'Test Chef',
          orgId: org.id,
        },
      });

      const recipe = await prisma.recipe.create({
        data: {
          name: 'Test Recipe',
          orgId: org.id,
          createdById: user.id,
        },
      });

      const menu = await prisma.menu.create({
        data: {
          name: 'Test Menu',
          orgId: org.id,
        },
      });

      const menuItem = await prisma.menuItem.create({
        data: {
          price: 15.99,
          category: 'main',
          menuId: menu.id,
          recipeId: recipe.id,
        },
      });

      expect(menuItem).toBeDefined();
      expect(menuItem.price).toBe(15.99);

      const menuWithItems = await prisma.menu.findUnique({
        where: { id: menu.id },
        include: {
          menuItems: {
            include: {
              recipe: true,
            },
          },
        },
      });

      expect(menuWithItems?.menuItems).toHaveLength(1);
      expect(menuWithItems?.menuItems[0].recipe.name).toBe('Test Recipe');
    });

    it('should create event with menu', async () => {
      const org = await prisma.org.create({
        data: { name: 'Test Org' },
      });

      const user = await prisma.user.create({
        data: {
          email: 'manager@test.com',
          name: 'Test Manager',
          orgId: org.id,
        },
      });

      const menu = await prisma.menu.create({
        data: {
          name: 'Test Menu',
          orgId: org.id,
        },
      });

      const event = await prisma.event.create({
        data: {
          name: 'Test Event',
          startDate: new Date(),
          orgId: org.id,
          createdById: user.id,
          menuId: menu.id,
        },
      });

      expect(event).toBeDefined();
      expect(event.name).toBe('Test Event');

      const eventWithMenu = await prisma.event.findUnique({
        where: { id: event.id },
        include: {
          menu: true,
          org: true,
          createdBy: true,
        },
      });

      expect(eventWithMenu?.menu?.name).toBe('Test Menu');
      expect(eventWithMenu?.org.name).toBe('Test Org');
      expect(eventWithMenu?.createdBy.name).toBe('Test Manager');
    });
  });

  describe('Complex Relationships', () => {
    it('should create sub-recipe relationship', async () => {
      const org = await prisma.org.create({
        data: { name: 'Test Org' },
      });

      const user = await prisma.user.create({
        data: {
          email: 'chef@test.com',
          name: 'Test Chef',
          orgId: org.id,
        },
      });

      const parentRecipe = await prisma.recipe.create({
        data: {
          name: 'Parent Recipe',
          orgId: org.id,
          createdById: user.id,
        },
      });

      const childRecipe = await prisma.recipe.create({
        data: {
          name: 'Child Recipe',
          orgId: org.id,
          createdById: user.id,
        },
      });

      const subRecipe = await prisma.subRecipe.create({
        data: {
          quantity: 2.0,
          parentRecipeId: parentRecipe.id,
          childRecipeId: childRecipe.id,
        },
      });

      expect(subRecipe).toBeDefined();
      expect(subRecipe.quantity).toBe(2.0);

      const parentWithSubs = await prisma.recipe.findUnique({
        where: { id: parentRecipe.id },
        include: {
          subRecipes: {
            include: {
              childRecipe: true,
            },
          },
        },
      });

      expect(parentWithSubs?.subRecipes).toHaveLength(1);
      expect(parentWithSubs?.subRecipes[0].childRecipe.name).toBe('Child Recipe');
    });

    it('should handle cascade deletes', async () => {
      const org = await prisma.org.create({
        data: { name: 'Test Org' },
      });

      const user = await prisma.user.create({
        data: {
          email: 'test@test.com',
          name: 'Test User',
          orgId: org.id,
        },
      });

      const supplier = await prisma.supplier.create({
        data: {
          name: 'Test Supplier',
          orgId: org.id,
        },
      });

      // Delete org should cascade to user and supplier
      await prisma.org.delete({
        where: { id: org.id },
      });

      const foundUser = await prisma.user.findUnique({
        where: { id: user.id },
      });

      const foundSupplier = await prisma.supplier.findUnique({
        where: { id: supplier.id },
      });

      expect(foundUser).toBeNull();
      expect(foundSupplier).toBeNull();
    });
  });

  describe('Data Validation', () => {
    it('should enforce unique constraints', async () => {
      await prisma.org.create({
        data: { name: 'Unique Org' },
      });

      await expect(
        prisma.org.create({
          data: { name: 'Unique Org' },
        })
      ).rejects.toThrow();
    });

    it('should enforce foreign key constraints', async () => {
      await expect(
        prisma.user.create({
          data: {
            email: 'test@test.com',
            name: 'Test User',
            orgId: 'non-existent-id',
          },
        })
      ).rejects.toThrow();
    });
  });
});

