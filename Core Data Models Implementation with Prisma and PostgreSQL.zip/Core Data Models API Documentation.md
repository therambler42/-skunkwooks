# Core Data Models API Documentation

## Overview

The Core Data Models API provides RESTful endpoints for managing restaurant and catering operations. This API supports multi-tenant organizations with role-based access control and comprehensive data management capabilities.

## Base URL

- **Development**: `http://localhost:8080`
- **Staging**: `https://core-data-models-staging.fly.dev`
- **Production**: `https://core-data-models-prod.fly.dev`

## Authentication

Currently, the API does not implement authentication. In a production environment, you would typically add JWT-based authentication or OAuth2.

## Response Format

All API responses follow a consistent JSON format:

### Success Response
```json
{
  "data": { ... },
  "status": "success"
}
```

### Error Response
```json
{
  "error": "Error message",
  "message": "Detailed error description",
  "status": "error"
}
```

## Endpoints

### Health Check

#### GET /health

Returns the health status of the application and database connection.

**Response:**
```json
{
  "status": "healthy",
  "timestamp": "2024-06-08T06:45:20.255Z",
  "database": "connected",
  "environment": "development"
}
```

**Status Codes:**
- `200 OK` - Application is healthy
- `503 Service Unavailable` - Application or database is unhealthy

---

### Statistics

#### GET /api/stats

Returns count statistics for all major entities in the system.

**Response:**
```json
{
  "organizations": 2,
  "users": 4,
  "ingredients": 50,
  "suppliers": 10,
  "recipes": 20,
  "menus": 3,
  "events": 3
}
```

**Status Codes:**
- `200 OK` - Statistics retrieved successfully
- `500 Internal Server Error` - Database error

---

### Organizations

#### GET /api/organizations

Retrieves a list of all organizations with their entity counts.

**Response:**
```json
[
  {
    "id": "org-uuid-1",
    "name": "Gourmet Delights Restaurant",
    "description": "Fine dining establishment specializing in contemporary cuisine",
    "createdAt": "2024-01-01T00:00:00.000Z",
    "updatedAt": "2024-01-01T00:00:00.000Z",
    "_count": {
      "users": 2,
      "suppliers": 5,
      "recipes": 10,
      "menus": 2,
      "events": 1
    }
  }
]
```

#### GET /api/organizations/:id

Retrieves detailed information about a specific organization including all related entities.

**Parameters:**
- `id` (string, required) - Organization UUID

**Response:**
```json
{
  "id": "org-uuid-1",
  "name": "Gourmet Delights Restaurant",
  "description": "Fine dining establishment",
  "createdAt": "2024-01-01T00:00:00.000Z",
  "updatedAt": "2024-01-01T00:00:00.000Z",
  "users": [
    {
      "id": "user-uuid-1",
      "email": "chef@gourmet.com",
      "name": "Head Chef",
      "role": "CHEF",
      "isActive": true
    }
  ],
  "suppliers": [...],
  "recipes": [...],
  "menus": [...],
  "events": [...]
}
```

**Status Codes:**
- `200 OK` - Organization found
- `404 Not Found` - Organization not found
- `500 Internal Server Error` - Database error

---

### Recipes

#### GET /api/recipes

Retrieves a list of recipes with optional filtering.

**Query Parameters:**
- `orgId` (string, optional) - Filter by organization ID
- `isPublic` (boolean, optional) - Filter by public visibility

**Example Request:**
```
GET /api/recipes?orgId=org-uuid-1&isPublic=true
```

**Response:**
```json
[
  {
    "id": "recipe-uuid-1",
    "name": "Truffle Risotto",
    "description": "Creamy arborio rice with black truffle",
    "instructions": [
      "Heat the stock in a saucepan",
      "Sauté onions until translucent",
      "Add rice and stir for 2 minutes"
    ],
    "prepTime": 15,
    "cookTime": 30,
    "servings": 4,
    "difficulty": "MEDIUM",
    "tags": ["italian", "vegetarian", "luxury"],
    "isPublic": true,
    "createdAt": "2024-01-01T00:00:00.000Z",
    "org": {
      "id": "org-uuid-1",
      "name": "Gourmet Delights Restaurant"
    },
    "createdBy": {
      "id": "user-uuid-1",
      "name": "Head Chef"
    },
    "ingredients": [
      {
        "id": "recipe-ingredient-uuid-1",
        "quantity": 300,
        "unit": "g",
        "notes": "Arborio rice",
        "ingredient": {
          "id": "ingredient-uuid-1",
          "name": "Arborio Rice",
          "category": "grains"
        }
      }
    ],
    "_count": {
      "ingredients": 8,
      "subRecipes": 1,
      "parentRecipes": 0
    }
  }
]
```

**Status Codes:**
- `200 OK` - Recipes retrieved successfully
- `500 Internal Server Error` - Database error

---

### Menus

#### GET /api/menus

Retrieves a list of menus with optional filtering.

**Query Parameters:**
- `orgId` (string, optional) - Filter by organization ID
- `isActive` (boolean, optional) - Filter by active status

**Example Request:**
```
GET /api/menus?orgId=org-uuid-1&isActive=true
```

**Response:**
```json
[
  {
    "id": "menu-uuid-1",
    "name": "Spring Tasting Menu",
    "description": "Seasonal menu featuring spring ingredients",
    "menuType": "SEASONAL",
    "isActive": true,
    "validFrom": "2024-03-01T00:00:00.000Z",
    "validTo": "2024-05-31T23:59:59.000Z",
    "createdAt": "2024-02-15T00:00:00.000Z",
    "org": {
      "id": "org-uuid-1",
      "name": "Gourmet Delights Restaurant"
    },
    "menuItems": [
      {
        "id": "menu-item-uuid-1",
        "name": "Truffle Risotto",
        "description": "Creamy arborio rice with black truffle",
        "price": 28.00,
        "category": "main",
        "isAvailable": true,
        "sortOrder": 1,
        "recipe": {
          "id": "recipe-uuid-1",
          "name": "Truffle Risotto",
          "difficulty": "MEDIUM"
        }
      }
    ],
    "_count": {
      "menuItems": 8,
      "events": 2
    }
  }
]
```

**Status Codes:**
- `200 OK` - Menus retrieved successfully
- `500 Internal Server Error` - Database error

---

### Events

#### GET /api/events

Retrieves a list of events with optional filtering.

**Query Parameters:**
- `orgId` (string, optional) - Filter by organization ID
- `status` (string, optional) - Filter by event status (PLANNED, CONFIRMED, IN_PROGRESS, COMPLETED, CANCELLED)

**Example Request:**
```
GET /api/events?orgId=org-uuid-1&status=CONFIRMED
```

**Response:**
```json
[
  {
    "id": "event-uuid-1",
    "name": "Corporate Gala Dinner",
    "description": "Annual corporate event for 150 guests",
    "eventType": "CATERING",
    "startDate": "2024-07-15T18:00:00.000Z",
    "endDate": "2024-07-15T23:00:00.000Z",
    "location": "Grand Ballroom, City Hotel",
    "guestCount": 150,
    "status": "CONFIRMED",
    "notes": "Vegetarian and gluten-free options required",
    "createdAt": "2024-06-01T00:00:00.000Z",
    "org": {
      "id": "org-uuid-1",
      "name": "Gourmet Delights Restaurant"
    },
    "createdBy": {
      "id": "user-uuid-2",
      "name": "Event Manager"
    },
    "menu": {
      "id": "menu-uuid-2",
      "name": "Corporate Catering Menu",
      "menuItems": [
        {
          "id": "menu-item-uuid-5",
          "name": "Grilled Salmon",
          "price": 32.00,
          "category": "main",
          "recipe": {
            "id": "recipe-uuid-5",
            "name": "Herb-Crusted Salmon"
          }
        }
      ]
    }
  }
]
```

**Status Codes:**
- `200 OK` - Events retrieved successfully
- `500 Internal Server Error` - Database error

---

## Data Models

### Organization
```typescript
{
  id: string;
  name: string;
  description?: string;
  createdAt: Date;
  updatedAt: Date;
}
```

### User
```typescript
{
  id: string;
  email: string;
  name: string;
  role: 'ADMIN' | 'MANAGER' | 'CHEF' | 'USER';
  isActive: boolean;
  orgId: string;
  createdAt: Date;
  updatedAt: Date;
}
```

### Recipe
```typescript
{
  id: string;
  name: string;
  description?: string;
  instructions: string[];
  prepTime?: number;
  cookTime?: number;
  servings?: number;
  difficulty: 'EASY' | 'MEDIUM' | 'HARD' | 'EXPERT';
  tags: string[];
  isPublic: boolean;
  orgId: string;
  createdById: string;
  createdAt: Date;
  updatedAt: Date;
}
```

### Menu
```typescript
{
  id: string;
  name: string;
  description?: string;
  menuType: 'REGULAR' | 'SEASONAL' | 'SPECIAL' | 'CATERING';
  isActive: boolean;
  validFrom?: Date;
  validTo?: Date;
  orgId: string;
  createdAt: Date;
  updatedAt: Date;
}
```

### Event
```typescript
{
  id: string;
  name: string;
  description?: string;
  eventType: 'CATERING' | 'RESTAURANT' | 'POPUP' | 'PRIVATE';
  startDate: Date;
  endDate?: Date;
  location?: string;
  guestCount?: number;
  status: 'PLANNED' | 'CONFIRMED' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED';
  notes?: string;
  orgId: string;
  createdById: string;
  menuId?: string;
  createdAt: Date;
  updatedAt: Date;
}
```

## Error Handling

The API uses standard HTTP status codes and provides detailed error messages:

### Common Error Codes
- `400 Bad Request` - Invalid request parameters
- `404 Not Found` - Resource not found
- `500 Internal Server Error` - Server or database error

### Error Response Format
```json
{
  "error": "Failed to fetch organization",
  "message": "Organization with ID 'invalid-uuid' not found"
}
```

## Rate Limiting

Currently, no rate limiting is implemented. In production, consider implementing rate limiting based on IP address or API key.

## Pagination

The current API does not implement pagination. For large datasets, consider adding pagination with `limit` and `offset` parameters.

## Examples

### Fetch Organization Statistics
```bash
curl -X GET "https://core-data-models-staging.fly.dev/api/stats"
```

### Get Recipes for Specific Organization
```bash
curl -X GET "https://core-data-models-staging.fly.dev/api/recipes?orgId=org-uuid-1"
```

### Check Application Health
```bash
curl -X GET "https://core-data-models-staging.fly.dev/health"
```

## SDK and Client Libraries

Currently, no official SDK is provided. The API can be consumed using any HTTP client library in your preferred programming language.

## Changelog

### Version 1.0.0
- Initial API implementation
- Basic CRUD operations for all entities
- Health check endpoint
- Statistics endpoint

## Support

For API support or questions, please refer to the main project documentation or create an issue in the repository.

