import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcryptjs';
import * as crypto from 'crypto';

// Encryption utilities
const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY || 'your-32-character-encryption-key-here';

export function encrypt(text: string): string {
  const algorithm = 'aes-256-cbc';
  const key = crypto.scryptSync(ENCRYPTION_KEY, 'salt', 32);
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv(algorithm, key, iv);
  
  let encrypted = cipher.update(text, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  
  return iv.toString('hex') + ':' + encrypted;
}

export function decrypt(encryptedText: string): string {
  try {
    const algorithm = 'aes-256-cbc';
    const key = crypto.scryptSync(ENCRYPTION_KEY, 'salt', 32);
    const textParts = encryptedText.split(':');
    const iv = Buffer.from(textParts.shift()!, 'hex');
    const encryptedData = textParts.join(':');
    const decipher = crypto.createDecipheriv(algorithm, key, iv);
    
    let decrypted = decipher.update(encryptedData, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    
    return decrypted;
  } catch (error) {
    console.error('Decryption failed:', error);
    return '';
  }
}

// Prisma middleware for field-level encryption
export function addEncryptionMiddleware(prisma: PrismaClient) {
  // Middleware for encrypting supplier cost on create/update
  prisma.$use(async (params, next) => {
    if (params.model === 'SupplierIngredient') {
      if (params.action === 'create' || params.action === 'update') {
        if (params.args.data && params.args.data.cost) {
          // Encrypt the cost field
          params.args.data.cost = encrypt(params.args.data.cost.toString());
        }
      }
    }
    
    const result = await next(params);
    
    // Decrypt cost field in the result for read operations
    if (params.model === 'SupplierIngredient') {
      if (params.action === 'findMany' || params.action === 'findFirst' || params.action === 'findUnique' || params.action === 'create' || params.action === 'update') {
        if (Array.isArray(result)) {
          result.forEach((item: any) => {
            if (item.cost) {
              item.cost = decrypt(item.cost);
            }
          });
        } else if (result && result.cost) {
          result.cost = decrypt(result.cost);
        }
      }
    }
    
    return result;
  });
}

// Create Prisma client with encryption middleware
export function createPrismaClient(): PrismaClient {
  const prisma = new PrismaClient();
  addEncryptionMiddleware(prisma);
  return prisma;
}

