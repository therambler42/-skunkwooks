import { PrismaClient } from '@prisma/client';
import { createPrismaClient } from '../src/encryption';

let prisma: PrismaClient;

beforeAll(async () => {
  // Use test database
  process.env.DATABASE_URL = process.env.DATABASE_URL?.replace('core_data_models', 'core_data_models_test') || 
    'postgresql://postgres:password@localhost:5432/core_data_models_test?schema=public';
  
  prisma = createPrismaClient();
  
  // Create test database if it doesn't exist
  try {
    await prisma.$connect();
  } catch (error) {
    console.log('Creating test database...');
    // Create test database using the main connection
    const mainPrisma = new PrismaClient({
      datasources: {
        db: {
          url: 'postgresql://postgres:password@localhost:5432/postgres?schema=public'
        }
      }
    });
    
    try {
      await mainPrisma.$executeRawUnsafe('CREATE DATABASE core_data_models_test;');
    } catch (createError) {
      // Database might already exist
    } finally {
      await mainPrisma.$disconnect();
    }
    
    // Now connect to the test database
    await prisma.$connect();
  }
});

beforeEach(async () => {
  // Clean up database before each test
  await prisma.event.deleteMany();
  await prisma.menuItem.deleteMany();
  await prisma.menu.deleteMany();
  await prisma.subRecipe.deleteMany();
  await prisma.recipeIngredient.deleteMany();
  await prisma.recipe.deleteMany();
  await prisma.supplierIngredient.deleteMany();
  await prisma.supplier.deleteMany();
  await prisma.ingredient.deleteMany();
  await prisma.user.deleteMany();
  await prisma.org.deleteMany();
});

afterAll(async () => {
  await prisma.$disconnect();
});

// Export prisma for use in tests
export { prisma };

