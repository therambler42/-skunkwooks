#!/bin/bash

# Fly.io deployment script for Core Data Models

set -e

echo "🚀 Starting Fly.io deployment process..."

# Check if flyctl is installed
if ! command -v flyctl &> /dev/null; then
    echo "❌ flyctl is not installed. Please install it first:"
    echo "   curl -L https://fly.io/install.sh | sh"
    exit 1
fi

# Check if user is logged in
if ! flyctl auth whoami &> /dev/null; then
    echo "❌ Not logged in to Fly.io. Please run: flyctl auth login"
    exit 1
fi

# Function to create and configure app
create_app() {
    local app_name=$1
    local config_file=$2
    
    echo "📱 Creating Fly.io app: $app_name"
    
    # Create app if it doesn't exist
    if ! flyctl apps list | grep -q "$app_name"; then
        flyctl apps create "$app_name" --org personal
    else
        echo "   App $app_name already exists"
    fi
    
    # Set secrets
    echo "🔐 Setting environment secrets..."
    flyctl secrets set \
        DATABASE_URL="postgres://username:password@hostname:5432/database" \
        ENCRYPTION_KEY="$(openssl rand -base64 32)" \
        --app "$app_name"
    
    # Create PostgreSQL database
    echo "🗄️ Setting up PostgreSQL database..."
    if ! flyctl postgres list | grep -q "${app_name}-db"; then
        flyctl postgres create \
            --name "${app_name}-db" \
            --region iad \
            --vm-size shared-cpu-1x \
            --volume-size 10 \
            --initial-cluster-size 1
        
        # Attach database to app
        flyctl postgres attach "${app_name}-db" --app "$app_name"
    else
        echo "   Database ${app_name}-db already exists"
    fi
}

# Function to deploy app
deploy_app() {
    local app_name=$1
    local config_file=$2
    
    echo "🚢 Deploying $app_name..."
    
    # Deploy using specific config
    flyctl deploy \
        --config "$config_file" \
        --app "$app_name" \
        --remote-only
    
    echo "✅ Deployment completed for $app_name"
}

# Function to run migrations
run_migrations() {
    local app_name=$1
    
    echo "🔄 Running database migrations on $app_name..."
    flyctl ssh console \
        --app "$app_name" \
        --command "npm run prisma:migrate:deploy"
}

# Function to seed database
seed_database() {
    local app_name=$1
    
    echo "🌱 Seeding database on $app_name..."
    flyctl ssh console \
        --app "$app_name" \
        --command "npm run prisma:seed"
}

# Function to health check
health_check() {
    local app_name=$1
    local url="https://${app_name}.fly.dev/health"
    
    echo "🏥 Running health check for $app_name..."
    
    # Wait for app to be ready
    sleep 30
    
    # Check health endpoint
    if curl -f "$url" > /dev/null 2>&1; then
        echo "✅ Health check passed for $app_name"
        echo "🌐 App is available at: $url"
    else
        echo "❌ Health check failed for $app_name"
        return 1
    fi
}

# Main deployment logic
case "${1:-staging}" in
    "staging")
        echo "🎯 Deploying to STAGING environment"
        create_app "core-data-models-staging" "fly.staging.toml"
        deploy_app "core-data-models-staging" "fly.staging.toml"
        run_migrations "core-data-models-staging"
        seed_database "core-data-models-staging"
        health_check "core-data-models-staging"
        ;;
    
    "production")
        echo "🎯 Deploying to PRODUCTION environment"
        
        # Confirmation for production
        read -p "⚠️  Are you sure you want to deploy to PRODUCTION? (y/N): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            echo "❌ Production deployment cancelled"
            exit 1
        fi
        
        create_app "core-data-models-prod" "fly.production.toml"
        deploy_app "core-data-models-prod" "fly.production.toml"
        run_migrations "core-data-models-prod"
        # Note: Don't seed production database automatically
        health_check "core-data-models-prod"
        ;;
    
    "setup")
        echo "🛠️ Setting up Fly.io apps (without deployment)"
        create_app "core-data-models-staging" "fly.staging.toml"
        create_app "core-data-models-prod" "fly.production.toml"
        echo "✅ Setup completed"
        ;;
    
    *)
        echo "Usage: $0 [staging|production|setup]"
        echo "  staging    - Deploy to staging environment (default)"
        echo "  production - Deploy to production environment"
        echo "  setup      - Create apps and databases without deploying"
        exit 1
        ;;
esac

echo "🎉 Deployment process completed successfully!"

