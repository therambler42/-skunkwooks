# Core Data Models - Fly.io Deployment Guide

## Prerequisites

1. **Fly.io Account**: Sign up at [fly.io](https://fly.io)
2. **Fly CLI**: Install flyctl
   ```bash
   curl -L https://fly.io/install.sh | sh
   ```
3. **Authentication**: Login to Fly.io
   ```bash
   flyctl auth login
   ```

## Environment Setup

### Staging Environment
- **App Name**: `core-data-models-staging`
- **Database**: `core-data-models-staging-db`
- **URL**: `https://core-data-models-staging.fly.dev`

### Production Environment
- **App Name**: `core-data-models-prod`
- **Database**: `core-data-models-prod-db`
- **URL**: `https://core-data-models-prod.fly.dev`

## Deployment Commands

### Quick Deployment
```bash
# Deploy to staging
./scripts/deploy.sh staging

# Deploy to production
./scripts/deploy.sh production

# Setup apps without deploying
./scripts/deploy.sh setup
```

### Manual Deployment Steps

#### 1. Create Applications
```bash
# Staging
flyctl apps create core-data-models-staging

# Production
flyctl apps create core-data-models-prod
```

#### 2. Create PostgreSQL Databases
```bash
# Staging database
flyctl postgres create \
  --name core-data-models-staging-db \
  --region iad \
  --vm-size shared-cpu-1x \
  --volume-size 10

# Production database
flyctl postgres create \
  --name core-data-models-prod-db \
  --region iad \
  --vm-size shared-cpu-2x \
  --volume-size 20
```

#### 3. Attach Databases
```bash
# Staging
flyctl postgres attach core-data-models-staging-db --app core-data-models-staging

# Production
flyctl postgres attach core-data-models-prod-db --app core-data-models-prod
```

#### 4. Set Environment Variables
```bash
# Generate encryption key
ENCRYPTION_KEY=$(openssl rand -base64 32)

# Set secrets for staging
flyctl secrets set \
  ENCRYPTION_KEY="$ENCRYPTION_KEY" \
  NODE_ENV="production" \
  --app core-data-models-staging

# Set secrets for production
flyctl secrets set \
  ENCRYPTION_KEY="$ENCRYPTION_KEY" \
  NODE_ENV="production" \
  --app core-data-models-prod
```

#### 5. Deploy Applications
```bash
# Deploy staging
flyctl deploy --config fly.staging.toml --app core-data-models-staging

# Deploy production
flyctl deploy --config fly.production.toml --app core-data-models-prod
```

#### 6. Run Database Migrations
```bash
# Staging
flyctl ssh console --app core-data-models-staging --command "npm run prisma:migrate:deploy"

# Production
flyctl ssh console --app core-data-models-prod --command "npm run prisma:migrate:deploy"
```

#### 7. Seed Database (Staging Only)
```bash
# Only seed staging environment
flyctl ssh console --app core-data-models-staging --command "npm run prisma:seed"
```

## Monitoring and Management

### View Logs
```bash
# Staging logs
flyctl logs --app core-data-models-staging

# Production logs
flyctl logs --app core-data-models-prod
```

### SSH into Application
```bash
# Staging
flyctl ssh console --app core-data-models-staging

# Production
flyctl ssh console --app core-data-models-prod
```

### Database Console
```bash
# Staging database
flyctl postgres connect --app core-data-models-staging-db

# Production database
flyctl postgres connect --app core-data-models-prod-db
```

### Health Checks
```bash
# Check staging health
curl https://core-data-models-staging.fly.dev/health

# Check production health
curl https://core-data-models-prod.fly.dev/health
```

## API Endpoints

### Health Check
- `GET /health` - Application health status

### Statistics
- `GET /api/stats` - Database statistics

### Organizations
- `GET /api/organizations` - List all organizations
- `GET /api/organizations/:id` - Get organization details

### Recipes
- `GET /api/recipes` - List recipes
- Query parameters: `orgId`, `isPublic`

### Menus
- `GET /api/menus` - List menus
- Query parameters: `orgId`, `isActive`

### Events
- `GET /api/events` - List events
- Query parameters: `orgId`, `status`

## Scaling

### Vertical Scaling
```bash
# Scale staging VM
flyctl scale vm shared-cpu-2x --memory 1024 --app core-data-models-staging

# Scale production VM
flyctl scale vm dedicated-cpu-2x --memory 2048 --app core-data-models-prod
```

### Horizontal Scaling
```bash
# Scale to multiple instances (production only)
flyctl scale count 2 --app core-data-models-prod
```

## Backup and Recovery

### Database Backup
```bash
# Create backup
flyctl postgres backup create --app core-data-models-prod-db

# List backups
flyctl postgres backup list --app core-data-models-prod-db
```

### Application Rollback
```bash
# View releases
flyctl releases --app core-data-models-prod

# Rollback to previous release
flyctl releases rollback --app core-data-models-prod
```

## Troubleshooting

### Common Issues

1. **Database Connection Errors**
   - Check DATABASE_URL secret is set correctly
   - Verify database is attached to the app

2. **Migration Failures**
   - Ensure database is accessible
   - Check migration files are valid

3. **Health Check Failures**
   - Verify application is listening on correct port (8080)
   - Check application logs for errors

### Debug Commands
```bash
# Check app status
flyctl status --app core-data-models-staging

# View app configuration
flyctl config show --app core-data-models-staging

# Check secrets
flyctl secrets list --app core-data-models-staging
```

## Security Considerations

1. **Environment Variables**: Never commit secrets to version control
2. **Database Access**: Use connection pooling and read replicas for production
3. **HTTPS**: All traffic is automatically encrypted via Fly.io
4. **Field Encryption**: Sensitive data (supplier costs) is encrypted at the application level

## Cost Optimization

1. **Auto-stop**: Staging apps auto-stop when idle
2. **Resource Allocation**: Staging uses minimal resources, production uses optimized resources
3. **Database Sizing**: Start small and scale based on usage

## Support

- **Fly.io Documentation**: https://fly.io/docs/
- **Fly.io Community**: https://community.fly.io/
- **Application Logs**: Use `flyctl logs` for debugging

