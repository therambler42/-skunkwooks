import { PrismaClient, UserRole } from '@prisma/client';
import { prisma } from './setup';

describe('Organization CRUD Operations', () => {

  describe('Create Organization', () => {
    it('should create a new organization', async () => {
      const orgData = {
        name: 'Test Restaurant',
        description: 'A test restaurant for unit testing',
      };

      const org = await prisma.org.create({
        data: orgData,
      });

      expect(org).toBeDefined();
      expect(org.id).toBeDefined();
      expect(org.name).toBe(orgData.name);
      expect(org.description).toBe(orgData.description);
      expect(org.createdAt).toBeDefined();
      expect(org.updatedAt).toBeDefined();
    });

    it('should fail to create organization with duplicate name', async () => {
      const orgData = {
        name: 'Duplicate Restaurant',
        description: 'First restaurant',
      };

      await prisma.org.create({ data: orgData });

      await expect(
        prisma.org.create({
          data: {
            name: 'Duplicate Restaurant',
            description: 'Second restaurant',
          },
        })
      ).rejects.toThrow();
    });
  });

  describe('Read Organization', () => {
    it('should find organization by id', async () => {
      const org = await prisma.org.create({
        data: {
          name: 'Find Test Restaurant',
          description: 'Restaurant for find test',
        },
      });

      const foundOrg = await prisma.org.findUnique({
        where: { id: org.id },
      });

      expect(foundOrg).toBeDefined();
      expect(foundOrg?.id).toBe(org.id);
      expect(foundOrg?.name).toBe(org.name);
    });

    it('should find organization by name', async () => {
      const orgData = {
        name: 'Unique Name Restaurant',
        description: 'Restaurant with unique name',
      };

      await prisma.org.create({ data: orgData });

      const foundOrg = await prisma.org.findUnique({
        where: { name: orgData.name },
      });

      expect(foundOrg).toBeDefined();
      expect(foundOrg?.name).toBe(orgData.name);
    });

    it('should return null for non-existent organization', async () => {
      const foundOrg = await prisma.org.findUnique({
        where: { id: 'non-existent-id' },
      });

      expect(foundOrg).toBeNull();
    });
  });

  describe('Update Organization', () => {
    it('should update organization description', async () => {
      const org = await prisma.org.create({
        data: {
          name: 'Update Test Restaurant',
          description: 'Original description',
        },
      });

      const updatedOrg = await prisma.org.update({
        where: { id: org.id },
        data: { description: 'Updated description' },
      });

      expect(updatedOrg.description).toBe('Updated description');
      expect(updatedOrg.updatedAt.getTime()).toBeGreaterThan(org.updatedAt.getTime());
    });
  });

  describe('Delete Organization', () => {
    it('should delete organization', async () => {
      const org = await prisma.org.create({
        data: {
          name: 'Delete Test Restaurant',
          description: 'Restaurant to be deleted',
        },
      });

      await prisma.org.delete({
        where: { id: org.id },
      });

      const foundOrg = await prisma.org.findUnique({
        where: { id: org.id },
      });

      expect(foundOrg).toBeNull();
    });

    it('should cascade delete related entities', async () => {
      const org = await prisma.org.create({
        data: {
          name: 'Cascade Test Restaurant',
          description: 'Restaurant for cascade test',
        },
      });

      const user = await prisma.user.create({
        data: {
          email: 'test@cascade.com',
          name: 'Test User',
          role: UserRole.USER,
          orgId: org.id,
        },
      });

      await prisma.org.delete({
        where: { id: org.id },
      });

      const foundUser = await prisma.user.findUnique({
        where: { id: user.id },
      });

      expect(foundUser).toBeNull();
    });
  });
});

