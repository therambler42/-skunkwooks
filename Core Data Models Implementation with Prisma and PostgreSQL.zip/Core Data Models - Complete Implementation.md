# Core Data Models - Complete Implementation

## Overview

This project implements a comprehensive Core Data Models system using Prisma ORM, PostgreSQL, TypeScript, and modern DevOps practices. The system provides a robust foundation for restaurant and catering management applications with advanced features including field-level encryption, comprehensive testing, and automated deployment pipelines.

## Features

### 🗄️ Database Models
- **Organizations**: Multi-tenant organization management
- **Users**: Role-based user management (Admin, Manager, Chef, User)
- **Ingredients**: Comprehensive ingredient catalog with allergen tracking
- **Suppliers**: Supplier management with encrypted cost data
- **Recipes**: Hierarchical recipe system with sub-recipes
- **Menus**: Dynamic menu management with seasonal variations
- **Events**: Event planning and catering management

### 🔐 Security
- **Field-level encryption** for sensitive supplier cost data using pgcrypto
- **Environment-based configuration** for different deployment stages
- **Secure database connections** with connection pooling

### 🧪 Testing
- **Comprehensive test suite** with Jest
- **Integration tests** covering all CRUD operations
- **95%+ code coverage** requirement
- **Automated testing** in CI/CD pipeline

### 🚀 Deployment
- **Docker containerization** for consistent environments
- **Fly.io deployment** with staging and production environments
- **GitHub Actions CI/CD** with automated testing and deployment
- **Database migrations** with zero-downtime deployments

## Quick Start

### Prerequisites
- Node.js 20+
- PostgreSQL 15+
- Docker (optional)

### Installation
```bash
# Clone the repository
git clone <repository-url>
cd core-data-models

# Install dependencies
npm install

# Set up environment variables
cp .env.example .env
# Edit .env with your database credentials

# Run database migrations
npm run prisma:migrate:deploy

# Seed the database
npm run prisma:seed

# Start the application
npm start
```

### Testing
```bash
# Run all tests
npm test

# Run tests with coverage
npm run test:coverage

# Run specific test file
npm test tests/integration.test.ts
```

## Project Structure

```
core-data-models/
├── .github/workflows/     # GitHub Actions CI/CD
├── docs/                  # Documentation
├── prisma/               # Database schema and migrations
│   ├── migrations/       # Database migration files
│   ├── schema.prisma     # Prisma schema definition
│   └── seed.ts          # Database seeding script
├── scripts/              # Deployment and utility scripts
├── src/                  # Application source code
│   ├── encryption.ts     # Encryption utilities
│   └── index.ts         # Main application server
├── tests/                # Test files
├── docker-compose.yml    # Docker services
├── Dockerfile           # Container definition
└── fly.*.toml          # Fly.io deployment configs
```

## API Endpoints

### Health Check
- `GET /health` - Application health status

### Statistics
- `GET /api/stats` - Database record counts

### Organizations
- `GET /api/organizations` - List all organizations
- `GET /api/organizations/:id` - Get organization details

### Recipes
- `GET /api/recipes` - List recipes
  - Query params: `orgId`, `isPublic`

### Menus
- `GET /api/menus` - List menus
  - Query params: `orgId`, `isActive`

### Events
- `GET /api/events` - List events
  - Query params: `orgId`, `status`

## Database Schema

The system uses a comprehensive relational database schema with the following key relationships:

- Organizations contain Users, Suppliers, Recipes, Menus, and Events
- Recipes can contain other Recipes (sub-recipes) and Ingredients
- Menus contain MenuItems that reference Recipes
- Events reference Menus and are created by Users
- Suppliers provide Ingredients with encrypted cost information

## Deployment

### Local Development
```bash
# Start PostgreSQL (if using Docker)
docker-compose up -d postgres

# Run migrations
npm run prisma:migrate:dev

# Start development server
npm run dev
```

### Staging Deployment
```bash
# Deploy to Fly.io staging
./scripts/deploy.sh staging
```

### Production Deployment
```bash
# Deploy to Fly.io production
./scripts/deploy.sh production
```

## Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `DATABASE_URL` | PostgreSQL connection string | Yes |
| `ENCRYPTION_KEY` | Key for field-level encryption | Yes |
| `NODE_ENV` | Environment (development/production) | No |
| `PORT` | Server port (default: 8080) | No |

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Ensure all tests pass
6. Submit a pull request

## License

This project is licensed under the MIT License.

## Support

For questions or issues, please refer to the documentation in the `docs/` directory or create an issue in the repository.

