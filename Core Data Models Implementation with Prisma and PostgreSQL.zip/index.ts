import express from 'express';
import cors from 'cors';
import { createPrismaClient } from './encryption';
import * as dotenv from 'dotenv';

dotenv.config();

const app = express();
const port = parseInt(process.env.PORT || '8080', 10);
const prisma = createPrismaClient();

// Middleware
app.use(cors());
app.use(express.json());

// Health check endpoint
app.get('/health', async (req, res) => {
  try {
    // Test database connection
    await prisma.$queryRaw`SELECT 1`;
    res.status(200).json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      database: 'connected',
      environment: process.env.NODE_ENV || 'development',
    });
  } catch (error) {
    res.status(503).json({
      status: 'unhealthy',
      timestamp: new Date().toISOString(),
      database: 'disconnected',
      error: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// API endpoints
app.get('/api/stats', async (req, res) => {
  try {
    const [
      orgCount,
      userCount,
      ingredientCount,
      supplierCount,
      recipeCount,
      menuCount,
      eventCount,
    ] = await Promise.all([
      prisma.org.count(),
      prisma.user.count(),
      prisma.ingredient.count(),
      prisma.supplier.count(),
      prisma.recipe.count(),
      prisma.menu.count(),
      prisma.event.count(),
    ]);

    res.json({
      organizations: orgCount,
      users: userCount,
      ingredients: ingredientCount,
      suppliers: supplierCount,
      recipes: recipeCount,
      menus: menuCount,
      events: eventCount,
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch statistics',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Organizations endpoints
app.get('/api/organizations', async (req, res) => {
  try {
    const organizations = await prisma.org.findMany({
      include: {
        _count: {
          select: {
            users: true,
            suppliers: true,
            recipes: true,
            menus: true,
            events: true,
          },
        },
      },
    });
    res.json(organizations);
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch organizations',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

app.get('/api/organizations/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const organization = await prisma.org.findUnique({
      where: { id },
      include: {
        users: true,
        suppliers: true,
        recipes: {
          include: {
            createdBy: true,
            _count: {
              select: {
                ingredients: true,
              },
            },
          },
        },
        menus: {
          include: {
            _count: {
              select: {
                menuItems: true,
              },
            },
          },
        },
        events: {
          include: {
            createdBy: true,
            menu: true,
          },
        },
      },
    });

    if (!organization) {
      return res.status(404).json({ error: 'Organization not found' });
    }

    res.json(organization);
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch organization',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Recipes endpoints
app.get('/api/recipes', async (req, res) => {
  try {
    const { orgId, isPublic } = req.query;
    const where: any = {};

    if (orgId) {
      where.orgId = orgId as string;
    }

    if (isPublic !== undefined) {
      where.isPublic = isPublic === 'true';
    }

    const recipes = await prisma.recipe.findMany({
      where,
      include: {
        org: true,
        createdBy: true,
        ingredients: {
          include: {
            ingredient: true,
          },
        },
        _count: {
          select: {
            ingredients: true,
            subRecipes: true,
            parentRecipes: true,
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
    });

    res.json(recipes);
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch recipes',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Menus endpoints
app.get('/api/menus', async (req, res) => {
  try {
    const { orgId, isActive } = req.query;
    const where: any = {};

    if (orgId) {
      where.orgId = orgId as string;
    }

    if (isActive !== undefined) {
      where.isActive = isActive === 'true';
    }

    const menus = await prisma.menu.findMany({
      where,
      include: {
        org: true,
        menuItems: {
          include: {
            recipe: true,
          },
          orderBy: {
            sortOrder: 'asc',
          },
        },
        _count: {
          select: {
            menuItems: true,
            events: true,
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
    });

    res.json(menus);
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch menus',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Events endpoints
app.get('/api/events', async (req, res) => {
  try {
    const { orgId, status } = req.query;
    const where: any = {};

    if (orgId) {
      where.orgId = orgId as string;
    }

    if (status) {
      where.status = status as string;
    }

    const events = await prisma.event.findMany({
      where,
      include: {
        org: true,
        createdBy: true,
        menu: {
          include: {
            menuItems: {
              include: {
                recipe: true,
              },
            },
          },
        },
      },
      orderBy: {
        startDate: 'desc',
      },
    });

    res.json(events);
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch events',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Error handling middleware
app.use((err: Error, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error('Unhandled error:', err);
  res.status(500).json({
    error: 'Internal server error',
    message: process.env.NODE_ENV === 'development' ? err.message : 'Something went wrong',
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    error: 'Not found',
    message: `Route ${req.method} ${req.path} not found`,
  });
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down gracefully');
  await prisma.$disconnect();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('SIGINT received, shutting down gracefully');
  await prisma.$disconnect();
  process.exit(0);
});

// Start server
app.listen(port, '0.0.0.0', () => {
  console.log(`🚀 Server running on port ${port}`);
  console.log(`📊 Health check: http://localhost:${port}/health`);
  console.log(`🌐 Environment: ${process.env.NODE_ENV || 'development'}`);
});

export default app;

