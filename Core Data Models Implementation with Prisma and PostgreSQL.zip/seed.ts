import { PrismaClient, UserRole, Difficulty, MenuType, EventType, EventStatus } from '@prisma/client';
import { createPrismaClient } from '../src/encryption';
import * as dotenv from 'dotenv';

dotenv.config();

const prisma = createPrismaClient();

// Sample data generators
const generateOrgs = () => [
  {
    name: 'Gourmet Delights Inc.',
    description: 'Premium catering and restaurant services specializing in fine dining experiences',
  },
  {
    name: 'Farm Fresh Foods Co.',
    description: 'Sustainable farm-to-table restaurant chain focused on organic and locally sourced ingredients',
  },
];

const generateIngredients = () => [
  // Vegetables
  { name: 'Organic Tomatoes', unit: 'kg', category: 'vegetables', allergens: [], nutritionInfo: { calories: 18, protein: 0.9, carbs: 3.9, fat: 0.2 } },
  { name: 'Fresh Spinach', unit: 'kg', category: 'vegetables', allergens: [], nutritionInfo: { calories: 23, protein: 2.9, carbs: 3.6, fat: 0.4 } },
  { name: 'Red Bell Peppers', unit: 'kg', category: 'vegetables', allergens: [], nutritionInfo: { calories: 31, protein: 1.0, carbs: 7.3, fat: 0.3 } },
  { name: 'Yellow Onions', unit: 'kg', category: 'vegetables', allergens: [], nutritionInfo: { calories: 40, protein: 1.1, carbs: 9.3, fat: 0.1 } },
  { name: 'Fresh Garlic', unit: 'kg', category: 'vegetables', allergens: [], nutritionInfo: { calories: 149, protein: 6.4, carbs: 33.1, fat: 0.5 } },
  { name: 'Carrots', unit: 'kg', category: 'vegetables', allergens: [], nutritionInfo: { calories: 41, protein: 0.9, carbs: 9.6, fat: 0.2 } },
  { name: 'Broccoli', unit: 'kg', category: 'vegetables', allergens: [], nutritionInfo: { calories: 34, protein: 2.8, carbs: 6.6, fat: 0.4 } },
  { name: 'Mushrooms', unit: 'kg', category: 'vegetables', allergens: [], nutritionInfo: { calories: 22, protein: 3.1, carbs: 3.3, fat: 0.3 } },
  { name: 'Zucchini', unit: 'kg', category: 'vegetables', allergens: [], nutritionInfo: { calories: 17, protein: 1.2, carbs: 3.1, fat: 0.3 } },
  { name: 'Cucumber', unit: 'kg', category: 'vegetables', allergens: [], nutritionInfo: { calories: 16, protein: 0.7, carbs: 4.0, fat: 0.1 } },

  // Proteins
  { name: 'Chicken Breast', unit: 'kg', category: 'meat', allergens: [], nutritionInfo: { calories: 165, protein: 31.0, carbs: 0, fat: 3.6 } },
  { name: 'Salmon Fillet', unit: 'kg', category: 'seafood', allergens: ['fish'], nutritionInfo: { calories: 208, protein: 20.4, carbs: 0, fat: 13.4 } },
  { name: 'Ground Beef', unit: 'kg', category: 'meat', allergens: [], nutritionInfo: { calories: 250, protein: 26.1, carbs: 0, fat: 15.0 } },
  { name: 'Pork Tenderloin', unit: 'kg', category: 'meat', allergens: [], nutritionInfo: { calories: 143, protein: 26.0, carbs: 0, fat: 3.5 } },
  { name: 'Shrimp', unit: 'kg', category: 'seafood', allergens: ['shellfish'], nutritionInfo: { calories: 99, protein: 24.0, carbs: 0.2, fat: 0.3 } },

  // Dairy
  { name: 'Whole Milk', unit: 'liters', category: 'dairy', allergens: ['milk'], nutritionInfo: { calories: 61, protein: 3.2, carbs: 4.8, fat: 3.3 } },
  { name: 'Heavy Cream', unit: 'liters', category: 'dairy', allergens: ['milk'], nutritionInfo: { calories: 340, protein: 2.1, carbs: 2.8, fat: 36.1 } },
  { name: 'Cheddar Cheese', unit: 'kg', category: 'dairy', allergens: ['milk'], nutritionInfo: { calories: 403, protein: 25.0, carbs: 1.3, fat: 33.1 } },
  { name: 'Greek Yogurt', unit: 'kg', category: 'dairy', allergens: ['milk'], nutritionInfo: { calories: 59, protein: 10.0, carbs: 3.6, fat: 0.4 } },
  { name: 'Butter', unit: 'kg', category: 'dairy', allergens: ['milk'], nutritionInfo: { calories: 717, protein: 0.9, carbs: 0.1, fat: 81.1 } },

  // Grains & Starches
  { name: 'Basmati Rice', unit: 'kg', category: 'grains', allergens: [], nutritionInfo: { calories: 365, protein: 7.1, carbs: 78.0, fat: 0.9 } },
  { name: 'Quinoa', unit: 'kg', category: 'grains', allergens: [], nutritionInfo: { calories: 368, protein: 14.1, carbs: 64.2, fat: 6.1 } },
  { name: 'Pasta', unit: 'kg', category: 'grains', allergens: ['gluten'], nutritionInfo: { calories: 371, protein: 13.0, carbs: 74.7, fat: 1.5 } },
  { name: 'Bread Flour', unit: 'kg', category: 'grains', allergens: ['gluten'], nutritionInfo: { calories: 364, protein: 12.0, carbs: 76.3, fat: 1.2 } },
  { name: 'Potatoes', unit: 'kg', category: 'vegetables', allergens: [], nutritionInfo: { calories: 77, protein: 2.1, carbs: 17.5, fat: 0.1 } },

  // Herbs & Spices
  { name: 'Fresh Basil', unit: 'kg', category: 'herbs', allergens: [], nutritionInfo: { calories: 22, protein: 3.2, carbs: 2.6, fat: 0.6 } },
  { name: 'Fresh Parsley', unit: 'kg', category: 'herbs', allergens: [], nutritionInfo: { calories: 36, protein: 3.0, carbs: 6.3, fat: 0.8 } },
  { name: 'Oregano', unit: 'kg', category: 'herbs', allergens: [], nutritionInfo: { calories: 265, protein: 9.0, carbs: 68.9, fat: 4.3 } },
  { name: 'Black Pepper', unit: 'kg', category: 'spices', allergens: [], nutritionInfo: { calories: 251, protein: 10.4, carbs: 63.9, fat: 3.3 } },
  { name: 'Sea Salt', unit: 'kg', category: 'spices', allergens: [], nutritionInfo: { calories: 0, protein: 0, carbs: 0, fat: 0 } },

  // Oils & Condiments
  { name: 'Extra Virgin Olive Oil', unit: 'liters', category: 'oils', allergens: [], nutritionInfo: { calories: 884, protein: 0, carbs: 0, fat: 100.0 } },
  { name: 'Balsamic Vinegar', unit: 'liters', category: 'condiments', allergens: [], nutritionInfo: { calories: 88, protein: 0.5, carbs: 17.0, fat: 0 } },

  // Fruits
  { name: 'Lemons', unit: 'kg', category: 'fruits', allergens: [], nutritionInfo: { calories: 29, protein: 1.1, carbs: 9.3, fat: 0.3 } },
  { name: 'Fresh Strawberries', unit: 'kg', category: 'fruits', allergens: [], nutritionInfo: { calories: 32, protein: 0.7, carbs: 7.7, fat: 0.3 } },

  // Nuts & Seeds
  { name: 'Almonds', unit: 'kg', category: 'nuts', allergens: ['nuts'], nutritionInfo: { calories: 579, protein: 21.2, carbs: 21.6, fat: 49.9 } },
  { name: 'Pine Nuts', unit: 'kg', category: 'nuts', allergens: ['nuts'], nutritionInfo: { calories: 673, protein: 13.7, carbs: 13.1, fat: 68.4 } },

  // Beverages
  { name: 'White Wine', unit: 'liters', category: 'beverages', allergens: ['sulfites'], nutritionInfo: { calories: 82, protein: 0.1, carbs: 2.6, fat: 0 } },
  { name: 'Vegetable Stock', unit: 'liters', category: 'stocks', allergens: [], nutritionInfo: { calories: 12, protein: 0.4, carbs: 2.0, fat: 0.2 } },

  // Baking
  { name: 'Eggs', unit: 'dozen', category: 'dairy', allergens: ['eggs'], nutritionInfo: { calories: 155, protein: 13.0, carbs: 1.1, fat: 11.0 } },
  { name: 'Vanilla Extract', unit: 'liters', category: 'extracts', allergens: [], nutritionInfo: { calories: 288, protein: 0.1, carbs: 12.7, fat: 0.1 } },

  // Specialty Items
  { name: 'Truffle Oil', unit: 'liters', category: 'oils', allergens: [], nutritionInfo: { calories: 884, protein: 0, carbs: 0, fat: 100.0 } },
  { name: 'Saffron', unit: 'grams', category: 'spices', allergens: [], nutritionInfo: { calories: 310, protein: 11.4, carbs: 65.4, fat: 5.9 } },

  // Frozen
  { name: 'Frozen Peas', unit: 'kg', category: 'vegetables', allergens: [], nutritionInfo: { calories: 81, protein: 5.4, carbs: 14.5, fat: 0.4 } },
  { name: 'Frozen Berries Mix', unit: 'kg', category: 'fruits', allergens: [], nutritionInfo: { calories: 57, protein: 0.7, carbs: 14.7, fat: 0.3 } },

  // Canned/Preserved
  { name: 'Canned Tomatoes', unit: 'kg', category: 'vegetables', allergens: [], nutritionInfo: { calories: 18, protein: 0.9, carbs: 4.2, fat: 0.2 } },
  { name: 'Capers', unit: 'kg', category: 'condiments', allergens: [], nutritionInfo: { calories: 23, protein: 2.4, carbs: 4.9, fat: 0.9 } },

  // Dessert Ingredients
  { name: 'Dark Chocolate', unit: 'kg', category: 'dessert', allergens: ['milk'], nutritionInfo: { calories: 546, protein: 7.9, carbs: 45.9, fat: 31.3 } },
  { name: 'Mascarpone', unit: 'kg', category: 'dairy', allergens: ['milk'], nutritionInfo: { calories: 429, protein: 4.8, carbs: 4.6, fat: 44.4 } },

  // International
  { name: 'Coconut Milk', unit: 'liters', category: 'dairy-alternative', allergens: [], nutritionInfo: { calories: 230, protein: 2.3, carbs: 5.5, fat: 23.8 } },
  { name: 'Soy Sauce', unit: 'liters', category: 'condiments', allergens: ['soy', 'gluten'], nutritionInfo: { calories: 8, protein: 1.3, carbs: 0.8, fat: 0.0 } },
];

const generateSuppliers = (orgIds: string[]) => [
  {
    name: 'Fresh Farm Produce',
    email: 'orders@freshfarm.com',
    phone: '+1-555-0101',
    address: '123 Farm Road, Green Valley, CA 95945',
    contactPerson: 'John Smith',
    orgId: orgIds[0],
  },
  {
    name: 'Ocean Fresh Seafood',
    email: 'sales@oceanfresh.com',
    phone: '+1-555-0102',
    address: '456 Harbor Drive, Coastal City, CA 90210',
    contactPerson: 'Maria Rodriguez',
    orgId: orgIds[0],
  },
  {
    name: 'Premium Meats Co.',
    email: 'wholesale@premiummeats.com',
    phone: '+1-555-0103',
    address: '789 Butcher Lane, Meat District, TX 75001',
    contactPerson: 'Robert Johnson',
    orgId: orgIds[0],
  },
  {
    name: 'Dairy Valley Suppliers',
    email: 'orders@dairyvalley.com',
    phone: '+1-555-0104',
    address: '321 Milk Road, Dairy Town, WI 53001',
    contactPerson: 'Sarah Wilson',
    orgId: orgIds[0],
  },
  {
    name: 'Spice World International',
    email: 'info@spiceworld.com',
    phone: '+1-555-0105',
    address: '654 Spice Street, Flavor City, NY 10001',
    contactPerson: 'Ahmed Hassan',
    orgId: orgIds[0],
  },
  {
    name: 'Organic Harvest Co.',
    email: 'sales@organicharvest.com',
    phone: '+1-555-0106',
    address: '987 Organic Ave, Natural Valley, OR 97001',
    contactPerson: 'Lisa Chen',
    orgId: orgIds[1],
  },
  {
    name: 'Artisan Bread Bakery',
    email: 'wholesale@artisanbread.com',
    phone: '+1-555-0107',
    address: '147 Baker Street, Bread Town, MA 02101',
    contactPerson: 'Pierre Dubois',
    orgId: orgIds[1],
  },
  {
    name: 'Mountain Spring Waters',
    email: 'orders@mountainspring.com',
    phone: '+1-555-0108',
    address: '258 Spring Road, Mountain View, CO 80424',
    contactPerson: 'David Thompson',
    orgId: orgIds[1],
  },
  {
    name: 'Gourmet Imports Ltd.',
    email: 'sales@gourmetimports.com',
    phone: '+1-555-0109',
    address: '369 Import Plaza, Trade City, FL 33101',
    contactPerson: 'Isabella Rossi',
    orgId: orgIds[1],
  },
  {
    name: 'Local Farmers Market',
    email: 'coordinator@localfarmers.com',
    phone: '+1-555-0110',
    address: '741 Market Square, Farm Town, IA 50001',
    contactPerson: 'Michael Brown',
    orgId: orgIds[1],
  },
];

async function main() {
  console.log('🌱 Starting database seeding...');

  try {
    // Clean existing data
    console.log('🧹 Cleaning existing data...');
    await prisma.event.deleteMany();
    await prisma.menuItem.deleteMany();
    await prisma.menu.deleteMany();
    await prisma.subRecipe.deleteMany();
    await prisma.recipeIngredient.deleteMany();
    await prisma.recipe.deleteMany();
    await prisma.supplierIngredient.deleteMany();
    await prisma.supplier.deleteMany();
    await prisma.ingredient.deleteMany();
    await prisma.user.deleteMany();
    await prisma.org.deleteMany();

    // Create organizations
    console.log('🏢 Creating organizations...');
    const orgs = await Promise.all(
      generateOrgs().map(org => prisma.org.create({ data: org }))
    );
    console.log(`✅ Created ${orgs.length} organizations`);

    // Create users
    console.log('👥 Creating users...');
    const users = await Promise.all([
      prisma.user.create({
        data: {
          email: 'admin@gourmetdelights.com',
          name: 'Alice Admin',
          role: UserRole.ADMIN,
          orgId: orgs[0].id,
        },
      }),
      prisma.user.create({
        data: {
          email: 'chef@gourmetdelights.com',
          name: 'Chef Gordon',
          role: UserRole.CHEF,
          orgId: orgs[0].id,
        },
      }),
      prisma.user.create({
        data: {
          email: 'manager@farmfresh.com',
          name: 'Manager Mike',
          role: UserRole.MANAGER,
          orgId: orgs[1].id,
        },
      }),
      prisma.user.create({
        data: {
          email: 'chef@farmfresh.com',
          name: 'Chef Julia',
          role: UserRole.CHEF,
          orgId: orgs[1].id,
        },
      }),
    ]);
    console.log(`✅ Created ${users.length} users`);

    // Create ingredients
    console.log('🥕 Creating ingredients...');
    const ingredients = await Promise.all(
      generateIngredients().map(ingredient => 
        prisma.ingredient.create({ data: ingredient })
      )
    );
    console.log(`✅ Created ${ingredients.length} ingredients`);

    // Create suppliers
    console.log('🚚 Creating suppliers...');
    const suppliers = await Promise.all(
      generateSuppliers([orgs[0].id, orgs[1].id]).map(supplier =>
        prisma.supplier.create({ data: supplier })
      )
    );
    console.log(`✅ Created ${suppliers.length} suppliers`);

    // Create supplier-ingredient relationships with encrypted costs
    console.log('💰 Creating supplier-ingredient relationships...');
    const supplierIngredients = [];
    for (let i = 0; i < suppliers.length; i++) {
      const supplier = suppliers[i];
      // Each supplier supplies 8-12 random ingredients
      const numIngredients = Math.floor(Math.random() * 5) + 8;
      const selectedIngredients = ingredients
        .sort(() => 0.5 - Math.random())
        .slice(0, numIngredients);

      for (const ingredient of selectedIngredients) {
        const cost = (Math.random() * 50 + 5).toFixed(2); // Random cost between $5-$55
        const supplierIngredient = await prisma.supplierIngredient.create({
          data: {
            cost: cost, // This will be encrypted by middleware
            currency: 'USD',
            minimumOrder: Math.floor(Math.random() * 10) + 1,
            leadTimeDays: Math.floor(Math.random() * 7) + 1,
            supplierId: supplier.id,
            ingredientId: ingredient.id,
          },
        });
        supplierIngredients.push(supplierIngredient);
      }
    }
    console.log(`✅ Created ${supplierIngredients.length} supplier-ingredient relationships`);

    // Create recipes
    console.log('📖 Creating recipes...');
    const recipeData = [
      {
        name: 'Classic Margherita Pizza',
        description: 'Traditional Italian pizza with fresh tomatoes, mozzarella, and basil',
        instructions: [
          'Prepare pizza dough and let it rise for 1 hour',
          'Roll out dough to desired thickness',
          'Spread tomato sauce evenly',
          'Add fresh mozzarella cheese',
          'Bake at 450°F for 12-15 minutes',
          'Garnish with fresh basil leaves'
        ],
        prepTime: 30,
        cookTime: 15,
        servings: 4,
        difficulty: Difficulty.EASY,
        tags: ['vegetarian', 'italian', 'pizza'],
        orgId: orgs[0].id,
        createdById: users[1].id,
      },
      {
        name: 'Grilled Salmon with Lemon Herb Butter',
        description: 'Fresh salmon fillet grilled to perfection with aromatic herb butter',
        instructions: [
          'Season salmon with salt and pepper',
          'Preheat grill to medium-high heat',
          'Grill salmon for 4-5 minutes per side',
          'Prepare herb butter with parsley, garlic, and lemon',
          'Serve immediately with herb butter on top'
        ],
        prepTime: 15,
        cookTime: 10,
        servings: 2,
        difficulty: Difficulty.MEDIUM,
        tags: ['seafood', 'healthy', 'grilled'],
        orgId: orgs[0].id,
        createdById: users[1].id,
      },
      {
        name: 'Creamy Mushroom Risotto',
        description: 'Rich and creamy Arborio rice with mixed mushrooms and Parmesan',
        instructions: [
          'Sauté mushrooms until golden brown',
          'Heat vegetable stock in a separate pot',
          'Toast Arborio rice with onions',
          'Add warm stock gradually, stirring constantly',
          'Fold in mushrooms and Parmesan cheese',
          'Finish with butter and fresh herbs'
        ],
        prepTime: 20,
        cookTime: 30,
        servings: 4,
        difficulty: Difficulty.HARD,
        tags: ['vegetarian', 'italian', 'rice'],
        orgId: orgs[0].id,
        createdById: users[1].id,
      },
      {
        name: 'Beef Tenderloin with Red Wine Reduction',
        description: 'Premium beef tenderloin with rich red wine sauce',
        instructions: [
          'Season beef tenderloin with salt and pepper',
          'Sear in hot pan until browned on all sides',
          'Roast in oven at 400°F to desired doneness',
          'Prepare red wine reduction with shallots',
          'Rest meat for 10 minutes before slicing',
          'Serve with red wine reduction'
        ],
        prepTime: 25,
        cookTime: 20,
        servings: 6,
        difficulty: Difficulty.EXPERT,
        tags: ['beef', 'fine-dining', 'wine'],
        orgId: orgs[0].id,
        createdById: users[1].id,
      },
      {
        name: 'Mediterranean Quinoa Salad',
        description: 'Healthy quinoa salad with fresh vegetables and feta cheese',
        instructions: [
          'Cook quinoa according to package instructions',
          'Dice tomatoes, cucumber, and red onion',
          'Crumble feta cheese',
          'Whisk olive oil with lemon juice and herbs',
          'Combine all ingredients and toss with dressing',
          'Chill for 30 minutes before serving'
        ],
        prepTime: 20,
        cookTime: 15,
        servings: 6,
        difficulty: Difficulty.EASY,
        tags: ['vegetarian', 'healthy', 'mediterranean', 'salad'],
        orgId: orgs[1].id,
        createdById: users[3].id,
      },
      {
        name: 'Chocolate Lava Cake',
        description: 'Decadent chocolate cake with molten center',
        instructions: [
          'Melt dark chocolate with butter',
          'Whisk eggs with sugar until pale',
          'Fold in chocolate mixture and flour',
          'Pour into buttered ramekins',
          'Bake at 425°F for 12-14 minutes',
          'Serve immediately with vanilla ice cream'
        ],
        prepTime: 20,
        cookTime: 14,
        servings: 4,
        difficulty: Difficulty.MEDIUM,
        tags: ['dessert', 'chocolate', 'french'],
        orgId: orgs[0].id,
        createdById: users[1].id,
      },
      {
        name: 'Thai Green Curry',
        description: 'Aromatic Thai curry with coconut milk and fresh herbs',
        instructions: [
          'Heat coconut milk in a large pot',
          'Add green curry paste and stir',
          'Add chicken and cook until tender',
          'Add vegetables and simmer',
          'Season with fish sauce and palm sugar',
          'Garnish with Thai basil and serve with rice'
        ],
        prepTime: 25,
        cookTime: 20,
        servings: 4,
        difficulty: Difficulty.MEDIUM,
        tags: ['thai', 'curry', 'spicy', 'coconut'],
        orgId: orgs[1].id,
        createdById: users[3].id,
      },
      {
        name: 'Caesar Salad',
        description: 'Classic Caesar salad with homemade dressing and croutons',
        instructions: [
          'Prepare Caesar dressing with anchovies and garlic',
          'Make fresh croutons from bread',
          'Wash and chop romaine lettuce',
          'Toss lettuce with dressing',
          'Top with croutons and Parmesan cheese',
          'Serve immediately'
        ],
        prepTime: 15,
        cookTime: 10,
        servings: 4,
        difficulty: Difficulty.EASY,
        tags: ['salad', 'classic', 'roman'],
        orgId: orgs[0].id,
        createdById: users[1].id,
      },
      {
        name: 'Herb-Crusted Rack of Lamb',
        description: 'Elegant rack of lamb with fresh herb crust',
        instructions: [
          'Season lamb rack with salt and pepper',
          'Sear in hot pan until browned',
          'Prepare herb crust with breadcrumbs and herbs',
          'Coat lamb with herb mixture',
          'Roast in oven at 400°F for 15-20 minutes',
          'Rest for 5 minutes before carving'
        ],
        prepTime: 20,
        cookTime: 25,
        servings: 4,
        difficulty: Difficulty.EXPERT,
        tags: ['lamb', 'herbs', 'fine-dining'],
        orgId: orgs[0].id,
        createdById: users[1].id,
      },
      {
        name: 'Vegetable Stir Fry',
        description: 'Quick and healthy stir fry with seasonal vegetables',
        instructions: [
          'Heat oil in wok or large pan',
          'Add garlic and ginger, stir briefly',
          'Add harder vegetables first',
          'Stir fry for 3-4 minutes',
          'Add softer vegetables and sauce',
          'Serve immediately over rice'
        ],
        prepTime: 15,
        cookTime: 8,
        servings: 4,
        difficulty: Difficulty.EASY,
        tags: ['vegetarian', 'healthy', 'asian', 'quick'],
        orgId: orgs[1].id,
        createdById: users[3].id,
      },
      {
        name: 'Lobster Thermidor',
        description: 'Luxurious lobster dish with creamy cheese sauce',
        instructions: [
          'Cook lobster and remove meat from shells',
          'Prepare cream sauce with wine and herbs',
          'Sauté lobster meat briefly',
          'Combine lobster with sauce',
          'Fill lobster shells with mixture',
          'Broil until golden and bubbly'
        ],
        prepTime: 30,
        cookTime: 20,
        servings: 2,
        difficulty: Difficulty.EXPERT,
        tags: ['seafood', 'luxury', 'french', 'lobster'],
        orgId: orgs[0].id,
        createdById: users[1].id,
      },
      {
        name: 'Homemade Pasta with Pesto',
        description: 'Fresh pasta with basil pesto and pine nuts',
        instructions: [
          'Make fresh pasta dough and roll thin',
          'Cut into desired shape',
          'Prepare pesto with basil, garlic, and pine nuts',
          'Cook pasta in salted boiling water',
          'Toss hot pasta with pesto',
          'Garnish with Parmesan and pine nuts'
        ],
        prepTime: 45,
        cookTime: 5,
        servings: 4,
        difficulty: Difficulty.MEDIUM,
        tags: ['pasta', 'italian', 'basil', 'homemade'],
        orgId: orgs[1].id,
        createdById: users[3].id,
      },
      {
        name: 'Beef Bourguignon',
        description: 'Classic French beef stew braised in red wine',
        instructions: [
          'Brown beef cubes in batches',
          'Sauté onions, carrots, and celery',
          'Add wine and beef stock',
          'Add herbs and simmer for 2 hours',
          'Add mushrooms in last 30 minutes',
          'Thicken sauce and serve with potatoes'
        ],
        prepTime: 30,
        cookTime: 150,
        servings: 6,
        difficulty: Difficulty.HARD,
        tags: ['beef', 'french', 'wine', 'stew'],
        orgId: orgs[0].id,
        createdById: users[1].id,
      },
      {
        name: 'Caprese Salad',
        description: 'Simple Italian salad with tomatoes, mozzarella, and basil',
        instructions: [
          'Slice fresh tomatoes and mozzarella',
          'Arrange alternating on plate',
          'Add fresh basil leaves',
          'Drizzle with olive oil',
          'Season with salt and pepper',
          'Finish with balsamic reduction'
        ],
        prepTime: 10,
        cookTime: 0,
        servings: 4,
        difficulty: Difficulty.EASY,
        tags: ['vegetarian', 'italian', 'fresh', 'no-cook'],
        orgId: orgs[1].id,
        createdById: users[3].id,
      },
      {
        name: 'Duck Confit',
        description: 'Traditional French duck leg preserved in its own fat',
        instructions: [
          'Cure duck legs with salt and herbs overnight',
          'Rinse and pat dry',
          'Cook slowly in duck fat at low temperature',
          'Store in fat until ready to serve',
          'Crisp skin under broiler before serving',
          'Serve with roasted vegetables'
        ],
        prepTime: 24 * 60, // 24 hours for curing
        cookTime: 180,
        servings: 4,
        difficulty: Difficulty.EXPERT,
        tags: ['duck', 'french', 'confit', 'traditional'],
        orgId: orgs[0].id,
        createdById: users[1].id,
      },
      {
        name: 'Vegetarian Chili',
        description: 'Hearty chili with beans and vegetables',
        instructions: [
          'Sauté onions, peppers, and garlic',
          'Add spices and cook until fragrant',
          'Add tomatoes and beans',
          'Simmer for 45 minutes',
          'Adjust seasoning to taste',
          'Serve with cornbread and toppings'
        ],
        prepTime: 20,
        cookTime: 60,
        servings: 8,
        difficulty: Difficulty.EASY,
        tags: ['vegetarian', 'chili', 'beans', 'comfort-food'],
        orgId: orgs[1].id,
        createdById: users[3].id,
      },
      {
        name: 'Seared Scallops with Cauliflower Puree',
        description: 'Pan-seared scallops with creamy cauliflower puree',
        instructions: [
          'Remove scallops from refrigerator 30 minutes before cooking',
          'Steam cauliflower until tender',
          'Puree cauliflower with cream and butter',
          'Pat scallops dry and season',
          'Sear scallops in hot pan for 2 minutes per side',
          'Serve immediately over cauliflower puree'
        ],
        prepTime: 20,
        cookTime: 15,
        servings: 4,
        difficulty: Difficulty.HARD,
        tags: ['seafood', 'scallops', 'fine-dining', 'elegant'],
        orgId: orgs[0].id,
        createdById: users[1].id,
      },
      {
        name: 'Banana Bread',
        description: 'Moist banana bread with walnuts',
        instructions: [
          'Mash ripe bananas',
          'Cream butter and sugar',
          'Add eggs and vanilla',
          'Fold in dry ingredients and bananas',
          'Add chopped walnuts',
          'Bake at 350°F for 60 minutes'
        ],
        prepTime: 15,
        cookTime: 60,
        servings: 8,
        difficulty: Difficulty.EASY,
        tags: ['dessert', 'bread', 'banana', 'baking'],
        orgId: orgs[1].id,
        createdById: users[3].id,
      },
      {
        name: 'Coq au Vin',
        description: 'Classic French chicken braised in wine',
        instructions: [
          'Brown chicken pieces in batches',
          'Sauté bacon, onions, and mushrooms',
          'Add wine and chicken stock',
          'Return chicken to pot',
          'Simmer for 45 minutes',
          'Thicken sauce and serve'
        ],
        prepTime: 25,
        cookTime: 60,
        servings: 6,
        difficulty: Difficulty.MEDIUM,
        tags: ['chicken', 'french', 'wine', 'classic'],
        orgId: orgs[0].id,
        createdById: users[1].id,
      },
      {
        name: 'Quinoa Buddha Bowl',
        description: 'Nutritious bowl with quinoa, roasted vegetables, and tahini dressing',
        instructions: [
          'Cook quinoa according to package directions',
          'Roast vegetables with olive oil and spices',
          'Prepare tahini dressing',
          'Massage kale with lemon juice',
          'Assemble bowl with all components',
          'Drizzle with dressing and serve'
        ],
        prepTime: 20,
        cookTime: 25,
        servings: 4,
        difficulty: Difficulty.EASY,
        tags: ['vegetarian', 'healthy', 'bowl', 'quinoa'],
        orgId: orgs[1].id,
        createdById: users[3].id,
      },
    ];

    const recipes = await Promise.all(
      recipeData.map(recipe => prisma.recipe.create({ data: recipe }))
    );
    console.log(`✅ Created ${recipes.length} recipes`);

    // Add ingredients to recipes
    console.log('🥘 Adding ingredients to recipes...');
    let recipeIngredientsCount = 0;
    for (const recipe of recipes) {
      // Each recipe gets 5-8 random ingredients
      const numIngredients = Math.floor(Math.random() * 4) + 5;
      const selectedIngredients = ingredients
        .sort(() => 0.5 - Math.random())
        .slice(0, numIngredients);

      for (const ingredient of selectedIngredients) {
        await prisma.recipeIngredient.create({
          data: {
            quantity: Math.random() * 5 + 0.5, // Random quantity between 0.5-5.5
            unit: ingredient.unit,
            notes: Math.random() > 0.7 ? 'finely chopped' : undefined,
            recipeId: recipe.id,
            ingredientId: ingredient.id,
          },
        });
        recipeIngredientsCount++;
      }
    }
    console.log(`✅ Created ${recipeIngredientsCount} recipe-ingredient relationships`);

    // Create sub-recipes (some recipes use other recipes as components)
    console.log('🔗 Creating sub-recipes...');
    const subRecipes = [];
    // Create 5 sub-recipe relationships
    for (let i = 0; i < 5; i++) {
      const parentRecipe = recipes[Math.floor(Math.random() * recipes.length)];
      const childRecipe = recipes[Math.floor(Math.random() * recipes.length)];
      
      if (parentRecipe.id !== childRecipe.id) {
        try {
          const subRecipe = await prisma.subRecipe.create({
            data: {
              quantity: Math.random() * 2 + 0.5,
              notes: 'Used as component',
              parentRecipeId: parentRecipe.id,
              childRecipeId: childRecipe.id,
            },
          });
          subRecipes.push(subRecipe);
        } catch (error) {
          // Skip if relationship already exists
        }
      }
    }
    console.log(`✅ Created ${subRecipes.length} sub-recipe relationships`);

    // Create menus
    console.log('📋 Creating menus...');
    const menus = await Promise.all([
      prisma.menu.create({
        data: {
          name: 'Summer Fine Dining Menu',
          description: 'Elegant summer menu featuring seasonal ingredients',
          menuType: MenuType.SEASONAL,
          validFrom: new Date('2024-06-01'),
          validTo: new Date('2024-08-31'),
          orgId: orgs[0].id,
        },
      }),
      prisma.menu.create({
        data: {
          name: 'Casual Lunch Menu',
          description: 'Light and fresh options for lunch service',
          menuType: MenuType.REGULAR,
          orgId: orgs[0].id,
        },
      }),
      prisma.menu.create({
        data: {
          name: 'Farm Fresh Dinner Menu',
          description: 'Farm-to-table dinner featuring organic ingredients',
          menuType: MenuType.REGULAR,
          orgId: orgs[1].id,
        },
      }),
    ]);
    console.log(`✅ Created ${menus.length} menus`);

    // Add items to menus
    console.log('🍽️ Adding items to menus...');
    let menuItemsCount = 0;
    for (const menu of menus) {
      // Each menu gets 6-10 recipes
      const numItems = Math.floor(Math.random() * 5) + 6;
      const orgRecipes = recipes.filter(r => r.orgId === menu.orgId);
      const selectedRecipes = orgRecipes
        .sort(() => 0.5 - Math.random())
        .slice(0, Math.min(numItems, orgRecipes.length));

      for (let i = 0; i < selectedRecipes.length; i++) {
        const recipe = selectedRecipes[i];
        await prisma.menuItem.create({
          data: {
            name: recipe.name,
            description: recipe.description,
            price: Math.random() * 30 + 15, // Random price between $15-$45
            category: i < 2 ? 'appetizer' : i < selectedRecipes.length - 2 ? 'main' : 'dessert',
            sortOrder: i,
            menuId: menu.id,
            recipeId: recipe.id,
          },
        });
        menuItemsCount++;
      }
    }
    console.log(`✅ Created ${menuItemsCount} menu items`);

    // Create events
    console.log('🎉 Creating events...');
    const events = await Promise.all([
      prisma.event.create({
        data: {
          name: 'Corporate Gala Dinner',
          description: 'Annual corporate gala with 200 guests',
          eventType: EventType.CATERING,
          startDate: new Date('2024-07-15T18:00:00Z'),
          endDate: new Date('2024-07-15T23:00:00Z'),
          location: 'Grand Ballroom, Downtown Hotel',
          guestCount: 200,
          status: EventStatus.CONFIRMED,
          orgId: orgs[0].id,
          createdById: users[0].id,
          menuId: menus[0].id,
        },
      }),
      prisma.event.create({
        data: {
          name: 'Wedding Reception',
          description: 'Elegant wedding reception for 150 guests',
          eventType: EventType.CATERING,
          startDate: new Date('2024-08-20T17:00:00Z'),
          endDate: new Date('2024-08-20T24:00:00Z'),
          location: 'Garden Pavilion, Rose Manor',
          guestCount: 150,
          status: EventStatus.PLANNED,
          orgId: orgs[0].id,
          createdById: users[0].id,
          menuId: menus[0].id,
        },
      }),
      prisma.event.create({
        data: {
          name: 'Farm-to-Table Pop-up',
          description: 'Special pop-up dinner featuring local farmers',
          eventType: EventType.POPUP,
          startDate: new Date('2024-09-10T19:00:00Z'),
          endDate: new Date('2024-09-10T22:00:00Z'),
          location: 'Riverside Farm, Organic Valley',
          guestCount: 50,
          status: EventStatus.PLANNED,
          orgId: orgs[1].id,
          createdById: users[2].id,
          menuId: menus[2].id,
        },
      }),
    ]);
    console.log(`✅ Created ${events.length} events`);

    console.log('🎊 Database seeding completed successfully!');
    console.log('\n📊 Summary:');
    console.log(`   Organizations: ${orgs.length}`);
    console.log(`   Users: ${users.length}`);
    console.log(`   Ingredients: ${ingredients.length}`);
    console.log(`   Suppliers: ${suppliers.length}`);
    console.log(`   Supplier-Ingredients: ${supplierIngredients.length}`);
    console.log(`   Recipes: ${recipes.length}`);
    console.log(`   Recipe-Ingredients: ${recipeIngredientsCount}`);
    console.log(`   Sub-Recipes: ${subRecipes.length}`);
    console.log(`   Menus: ${menus.length}`);
    console.log(`   Menu Items: ${menuItemsCount}`);
    console.log(`   Events: ${events.length}`);

  } catch (error) {
    console.error('❌ Error during seeding:', error);
    throw error;
  } finally {
    await prisma.$disconnect();
  }
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  });

