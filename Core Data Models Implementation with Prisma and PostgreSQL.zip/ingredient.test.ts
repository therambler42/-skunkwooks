import { PrismaClient } from '@prisma/client';
import { prisma } from './setup';

describe('Ingredient CRUD Operations', () => {

  describe('Create Ingredient', () => {
    it('should create a new ingredient', async () => {
      const ingredientData = {
        name: 'Test Tomato',
        description: 'Fresh red tomatoes',
        unit: 'kg',
        category: 'vegetables',
        allergens: [],
        nutritionInfo: {
          calories: 18,
          protein: 0.9,
          carbs: 3.9,
          fat: 0.2,
        },
      };

      const ingredient = await prisma.ingredient.create({
        data: ingredientData,
      });

      expect(ingredient).toBeDefined();
      expect(ingredient.id).toBeDefined();
      expect(ingredient.name).toBe(ingredientData.name);
      expect(ingredient.unit).toBe(ingredientData.unit);
      expect(ingredient.category).toBe(ingredientData.category);
      expect(ingredient.allergens).toEqual(ingredientData.allergens);
      expect(ingredient.nutritionInfo).toEqual(ingredientData.nutritionInfo);
    });

    it('should create ingredient with allergens', async () => {
      const ingredient = await prisma.ingredient.create({
        data: {
          name: 'Test Milk',
          unit: 'liters',
          category: 'dairy',
          allergens: ['milk', 'lactose'],
        },
      });

      expect(ingredient.allergens).toEqual(['milk', 'lactose']);
    });

    it('should fail to create ingredient with duplicate name', async () => {
      await prisma.ingredient.create({
        data: {
          name: 'Duplicate Ingredient',
          unit: 'kg',
        },
      });

      await expect(
        prisma.ingredient.create({
          data: {
            name: 'Duplicate Ingredient',
            unit: 'lbs',
          },
        })
      ).rejects.toThrow();
    });
  });

  describe('Read Ingredient', () => {
    it('should find ingredient by id', async () => {
      const ingredient = await prisma.ingredient.create({
        data: {
          name: 'Find Test Ingredient',
          unit: 'kg',
          category: 'test',
        },
      });

      const foundIngredient = await prisma.ingredient.findUnique({
        where: { id: ingredient.id },
      });

      expect(foundIngredient).toBeDefined();
      expect(foundIngredient?.id).toBe(ingredient.id);
    });

    it('should find ingredients by category', async () => {
      await prisma.ingredient.createMany({
        data: [
          { name: 'Carrot', unit: 'kg', category: 'vegetables' },
          { name: 'Broccoli', unit: 'kg', category: 'vegetables' },
          { name: 'Chicken', unit: 'kg', category: 'meat' },
        ],
      });

      const vegetables = await prisma.ingredient.findMany({
        where: { category: 'vegetables' },
      });

      expect(vegetables).toHaveLength(2);
      expect(vegetables.every(ing => ing.category === 'vegetables')).toBe(true);
    });

    it('should find ingredients with allergens', async () => {
      await prisma.ingredient.createMany({
        data: [
          { name: 'Peanuts', unit: 'kg', allergens: ['nuts'] },
          { name: 'Wheat Flour', unit: 'kg', allergens: ['gluten'] },
          { name: 'Rice', unit: 'kg', allergens: [] },
        ],
      });

      const allergenic = await prisma.ingredient.findMany({
        where: {
          allergens: {
            isEmpty: false,
          },
        },
      });

      expect(allergenic).toHaveLength(2);
    });
  });

  describe('Update Ingredient', () => {
    it('should update ingredient description', async () => {
      const ingredient = await prisma.ingredient.create({
        data: {
          name: 'Update Test Ingredient',
          unit: 'kg',
          description: 'Original description',
        },
      });

      const updatedIngredient = await prisma.ingredient.update({
        where: { id: ingredient.id },
        data: { description: 'Updated description' },
      });

      expect(updatedIngredient.description).toBe('Updated description');
    });

    it('should update nutrition info', async () => {
      const ingredient = await prisma.ingredient.create({
        data: {
          name: 'Nutrition Update Test',
          unit: 'kg',
          nutritionInfo: { calories: 100 },
        },
      });

      const updatedIngredient = await prisma.ingredient.update({
        where: { id: ingredient.id },
        data: {
          nutritionInfo: {
            calories: 150,
            protein: 5.0,
            carbs: 20.0,
            fat: 2.0,
          },
        },
      });

      expect(updatedIngredient.nutritionInfo).toEqual({
        calories: 150,
        protein: 5.0,
        carbs: 20.0,
        fat: 2.0,
      });
    });
  });

  describe('Delete Ingredient', () => {
    it('should delete ingredient', async () => {
      const ingredient = await prisma.ingredient.create({
        data: {
          name: 'Delete Test Ingredient',
          unit: 'kg',
        },
      });

      await prisma.ingredient.delete({
        where: { id: ingredient.id },
      });

      const foundIngredient = await prisma.ingredient.findUnique({
        where: { id: ingredient.id },
      });

      expect(foundIngredient).toBeNull();
    });
  });
});

