import { PrismaClient, UserRole, MenuType, EventType, EventStatus } from '@prisma/client';
import { prisma } from './setup';

describe('Menu and Event CRUD Operations', () => {
  let testOrg: any;
  let testUser: any;
  let testRecipe: any;

  beforeEach(async () => {
    testOrg = await prisma.org.create({
      data: {
        name: 'Test Organization for Menus',
        description: 'Organization for menu testing',
      },
    });

    testUser = await prisma.user.create({
      data: {
        email: 'manager@test.com',
        name: 'Test Manager',
        role: UserRole.MANAGER,
        orgId: testOrg.id,
      },
    });

    testRecipe = await prisma.recipe.create({
      data: {
        name: 'Test Recipe for Menus',
        orgId: testOrg.id,
        createdById: testUser.id,
      },
    });
  });

  describe('Menu CRUD Operations', () => {
    describe('Create Menu', () => {
      it('should create a new menu', async () => {
        const menuData = {
          name: 'Test Menu',
          description: 'A delicious test menu',
          menuType: MenuType.REGULAR,
          isActive: true,
          validFrom: new Date('2024-01-01'),
          validTo: new Date('2024-12-31'),
          orgId: testOrg.id,
        };

        const menu = await prisma.menu.create({
          data: menuData,
        });

        expect(menu).toBeDefined();
        expect(menu.id).toBeDefined();
        expect(menu.name).toBe(menuData.name);
        expect(menu.description).toBe(menuData.description);
        expect(menu.menuType).toBe(menuData.menuType);
        expect(menu.isActive).toBe(menuData.isActive);
        expect(menu.validFrom).toEqual(menuData.validFrom);
        expect(menu.validTo).toEqual(menuData.validTo);
        expect(menu.orgId).toBe(menuData.orgId);
      });

      it('should fail to create menu with duplicate name in same org', async () => {
        const menuData = {
          name: 'Duplicate Menu',
          orgId: testOrg.id,
        };

        await prisma.menu.create({ data: menuData });

        await expect(
          prisma.menu.create({ data: menuData })
        ).rejects.toThrow();
      });

      it('should create menus with different types', async () => {
        const menuTypes = [MenuType.REGULAR, MenuType.SEASONAL, MenuType.SPECIAL, MenuType.CATERING];

        for (let i = 0; i < menuTypes.length; i++) {
          const menu = await prisma.menu.create({
            data: {
              name: `Menu ${i}`,
              menuType: menuTypes[i],
              orgId: testOrg.id,
            },
          });

          expect(menu.menuType).toBe(menuTypes[i]);
        }
      });
    });

    describe('Read Menu', () => {
      it('should find menu by id with relations', async () => {
        const menu = await prisma.menu.create({
          data: {
            name: 'Find Test Menu',
            orgId: testOrg.id,
          },
        });

        const foundMenu = await prisma.menu.findUnique({
          where: { id: menu.id },
          include: {
            org: true,
            menuItems: {
              include: {
                recipe: true,
              },
            },
          },
        });

        expect(foundMenu).toBeDefined();
        expect(foundMenu?.org.id).toBe(testOrg.id);
      });

      it('should find active menus', async () => {
        await prisma.menu.createMany({
          data: [
            { name: 'Active Menu', isActive: true, orgId: testOrg.id },
            { name: 'Inactive Menu', isActive: false, orgId: testOrg.id },
          ],
        });

        const activeMenus = await prisma.menu.findMany({
          where: { isActive: true },
        });

        expect(activeMenus).toHaveLength(1);
        expect(activeMenus[0].name).toBe('Active Menu');
      });

      it('should find menus by date range', async () => {
        const now = new Date();
        const future = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000); // 30 days from now

        await prisma.menu.create({
          data: {
            name: 'Current Menu',
            validFrom: now,
            validTo: future,
            orgId: testOrg.id,
          },
        });

        const currentMenus = await prisma.menu.findMany({
          where: {
            AND: [
              { validFrom: { lte: now } },
              { validTo: { gte: now } },
            ],
          },
        });

        expect(currentMenus).toHaveLength(1);
        expect(currentMenus[0].name).toBe('Current Menu');
      });
    });

    describe('Update Menu', () => {
      it('should update menu description', async () => {
        const menu = await prisma.menu.create({
          data: {
            name: 'Update Test Menu',
            description: 'Original description',
            orgId: testOrg.id,
          },
        });

        const updatedMenu = await prisma.menu.update({
          where: { id: menu.id },
          data: { description: 'Updated description' },
        });

        expect(updatedMenu.description).toBe('Updated description');
      });

      it('should deactivate menu', async () => {
        const menu = await prisma.menu.create({
          data: {
            name: 'Deactivate Test Menu',
            isActive: true,
            orgId: testOrg.id,
          },
        });

        const updatedMenu = await prisma.menu.update({
          where: { id: menu.id },
          data: { isActive: false },
        });

        expect(updatedMenu.isActive).toBe(false);
      });
    });

    describe('Delete Menu', () => {
      it('should delete menu', async () => {
        const menu = await prisma.menu.create({
          data: {
            name: 'Delete Test Menu',
            orgId: testOrg.id,
          },
        });

        await prisma.menu.delete({
          where: { id: menu.id },
        });

        const foundMenu = await prisma.menu.findUnique({
          where: { id: menu.id },
        });

        expect(foundMenu).toBeNull();
      });
    });
  });

  describe('MenuItem CRUD Operations', () => {
    let testMenu: any;

    beforeEach(async () => {
      testMenu = await prisma.menu.create({
        data: {
          name: 'Test Menu for Items',
          orgId: testOrg.id,
        },
      });
    });

    describe('Create MenuItem', () => {
      it('should add recipe to menu', async () => {
        const menuItemData = {
          name: 'Custom Menu Item Name',
          description: 'Custom description',
          price: 25.99,
          category: 'main',
          isAvailable: true,
          sortOrder: 1,
          menuId: testMenu.id,
          recipeId: testRecipe.id,
        };

        const menuItem = await prisma.menuItem.create({
          data: menuItemData,
        });

        expect(menuItem).toBeDefined();
        expect(menuItem.name).toBe(menuItemData.name);
        expect(menuItem.description).toBe(menuItemData.description);
        expect(menuItem.price).toBe(menuItemData.price);
        expect(menuItem.category).toBe(menuItemData.category);
        expect(menuItem.isAvailable).toBe(menuItemData.isAvailable);
        expect(menuItem.sortOrder).toBe(menuItemData.sortOrder);
        expect(menuItem.menuId).toBe(menuItemData.menuId);
        expect(menuItem.recipeId).toBe(menuItemData.recipeId);
      });

      it('should fail to add duplicate recipe to menu', async () => {
        const data = {
          price: 20.00,
          menuId: testMenu.id,
          recipeId: testRecipe.id,
        };

        await prisma.menuItem.create({ data });

        await expect(
          prisma.menuItem.create({ data })
        ).rejects.toThrow();
      });
    });

    describe('Read MenuItem', () => {
      it('should find menu items with relations', async () => {
        await prisma.menuItem.create({
          data: {
            price: 15.99,
            category: 'appetizer',
            menuId: testMenu.id,
            recipeId: testRecipe.id,
          },
        });

        const menuItems = await prisma.menuItem.findMany({
          where: { menuId: testMenu.id },
          include: {
            menu: true,
            recipe: true,
          },
          orderBy: { sortOrder: 'asc' },
        });

        expect(menuItems).toHaveLength(1);
        expect(menuItems[0].menu.id).toBe(testMenu.id);
        expect(menuItems[0].recipe.id).toBe(testRecipe.id);
      });

      it('should find available menu items', async () => {
        await prisma.menuItem.createMany({
          data: [
            { price: 10.00, isAvailable: true, menuId: testMenu.id, recipeId: testRecipe.id },
          ],
        });

        // Create another recipe for second menu item
        const recipe2 = await prisma.recipe.create({
          data: {
            name: 'Second Recipe',
            orgId: testOrg.id,
            createdById: testUser.id,
          },
        });

        await prisma.menuItem.create({
          data: {
            price: 20.00,
            isAvailable: false,
            menuId: testMenu.id,
            recipeId: recipe2.id,
          },
        });

        const availableItems = await prisma.menuItem.findMany({
          where: { isAvailable: true },
        });

        expect(availableItems).toHaveLength(1);
        expect(availableItems[0].price).toBe(10.00);
      });
    });

    describe('Update MenuItem', () => {
      it('should update menu item price', async () => {
        const menuItem = await prisma.menuItem.create({
          data: {
            price: 15.00,
            menuId: testMenu.id,
            recipeId: testRecipe.id,
          },
        });

        const updated = await prisma.menuItem.update({
          where: { id: menuItem.id },
          data: { price: 18.00 },
        });

        expect(updated.price).toBe(18.00);
      });

      it('should update availability', async () => {
        const menuItem = await prisma.menuItem.create({
          data: {
            price: 15.00,
            isAvailable: true,
            menuId: testMenu.id,
            recipeId: testRecipe.id,
          },
        });

        const updated = await prisma.menuItem.update({
          where: { id: menuItem.id },
          data: { isAvailable: false },
        });

        expect(updated.isAvailable).toBe(false);
      });
    });

    describe('Delete MenuItem', () => {
      it('should remove recipe from menu', async () => {
        const menuItem = await prisma.menuItem.create({
          data: {
            price: 15.00,
            menuId: testMenu.id,
            recipeId: testRecipe.id,
          },
        });

        await prisma.menuItem.delete({
          where: { id: menuItem.id },
        });

        const found = await prisma.menuItem.findUnique({
          where: { id: menuItem.id },
        });

        expect(found).toBeNull();
      });
    });
  });

  describe('Event CRUD Operations', () => {
    let testMenu: any;

    beforeEach(async () => {
      testMenu = await prisma.menu.create({
        data: {
          name: 'Test Menu for Events',
          orgId: testOrg.id,
        },
      });
    });

    describe('Create Event', () => {
      it('should create a new event', async () => {
        const eventData = {
          name: 'Test Event',
          description: 'A wonderful test event',
          eventType: EventType.CATERING,
          startDate: new Date('2024-07-15T18:00:00Z'),
          endDate: new Date('2024-07-15T23:00:00Z'),
          location: 'Test Venue',
          guestCount: 100,
          status: EventStatus.PLANNED,
          notes: 'Special dietary requirements',
          orgId: testOrg.id,
          createdById: testUser.id,
          menuId: testMenu.id,
        };

        const event = await prisma.event.create({
          data: eventData,
        });

        expect(event).toBeDefined();
        expect(event.id).toBeDefined();
        expect(event.name).toBe(eventData.name);
        expect(event.description).toBe(eventData.description);
        expect(event.eventType).toBe(eventData.eventType);
        expect(event.startDate).toEqual(eventData.startDate);
        expect(event.endDate).toEqual(eventData.endDate);
        expect(event.location).toBe(eventData.location);
        expect(event.guestCount).toBe(eventData.guestCount);
        expect(event.status).toBe(eventData.status);
        expect(event.notes).toBe(eventData.notes);
        expect(event.orgId).toBe(eventData.orgId);
        expect(event.createdById).toBe(eventData.createdById);
        expect(event.menuId).toBe(eventData.menuId);
      });

      it('should create events with different types and statuses', async () => {
        const eventTypes = [EventType.CATERING, EventType.RESTAURANT, EventType.POPUP, EventType.PRIVATE];
        const statuses = [EventStatus.PLANNED, EventStatus.CONFIRMED, EventStatus.IN_PROGRESS, EventStatus.COMPLETED, EventStatus.CANCELLED];

        for (let i = 0; i < eventTypes.length; i++) {
          const event = await prisma.event.create({
            data: {
              name: `Event ${i}`,
              eventType: eventTypes[i],
              status: statuses[i % statuses.length],
              startDate: new Date(),
              orgId: testOrg.id,
              createdById: testUser.id,
            },
          });

          expect(event.eventType).toBe(eventTypes[i]);
          expect(event.status).toBe(statuses[i % statuses.length]);
        }
      });
    });

    describe('Read Event', () => {
      it('should find event by id with relations', async () => {
        const event = await prisma.event.create({
          data: {
            name: 'Find Test Event',
            startDate: new Date(),
            orgId: testOrg.id,
            createdById: testUser.id,
            menuId: testMenu.id,
          },
        });

        const foundEvent = await prisma.event.findUnique({
          where: { id: event.id },
          include: {
            org: true,
            createdBy: true,
            menu: {
              include: {
                menuItems: {
                  include: {
                    recipe: true,
                  },
                },
              },
            },
          },
        });

        expect(foundEvent).toBeDefined();
        expect(foundEvent?.org.id).toBe(testOrg.id);
        expect(foundEvent?.createdBy.id).toBe(testUser.id);
        expect(foundEvent?.menu?.id).toBe(testMenu.id);
      });

      it('should find events by date range', async () => {
        const today = new Date();
        const tomorrow = new Date(today.getTime() + 24 * 60 * 60 * 1000);
        const nextWeek = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);

        await prisma.event.createMany({
          data: [
            {
              name: 'Today Event',
              startDate: today,
              orgId: testOrg.id,
              createdById: testUser.id,
            },
            {
              name: 'Tomorrow Event',
              startDate: tomorrow,
              orgId: testOrg.id,
              createdById: testUser.id,
            },
            {
              name: 'Next Week Event',
              startDate: nextWeek,
              orgId: testOrg.id,
              createdById: testUser.id,
            },
          ],
        });

        const thisWeekEvents = await prisma.event.findMany({
          where: {
            startDate: {
              gte: today,
              lt: new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000),
            },
          },
        });

        expect(thisWeekEvents).toHaveLength(2);
      });

      it('should find events by status', async () => {
        await prisma.event.createMany({
          data: [
            {
              name: 'Planned Event',
              status: EventStatus.PLANNED,
              startDate: new Date(),
              orgId: testOrg.id,
              createdById: testUser.id,
            },
            {
              name: 'Confirmed Event',
              status: EventStatus.CONFIRMED,
              startDate: new Date(),
              orgId: testOrg.id,
              createdById: testUser.id,
            },
          ],
        });

        const confirmedEvents = await prisma.event.findMany({
          where: { status: EventStatus.CONFIRMED },
        });

        expect(confirmedEvents).toHaveLength(1);
        expect(confirmedEvents[0].name).toBe('Confirmed Event');
      });
    });

    describe('Update Event', () => {
      it('should update event status', async () => {
        const event = await prisma.event.create({
          data: {
            name: 'Update Test Event',
            status: EventStatus.PLANNED,
            startDate: new Date(),
            orgId: testOrg.id,
            createdById: testUser.id,
          },
        });

        const updatedEvent = await prisma.event.update({
          where: { id: event.id },
          data: { status: EventStatus.CONFIRMED },
        });

        expect(updatedEvent.status).toBe(EventStatus.CONFIRMED);
      });

      it('should update guest count', async () => {
        const event = await prisma.event.create({
          data: {
            name: 'Guest Count Test Event',
            guestCount: 50,
            startDate: new Date(),
            orgId: testOrg.id,
            createdById: testUser.id,
          },
        });

        const updatedEvent = await prisma.event.update({
          where: { id: event.id },
          data: { guestCount: 75 },
        });

        expect(updatedEvent.guestCount).toBe(75);
      });
    });

    describe('Delete Event', () => {
      it('should delete event', async () => {
        const event = await prisma.event.create({
          data: {
            name: 'Delete Test Event',
            startDate: new Date(),
            orgId: testOrg.id,
            createdById: testUser.id,
          },
        });

        await prisma.event.delete({
          where: { id: event.id },
        });

        const foundEvent = await prisma.event.findUnique({
          where: { id: event.id },
        });

        expect(foundEvent).toBeNull();
      });
    });
  });
});

