import { PrismaClient, UserRole } from '@prisma/client';
import { prisma } from './setup';

describe('User CRUD Operations', () => {
  let testOrg: any;

  beforeEach(async () => {
    testOrg = await prisma.org.create({
      data: {
        name: 'Test Organization for Users',
        description: 'Organization for user testing',
      },
    });
  });

  describe('Create User', () => {
    it('should create a new user', async () => {
      const userData = {
        email: 'test@example.com',
        name: 'Test User',
        role: UserRole.USER,
        orgId: testOrg.id,
      };

      const user = await prisma.user.create({
        data: userData,
      });

      expect(user).toBeDefined();
      expect(user.id).toBeDefined();
      expect(user.email).toBe(userData.email);
      expect(user.name).toBe(userData.name);
      expect(user.role).toBe(userData.role);
      expect(user.orgId).toBe(userData.orgId);
      expect(user.isActive).toBe(true);
      expect(user.createdAt).toBeDefined();
      expect(user.updatedAt).toBeDefined();
    });

    it('should fail to create user with duplicate email', async () => {
      const userData = {
        email: 'duplicate@example.com',
        name: 'First User',
        role: UserRole.USER,
        orgId: testOrg.id,
      };

      await prisma.user.create({ data: userData });

      await expect(
        prisma.user.create({
          data: {
            email: 'duplicate@example.com',
            name: 'Second User',
            role: UserRole.ADMIN,
            orgId: testOrg.id,
          },
        })
      ).rejects.toThrow();
    });

    it('should create user with different roles', async () => {
      const roles = [UserRole.ADMIN, UserRole.MANAGER, UserRole.CHEF, UserRole.USER];

      for (let i = 0; i < roles.length; i++) {
        const user = await prisma.user.create({
          data: {
            email: `user${i}@example.com`,
            name: `User ${i}`,
            role: roles[i],
            orgId: testOrg.id,
          },
        });

        expect(user.role).toBe(roles[i]);
      }
    });
  });

  describe('Read User', () => {
    it('should find user by id', async () => {
      const user = await prisma.user.create({
        data: {
          email: 'find@example.com',
          name: 'Find User',
          role: UserRole.USER,
          orgId: testOrg.id,
        },
      });

      const foundUser = await prisma.user.findUnique({
        where: { id: user.id },
        include: { org: true },
      });

      expect(foundUser).toBeDefined();
      expect(foundUser?.id).toBe(user.id);
      expect(foundUser?.org.id).toBe(testOrg.id);
    });

    it('should find users by organization', async () => {
      await prisma.user.createMany({
        data: [
          {
            email: 'user1@org.com',
            name: 'User 1',
            role: UserRole.USER,
            orgId: testOrg.id,
          },
          {
            email: 'user2@org.com',
            name: 'User 2',
            role: UserRole.CHEF,
            orgId: testOrg.id,
          },
        ],
      });

      const users = await prisma.user.findMany({
        where: { orgId: testOrg.id },
      });

      expect(users).toHaveLength(2);
      expect(users.every(user => user.orgId === testOrg.id)).toBe(true);
    });
  });

  describe('Update User', () => {
    it('should update user role', async () => {
      const user = await prisma.user.create({
        data: {
          email: 'update@example.com',
          name: 'Update User',
          role: UserRole.USER,
          orgId: testOrg.id,
        },
      });

      const updatedUser = await prisma.user.update({
        where: { id: user.id },
        data: { role: UserRole.ADMIN },
      });

      expect(updatedUser.role).toBe(UserRole.ADMIN);
    });

    it('should deactivate user', async () => {
      const user = await prisma.user.create({
        data: {
          email: 'deactivate@example.com',
          name: 'Deactivate User',
          role: UserRole.USER,
          orgId: testOrg.id,
        },
      });

      const updatedUser = await prisma.user.update({
        where: { id: user.id },
        data: { isActive: false },
      });

      expect(updatedUser.isActive).toBe(false);
    });
  });

  describe('Delete User', () => {
    it('should delete user', async () => {
      const user = await prisma.user.create({
        data: {
          email: 'delete@example.com',
          name: 'Delete User',
          role: UserRole.USER,
          orgId: testOrg.id,
        },
      });

      await prisma.user.delete({
        where: { id: user.id },
      });

      const foundUser = await prisma.user.findUnique({
        where: { id: user.id },
      });

      expect(foundUser).toBeNull();
    });
  });
});

