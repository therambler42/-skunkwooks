from flask import Blueprint, request, jsonify
from src.models.marketplace import db, Organization, ApiKey
from src.auth import generate_api_key, require_api_key, limiter
import secrets

# Create API management blueprint
api_mgmt_bp = Blueprint('api_mgmt', __name__)

@api_mgmt_bp.route('/organizations', methods=['POST'])
@limiter.limit("10 per hour")
def create_organization():
    """Create a new organization"""
    try:
        data = request.get_json()
        
        if not data or not data.get('name') or not data.get('email'):
            return jsonify({'error': 'Name and email are required'}), 400
        
        # Check if organization already exists
        existing = Organization.query.filter_by(email=data['email']).first()
        if existing:
            return jsonify({'error': 'Organization with this email already exists'}), 409
        
        # Create organization
        org = Organization(
            name=data['name'],
            email=data['email']
        )
        db.session.add(org)
        db.session.flush()  # Get the ID
        
        # Create initial API key
        api_key = generate_api_key()
        key_record = ApiKey(
            key=api_key,
            name='Default API Key',
            organization_id=org.id,
            rate_limit=data.get('rate_limit', 1000)
        )
        db.session.add(key_record)
        db.session.commit()
        
        return jsonify({
            'organization': org.to_dict(),
            'api_key': {
                'id': key_record.id,
                'key': api_key,  # Only return the key on creation
                'name': key_record.name,
                'rate_limit': key_record.rate_limit
            }
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@api_mgmt_bp.route('/api-keys', methods=['GET'])
@require_api_key
def list_api_keys():
    """List API keys for the authenticated organization"""
    try:
        org = request.organization
        api_keys = ApiKey.query.filter_by(organization_id=org.id).all()
        
        return jsonify({
            'api_keys': [key.to_dict() for key in api_keys]
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api_mgmt_bp.route('/api-keys', methods=['POST'])
@require_api_key
@limiter.limit("5 per hour")
def create_api_key():
    """Create a new API key for the authenticated organization"""
    try:
        data = request.get_json()
        org = request.organization
        
        if not data or not data.get('name'):
            return jsonify({'error': 'API key name is required'}), 400
        
        # Generate new API key
        api_key = generate_api_key()
        key_record = ApiKey(
            key=api_key,
            name=data['name'],
            organization_id=org.id,
            rate_limit=data.get('rate_limit', 1000)
        )
        db.session.add(key_record)
        db.session.commit()
        
        return jsonify({
            'id': key_record.id,
            'key': api_key,  # Only return the key on creation
            'name': key_record.name,
            'rate_limit': key_record.rate_limit,
            'created_at': key_record.created_at.isoformat()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@api_mgmt_bp.route('/api-keys/<int:key_id>', methods=['PUT'])
@require_api_key
def update_api_key(key_id):
    """Update an API key"""
    try:
        data = request.get_json()
        org = request.organization
        
        key_record = ApiKey.query.filter_by(id=key_id, organization_id=org.id).first()
        if not key_record:
            return jsonify({'error': 'API key not found'}), 404
        
        # Update allowed fields
        if 'name' in data:
            key_record.name = data['name']
        if 'rate_limit' in data:
            key_record.rate_limit = data['rate_limit']
        if 'is_active' in data:
            key_record.is_active = data['is_active']
        
        db.session.commit()
        
        return jsonify(key_record.to_dict())
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@api_mgmt_bp.route('/api-keys/<int:key_id>', methods=['DELETE'])
@require_api_key
def delete_api_key(key_id):
    """Delete an API key"""
    try:
        org = request.organization
        
        key_record = ApiKey.query.filter_by(id=key_id, organization_id=org.id).first()
        if not key_record:
            return jsonify({'error': 'API key not found'}), 404
        
        # Don't allow deleting the last active API key
        active_keys = ApiKey.query.filter_by(organization_id=org.id, is_active=True).count()
        if active_keys <= 1 and key_record.is_active:
            return jsonify({'error': 'Cannot delete the last active API key'}), 400
        
        db.session.delete(key_record)
        db.session.commit()
        
        return jsonify({'message': 'API key deleted successfully'})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@api_mgmt_bp.route('/organization', methods=['GET'])
@require_api_key
def get_organization():
    """Get organization details"""
    try:
        org = request.organization
        return jsonify(org.to_dict())
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api_mgmt_bp.route('/organization', methods=['PUT'])
@require_api_key
def update_organization():
    """Update organization details"""
    try:
        data = request.get_json()
        org = request.organization
        
        if 'name' in data:
            org.name = data['name']
        if 'email' in data:
            # Check if email is already taken by another organization
            existing = Organization.query.filter_by(email=data['email']).first()
            if existing and existing.id != org.id:
                return jsonify({'error': 'Email already taken by another organization'}), 409
            org.email = data['email']
        
        db.session.commit()
        
        return jsonify(org.to_dict())
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

