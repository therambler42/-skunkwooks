import graphene
from graphene import ObjectType, String, Int, Float, Boolean, DateTime, List, Field, Mutation, Schema
from src.models.marketplace import (
    db, Organization, ApiKey, Webhook, WebhookDelivery, 
    Product, PurchaseOrder, BatchRecallEvent
)

# Simple GraphQL Object Types (without SQLAlchemy integration due to version conflicts)
class OrganizationType(ObjectType):
    id = Int()
    name = String()
    email = String()
    created_at = String()

class ApiKeyType(ObjectType):
    id = Int()
    name = String()
    organization_id = Int()
    is_active = Boolean()
    rate_limit = Int()
    created_at = String()
    last_used = String()

class WebhookType(ObjectType):
    id = Int()
    organization_id = Int()
    event_type = String()
    endpoint_url = String()
    secret = String()
    is_active = Boolean()
    created_at = String()

class WebhookDeliveryType(ObjectType):
    id = Int()
    webhook_id = Int()
    event_id = String()
    payload = String()
    status = String()
    response_code = Int()
    response_body = String()
    attempts = Int()
    created_at = String()
    delivered_at = String()

class ProductType(ObjectType):
    id = Int()
    name = String()
    sku = String()
    price = Float()
    inventory_count = Int()
    created_at = String()

class PurchaseOrderType(ObjectType):
    id = Int()
    order_number = String()
    supplier = String()
    status = String()
    total_amount = Float()
    created_at = String()
    updated_at = String()

class BatchRecallType(ObjectType):
    id = Int()
    batch_number = String()
    product_id = Int()
    reason = String()
    severity = String()
    affected_quantity = Int()
    created_at = String()

# Helper function to convert model to dict
def model_to_dict(model):
    if hasattr(model, 'to_dict'):
        return model.to_dict()
    return {}

# Input Types for Mutations
class ProductInput(graphene.InputObjectType):
    name = String(required=True)
    sku = String(required=True)
    price = Float(required=True)
    inventory_count = Int(default_value=0)

class PurchaseOrderInput(graphene.InputObjectType):
    order_number = String(required=True)
    supplier = String(required=True)
    total_amount = Float(required=True)
    status = String(default_value="pending")

class BatchRecallInput(graphene.InputObjectType):
    batch_number = String(required=True)
    product_id = Int(required=True)
    reason = String(required=True)
    severity = String(default_value="medium")
    affected_quantity = Int(required=True)

# Mutations
class CreateProduct(Mutation):
    class Arguments:
        product_data = ProductInput(required=True)
    
    product = Field(ProductType)
    success = Boolean()
    message = String()
    
    def mutate(self, info, product_data):
        try:
            # Check if SKU already exists
            existing = Product.query.filter_by(sku=product_data.sku).first()
            if existing:
                return CreateProduct(success=False, message="SKU already exists")
            
            product = Product(
                name=product_data.name,
                sku=product_data.sku,
                price=product_data.price,
                inventory_count=product_data.inventory_count
            )
            db.session.add(product)
            db.session.commit()
            
            product_dict = model_to_dict(product)
            return CreateProduct(
                product=ProductType(**product_dict), 
                success=True, 
                message="Product created successfully"
            )
        except Exception as e:
            db.session.rollback()
            return CreateProduct(success=False, message=str(e))

class UpdateProductInventory(Mutation):
    class Arguments:
        product_id = Int(required=True)
        new_count = Int(required=True)
    
    product = Field(ProductType)
    success = Boolean()
    message = String()
    
    def mutate(self, info, product_id, new_count):
        try:
            product = Product.query.get(product_id)
            if not product:
                return UpdateProductInventory(success=False, message="Product not found")
            
            previous_count = product.inventory_count
            product.inventory_count = new_count
            db.session.commit()
            
            # Trigger webhook
            from src.webhook_service import WebhookService
            product_data = model_to_dict(product)
            product_data['previous_count'] = previous_count
            WebhookService.trigger_inventory_updated(product_data)
            
            product_dict = model_to_dict(product)
            return UpdateProductInventory(
                product=ProductType(**product_dict), 
                success=True, 
                message="Inventory updated successfully"
            )
        except Exception as e:
            db.session.rollback()
            return UpdateProductInventory(success=False, message=str(e))

class CreatePurchaseOrder(Mutation):
    class Arguments:
        order_data = PurchaseOrderInput(required=True)
    
    purchase_order = Field(PurchaseOrderType)
    success = Boolean()
    message = String()
    
    def mutate(self, info, order_data):
        try:
            # Check if order number already exists
            existing = PurchaseOrder.query.filter_by(order_number=order_data.order_number).first()
            if existing:
                return CreatePurchaseOrder(success=False, message="Order number already exists")
            
            order = PurchaseOrder(
                order_number=order_data.order_number,
                supplier=order_data.supplier,
                total_amount=order_data.total_amount,
                status=order_data.status
            )
            db.session.add(order)
            db.session.commit()
            
            order_dict = model_to_dict(order)
            return CreatePurchaseOrder(
                purchase_order=PurchaseOrderType(**order_dict), 
                success=True, 
                message="Purchase order created successfully"
            )
        except Exception as e:
            db.session.rollback()
            return CreatePurchaseOrder(success=False, message=str(e))

class UpdatePurchaseOrderStatus(Mutation):
    class Arguments:
        order_id = Int(required=True)
        status = String(required=True)
    
    purchase_order = Field(PurchaseOrderType)
    success = Boolean()
    message = String()
    
    def mutate(self, info, order_id, status):
        try:
            order = PurchaseOrder.query.get(order_id)
            if not order:
                return UpdatePurchaseOrderStatus(success=False, message="Purchase order not found")
            
            order.status = status
            db.session.commit()
            
            # Trigger webhook
            from src.webhook_service import WebhookService
            WebhookService.trigger_purchase_order_status(model_to_dict(order))
            
            order_dict = model_to_dict(order)
            return UpdatePurchaseOrderStatus(
                purchase_order=PurchaseOrderType(**order_dict), 
                success=True, 
                message="Purchase order status updated successfully"
            )
        except Exception as e:
            db.session.rollback()
            return UpdatePurchaseOrderStatus(success=False, message=str(e))

class CreateBatchRecall(Mutation):
    class Arguments:
        recall_data = BatchRecallInput(required=True)
    
    batch_recall = Field(BatchRecallType)
    success = Boolean()
    message = String()
    
    def mutate(self, info, recall_data):
        try:
            # Check if product exists
            product = Product.query.get(recall_data.product_id)
            if not product:
                return CreateBatchRecall(success=False, message="Product not found")
            
            recall = BatchRecallEvent(
                batch_number=recall_data.batch_number,
                product_id=recall_data.product_id,
                reason=recall_data.reason,
                severity=recall_data.severity,
                affected_quantity=recall_data.affected_quantity
            )
            db.session.add(recall)
            db.session.commit()
            
            # Trigger webhook
            from src.webhook_service import WebhookService
            WebhookService.trigger_batch_recall(model_to_dict(recall))
            
            recall_dict = model_to_dict(recall)
            return CreateBatchRecall(
                batch_recall=BatchRecallType(**recall_dict), 
                success=True, 
                message="Batch recall created successfully"
            )
        except Exception as e:
            db.session.rollback()
            return CreateBatchRecall(success=False, message=str(e))

# Query Root
class Query(ObjectType):
    # Product queries
    products = List(ProductType)
    product = Field(ProductType, id=Int(required=True))
    
    # Purchase Order queries
    purchase_orders = List(PurchaseOrderType)
    purchase_order = Field(PurchaseOrderType, id=Int(required=True))
    
    # Batch Recall queries
    batch_recalls = List(BatchRecallType)
    batch_recall = Field(BatchRecallType, id=Int(required=True))
    
    # Organization queries (for authenticated users)
    my_organization = Field(OrganizationType)
    my_webhooks = List(WebhookType)
    my_webhook_deliveries = List(WebhookDeliveryType)
    
    def resolve_products(self, info):
        products = Product.query.all()
        return [ProductType(**model_to_dict(p)) for p in products]
    
    def resolve_product(self, info, id):
        product = Product.query.get(id)
        if product:
            return ProductType(**model_to_dict(product))
        return None
    
    def resolve_purchase_orders(self, info):
        orders = PurchaseOrder.query.all()
        return [PurchaseOrderType(**model_to_dict(o)) for o in orders]
    
    def resolve_purchase_order(self, info, id):
        order = PurchaseOrder.query.get(id)
        if order:
            return PurchaseOrderType(**model_to_dict(order))
        return None
    
    def resolve_batch_recalls(self, info):
        recalls = BatchRecallEvent.query.all()
        return [BatchRecallType(**model_to_dict(r)) for r in recalls]
    
    def resolve_batch_recall(self, info, id):
        recall = BatchRecallEvent.query.get(id)
        if recall:
            return BatchRecallType(**model_to_dict(recall))
        return None
    
    def resolve_my_organization(self, info):
        # This would be populated by authentication middleware
        request = info.context.get('request')
        if request and hasattr(request, 'organization'):
            org = request.organization
            return OrganizationType(**model_to_dict(org))
        return None
    
    def resolve_my_webhooks(self, info):
        request = info.context.get('request')
        if request and hasattr(request, 'organization'):
            org = request.organization
            webhooks = Webhook.query.filter_by(organization_id=org.id).all()
            return [WebhookType(**model_to_dict(w)) for w in webhooks]
        return []
    
    def resolve_my_webhook_deliveries(self, info):
        request = info.context.get('request')
        if request and hasattr(request, 'organization'):
            org = request.organization
            webhook_ids = [w.id for w in Webhook.query.filter_by(organization_id=org.id).all()]
            deliveries = WebhookDelivery.query.filter(WebhookDelivery.webhook_id.in_(webhook_ids)).all()
            return [WebhookDeliveryType(**model_to_dict(d)) for d in deliveries]
        return []

# Mutation Root
class Mutation(ObjectType):
    create_product = CreateProduct.Field()
    update_product_inventory = UpdateProductInventory.Field()
    create_purchase_order = CreatePurchaseOrder.Field()
    update_purchase_order_status = UpdatePurchaseOrderStatus.Field()
    create_batch_recall = CreateBatchRecall.Field()

# Create the schema
schema = Schema(query=Query, mutation=Mutation)

