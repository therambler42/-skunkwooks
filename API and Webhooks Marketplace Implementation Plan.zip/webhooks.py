from flask import Blueprint, request, jsonify
from src.models.marketplace import db, Webhook, WebhookDelivery
from src.auth import require_api_key, limiter
import secrets

# Create webhook management blueprint
webhook_bp = Blueprint('webhooks', __name__)

@webhook_bp.route('/webhooks', methods=['GET'])
@require_api_key
def list_webhooks():
    """List webhooks for the authenticated organization"""
    try:
        org = request.organization
        webhooks = Webhook.query.filter_by(organization_id=org.id).all()
        
        return jsonify({
            'webhooks': [webhook.to_dict() for webhook in webhooks]
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@webhook_bp.route('/webhooks', methods=['POST'])
@require_api_key
@limiter.limit("10 per hour")
def create_webhook():
    """Create a new webhook for the authenticated organization"""
    try:
        data = request.get_json()
        org = request.organization
        
        if not data or not data.get('event_type') or not data.get('endpoint_url'):
            return jsonify({'error': 'event_type and endpoint_url are required'}), 400
        
        # Validate event type
        valid_events = ['InventoryUpdated', 'PurchaseOrderStatus', 'BatchRecall']
        if data['event_type'] not in valid_events:
            return jsonify({'error': f'Invalid event_type. Must be one of: {valid_events}'}), 400
        
        # Check if webhook already exists for this event type
        existing = Webhook.query.filter_by(
            organization_id=org.id,
            event_type=data['event_type']
        ).first()
        if existing:
            return jsonify({'error': f'Webhook for {data["event_type"]} already exists'}), 409
        
        # Generate webhook secret
        webhook_secret = secrets.token_urlsafe(32)
        
        # Create webhook
        webhook = Webhook(
            organization_id=org.id,
            event_type=data['event_type'],
            endpoint_url=data['endpoint_url'],
            secret=webhook_secret,
            is_active=data.get('is_active', True)
        )
        db.session.add(webhook)
        db.session.commit()
        
        return jsonify({
            'id': webhook.id,
            'event_type': webhook.event_type,
            'endpoint_url': webhook.endpoint_url,
            'secret': webhook_secret,  # Only return secret on creation
            'is_active': webhook.is_active,
            'created_at': webhook.created_at.isoformat()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@webhook_bp.route('/webhooks/<int:webhook_id>', methods=['PUT'])
@require_api_key
def update_webhook(webhook_id):
    """Update a webhook"""
    try:
        data = request.get_json()
        org = request.organization
        
        webhook = Webhook.query.filter_by(id=webhook_id, organization_id=org.id).first()
        if not webhook:
            return jsonify({'error': 'Webhook not found'}), 404
        
        # Update allowed fields
        if 'endpoint_url' in data:
            webhook.endpoint_url = data['endpoint_url']
        if 'is_active' in data:
            webhook.is_active = data['is_active']
        
        db.session.commit()
        
        return jsonify(webhook.to_dict())
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@webhook_bp.route('/webhooks/<int:webhook_id>', methods=['DELETE'])
@require_api_key
def delete_webhook(webhook_id):
    """Delete a webhook"""
    try:
        org = request.organization
        
        webhook = Webhook.query.filter_by(id=webhook_id, organization_id=org.id).first()
        if not webhook:
            return jsonify({'error': 'Webhook not found'}), 404
        
        db.session.delete(webhook)
        db.session.commit()
        
        return jsonify({'message': 'Webhook deleted successfully'})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@webhook_bp.route('/webhooks/<int:webhook_id>/regenerate-secret', methods=['POST'])
@require_api_key
@limiter.limit("5 per hour")
def regenerate_webhook_secret(webhook_id):
    """Regenerate webhook secret"""
    try:
        org = request.organization
        
        webhook = Webhook.query.filter_by(id=webhook_id, organization_id=org.id).first()
        if not webhook:
            return jsonify({'error': 'Webhook not found'}), 404
        
        # Generate new secret
        new_secret = secrets.token_urlsafe(32)
        webhook.secret = new_secret
        db.session.commit()
        
        return jsonify({
            'id': webhook.id,
            'secret': new_secret,
            'message': 'Webhook secret regenerated successfully'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@webhook_bp.route('/webhooks/<int:webhook_id>/deliveries', methods=['GET'])
@require_api_key
def list_webhook_deliveries(webhook_id):
    """List deliveries for a specific webhook"""
    try:
        org = request.organization
        
        webhook = Webhook.query.filter_by(id=webhook_id, organization_id=org.id).first()
        if not webhook:
            return jsonify({'error': 'Webhook not found'}), 404
        
        # Get pagination parameters
        page = request.args.get('page', 1, type=int)
        per_page = min(request.args.get('per_page', 20, type=int), 100)
        
        deliveries = WebhookDelivery.query.filter_by(webhook_id=webhook_id)\
            .order_by(WebhookDelivery.created_at.desc())\
            .paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'deliveries': [delivery.to_dict() for delivery in deliveries.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': deliveries.total,
                'pages': deliveries.pages
            }
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@webhook_bp.route('/webhooks/<int:webhook_id>/test', methods=['POST'])
@require_api_key
@limiter.limit("5 per hour")
def test_webhook(webhook_id):
    """Send a test webhook"""
    try:
        org = request.organization
        
        webhook = Webhook.query.filter_by(id=webhook_id, organization_id=org.id).first()
        if not webhook:
            return jsonify({'error': 'Webhook not found'}), 404
        
        # Create test event data based on webhook type
        test_data = {
            'InventoryUpdated': {
                'id': 'test_inv_123',
                'event_type': 'InventoryUpdated',
                'timestamp': '2025-06-08T03:30:00Z',
                'data': {
                    'product_id': 1,
                    'sku': 'TEST-SKU-001',
                    'name': 'Test Product',
                    'previous_count': 10,
                    'current_count': 15,
                    'change': 5
                }
            },
            'PurchaseOrderStatus': {
                'id': 'test_po_123',
                'event_type': 'PurchaseOrderStatus',
                'timestamp': '2025-06-08T03:30:00Z',
                'data': {
                    'order_id': 1,
                    'order_number': 'PO-TEST-001',
                    'supplier': 'Test Supplier',
                    'status': 'shipped',
                    'total_amount': 1000.00,
                    'updated_at': '2025-06-08T03:30:00Z'
                }
            },
            'BatchRecall': {
                'id': 'test_recall_123',
                'event_type': 'BatchRecall',
                'timestamp': '2025-06-08T03:30:00Z',
                'data': {
                    'recall_id': 1,
                    'batch_number': 'BATCH-TEST-001',
                    'product_id': 1,
                    'reason': 'Test recall for webhook testing',
                    'severity': 'low',
                    'affected_quantity': 100,
                    'created_at': '2025-06-08T03:30:00Z'
                }
            }
        }
        
        event_data = test_data.get(webhook.event_type)
        if not event_data:
            return jsonify({'error': 'Invalid webhook event type'}), 400
        
        # Send test webhook
        from src.webhook_service import WebhookService
        success, status_code = WebhookService.send_webhook(webhook, event_data)
        
        return jsonify({
            'success': success,
            'status_code': status_code,
            'message': 'Test webhook sent successfully' if success else 'Test webhook failed'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Event trigger endpoints (for testing purposes)
@webhook_bp.route('/events/inventory-updated', methods=['POST'])
@require_api_key
def trigger_inventory_updated():
    """Trigger InventoryUpdated webhook event"""
    try:
        data = request.get_json()
        
        if not data or not data.get('product_id'):
            return jsonify({'error': 'product_id is required'}), 400
        
        from src.models.marketplace import Product
        product = Product.query.get(data['product_id'])
        if not product:
            return jsonify({'error': 'Product not found'}), 404
        
        # Update inventory if new count provided
        if 'new_count' in data:
            previous_count = product.inventory_count
            product.inventory_count = data['new_count']
            db.session.commit()
            
            # Trigger webhook
            from src.webhook_service import WebhookService
            product_data = product.to_dict()
            product_data['previous_count'] = previous_count
            results = WebhookService.trigger_inventory_updated(product_data)
            
            return jsonify({
                'message': 'InventoryUpdated event triggered',
                'webhook_results': results
            })
        else:
            return jsonify({'error': 'new_count is required'}), 400
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@webhook_bp.route('/events/purchase-order-status', methods=['POST'])
@require_api_key
def trigger_purchase_order_status():
    """Trigger PurchaseOrderStatus webhook event"""
    try:
        data = request.get_json()
        
        if not data or not data.get('order_id'):
            return jsonify({'error': 'order_id is required'}), 400
        
        from src.models.marketplace import PurchaseOrder
        order = PurchaseOrder.query.get(data['order_id'])
        if not order:
            return jsonify({'error': 'Purchase order not found'}), 404
        
        # Update status if provided
        if 'new_status' in data:
            order.status = data['new_status']
            db.session.commit()
        
        # Trigger webhook
        from src.webhook_service import WebhookService
        results = WebhookService.trigger_purchase_order_status(order.to_dict())
        
        return jsonify({
            'message': 'PurchaseOrderStatus event triggered',
            'webhook_results': results
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@webhook_bp.route('/events/batch-recall', methods=['POST'])
@require_api_key
def trigger_batch_recall():
    """Trigger BatchRecall webhook event"""
    try:
        data = request.get_json()
        
        required_fields = ['batch_number', 'product_id', 'reason', 'affected_quantity']
        for field in required_fields:
            if not data or not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        from src.models.marketplace import Product, BatchRecallEvent
        product = Product.query.get(data['product_id'])
        if not product:
            return jsonify({'error': 'Product not found'}), 404
        
        # Create batch recall event
        recall = BatchRecallEvent(
            batch_number=data['batch_number'],
            product_id=data['product_id'],
            reason=data['reason'],
            severity=data.get('severity', 'medium'),
            affected_quantity=data['affected_quantity']
        )
        db.session.add(recall)
        db.session.commit()
        
        # Trigger webhook
        from src.webhook_service import WebhookService
        results = WebhookService.trigger_batch_recall(recall.to_dict())
        
        return jsonify({
            'message': 'BatchRecall event triggered',
            'recall_id': recall.id,
            'webhook_results': results
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

