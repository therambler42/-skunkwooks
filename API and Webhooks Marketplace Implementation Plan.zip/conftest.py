import pytest
import json
from src.main import app
from src.models.marketplace import db

@pytest.fixture
def client():
    """Create a test client for the Flask application."""
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    app.config['WTF_CSRF_ENABLED'] = False
    # Disable rate limiting for tests
    app.config['RATELIMIT_ENABLED'] = False
    
    with app.test_client() as client:
        with app.app_context():
            db.create_all()
            yield client
            db.drop_all()

@pytest.fixture
def organization_data():
    """Sample organization data for testing."""
    return {
        'name': 'Test Organization',
        'email': 'test@example.com',
        'rate_limit': 1000
    }

@pytest.fixture
def api_key(client, organization_data):
    """Create an organization and return its API key."""
    response = client.post('/api/organizations', 
                          data=json.dumps(organization_data),
                          content_type='application/json')
    assert response.status_code == 201
    data = json.loads(response.data)
    return data['api_key']

@pytest.fixture
def auth_headers(api_key):
    """Return authorization headers with API key."""
    return {'Authorization': f'Bearer {api_key}'}

