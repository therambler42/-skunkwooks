import { useState, useEffect } from 'react'
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Alert, AlertDescription } from '@/components/ui/alert.jsx'
import { 
  Key, 
  Webhook, 
  Settings, 
  Plus, 
  Trash2, 
  RefreshCw, 
  Eye, 
  EyeOff,
  CheckCircle,
  XCircle,
  Clock,
  Activity
} from 'lucide-react'
import './App.css'

const API_BASE_URL = 'https://2j6h5i7c3q53.manus.space/api'

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <main className="container mx-auto px-4 py-8">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/api-keys" element={<ApiKeysPage />} />
            <Route path="/webhooks" element={<WebhooksPage />} />
            <Route path="/organization" element={<OrganizationPage />} />
          </Routes>
        </main>
      </div>
    </Router>
  )
}

function Navigation() {
  const location = useLocation()
  
  const navItems = [
    { path: '/', label: 'Dashboard', icon: Activity },
    { path: '/api-keys', label: 'API Keys', icon: Key },
    { path: '/webhooks', label: 'Webhooks', icon: Webhook },
    { path: '/organization', label: 'Organization', icon: Settings },
  ]

  return (
    <nav className="bg-white shadow-sm border-b">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-8">
            <h1 className="text-xl font-bold text-gray-900">
              API & Webhooks Marketplace
            </h1>
            <div className="flex space-x-4">
              {navItems.map(({ path, label, icon: Icon }) => (
                <Link
                  key={path}
                  to={path}
                  className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    location.pathname === path
                      ? 'bg-blue-100 text-blue-700'
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{label}</span>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </nav>
  )
}

function Dashboard() {
  const [stats, setStats] = useState({
    apiKeys: 0,
    webhooks: 0,
    deliveries: 0,
    successRate: 0
  })
  const [apiKey, setApiKey] = useState('')

  useEffect(() => {
    const savedApiKey = localStorage.getItem('apiKey')
    if (savedApiKey) {
      setApiKey(savedApiKey)
      fetchStats(savedApiKey)
    }
  }, [])

  const fetchStats = async (key) => {
    try {
      const headers = { 'Authorization': `Bearer ${key}` }
      
      const [keysRes, webhooksRes] = await Promise.all([
        fetch(`${API_BASE_URL}/api-keys`, { headers }),
        fetch(`${API_BASE_URL}/webhooks`, { headers })
      ])
      
      if (keysRes.ok && webhooksRes.ok) {
        const keysData = await keysRes.json()
        const webhooksData = await webhooksRes.json()
        
        setStats({
          apiKeys: keysData.api_keys?.length || 0,
          webhooks: webhooksData.webhooks?.length || 0,
          deliveries: 0, // Would need additional endpoint
          successRate: 95 // Mock data
        })
      }
    } catch (error) {
      console.error('Failed to fetch stats:', error)
    }
  }

  const handleApiKeySubmit = (e) => {
    e.preventDefault()
    localStorage.setItem('apiKey', apiKey)
    fetchStats(apiKey)
  }

  if (!localStorage.getItem('apiKey')) {
    return (
      <div className="max-w-md mx-auto mt-16">
        <Card>
          <CardHeader>
            <CardTitle>Welcome to API & Webhooks Admin</CardTitle>
            <CardDescription>
              Enter your API key to get started
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleApiKeySubmit} className="space-y-4">
              <div>
                <Label htmlFor="apiKey">API Key</Label>
                <Input
                  id="apiKey"
                  type="password"
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  placeholder="Enter your API key"
                  required
                />
              </div>
              <Button type="submit" className="w-full">
                Connect
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold text-gray-900">Dashboard</h2>
        <Button
          variant="outline"
          onClick={() => {
            localStorage.removeItem('apiKey')
            window.location.reload()
          }}
        >
          Disconnect
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">API Keys</CardTitle>
            <Key className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.apiKeys}</div>
            <p className="text-xs text-muted-foreground">
              Active API keys
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Webhooks</CardTitle>
            <Webhook className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.webhooks}</div>
            <p className="text-xs text-muted-foreground">
              Configured webhooks
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Deliveries</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.deliveries}</div>
            <p className="text-xs text-muted-foreground">
              Total webhook deliveries
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.successRate}%</div>
            <p className="text-xs text-muted-foreground">
              Webhook delivery success
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function ApiKeysPage() {
  const [apiKeys, setApiKeys] = useState([])
  const [loading, setLoading] = useState(true)
  const [showCreateForm, setShowCreateForm] = useState(false)
  const [newKeyName, setNewKeyName] = useState('')
  const [newKeyRateLimit, setNewKeyRateLimit] = useState(1000)
  const [visibleKeys, setVisibleKeys] = useState(new Set())

  useEffect(() => {
    fetchApiKeys()
  }, [])

  const fetchApiKeys = async () => {
    try {
      const apiKey = localStorage.getItem('apiKey')
      const response = await fetch(`${API_BASE_URL}/api-keys`, {
        headers: { 'Authorization': `Bearer ${apiKey}` }
      })
      
      if (response.ok) {
        const data = await response.json()
        setApiKeys(data.api_keys || [])
      }
    } catch (error) {
      console.error('Failed to fetch API keys:', error)
    } finally {
      setLoading(false)
    }
  }

  const createApiKey = async (e) => {
    e.preventDefault()
    try {
      const apiKey = localStorage.getItem('apiKey')
      const response = await fetch(`${API_BASE_URL}/api-keys`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          name: newKeyName,
          rate_limit: newKeyRateLimit
        })
      })
      
      if (response.ok) {
        setNewKeyName('')
        setNewKeyRateLimit(1000)
        setShowCreateForm(false)
        fetchApiKeys()
      }
    } catch (error) {
      console.error('Failed to create API key:', error)
    }
  }

  const deleteApiKey = async (keyId) => {
    if (!confirm('Are you sure you want to delete this API key?')) return
    
    try {
      const apiKey = localStorage.getItem('apiKey')
      const response = await fetch(`${API_BASE_URL}/api-keys/${keyId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${apiKey}` }
      })
      
      if (response.ok) {
        fetchApiKeys()
      }
    } catch (error) {
      console.error('Failed to delete API key:', error)
    }
  }

  const toggleKeyVisibility = (keyId) => {
    const newVisible = new Set(visibleKeys)
    if (newVisible.has(keyId)) {
      newVisible.delete(keyId)
    } else {
      newVisible.add(keyId)
    }
    setVisibleKeys(newVisible)
  }

  if (loading) {
    return <div className="text-center py-8">Loading...</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold text-gray-900">API Keys</h2>
        <Button onClick={() => setShowCreateForm(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Create API Key
        </Button>
      </div>

      {showCreateForm && (
        <Card>
          <CardHeader>
            <CardTitle>Create New API Key</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={createApiKey} className="space-y-4">
              <div>
                <Label htmlFor="keyName">Name</Label>
                <Input
                  id="keyName"
                  value={newKeyName}
                  onChange={(e) => setNewKeyName(e.target.value)}
                  placeholder="API Key Name"
                  required
                />
              </div>
              <div>
                <Label htmlFor="rateLimit">Rate Limit (requests per hour)</Label>
                <Input
                  id="rateLimit"
                  type="number"
                  value={newKeyRateLimit}
                  onChange={(e) => setNewKeyRateLimit(parseInt(e.target.value))}
                  min="1"
                  max="10000"
                />
              </div>
              <div className="flex space-x-2">
                <Button type="submit">Create</Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowCreateForm(false)}
                >
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4">
        {apiKeys.map((key) => (
          <Card key={key.id}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <h3 className="font-semibold">{key.name}</h3>
                    <Badge variant={key.is_active ? 'default' : 'secondary'}>
                      {key.is_active ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                  <div className="flex items-center space-x-2">
                    <code className="bg-gray-100 px-2 py-1 rounded text-sm">
                      {visibleKeys.has(key.id) ? key.key : '••••••••••••••••'}
                    </code>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => toggleKeyVisibility(key.id)}
                    >
                      {visibleKeys.has(key.id) ? (
                        <EyeOff className="w-4 h-4" />
                      ) : (
                        <Eye className="w-4 h-4" />
                      )}
                    </Button>
                  </div>
                  <p className="text-sm text-gray-600">
                    Rate limit: {key.rate_limit} requests/hour
                  </p>
                  <p className="text-sm text-gray-600">
                    Created: {new Date(key.created_at).toLocaleDateString()}
                  </p>
                </div>
                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => deleteApiKey(key.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

function WebhooksPage() {
  const [webhooks, setWebhooks] = useState([])
  const [loading, setLoading] = useState(true)
  const [showCreateForm, setShowCreateForm] = useState(false)
  const [newWebhook, setNewWebhook] = useState({
    event_type: 'InventoryUpdated',
    endpoint_url: ''
  })

  useEffect(() => {
    fetchWebhooks()
  }, [])

  const fetchWebhooks = async () => {
    try {
      const apiKey = localStorage.getItem('apiKey')
      const response = await fetch(`${API_BASE_URL}/webhooks`, {
        headers: { 'Authorization': `Bearer ${apiKey}` }
      })
      
      if (response.ok) {
        const data = await response.json()
        setWebhooks(data.webhooks || [])
      }
    } catch (error) {
      console.error('Failed to fetch webhooks:', error)
    } finally {
      setLoading(false)
    }
  }

  const createWebhook = async (e) => {
    e.preventDefault()
    try {
      const apiKey = localStorage.getItem('apiKey')
      const response = await fetch(`${API_BASE_URL}/webhooks`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify(newWebhook)
      })
      
      if (response.ok) {
        setNewWebhook({ event_type: 'InventoryUpdated', endpoint_url: '' })
        setShowCreateForm(false)
        fetchWebhooks()
      }
    } catch (error) {
      console.error('Failed to create webhook:', error)
    }
  }

  const testWebhook = async (webhookId) => {
    try {
      const apiKey = localStorage.getItem('apiKey')
      const response = await fetch(`${API_BASE_URL}/webhooks/${webhookId}/test`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${apiKey}` }
      })
      
      if (response.ok) {
        const data = await response.json()
        alert(`Test webhook ${data.success ? 'succeeded' : 'failed'}`)
      }
    } catch (error) {
      console.error('Failed to test webhook:', error)
    }
  }

  const deleteWebhook = async (webhookId) => {
    if (!confirm('Are you sure you want to delete this webhook?')) return
    
    try {
      const apiKey = localStorage.getItem('apiKey')
      const response = await fetch(`${API_BASE_URL}/webhooks/${webhookId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${apiKey}` }
      })
      
      if (response.ok) {
        fetchWebhooks()
      }
    } catch (error) {
      console.error('Failed to delete webhook:', error)
    }
  }

  if (loading) {
    return <div className="text-center py-8">Loading...</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold text-gray-900">Webhooks</h2>
        <Button onClick={() => setShowCreateForm(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Create Webhook
        </Button>
      </div>

      {showCreateForm && (
        <Card>
          <CardHeader>
            <CardTitle>Create New Webhook</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={createWebhook} className="space-y-4">
              <div>
                <Label htmlFor="eventType">Event Type</Label>
                <select
                  id="eventType"
                  value={newWebhook.event_type}
                  onChange={(e) => setNewWebhook({ ...newWebhook, event_type: e.target.value })}
                  className="w-full p-2 border rounded-md"
                >
                  <option value="InventoryUpdated">Inventory Updated</option>
                  <option value="PurchaseOrderStatus">Purchase Order Status</option>
                  <option value="BatchRecall">Batch Recall</option>
                </select>
              </div>
              <div>
                <Label htmlFor="endpointUrl">Endpoint URL</Label>
                <Input
                  id="endpointUrl"
                  value={newWebhook.endpoint_url}
                  onChange={(e) => setNewWebhook({ ...newWebhook, endpoint_url: e.target.value })}
                  placeholder="https://your-app.com/webhooks"
                  required
                />
              </div>
              <div className="flex space-x-2">
                <Button type="submit">Create</Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowCreateForm(false)}
                >
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4">
        {webhooks.map((webhook) => (
          <Card key={webhook.id}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <h3 className="font-semibold">{webhook.event_type}</h3>
                    <Badge variant={webhook.is_active ? 'default' : 'secondary'}>
                      {webhook.is_active ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600">{webhook.endpoint_url}</p>
                  <p className="text-sm text-gray-600">
                    Created: {new Date(webhook.created_at).toLocaleDateString()}
                  </p>
                </div>
                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => testWebhook(webhook.id)}
                  >
                    <RefreshCw className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => deleteWebhook(webhook.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

function OrganizationPage() {
  const [organization, setOrganization] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchOrganization()
  }, [])

  const fetchOrganization = async () => {
    try {
      const apiKey = localStorage.getItem('apiKey')
      const response = await fetch(`${API_BASE_URL}/organization`, {
        headers: { 'Authorization': `Bearer ${apiKey}` }
      })
      
      if (response.ok) {
        const data = await response.json()
        setOrganization(data)
      }
    } catch (error) {
      console.error('Failed to fetch organization:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return <div className="text-center py-8">Loading...</div>
  }

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold text-gray-900">Organization</h2>
      
      {organization && (
        <Card>
          <CardHeader>
            <CardTitle>Organization Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Name</Label>
              <p className="text-lg">{organization.name}</p>
            </div>
            <div>
              <Label>Email</Label>
              <p className="text-lg">{organization.email}</p>
            </div>
            <div>
              <Label>Created</Label>
              <p className="text-lg">{new Date(organization.created_at).toLocaleDateString()}</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

export default App

