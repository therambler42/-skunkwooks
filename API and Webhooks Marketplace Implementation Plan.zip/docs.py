from flask import Blueprint, render_template_string, jsonify
from src.graphql_schema import schema

# Create documentation blueprint
docs_bp = Blueprint('docs', __name__)

# GraphQL Voyager HTML template
VOYAGER_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>GraphQL Voyager - API Schema</title>
    <style>
        body {
            height: 100%;
            margin: 0;
            width: 100%;
            overflow: hidden;
        }
        #voyager {
            height: 100vh;
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/graphql-voyager@1.0.0-rc.31/dist/voyager.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/graphql-voyager@1.0.0-rc.31/dist/voyager.css" />
</head>
<body>
    <div id="voyager">Loading...</div>
    <script>
        function introspectionProvider(introspectionQuery) {
            return fetch('/api/graphql/public', {
                method: 'post',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({query: introspectionQuery}),
            }).then(function (response) {
                return response.text();
            }).then(function (responseBody) {
                try {
                    return JSON.parse(responseBody);
                } catch (error) {
                    return responseBody;
                }
            });
        }

        GraphQLVoyager.init(document.getElementById('voyager'), {
            introspection: introspectionProvider
        });
    </script>
</body>
</html>
"""

API_DOCS_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>API Documentation - API & Webhooks Marketplace</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f8f9fa;
        }
        .container {
            background: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1, h2, h3 {
            color: #2c3e50;
        }
        h1 {
            border-bottom: 3px solid #3498db;
            padding-bottom: 10px;
        }
        h2 {
            margin-top: 30px;
            color: #34495e;
        }
        .endpoint {
            background: #f8f9fa;
            border-left: 4px solid #3498db;
            padding: 15px;
            margin: 15px 0;
            border-radius: 4px;
        }
        .method {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-weight: bold;
            font-size: 12px;
            margin-right: 10px;
        }
        .get { background: #27ae60; color: white; }
        .post { background: #e74c3c; color: white; }
        .put { background: #f39c12; color: white; }
        .delete { background: #e67e22; color: white; }
        code {
            background: #ecf0f1;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: 'Monaco', 'Consolas', monospace;
        }
        pre {
            background: #2c3e50;
            color: #ecf0f1;
            padding: 20px;
            border-radius: 6px;
            overflow-x: auto;
        }
        .nav {
            background: #34495e;
            padding: 15px;
            margin: -40px -40px 30px -40px;
            border-radius: 8px 8px 0 0;
        }
        .nav a {
            color: #ecf0f1;
            text-decoration: none;
            margin-right: 20px;
            font-weight: 500;
        }
        .nav a:hover {
            color: #3498db;
        }
        .auth-note {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            padding: 15px;
            border-radius: 4px;
            margin: 20px 0;
        }
        .example {
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            padding: 15px;
            border-radius: 4px;
            margin: 10px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="nav">
            <a href="/docs/api">API Documentation</a>
            <a href="/docs/webhooks">Webhook Documentation</a>
            <a href="/docs/voyager">GraphQL Schema Visualizer</a>
            <a href="/api/graphql/public">GraphQL Playground</a>
        </div>

        <h1>API Documentation</h1>
        <p>Welcome to the API & Webhooks Marketplace API documentation. This API provides comprehensive access to manage organizations, API keys, webhooks, and marketplace data through both REST and GraphQL endpoints.</p>

        <div class="auth-note">
            <strong>Authentication:</strong> Most endpoints require an API key. Include your API key in the <code>Authorization</code> header as <code>Bearer YOUR_API_KEY</code> or in the <code>X-API-Key</code> header.
        </div>

        <h2>Base URL</h2>
        <p><code>http://127.0.0.1:5000/api</code></p>

        <h2>Rate Limiting</h2>
        <p>API requests are rate limited based on your organization's plan. Default limits:</p>
        <ul>
            <li>Authenticated requests: 1000 requests per hour</li>
            <li>Public endpoints: 100 requests per hour</li>
        </ul>

        <h2>Organization Management</h2>

        <div class="endpoint">
            <span class="method post">POST</span>
            <strong>/organizations</strong>
            <p>Create a new organization and receive an initial API key.</p>
            <div class="example">
                <strong>Request Body:</strong>
                <pre>{
  "name": "Your Organization",
  "email": "admin@yourorg.com",
  "rate_limit": 1000
}</pre>
            </div>
        </div>

        <div class="endpoint">
            <span class="method get">GET</span>
            <strong>/organization</strong>
            <p>Get current organization details. Requires authentication.</p>
        </div>

        <div class="endpoint">
            <span class="method put">PUT</span>
            <strong>/organization</strong>
            <p>Update organization details. Requires authentication.</p>
        </div>

        <h2>API Key Management</h2>

        <div class="endpoint">
            <span class="method get">GET</span>
            <strong>/api-keys</strong>
            <p>List all API keys for your organization. Requires authentication.</p>
        </div>

        <div class="endpoint">
            <span class="method post">POST</span>
            <strong>/api-keys</strong>
            <p>Create a new API key. Requires authentication.</p>
            <div class="example">
                <strong>Request Body:</strong>
                <pre>{
  "name": "Production API Key",
  "rate_limit": 5000
}</pre>
            </div>
        </div>

        <div class="endpoint">
            <span class="method put">PUT</span>
            <strong>/api-keys/{id}</strong>
            <p>Update an API key. Requires authentication.</p>
        </div>

        <div class="endpoint">
            <span class="method delete">DELETE</span>
            <strong>/api-keys/{id}</strong>
            <p>Delete an API key. Requires authentication.</p>
        </div>

        <h2>Webhook Management</h2>

        <div class="endpoint">
            <span class="method get">GET</span>
            <strong>/webhooks</strong>
            <p>List all webhooks for your organization. Requires authentication.</p>
        </div>

        <div class="endpoint">
            <span class="method post">POST</span>
            <strong>/webhooks</strong>
            <p>Create a new webhook. Requires authentication.</p>
            <div class="example">
                <strong>Request Body:</strong>
                <pre>{
  "event_type": "InventoryUpdated",
  "endpoint_url": "https://your-app.com/webhooks/inventory"
}</pre>
                <strong>Supported Event Types:</strong>
                <ul>
                    <li><code>InventoryUpdated</code> - Triggered when product inventory changes</li>
                    <li><code>PurchaseOrderStatus</code> - Triggered when purchase order status changes</li>
                    <li><code>BatchRecall</code> - Triggered when a batch recall is created</li>
                </ul>
            </div>
        </div>

        <div class="endpoint">
            <span class="method post">POST</span>
            <strong>/webhooks/{id}/test</strong>
            <p>Send a test webhook to verify endpoint connectivity. Requires authentication.</p>
        </div>

        <div class="endpoint">
            <span class="method get">GET</span>
            <strong>/webhooks/{id}/deliveries</strong>
            <p>Get webhook delivery history. Requires authentication.</p>
        </div>

        <h2>GraphQL API</h2>

        <div class="endpoint">
            <span class="method get">GET</span>
            <span class="method post">POST</span>
            <strong>/graphql</strong>
            <p>GraphQL endpoint with full access. Requires authentication.</p>
        </div>

        <div class="endpoint">
            <span class="method get">GET</span>
            <span class="method post">POST</span>
            <strong>/graphql/public</strong>
            <p>Public GraphQL endpoint with read-only access. No authentication required.</p>
        </div>

        <h2>Event Triggers (Testing)</h2>

        <div class="endpoint">
            <span class="method post">POST</span>
            <strong>/events/inventory-updated</strong>
            <p>Manually trigger an InventoryUpdated webhook event. Requires authentication.</p>
            <div class="example">
                <strong>Request Body:</strong>
                <pre>{
  "product_id": 1,
  "new_count": 150
}</pre>
            </div>
        </div>

        <div class="endpoint">
            <span class="method post">POST</span>
            <strong>/events/purchase-order-status</strong>
            <p>Manually trigger a PurchaseOrderStatus webhook event. Requires authentication.</p>
            <div class="example">
                <strong>Request Body:</strong>
                <pre>{
  "order_id": 1,
  "new_status": "shipped"
}</pre>
            </div>
        </div>

        <div class="endpoint">
            <span class="method post">POST</span>
            <strong>/events/batch-recall</strong>
            <p>Manually trigger a BatchRecall webhook event. Requires authentication.</p>
            <div class="example">
                <strong>Request Body:</strong>
                <pre>{
  "batch_number": "BATCH-2025-001",
  "product_id": 1,
  "reason": "Quality control issue",
  "severity": "high",
  "affected_quantity": 500
}</pre>
            </div>
        </div>

        <h2>Error Responses</h2>
        <p>The API uses standard HTTP status codes and returns JSON error responses:</p>
        <div class="example">
            <pre>{
  "error": "Error description",
  "code": "ERROR_CODE"
}</pre>
        </div>

        <h2>Getting Started</h2>
        <ol>
            <li>Create an organization by POSTing to <code>/organizations</code></li>
            <li>Save the returned API key</li>
            <li>Use the API key to authenticate subsequent requests</li>
            <li>Set up webhooks for the events you want to monitor</li>
            <li>Start making GraphQL queries or using the REST endpoints</li>
        </ol>
    </div>
</body>
</html>
"""

WEBHOOK_DOCS_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Webhook Documentation - API & Webhooks Marketplace</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f8f9fa;
        }
        .container {
            background: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1, h2, h3 {
            color: #2c3e50;
        }
        h1 {
            border-bottom: 3px solid #3498db;
            padding-bottom: 10px;
        }
        h2 {
            margin-top: 30px;
            color: #34495e;
        }
        .webhook-event {
            background: #f8f9fa;
            border-left: 4px solid #e74c3c;
            padding: 15px;
            margin: 15px 0;
            border-radius: 4px;
        }
        code {
            background: #ecf0f1;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: 'Monaco', 'Consolas', monospace;
        }
        pre {
            background: #2c3e50;
            color: #ecf0f1;
            padding: 20px;
            border-radius: 6px;
            overflow-x: auto;
        }
        .nav {
            background: #34495e;
            padding: 15px;
            margin: -40px -40px 30px -40px;
            border-radius: 8px 8px 0 0;
        }
        .nav a {
            color: #ecf0f1;
            text-decoration: none;
            margin-right: 20px;
            font-weight: 500;
        }
        .nav a:hover {
            color: #3498db;
        }
        .security-note {
            background: #d4edda;
            border: 1px solid #c3e6cb;
            padding: 15px;
            border-radius: 4px;
            margin: 20px 0;
        }
        .example {
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            padding: 15px;
            border-radius: 4px;
            margin: 10px 0;
        }
        .severity {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-weight: bold;
            font-size: 12px;
            margin-left: 10px;
        }
        .severity.low { background: #27ae60; color: white; }
        .severity.medium { background: #f39c12; color: white; }
        .severity.high { background: #e74c3c; color: white; }
        .severity.critical { background: #8e44ad; color: white; }
    </style>
</head>
<body>
    <div class="container">
        <div class="nav">
            <a href="/docs/api">API Documentation</a>
            <a href="/docs/webhooks">Webhook Documentation</a>
            <a href="/docs/voyager">GraphQL Schema Visualizer</a>
            <a href="/api/graphql/public">GraphQL Playground</a>
        </div>

        <h1>Webhook Documentation</h1>
        <p>Webhooks allow your application to receive real-time notifications when specific events occur in the API & Webhooks Marketplace. This guide explains how to set up and handle webhook events.</p>

        <div class="security-note">
            <strong>Security:</strong> All webhook payloads are signed with HMAC-SHA256 using your webhook secret. Always verify the signature before processing webhook data.
        </div>

        <h2>Webhook Setup</h2>
        <ol>
            <li>Create a webhook endpoint in your application that can receive POST requests</li>
            <li>Use the API to register your webhook URL for specific event types</li>
            <li>Implement signature verification for security</li>
            <li>Handle webhook events and respond with appropriate HTTP status codes</li>
        </ol>

        <h2>Webhook Security</h2>
        <p>Each webhook request includes a signature in the <code>X-Webhook-Signature</code> header. Verify this signature to ensure the request is authentic:</p>
        <div class="example">
            <strong>Python Example:</strong>
            <pre>import hmac
import hashlib

def verify_webhook_signature(payload, signature, secret):
    expected_signature = hmac.new(
        secret.encode('utf-8'),
        payload.encode('utf-8'),
        hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(f"sha256={expected_signature}", signature)</pre>
        </div>

        <h2>Webhook Headers</h2>
        <p>Each webhook request includes these headers:</p>
        <ul>
            <li><code>Content-Type: application/json</code></li>
            <li><code>X-Webhook-Signature: sha256=...</code> - HMAC signature</li>
            <li><code>X-Event-Type: EventName</code> - The type of event</li>
            <li><code>User-Agent: API-Webhooks-Marketplace/1.0</code></li>
        </ul>

        <h2>Response Requirements</h2>
        <p>Your webhook endpoint should:</p>
        <ul>
            <li>Respond with HTTP status 200-299 for successful processing</li>
            <li>Respond within 30 seconds</li>
            <li>Handle duplicate events idempotently (use the event ID)</li>
            <li>Return appropriate error status codes for failures</li>
        </ul>

        <h2>Supported Events</h2>

        <div class="webhook-event">
            <h3>InventoryUpdated</h3>
            <p>Triggered when product inventory levels change.</p>
            <div class="example">
                <strong>Payload Example:</strong>
                <pre>{
  "id": "inv_123_1641234567.89",
  "event_type": "InventoryUpdated",
  "timestamp": "2025-06-08T10:30:00Z",
  "data": {
    "product_id": 123,
    "sku": "PROD-001",
    "name": "Sample Product",
    "previous_count": 100,
    "current_count": 85,
    "change": -15
  }
}</pre>
            </div>
            <strong>Use Cases:</strong>
            <ul>
                <li>Update inventory displays in real-time</li>
                <li>Trigger reorder alerts when stock is low</li>
                <li>Sync inventory across multiple systems</li>
            </ul>
        </div>

        <div class="webhook-event">
            <h3>PurchaseOrderStatus</h3>
            <p>Triggered when purchase order status changes.</p>
            <div class="example">
                <strong>Payload Example:</strong>
                <pre>{
  "id": "po_456_1641234567.89",
  "event_type": "PurchaseOrderStatus",
  "timestamp": "2025-06-08T10:30:00Z",
  "data": {
    "order_id": 456,
    "order_number": "PO-2025-001",
    "supplier": "ABC Supplier Inc.",
    "status": "shipped",
    "total_amount": 15000.00,
    "updated_at": "2025-06-08T10:30:00Z"
  }
}</pre>
            </div>
            <strong>Status Values:</strong>
            <ul>
                <li><code>pending</code> - Order created but not yet approved</li>
                <li><code>approved</code> - Order approved and sent to supplier</li>
                <li><code>shipped</code> - Order shipped by supplier</li>
                <li><code>delivered</code> - Order received and confirmed</li>
                <li><code>cancelled</code> - Order cancelled</li>
            </ul>
        </div>

        <div class="webhook-event">
            <h3>BatchRecall</h3>
            <p>Triggered when a product batch recall is initiated.</p>
            <div class="example">
                <strong>Payload Example:</strong>
                <pre>{
  "id": "recall_789_1641234567.89",
  "event_type": "BatchRecall",
  "timestamp": "2025-06-08T10:30:00Z",
  "data": {
    "recall_id": 789,
    "batch_number": "BATCH-2025-001",
    "product_id": 123,
    "reason": "Quality control issue detected",
    "severity": "high",
    "affected_quantity": 500,
    "created_at": "2025-06-08T10:30:00Z"
  }
}</pre>
            </div>
            <strong>Severity Levels:</strong>
            <ul>
                <li><span class="severity low">low</span> - Minor issue, voluntary recall</li>
                <li><span class="severity medium">medium</span> - Moderate risk, recommended recall</li>
                <li><span class="severity high">high</span> - Significant risk, urgent recall</li>
                <li><span class="severity critical">critical</span> - Immediate danger, emergency recall</li>
            </ul>
        </div>

        <h2>Webhook Delivery</h2>
        <p>The system attempts to deliver webhooks with the following behavior:</p>
        <ul>
            <li>Initial delivery attempt immediately after event occurs</li>
            <li>Retry failed deliveries with exponential backoff</li>
            <li>Maximum of 3 delivery attempts</li>
            <li>Delivery history is available via the API</li>
        </ul>

        <h2>Testing Webhooks</h2>
        <p>You can test your webhook endpoints using:</p>
        <ul>
            <li>The test webhook feature in the admin interface</li>
            <li>Manual event triggers via the API</li>
            <li>Tools like ngrok for local development</li>
        </ul>

        <div class="example">
            <strong>Testing with cURL:</strong>
            <pre>curl -X POST http://127.0.0.1:5000/api/webhooks/1/test \\
  -H "Authorization: Bearer YOUR_API_KEY"</pre>
        </div>

        <h2>Best Practices</h2>
        <ul>
            <li><strong>Idempotency:</strong> Use the event ID to prevent duplicate processing</li>
            <li><strong>Async Processing:</strong> Process webhooks asynchronously to respond quickly</li>
            <li><strong>Error Handling:</strong> Implement proper error handling and logging</li>
            <li><strong>Monitoring:</strong> Monitor webhook delivery success rates</li>
            <li><strong>Security:</strong> Always verify webhook signatures</li>
            <li><strong>Timeouts:</strong> Set appropriate timeouts for webhook processing</li>
        </ul>

        <h2>Troubleshooting</h2>
        <h3>Common Issues</h3>
        <ul>
            <li><strong>Timeouts:</strong> Ensure your endpoint responds within 30 seconds</li>
            <li><strong>SSL Errors:</strong> Use valid SSL certificates for HTTPS endpoints</li>
            <li><strong>Signature Verification:</strong> Check that you're using the correct secret</li>
            <li><strong>Duplicate Events:</strong> Implement idempotency using event IDs</li>
        </ul>

        <h3>Debugging</h3>
        <p>Use the webhook delivery history API to debug failed deliveries:</p>
        <div class="example">
            <pre>GET /api/webhooks/{webhook_id}/deliveries</pre>
        </div>
    </div>
</body>
</html>
"""

@docs_bp.route('/docs/voyager')
def voyager():
    """GraphQL Voyager schema visualization"""
    return render_template_string(VOYAGER_TEMPLATE)

@docs_bp.route('/docs/api')
def api_docs():
    """API documentation page"""
    return render_template_string(API_DOCS_TEMPLATE)

@docs_bp.route('/docs/webhooks')
def webhook_docs():
    """Webhook documentation page"""
    return render_template_string(WEBHOOK_DOCS_TEMPLATE)

@docs_bp.route('/docs/schema.json')
def schema_json():
    """GraphQL schema in JSON format"""
    try:
        from graphql import get_introspection_query, execute
        
        # Get introspection query result
        introspection_query = get_introspection_query()
        result = execute(schema, introspection_query)
        
        if result.errors:
            return jsonify({'errors': [str(error) for error in result.errors]}), 500
        
        return jsonify(result.data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@docs_bp.route('/docs/schema.graphql')
def schema_sdl():
    """GraphQL schema in SDL format"""
    try:
        # Return a basic schema description since print_schema is not available
        sdl = """
# API & Webhooks Marketplace GraphQL Schema

type Query {
  # Product queries
  products: [Product]
  product(id: Int!): Product
  
  # Purchase Order queries
  purchaseOrders: [PurchaseOrder]
  purchaseOrder(id: Int!): PurchaseOrder
  
  # Batch Recall queries
  batchRecalls: [BatchRecall]
  batchRecall(id: Int!): BatchRecall
  
  # Organization queries (authenticated)
  myOrganization: Organization
  myWebhooks: [Webhook]
  myWebhookDeliveries: [WebhookDelivery]
}

type Mutation {
  createProduct(productData: ProductInput!): CreateProductPayload
  updateProductInventory(productId: Int!, newCount: Int!): UpdateProductInventoryPayload
  createPurchaseOrder(orderData: PurchaseOrderInput!): CreatePurchaseOrderPayload
  updatePurchaseOrderStatus(orderId: Int!, status: String!): UpdatePurchaseOrderStatusPayload
  createBatchRecall(recallData: BatchRecallInput!): CreateBatchRecallPayload
}

type Product {
  id: Int
  name: String
  sku: String
  price: Float
  inventoryCount: Int
  createdAt: String
}

type PurchaseOrder {
  id: Int
  orderNumber: String
  supplier: String
  status: String
  totalAmount: Float
  createdAt: String
  updatedAt: String
}

type BatchRecall {
  id: Int
  batchNumber: String
  productId: Int
  reason: String
  severity: String
  affectedQuantity: Int
  createdAt: String
}

type Organization {
  id: Int
  name: String
  email: String
  createdAt: String
}

type Webhook {
  id: Int
  organizationId: Int
  eventType: String
  endpointUrl: String
  secret: String
  isActive: Boolean
  createdAt: String
}

type WebhookDelivery {
  id: Int
  webhookId: Int
  eventId: String
  payload: String
  status: String
  responseCode: Int
  responseBody: String
  attempts: Int
  createdAt: String
  deliveredAt: String
}

input ProductInput {
  name: String!
  sku: String!
  price: Float!
  inventoryCount: Int = 0
}

input PurchaseOrderInput {
  orderNumber: String!
  supplier: String!
  totalAmount: Float!
  status: String = "pending"
}

input BatchRecallInput {
  batchNumber: String!
  productId: Int!
  reason: String!
  severity: String = "medium"
  affectedQuantity: Int!
}

type CreateProductPayload {
  product: Product
  success: Boolean
  message: String
}

type UpdateProductInventoryPayload {
  product: Product
  success: Boolean
  message: String
}

type CreatePurchaseOrderPayload {
  purchaseOrder: PurchaseOrder
  success: Boolean
  message: String
}

type UpdatePurchaseOrderStatusPayload {
  purchaseOrder: PurchaseOrder
  success: Boolean
  message: String
}

type CreateBatchRecallPayload {
  batchRecall: BatchRecall
  success: Boolean
  message: String
}
"""
        return sdl, 200, {'Content-Type': 'text/plain'}
    except Exception as e:
        return f"Error generating schema: {str(e)}", 500

