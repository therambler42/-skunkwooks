# API Usage Examples - API & Webhooks Marketplace

## Authentication

All authenticated endpoints require an API key in one of these formats:

```bash
# Bearer token in Authorization header
curl -H "Authorization: Bearer YOUR_API_KEY" ...

# X-API-Key header
curl -H "X-API-Key: YOUR_API_KEY" ...
```

## Organization Management

### Create Organization

```bash
curl -X POST https://2j6h5i7c3q53.manus.space/api/organizations \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Acme Corporation",
    "email": "admin@acme.com",
    "rate_limit": 5000
  }'
```

**Response:**
```json
{
  "api_key": {
    "id": 1,
    "key": "abc123...",
    "name": "Default API Key",
    "rate_limit": 5000
  },
  "organization": {
    "id": 1,
    "name": "Acme Corporation",
    "email": "admin@acme.com",
    "created_at": "2025-06-08T07:42:05"
  }
}
```

### Get Organization Details

```bash
curl -H "Authorization: Bearer YOUR_API_KEY" \
  https://2j6h5i7c3q53.manus.space/api/organization
```

## API Key Management

### List API Keys

```bash
curl -H "Authorization: Bearer YOUR_API_KEY" \
  https://2j6h5i7c3q53.manus.space/api/api-keys
```

### Create New API Key

```bash
curl -X POST https://2j6h5i7c3q53.manus.space/api/api-keys \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{
    "name": "Production API Key",
    "rate_limit": 10000
  }'
```

### Delete API Key

```bash
curl -X DELETE https://2j6h5i7c3q53.manus.space/api/api-keys/2 \
  -H "Authorization: Bearer YOUR_API_KEY"
```

## Webhook Management

### Create Webhook

```bash
# Inventory Updated Webhook
curl -X POST https://2j6h5i7c3q53.manus.space/api/webhooks \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{
    "event_type": "InventoryUpdated",
    "endpoint_url": "https://your-app.com/webhooks/inventory"
  }'

# Purchase Order Status Webhook
curl -X POST https://2j6h5i7c3q53.manus.space/api/webhooks \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{
    "event_type": "PurchaseOrderStatus",
    "endpoint_url": "https://your-app.com/webhooks/orders"
  }'

# Batch Recall Webhook
curl -X POST https://2j6h5i7c3q53.manus.space/api/webhooks \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{
    "event_type": "BatchRecall",
    "endpoint_url": "https://your-app.com/webhooks/recalls"
  }'
```

### List Webhooks

```bash
curl -H "Authorization: Bearer YOUR_API_KEY" \
  https://2j6h5i7c3q53.manus.space/api/webhooks
```

### Test Webhook

```bash
curl -X POST https://2j6h5i7c3q53.manus.space/api/webhooks/1/test \
  -H "Authorization: Bearer YOUR_API_KEY"
```

### Get Webhook Deliveries

```bash
curl -H "Authorization: Bearer YOUR_API_KEY" \
  https://2j6h5i7c3q53.manus.space/api/webhooks/1/deliveries
```

## GraphQL API

### Public Queries (No Authentication)

```bash
# Get all products
curl -X POST https://2j6h5i7c3q53.manus.space/api/graphql/public \
  -H "Content-Type: application/json" \
  -d '{
    "query": "{ products { id name sku price inventoryCount } }"
  }'

# Get specific product
curl -X POST https://2j6h5i7c3q53.manus.space/api/graphql/public \
  -H "Content-Type: application/json" \
  -d '{
    "query": "{ product(id: 1) { id name sku price description inventoryCount } }"
  }'

# Get purchase orders
curl -X POST https://2j6h5i7c3q53.manus.space/api/graphql/public \
  -H "Content-Type: application/json" \
  -d '{
    "query": "{ purchaseOrders { id status totalAmount createdAt } }"
  }'
```

### Authenticated Queries and Mutations

```bash
# Create product
curl -X POST https://2j6h5i7c3q53.manus.space/api/graphql \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{
    "query": "mutation { createProduct(productData: { name: \"Wireless Headphones\", sku: \"WH-001\", price: 99.99, description: \"High-quality wireless headphones\", inventoryCount: 50 }) { product { id name sku price } success message } }"
  }'

# Update product
curl -X POST https://2j6h5i7c3q53.manus.space/api/graphql \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{
    "query": "mutation { updateProduct(id: 1, productData: { price: 89.99, inventoryCount: 75 }) { product { id name price inventoryCount } success message } }"
  }'

# Create purchase order
curl -X POST https://2j6h5i7c3q53.manus.space/api/graphql \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{
    "query": "mutation { createPurchaseOrder(orderData: { productId: 1, quantity: 2, customerEmail: \"customer@example.com\" }) { order { id status totalAmount } success message } }"
  }'

# Update order status
curl -X POST https://2j6h5i7c3q53.manus.space/api/graphql \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{
    "query": "mutation { updateOrderStatus(id: 1, status: \"shipped\") { order { id status } success message } }"
  }'
```

## Event Triggers (Testing)

### Trigger Inventory Updated Event

```bash
curl -X POST https://2j6h5i7c3q53.manus.space/api/events/inventory-updated \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{
    "product_id": 1,
    "new_count": 25,
    "previous_count": 50
  }'
```

### Trigger Purchase Order Status Event

```bash
curl -X POST https://2j6h5i7c3q53.manus.space/api/events/purchase-order-status \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{
    "order_id": 1,
    "new_status": "delivered",
    "previous_status": "shipped"
  }'
```

### Trigger Batch Recall Event

```bash
curl -X POST https://2j6h5i7c3q53.manus.space/api/events/batch-recall \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{
    "batch_number": "BATCH-2025-001",
    "product_id": 1,
    "reason": "Quality control issue detected",
    "severity": "high",
    "affected_quantity": 100
  }'
```

## Webhook Endpoint Implementation

### Receiving Webhooks

Your webhook endpoint should:

1. **Verify the signature:**

```python
import hmac
import hashlib

def verify_webhook_signature(payload, signature, secret):
    expected_signature = hmac.new(
        secret.encode('utf-8'),
        payload.encode('utf-8'),
        hashlib.sha256
    ).hexdigest()
    expected_signature = f"sha256={expected_signature}"
    return hmac.compare_digest(expected_signature, signature)

# Flask example
from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/webhooks/inventory', methods=['POST'])
def handle_inventory_webhook():
    payload = request.get_data(as_text=True)
    signature = request.headers.get('X-Webhook-Signature')
    secret = 'your-webhook-secret'
    
    if not verify_webhook_signature(payload, signature, secret):
        return jsonify({'error': 'Invalid signature'}), 401
    
    data = request.get_json()
    
    # Process the inventory update
    print(f"Inventory updated for product {data['data']['product_id']}")
    print(f"New count: {data['data']['new_count']}")
    
    return jsonify({'status': 'success'})
```

2. **Handle different event types:**

```python
@app.route('/webhooks/orders', methods=['POST'])
def handle_order_webhook():
    # Verify signature (same as above)
    data = request.get_json()
    
    if data['event_type'] == 'PurchaseOrderStatus':
        order_id = data['data']['order_id']
        new_status = data['data']['new_status']
        
        # Update your internal order tracking
        update_order_status(order_id, new_status)
    
    return jsonify({'status': 'success'})

@app.route('/webhooks/recalls', methods=['POST'])
def handle_recall_webhook():
    # Verify signature (same as above)
    data = request.get_json()
    
    if data['event_type'] == 'BatchRecall':
        batch_number = data['data']['batch_number']
        severity = data['data']['severity']
        
        # Handle batch recall
        if severity == 'high':
            send_urgent_notification(batch_number)
        
        process_batch_recall(data['data'])
    
    return jsonify({'status': 'success'})
```

## JavaScript/Node.js Examples

### Using Fetch API

```javascript
// Create organization
const createOrganization = async () => {
  const response = await fetch('https://2j6h5i7c3q53.manus.space/api/organizations', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      name: 'My Company',
      email: 'admin@mycompany.com',
      rate_limit: 3000
    })
  });
  
  const data = await response.json();
  console.log('API Key:', data.api_key.key);
  return data.api_key.key;
};

// GraphQL query
const getProducts = async (apiKey) => {
  const response = await fetch('https://2j6h5i7c3q53.manus.space/api/graphql', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      query: `{
        products {
          id
          name
          sku
          price
          inventoryCount
        }
      }`
    })
  });
  
  const data = await response.json();
  return data.data.products;
};

// Create webhook
const createWebhook = async (apiKey) => {
  const response = await fetch('https://2j6h5i7c3q53.manus.space/api/webhooks', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      event_type: 'InventoryUpdated',
      endpoint_url: 'https://myapp.com/webhooks/inventory'
    })
  });
  
  return await response.json();
};
```

## Python Examples

### Using Requests Library

```python
import requests
import json

class MarketplaceAPI:
    def __init__(self, base_url='https://2j6h5i7c3q53.manus.space/api'):
        self.base_url = base_url
        self.api_key = None
    
    def create_organization(self, name, email, rate_limit=1000):
        response = requests.post(f'{self.base_url}/organizations', json={
            'name': name,
            'email': email,
            'rate_limit': rate_limit
        })
        data = response.json()
        self.api_key = data['api_key']['key']
        return data
    
    def get_headers(self):
        return {
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json'
        }
    
    def create_webhook(self, event_type, endpoint_url):
        response = requests.post(
            f'{self.base_url}/webhooks',
            json={
                'event_type': event_type,
                'endpoint_url': endpoint_url
            },
            headers=self.get_headers()
        )
        return response.json()
    
    def graphql_query(self, query, variables=None):
        response = requests.post(
            f'{self.base_url}/graphql',
            json={
                'query': query,
                'variables': variables or {}
            },
            headers=self.get_headers()
        )
        return response.json()

# Usage example
api = MarketplaceAPI()

# Create organization
org_data = api.create_organization('Tech Startup', 'admin@techstartup.com', 5000)
print(f"Created organization with API key: {api.api_key}")

# Create webhooks
webhook = api.create_webhook('InventoryUpdated', 'https://myapp.com/webhooks/inventory')
print(f"Created webhook: {webhook}")

# GraphQL query
products = api.graphql_query('''
{
  products {
    id
    name
    sku
    price
    inventoryCount
  }
}
''')
print(f"Products: {products}")
```

## Error Handling

### Common HTTP Status Codes

- `200` - Success
- `201` - Created
- `400` - Bad Request (validation error)
- `401` - Unauthorized (invalid API key)
- `403` - Forbidden (rate limited)
- `404` - Not Found
- `409` - Conflict (duplicate resource)
- `500` - Internal Server Error

### Error Response Format

```json
{
  "error": "Error description",
  "code": "ERROR_CODE",
  "details": {
    "field": "Additional error details"
  }
}
```

### Rate Limiting Headers

When rate limited, responses include:

```
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 0
X-RateLimit-Reset: 1641234567
```

