import pytest
import json
import time
from unittest.mock import patch
from tests.conftest import client, organization_data, api_key, auth_headers

class TestRateLimiting:
    """Test rate limiting functionality."""
    
    def test_rate_limit_enforcement(self, client, auth_headers):
        """Test that rate limits are enforced."""
        # Make multiple requests quickly to trigger rate limit
        # Note: This test may be flaky depending on rate limit implementation
        
        responses = []
        for i in range(5):
            response = client.get('/api/api-keys', headers=auth_headers)
            responses.append(response.status_code)
        
        # All requests should succeed initially (assuming reasonable rate limits)
        assert all(status == 200 for status in responses)
    
    def test_rate_limit_headers(self, client, auth_headers):
        """Test that rate limit headers are included in responses."""
        response = client.get('/api/api-keys', headers=auth_headers)
        
        # Check for rate limit headers (implementation dependent)
        # These headers may vary based on Flask-Limiter configuration
        assert response.status_code == 200
    
    def test_public_endpoint_rate_limiting(self, client):
        """Test rate limiting on public endpoints."""
        query = {'query': '{ products { id name } }'}
        
        # Make multiple requests to public GraphQL endpoint
        responses = []
        for i in range(3):
            response = client.post('/api/graphql/public',
                                  data=json.dumps(query),
                                  content_type='application/json')
            responses.append(response.status_code)
        
        # All requests should succeed initially
        assert all(status == 200 for status in responses)

class TestAuthentication:
    """Test authentication and authorization."""
    
    def test_valid_api_key_authentication(self, client, api_key):
        """Test authentication with valid API key."""
        headers = {'Authorization': f'Bearer {api_key}'}
        response = client.get('/api/organization', headers=headers)
        assert response.status_code == 200
    
    def test_invalid_api_key_authentication(self, client):
        """Test authentication with invalid API key."""
        headers = {'Authorization': 'Bearer invalid-key'}
        response = client.get('/api/organization', headers=headers)
        assert response.status_code == 401
    
    def test_missing_api_key_authentication(self, client):
        """Test authentication without API key."""
        response = client.get('/api/organization')
        assert response.status_code == 401
    
    def test_x_api_key_header_authentication(self, client, api_key):
        """Test authentication using X-API-Key header."""
        headers = {'X-API-Key': api_key}
        response = client.get('/api/organization', headers=headers)
        assert response.status_code == 200
    
    def test_malformed_authorization_header(self, client):
        """Test authentication with malformed Authorization header."""
        headers = {'Authorization': 'InvalidFormat'}
        response = client.get('/api/organization', headers=headers)
        assert response.status_code == 401

class TestErrorHandling:
    """Test error handling across the API."""
    
    def test_404_error_handling(self, client, auth_headers):
        """Test 404 error handling."""
        response = client.get('/api/nonexistent-endpoint', headers=auth_headers)
        assert response.status_code == 404
    
    def test_405_method_not_allowed(self, client, auth_headers):
        """Test 405 Method Not Allowed error."""
        response = client.patch('/api/organizations', headers=auth_headers)
        assert response.status_code == 405
    
    def test_invalid_json_payload(self, client, auth_headers):
        """Test handling of invalid JSON payload."""
        response = client.post('/api/webhooks',
                              data='invalid json',
                              content_type='application/json',
                              headers=auth_headers)
        assert response.status_code == 400
    
    def test_missing_required_fields(self, client, auth_headers):
        """Test handling of missing required fields."""
        incomplete_data = {'event_type': 'InventoryUpdated'}  # Missing endpoint_url
        
        response = client.post('/api/webhooks',
                              data=json.dumps(incomplete_data),
                              content_type='application/json',
                              headers=auth_headers)
        assert response.status_code == 400

class TestCORS:
    """Test CORS (Cross-Origin Resource Sharing) functionality."""
    
    def test_cors_headers_present(self, client):
        """Test that CORS headers are present in responses."""
        response = client.options('/api/organizations')
        
        # Check for CORS headers
        assert 'Access-Control-Allow-Origin' in response.headers
        assert 'Access-Control-Allow-Methods' in response.headers
        assert 'Access-Control-Allow-Headers' in response.headers
    
    def test_preflight_request(self, client):
        """Test CORS preflight request handling."""
        headers = {
            'Origin': 'http://localhost:3000',
            'Access-Control-Request-Method': 'POST',
            'Access-Control-Request-Headers': 'Content-Type,Authorization'
        }
        
        response = client.options('/api/webhooks', headers=headers)
        assert response.status_code == 200

class TestDataValidation:
    """Test data validation across endpoints."""
    
    def test_organization_email_validation(self, client):
        """Test email validation for organization creation."""
        invalid_data = {
            'name': 'Test Org',
            'email': 'invalid-email',
            'rate_limit': 1000
        }
        
        response = client.post('/api/organizations',
                              data=json.dumps(invalid_data),
                              content_type='application/json')
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert 'error' in data
    
    def test_webhook_url_validation(self, client, auth_headers):
        """Test URL validation for webhook creation."""
        invalid_data = {
            'event_type': 'InventoryUpdated',
            'endpoint_url': 'not-a-valid-url'
        }
        
        response = client.post('/api/webhooks',
                              data=json.dumps(invalid_data),
                              content_type='application/json',
                              headers=auth_headers)
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert 'error' in data
    
    def test_api_key_rate_limit_validation(self, client, auth_headers):
        """Test rate limit validation for API key creation."""
        invalid_data = {
            'name': 'Test Key',
            'rate_limit': -100  # Invalid negative rate limit
        }
        
        response = client.post('/api/api-keys',
                              data=json.dumps(invalid_data),
                              content_type='application/json',
                              headers=auth_headers)
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert 'error' in data

class TestDatabaseIntegrity:
    """Test database integrity and constraints."""
    
    def test_organization_unique_email_constraint(self, client, organization_data):
        """Test that organization email uniqueness is enforced."""
        # Create first organization
        response1 = client.post('/api/organizations',
                               data=json.dumps(organization_data),
                               content_type='application/json')
        assert response1.status_code == 201
        
        # Try to create second organization with same email
        response2 = client.post('/api/organizations',
                               data=json.dumps(organization_data),
                               content_type='application/json')
        assert response2.status_code == 400
    
    def test_api_key_organization_relationship(self, client, auth_headers):
        """Test that API keys are properly associated with organizations."""
        # Create an API key
        key_data = {'name': 'Test Key', 'rate_limit': 1000}
        response = client.post('/api/api-keys',
                              data=json.dumps(key_data),
                              content_type='application/json',
                              headers=auth_headers)
        
        assert response.status_code == 201
        
        # Verify the key is listed for the organization
        list_response = client.get('/api/api-keys', headers=auth_headers)
        assert list_response.status_code == 200
        
        data = json.loads(list_response.data)
        key_names = [key['name'] for key in data['api_keys']]
        assert 'Test Key' in key_names

