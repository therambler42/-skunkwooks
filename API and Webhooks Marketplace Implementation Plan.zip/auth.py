import os
import secrets
import hashlib
from functools import wraps
from flask import request, jsonify, current_app
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from src.models.marketplace import db, ApiKey, Organization

# Initialize rate limiter
limiter = Limiter(
    key_func=get_remote_address,
    default_limits=["1000 per hour"]
)

def generate_api_key():
    """Generate a secure API key"""
    return secrets.token_urlsafe(32)

def hash_api_key(api_key):
    """Hash an API key for secure storage"""
    return hashlib.sha256(api_key.encode()).hexdigest()

def get_api_key_from_request():
    """Extract API key from request headers"""
    auth_header = request.headers.get('Authorization')
    if auth_header and auth_header.startswith('Bearer '):
        return auth_header[7:]  # Remove 'Bearer ' prefix
    
    # Also check for X-API-Key header
    return request.headers.get('X-API-Key')

def authenticate_api_key():
    """Authenticate API key and return organization"""
    api_key = get_api_key_from_request()
    if not api_key:
        return None, {'error': 'API key required', 'code': 'MISSING_API_KEY'}, 401
    
    # Find the API key in database
    key_record = ApiKey.query.filter_by(key=api_key, is_active=True).first()
    if not key_record:
        return None, {'error': 'Invalid API key', 'code': 'INVALID_API_KEY'}, 401
    
    # Update last used timestamp
    key_record.last_used = db.func.current_timestamp()
    db.session.commit()
    
    return key_record.organization, None, None

def require_api_key(f):
    """Decorator to require valid API key for endpoint access"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        organization, error, status_code = authenticate_api_key()
        if error:
            return jsonify(error), status_code
        
        # Add organization to request context
        request.organization = organization
        return f(*args, **kwargs)
    return decorated_function

def get_rate_limit_for_org(organization_id):
    """Get rate limit for organization based on their API key settings"""
    api_key = ApiKey.query.filter_by(organization_id=organization_id, is_active=True).first()
    if api_key:
        return f"{api_key.rate_limit} per hour"
    return "1000 per hour"  # Default rate limit

def rate_limit_per_org():
    """Dynamic rate limiting based on organization"""
    api_key = get_api_key_from_request()
    if api_key:
        key_record = ApiKey.query.filter_by(key=api_key, is_active=True).first()
        if key_record:
            return f"{key_record.rate_limit} per hour"
    return "100 per hour"  # Lower limit for unauthenticated requests

def init_auth(app):
    """Initialize authentication and rate limiting for the app"""
    limiter.init_app(app)
    return limiter

