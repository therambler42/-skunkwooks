import json
import requests
import hashlib
import hmac
from datetime import datetime
from flask import current_app
from src.models.marketplace import db, Webhook, WebhookDelivery

class WebhookService:
    """Service for managing and delivering webhooks"""
    
    @staticmethod
    def create_webhook_signature(payload, secret):
        """Create HMAC signature for webhook payload"""
        signature = hmac.new(
            secret.encode('utf-8'),
            payload.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
        return f"sha256={signature}"
    
    @staticmethod
    def send_webhook(webhook, event_data):
        """Send webhook to endpoint with proper authentication"""
        try:
            payload = json.dumps(event_data)
            signature = WebhookService.create_webhook_signature(payload, webhook.secret)
            
            headers = {
                'Content-Type': 'application/json',
                'X-Webhook-Signature': signature,
                'X-Event-Type': webhook.event_type,
                'User-Agent': 'API-Webhooks-Marketplace/1.0'
            }
            
            # Create delivery record
            delivery = WebhookDelivery(
                webhook_id=webhook.id,
                event_id=event_data.get('id', ''),
                payload=payload,
                status='pending'
            )
            db.session.add(delivery)
            db.session.commit()
            
            # Send the webhook
            response = requests.post(
                webhook.endpoint_url,
                data=payload,
                headers=headers,
                timeout=30
            )
            
            # Update delivery record
            delivery.status = 'success' if response.status_code < 400 else 'failed'
            delivery.response_code = response.status_code
            delivery.response_body = response.text[:1000]  # Limit response body size
            delivery.attempts += 1
            delivery.delivered_at = datetime.utcnow()
            
            db.session.commit()
            
            return True, response.status_code
            
        except Exception as e:
            # Update delivery record with error
            delivery.status = 'failed'
            delivery.response_body = str(e)[:1000]
            delivery.attempts += 1
            db.session.commit()
            
            current_app.logger.error(f"Webhook delivery failed: {str(e)}")
            return False, None
    
    @staticmethod
    def trigger_webhooks(event_type, event_data):
        """Trigger all active webhooks for a specific event type"""
        webhooks = Webhook.query.filter_by(
            event_type=event_type,
            is_active=True
        ).all()
        
        results = []
        for webhook in webhooks:
            success, status_code = WebhookService.send_webhook(webhook, event_data)
            results.append({
                'webhook_id': webhook.id,
                'organization_id': webhook.organization_id,
                'success': success,
                'status_code': status_code
            })
        
        return results
    
    @staticmethod
    def trigger_inventory_updated(product_data):
        """Trigger InventoryUpdated webhook"""
        event_data = {
            'id': f"inv_{product_data['id']}_{datetime.utcnow().timestamp()}",
            'event_type': 'InventoryUpdated',
            'timestamp': datetime.utcnow().isoformat(),
            'data': {
                'product_id': product_data['id'],
                'sku': product_data['sku'],
                'name': product_data['name'],
                'previous_count': product_data.get('previous_count'),
                'current_count': product_data['inventory_count'],
                'change': product_data['inventory_count'] - product_data.get('previous_count', 0)
            }
        }
        return WebhookService.trigger_webhooks('InventoryUpdated', event_data)
    
    @staticmethod
    def trigger_purchase_order_status(order_data):
        """Trigger PurchaseOrderStatus webhook"""
        event_data = {
            'id': f"po_{order_data['id']}_{datetime.utcnow().timestamp()}",
            'event_type': 'PurchaseOrderStatus',
            'timestamp': datetime.utcnow().isoformat(),
            'data': {
                'order_id': order_data['id'],
                'order_number': order_data['order_number'],
                'supplier': order_data['supplier'],
                'status': order_data['status'],
                'total_amount': order_data['total_amount'],
                'updated_at': order_data['updated_at']
            }
        }
        return WebhookService.trigger_webhooks('PurchaseOrderStatus', event_data)
    
    @staticmethod
    def trigger_batch_recall(recall_data):
        """Trigger BatchRecall webhook"""
        event_data = {
            'id': f"recall_{recall_data['id']}_{datetime.utcnow().timestamp()}",
            'event_type': 'BatchRecall',
            'timestamp': datetime.utcnow().isoformat(),
            'data': {
                'recall_id': recall_data['id'],
                'batch_number': recall_data['batch_number'],
                'product_id': recall_data['product_id'],
                'reason': recall_data['reason'],
                'severity': recall_data['severity'],
                'affected_quantity': recall_data['affected_quantity'],
                'created_at': recall_data['created_at']
            }
        }
        return WebhookService.trigger_webhooks('BatchRecall', event_data)


    
    @staticmethod
    def generate_signature(payload, secret):
        """Generate HMAC signature for webhook payload."""
        return WebhookService.create_webhook_signature(payload, secret)
    
    @staticmethod
    def verify_signature(payload, signature, secret):
        """Verify webhook signature."""
        expected_signature = WebhookService.create_webhook_signature(payload, secret)
        return hmac.compare_digest(expected_signature, signature)

