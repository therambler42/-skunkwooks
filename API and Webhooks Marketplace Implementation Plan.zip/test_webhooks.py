import pytest
import json
from unittest.mock import patch, MagicMock
from tests.conftest import client, organization_data, api_key, auth_headers

class TestWebhookManagement:
    """Test webhook management endpoints."""
    
    def test_create_webhook(self, client, auth_headers):
        """Test creating a new webhook."""
        webhook_data = {
            'event_type': 'InventoryUpdated',
            'endpoint_url': 'https://example.com/webhook'
        }
        
        response = client.post('/api/webhooks',
                              data=json.dumps(webhook_data),
                              content_type='application/json',
                              headers=auth_headers)
        
        assert response.status_code == 201
        data = json.loads(response.data)
        assert data['event_type'] == webhook_data['event_type']
        assert data['endpoint_url'] == webhook_data['endpoint_url']
        assert 'secret' in data
        assert data['is_active'] == True
    
    def test_create_webhook_invalid_event_type(self, client, auth_headers):
        """Test creating webhook with invalid event type fails."""
        webhook_data = {
            'event_type': 'InvalidEvent',
            'endpoint_url': 'https://example.com/webhook'
        }
        
        response = client.post('/api/webhooks',
                              data=json.dumps(webhook_data),
                              content_type='application/json',
                              headers=auth_headers)
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert 'error' in data
    
    def test_list_webhooks(self, client, auth_headers):
        """Test listing webhooks."""
        # Create a webhook first
        webhook_data = {
            'event_type': 'PurchaseOrderStatus',
            'endpoint_url': 'https://example.com/webhook'
        }
        client.post('/api/webhooks',
                   data=json.dumps(webhook_data),
                   content_type='application/json',
                   headers=auth_headers)
        
        response = client.get('/api/webhooks', headers=auth_headers)
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'webhooks' in data
        assert len(data['webhooks']) >= 1
    
    def test_list_webhooks_unauthorized(self, client):
        """Test listing webhooks without authentication fails."""
        response = client.get('/api/webhooks')
        assert response.status_code == 401
    
    @patch('src.webhook_service.requests.post')
    def test_webhook_test_delivery(self, mock_post, client, auth_headers):
        """Test webhook test delivery."""
        # Mock successful HTTP response
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.text = 'OK'
        mock_post.return_value = mock_response
        
        # Create a webhook first
        webhook_data = {
            'event_type': 'BatchRecall',
            'endpoint_url': 'https://example.com/webhook'
        }
        create_response = client.post('/api/webhooks',
                                     data=json.dumps(webhook_data),
                                     content_type='application/json',
                                     headers=auth_headers)
        
        webhook_id = json.loads(create_response.data)['id']
        
        # Test the webhook
        response = client.post(f'/api/webhooks/{webhook_id}/test',
                              headers=auth_headers)
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['success'] == True
        assert data['status_code'] == 200
        
        # Verify the mock was called
        mock_post.assert_called_once()
    
    @patch('src.webhook_service.requests.post')
    def test_webhook_test_delivery_failure(self, mock_post, client, auth_headers):
        """Test webhook test delivery with endpoint failure."""
        # Mock failed HTTP response
        mock_post.side_effect = Exception("Connection failed")
        
        # Create a webhook first
        webhook_data = {
            'event_type': 'InventoryUpdated',
            'endpoint_url': 'https://invalid-endpoint.com/webhook'
        }
        create_response = client.post('/api/webhooks',
                                     data=json.dumps(webhook_data),
                                     content_type='application/json',
                                     headers=auth_headers)
        
        webhook_id = json.loads(create_response.data)['id']
        
        # Test the webhook
        response = client.post(f'/api/webhooks/{webhook_id}/test',
                              headers=auth_headers)
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['success'] == False
        assert 'error' in data

class TestWebhookEvents:
    """Test webhook event triggering."""
    
    @patch('src.webhook_service.WebhookService.deliver_webhook')
    def test_inventory_updated_event(self, mock_deliver, client, auth_headers):
        """Test InventoryUpdated event triggering."""
        # Create a webhook for InventoryUpdated events
        webhook_data = {
            'event_type': 'InventoryUpdated',
            'endpoint_url': 'https://example.com/webhook'
        }
        client.post('/api/webhooks',
                   data=json.dumps(webhook_data),
                   content_type='application/json',
                   headers=auth_headers)
        
        # Trigger the event
        event_data = {
            'product_id': 1,
            'new_count': 150
        }
        
        response = client.post('/api/events/inventory-updated',
                              data=json.dumps(event_data),
                              content_type='application/json',
                              headers=auth_headers)
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['message'] == 'Event triggered successfully'
        
        # Verify webhook delivery was called
        mock_deliver.assert_called()
    
    @patch('src.webhook_service.WebhookService.deliver_webhook')
    def test_purchase_order_status_event(self, mock_deliver, client, auth_headers):
        """Test PurchaseOrderStatus event triggering."""
        # Create a webhook for PurchaseOrderStatus events
        webhook_data = {
            'event_type': 'PurchaseOrderStatus',
            'endpoint_url': 'https://example.com/webhook'
        }
        client.post('/api/webhooks',
                   data=json.dumps(webhook_data),
                   content_type='application/json',
                   headers=auth_headers)
        
        # Trigger the event
        event_data = {
            'order_id': 1,
            'new_status': 'shipped'
        }
        
        response = client.post('/api/events/purchase-order-status',
                              data=json.dumps(event_data),
                              content_type='application/json',
                              headers=auth_headers)
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['message'] == 'Event triggered successfully'
        
        # Verify webhook delivery was called
        mock_deliver.assert_called()
    
    @patch('src.webhook_service.WebhookService.deliver_webhook')
    def test_batch_recall_event(self, mock_deliver, client, auth_headers):
        """Test BatchRecall event triggering."""
        # Create a webhook for BatchRecall events
        webhook_data = {
            'event_type': 'BatchRecall',
            'endpoint_url': 'https://example.com/webhook'
        }
        client.post('/api/webhooks',
                   data=json.dumps(webhook_data),
                   content_type='application/json',
                   headers=auth_headers)
        
        # Trigger the event
        event_data = {
            'batch_number': 'BATCH-2025-001',
            'product_id': 1,
            'reason': 'Quality control issue',
            'severity': 'high',
            'affected_quantity': 500
        }
        
        response = client.post('/api/events/batch-recall',
                              data=json.dumps(event_data),
                              content_type='application/json',
                              headers=auth_headers)
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['message'] == 'Event triggered successfully'
        
        # Verify webhook delivery was called
        mock_deliver.assert_called()

class TestWebhookSecurity:
    """Test webhook security features."""
    
    def test_webhook_signature_generation(self):
        """Test webhook signature generation."""
        from src.webhook_service import WebhookService
        
        payload = '{"test": "data"}'
        secret = 'test-secret'
        
        signature = WebhookService.generate_signature(payload, secret)
        
        assert signature.startswith('sha256=')
        assert len(signature) > 10
    
    def test_webhook_signature_verification(self):
        """Test webhook signature verification."""
        from src.webhook_service import WebhookService
        
        payload = '{"test": "data"}'
        secret = 'test-secret'
        
        signature = WebhookService.generate_signature(payload, secret)
        
        # Valid signature should verify
        assert WebhookService.verify_signature(payload, signature, secret) == True
        
        # Invalid signature should not verify
        assert WebhookService.verify_signature(payload, 'sha256=invalid', secret) == False
        
        # Wrong secret should not verify
        assert WebhookService.verify_signature(payload, signature, 'wrong-secret') == False

