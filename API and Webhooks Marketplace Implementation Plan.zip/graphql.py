from flask import Blueprint, request, jsonify
from flask_graphql import GraphQLView
from src.graphql_schema import schema
from src.auth import require_api_key, limiter, rate_limit_per_org

# Create GraphQL blueprint
graphql_bp = Blueprint('graphql', __name__)

class AuthenticatedGraphQLView(GraphQLView):
    """Custom GraphQL view with authentication"""
    
    def get_context(self):
        context = super().get_context() or {}
        if not isinstance(context, dict):
            context = {}
        context['request'] = request
        return context
    
    def dispatch_request(self):
        # Check for API key authentication
        from src.auth import authenticate_api_key
        organization, error, status_code = authenticate_api_key()
        
        if error:
            return jsonify(error), status_code
        
        # Add organization info to request for GraphQL context
        request.organization = organization
        request.organization_id = organization.id if organization else None
        
        return super().dispatch_request()

# Add GraphQL endpoint with authentication and rate limiting
graphql_bp.add_url_rule(
    '/graphql',
    view_func=limiter.limit(rate_limit_per_org)(
        AuthenticatedGraphQLView.as_view(
            'graphql',
            schema=schema,
            graphiql=True  # Enable GraphiQL interface for development
        )
    ),
    methods=['GET', 'POST']
)

# Public GraphQL endpoint (read-only, no authentication required)
class PublicGraphQLView(GraphQLView):
    """Public GraphQL view for read-only access"""
    
    def get_context(self):
        context = super().get_context() or {}
        if not isinstance(context, dict):
            context = {}
        context['request'] = request
        return context
    
    def dispatch_request(self):
        # Only allow queries, not mutations
        if request.method == 'POST':
            data = request.get_json()
            if data and 'mutation' in data.get('query', '').lower():
                return jsonify({'error': 'Mutations not allowed on public endpoint'}), 403
        
        return super().dispatch_request()

# Add public GraphQL endpoint with rate limiting
graphql_bp.add_url_rule(
    '/graphql/public',
    view_func=limiter.limit("100 per hour")(
        PublicGraphQLView.as_view(
            'public_graphql',
            schema=schema,
            graphiql=True
        )
    ),
    methods=['GET', 'POST']
)

