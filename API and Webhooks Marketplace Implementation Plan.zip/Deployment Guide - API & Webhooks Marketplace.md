# Deployment Guide - API & Webhooks Marketplace

## Prerequisites

- Python 3.11+
- Node.js 20+
- Git

## Local Development Setup

### Backend Setup

1. **Clone and setup the backend:**
```bash
git clone <repository-url>
cd api-webhooks-marketplace
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

2. **Configure environment variables:**
```bash
export FLASK_ENV=development
export FLASK_DEBUG=1
export SECRET_KEY=your-secret-key-here
export DATABASE_URL=sqlite:///marketplace.db
```

3. **Initialize the database:**
```bash
python src/main.py
# Database tables will be created automatically
```

4. **Run the backend:**
```bash
python src/main.py
# Server will start on http://127.0.0.1:5000
```

### Frontend Setup

1. **Setup the admin interface:**
```bash
cd api-webhooks-admin
npm install
```

2. **Configure API URL:**
Edit `src/App.jsx` and update the API_BASE_URL:
```javascript
const API_BASE_URL = 'http://127.0.0.1:5000/api'  // For local development
```

3. **Run the frontend:**
```bash
npm run dev
# Server will start on http://localhost:5173
```

## Production Deployment

### Backend Deployment

1. **Prepare for deployment:**
```bash
cd api-webhooks-marketplace
source venv/bin/activate
pip freeze > requirements.txt
```

2. **Deploy using Manus service:**
```bash
# Use the Manus deployment service
manus deploy backend --framework flask --project-dir /path/to/api-webhooks-marketplace
```

3. **Environment variables for production:**
```bash
export FLASK_ENV=production
export SECRET_KEY=secure-random-key
export DATABASE_URL=postgresql://user:pass@host:port/dbname  # For production DB
export CORS_ORIGINS=https://your-frontend-domain.com
```

### Frontend Deployment

1. **Build for production:**
```bash
cd api-webhooks-admin
# Update API_BASE_URL in src/App.jsx to your deployed backend URL
npm run build
```

2. **Deploy using Manus service:**
```bash
# Use the Manus deployment service
manus deploy frontend --framework react --project-dir /path/to/api-webhooks-admin
```

## Configuration Options

### Backend Configuration

**Environment Variables:**
- `FLASK_ENV` - Environment (development/production)
- `SECRET_KEY` - Flask secret key for sessions
- `DATABASE_URL` - Database connection string
- `CORS_ORIGINS` - Allowed CORS origins
- `RATE_LIMIT_STORAGE_URL` - Redis URL for rate limiting (optional)

**Rate Limiting:**
- Default: In-memory storage (development only)
- Production: Configure Redis for distributed rate limiting

### Frontend Configuration

**API Configuration:**
Update `src/App.jsx`:
```javascript
const API_BASE_URL = 'https://your-backend-domain.com/api'
```

## Database Setup

### Development (SQLite)
- Automatic setup on first run
- Database file: `marketplace.db`
- No additional configuration needed

### Production (PostgreSQL)
```sql
CREATE DATABASE marketplace;
CREATE USER marketplace_user WITH PASSWORD 'secure_password';
GRANT ALL PRIVILEGES ON DATABASE marketplace TO marketplace_user;
```

Update `DATABASE_URL`:
```bash
export DATABASE_URL=postgresql://marketplace_user:secure_password@localhost:5432/marketplace
```

## Security Considerations

### API Keys
- Generated using cryptographically secure random bytes
- Stored as hashed values in database
- Rate limited per organization

### Webhooks
- HMAC-SHA256 signature verification
- Unique secrets per webhook
- Timeout protection (30 seconds)

### CORS
- Configure allowed origins in production
- Avoid wildcard (*) in production

### Rate Limiting
- Implement Redis backend for production
- Configure appropriate limits per organization tier

## Monitoring and Logging

### Application Logs
```python
import logging
logging.basicConfig(level=logging.INFO)
```

### Webhook Delivery Tracking
- All webhook deliveries logged to database
- Success/failure status tracking
- Retry attempt logging

### Rate Limit Monitoring
- Monitor rate limit hits per organization
- Alert on excessive rate limiting

## Troubleshooting

### Common Issues

**CORS Errors:**
- Verify CORS_ORIGINS environment variable
- Check frontend API_BASE_URL configuration

**Database Connection:**
- Verify DATABASE_URL format
- Check database server connectivity
- Ensure database exists and user has permissions

**Webhook Delivery Failures:**
- Check endpoint URL accessibility
- Verify webhook signature verification
- Review webhook delivery logs

**Rate Limiting Issues:**
- Check Redis connection (if using Redis)
- Verify rate limit configuration
- Monitor rate limit storage backend

### Debug Mode

Enable debug mode for development:
```bash
export FLASK_DEBUG=1
export FLASK_ENV=development
```

### Health Checks

**Backend Health Check:**
```bash
curl https://your-backend-domain.com/api/health
```

**Database Health Check:**
```bash
curl https://your-backend-domain.com/api/health/db
```

## Scaling Considerations

### Backend Scaling
- Use multiple Flask instances behind load balancer
- Implement Redis for shared rate limiting
- Use PostgreSQL for production database

### Database Scaling
- Implement read replicas for query scaling
- Use connection pooling
- Consider database partitioning for large datasets

### Webhook Scaling
- Implement webhook delivery queue (Celery/Redis)
- Add retry logic with exponential backoff
- Monitor webhook endpoint performance

## Backup and Recovery

### Database Backup
```bash
# PostgreSQL backup
pg_dump marketplace > marketplace_backup.sql

# Restore
psql marketplace < marketplace_backup.sql
```

### Configuration Backup
- Store environment variables securely
- Backup webhook configurations
- Document API key management procedures

## Performance Optimization

### Backend Optimization
- Enable database query optimization
- Implement caching for frequently accessed data
- Use database indexes for common queries

### Frontend Optimization
- Enable gzip compression
- Implement code splitting
- Use CDN for static assets

### API Optimization
- Implement GraphQL query complexity analysis
- Add response caching for public endpoints
- Optimize database queries with proper indexing

