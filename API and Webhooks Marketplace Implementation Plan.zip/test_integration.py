import pytest
import json
from unittest.mock import patch, MagicMock
from tests.conftest import client, organization_data, api_key, auth_headers

class TestFullWorkflow:
    """Integration tests for complete workflows."""
    
    def test_complete_organization_setup_workflow(self, client):
        """Test complete organization setup and API usage workflow."""
        # Step 1: Create organization
        org_data = {
            'name': 'Integration Test Org',
            'email': 'integration@test.com',
            'rate_limit': 2000
        }
        
        create_response = client.post('/api/organizations',
                                     data=json.dumps(org_data),
                                     content_type='application/json')
        
        assert create_response.status_code == 201
        create_data = json.loads(create_response.data)
        api_key = create_data['api_key']
        headers = {'Authorization': f'Bearer {api_key}'}
        
        # Step 2: Verify organization details
        org_response = client.get('/api/organization', headers=headers)
        assert org_response.status_code == 200
        org_details = json.loads(org_response.data)
        assert org_details['name'] == org_data['name']
        
        # Step 3: Create additional API key
        key_data = {'name': 'Secondary Key', 'rate_limit': 1500}
        key_response = client.post('/api/api-keys',
                                  data=json.dumps(key_data),
                                  content_type='application/json',
                                  headers=headers)
        
        assert key_response.status_code == 201
        
        # Step 4: Create webhooks for all event types
        event_types = ['InventoryUpdated', 'PurchaseOrderStatus', 'BatchRecall']
        webhook_ids = []
        
        for event_type in event_types:
            webhook_data = {
                'event_type': event_type,
                'endpoint_url': f'https://example.com/webhook/{event_type.lower()}'
            }
            
            webhook_response = client.post('/api/webhooks',
                                          data=json.dumps(webhook_data),
                                          content_type='application/json',
                                          headers=headers)
            
            assert webhook_response.status_code == 201
            webhook_ids.append(json.loads(webhook_response.data)['id'])
        
        # Step 5: Test GraphQL operations
        # Create a product via GraphQL
        mutation = {
            'query': '''
                mutation {
                    createProduct(productData: {
                        name: "Integration Test Product",
                        sku: "INT-001",
                        price: 99.99,
                        inventoryCount: 50
                    }) {
                        product { id name sku }
                        success
                    }
                }
            '''
        }
        
        graphql_response = client.post('/api/graphql',
                                      data=json.dumps(mutation),
                                      content_type='application/json',
                                      headers=headers)
        
        assert graphql_response.status_code == 200
        graphql_data = json.loads(graphql_response.data)
        assert graphql_data['data']['createProduct']['success'] == True
        
        # Step 6: Query the created product
        query = {
            'query': '{ products { id name sku price inventoryCount } }'
        }
        
        query_response = client.post('/api/graphql',
                                    data=json.dumps(query),
                                    content_type='application/json',
                                    headers=headers)
        
        assert query_response.status_code == 200
        query_data = json.loads(query_response.data)
        products = query_data['data']['products']
        assert len(products) >= 1
        assert any(p['name'] == 'Integration Test Product' for p in products)
        
        # Step 7: Test webhook functionality
        with patch('src.webhook_service.requests.post') as mock_post:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.text = 'OK'
            mock_post.return_value = mock_response
            
            # Test each webhook
            for webhook_id in webhook_ids:
                test_response = client.post(f'/api/webhooks/{webhook_id}/test',
                                           headers=headers)
                assert test_response.status_code == 200
                test_data = json.loads(test_response.data)
                assert test_data['success'] == True
    
    @patch('src.webhook_service.WebhookService.deliver_webhook')
    def test_event_to_webhook_delivery_workflow(self, mock_deliver, client, auth_headers):
        """Test complete event triggering to webhook delivery workflow."""
        # Create webhooks for all event types
        event_configs = [
            {'event_type': 'InventoryUpdated', 'url': 'https://app.com/inventory'},
            {'event_type': 'PurchaseOrderStatus', 'url': 'https://app.com/orders'},
            {'event_type': 'BatchRecall', 'url': 'https://app.com/recalls'}
        ]
        
        webhook_ids = []
        for config in event_configs:
            webhook_data = {
                'event_type': config['event_type'],
                'endpoint_url': config['url']
            }
            
            response = client.post('/api/webhooks',
                                  data=json.dumps(webhook_data),
                                  content_type='application/json',
                                  headers=auth_headers)
            
            assert response.status_code == 201
            webhook_ids.append(json.loads(response.data)['id'])
        
        # Trigger each event type and verify webhook delivery
        event_tests = [
            {
                'endpoint': '/api/events/inventory-updated',
                'data': {'product_id': 1, 'new_count': 75}
            },
            {
                'endpoint': '/api/events/purchase-order-status',
                'data': {'order_id': 1, 'new_status': 'delivered'}
            },
            {
                'endpoint': '/api/events/batch-recall',
                'data': {
                    'batch_number': 'BATCH-INT-001',
                    'product_id': 1,
                    'reason': 'Integration test recall',
                    'severity': 'low',
                    'affected_quantity': 10
                }
            }
        ]
        
        for event_test in event_tests:
            response = client.post(event_test['endpoint'],
                                  data=json.dumps(event_test['data']),
                                  content_type='application/json',
                                  headers=auth_headers)
            
            assert response.status_code == 200
            data = json.loads(response.data)
            assert data['message'] == 'Event triggered successfully'
        
        # Verify webhook delivery was called for each event
        assert mock_deliver.call_count == len(event_tests)
    
    def test_api_key_lifecycle_workflow(self, client, auth_headers):
        """Test complete API key lifecycle workflow."""
        # Create a new API key
        key_data = {'name': 'Lifecycle Test Key', 'rate_limit': 500}
        create_response = client.post('/api/api-keys',
                                     data=json.dumps(key_data),
                                     content_type='application/json',
                                     headers=auth_headers)
        
        assert create_response.status_code == 201
        key_info = json.loads(create_response.data)
        key_id = key_info['id']
        new_api_key = key_info['key']
        
        # Use the new API key to make authenticated requests
        new_headers = {'Authorization': f'Bearer {new_api_key}'}
        
        # Test that the new key works
        test_response = client.get('/api/organization', headers=new_headers)
        assert test_response.status_code == 200
        
        # Update the API key
        update_data = {'name': 'Updated Lifecycle Key', 'rate_limit': 750}
        update_response = client.put(f'/api/api-keys/{key_id}',
                                    data=json.dumps(update_data),
                                    content_type='application/json',
                                    headers=auth_headers)
        
        assert update_response.status_code == 200
        
        # Verify the update
        list_response = client.get('/api/api-keys', headers=auth_headers)
        assert list_response.status_code == 200
        keys = json.loads(list_response.data)['api_keys']
        updated_key = next(k for k in keys if k['id'] == key_id)
        assert updated_key['name'] == 'Updated Lifecycle Key'
        assert updated_key['rate_limit'] == 750
        
        # Delete the API key
        delete_response = client.delete(f'/api/api-keys/{key_id}',
                                       headers=auth_headers)
        assert delete_response.status_code == 200
        
        # Verify the key no longer works
        test_response = client.get('/api/organization', headers=new_headers)
        assert test_response.status_code == 401
    
    def test_graphql_public_vs_authenticated_access(self, client, auth_headers):
        """Test differences between public and authenticated GraphQL access."""
        # Test public endpoint - should allow queries but not mutations
        public_query = {'query': '{ products { id name } }'}
        public_response = client.post('/api/graphql/public',
                                     data=json.dumps(public_query),
                                     content_type='application/json')
        
        assert public_response.status_code == 200
        public_data = json.loads(public_response.data)
        assert 'data' in public_data
        
        # Test public endpoint with mutation - should fail
        public_mutation = {
            'query': 'mutation { createProduct(productData: {name: "Test", sku: "TEST", price: 10.0}) { success } }'
        }
        public_mut_response = client.post('/api/graphql/public',
                                         data=json.dumps(public_mutation),
                                         content_type='application/json')
        
        assert public_mut_response.status_code == 200
        public_mut_data = json.loads(public_mut_response.data)
        assert 'errors' in public_mut_data
        
        # Test authenticated endpoint - should allow both queries and mutations
        auth_query = {'query': '{ products { id name } }'}
        auth_response = client.post('/api/graphql',
                                   data=json.dumps(auth_query),
                                   content_type='application/json',
                                   headers=auth_headers)
        
        assert auth_response.status_code == 200
        auth_data = json.loads(auth_response.data)
        assert 'data' in auth_data
        
        # Test authenticated mutation
        auth_mutation = {
            'query': '''
                mutation {
                    createProduct(productData: {
                        name: "Auth Test Product",
                        sku: "AUTH-001",
                        price: 15.99
                    }) {
                        product { id name }
                        success
                    }
                }
            '''
        }
        auth_mut_response = client.post('/api/graphql',
                                       data=json.dumps(auth_mutation),
                                       content_type='application/json',
                                       headers=auth_headers)
        
        assert auth_mut_response.status_code == 200
        auth_mut_data = json.loads(auth_mut_response.data)
        assert 'data' in auth_mut_data
        assert auth_mut_data['data']['createProduct']['success'] == True

class TestErrorRecovery:
    """Test error recovery and resilience."""
    
    def test_database_error_handling(self, client):
        """Test handling of database errors."""
        # This test would require mocking database failures
        # For now, we'll test basic error scenarios
        
        # Test with invalid organization data that might cause DB errors
        invalid_data = {
            'name': '',  # Empty name might cause constraint violation
            'email': 'test@example.com'
        }
        
        response = client.post('/api/organizations',
                              data=json.dumps(invalid_data),
                              content_type='application/json')
        
        # Should handle the error gracefully
        assert response.status_code in [400, 500]
        data = json.loads(response.data)
        assert 'error' in data
    
    @patch('src.webhook_service.requests.post')
    def test_webhook_delivery_retry_logic(self, mock_post, client, auth_headers):
        """Test webhook delivery retry logic."""
        # Mock failed then successful delivery
        mock_post.side_effect = [
            Exception("Connection timeout"),  # First attempt fails
            MagicMock(status_code=200, text='OK')  # Second attempt succeeds
        ]
        
        # Create a webhook
        webhook_data = {
            'event_type': 'InventoryUpdated',
            'endpoint_url': 'https://unreliable-endpoint.com/webhook'
        }
        create_response = client.post('/api/webhooks',
                                     data=json.dumps(webhook_data),
                                     content_type='application/json',
                                     headers=auth_headers)
        
        webhook_id = json.loads(create_response.data)['id']
        
        # Test webhook delivery
        response = client.post(f'/api/webhooks/{webhook_id}/test',
                              headers=auth_headers)
        
        # Should handle the failure gracefully
        assert response.status_code == 200
        data = json.loads(response.data)
        # The exact behavior depends on retry implementation
        assert 'success' in data

