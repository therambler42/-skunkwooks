import pytest
import json
from tests.conftest import client, organization_data, api_key, auth_headers

class TestOrganizationAPI:
    """Test organization management endpoints."""
    
    def test_create_organization(self, client, organization_data):
        """Test creating a new organization."""
        response = client.post('/api/organizations',
                              data=json.dumps(organization_data),
                              content_type='application/json')
        
        assert response.status_code == 201
        data = json.loads(response.data)
        assert 'api_key' in data
        assert data['organization']['name'] == organization_data['name']
        assert data['organization']['email'] == organization_data['email']
    
    def test_create_organization_duplicate_email(self, client, organization_data):
        """Test creating organization with duplicate email fails."""
        # Create first organization
        client.post('/api/organizations',
                   data=json.dumps(organization_data),
                   content_type='application/json')
        
        # Try to create another with same email
        response = client.post('/api/organizations',
                              data=json.dumps(organization_data),
                              content_type='application/json')
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert 'error' in data
    
    def test_get_organization(self, client, auth_headers):
        """Test getting organization details."""
        response = client.get('/api/organization', headers=auth_headers)
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'name' in data
        assert 'email' in data
        assert 'created_at' in data
    
    def test_get_organization_unauthorized(self, client):
        """Test getting organization without authentication fails."""
        response = client.get('/api/organization')
        assert response.status_code == 401

class TestAPIKeyManagement:
    """Test API key management endpoints."""
    
    def test_list_api_keys(self, client, auth_headers):
        """Test listing API keys."""
        response = client.get('/api/api-keys', headers=auth_headers)
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'api_keys' in data
        assert len(data['api_keys']) >= 1  # At least the default key
    
    def test_create_api_key(self, client, auth_headers):
        """Test creating a new API key."""
        key_data = {
            'name': 'Test API Key',
            'rate_limit': 2000
        }
        
        response = client.post('/api/api-keys',
                              data=json.dumps(key_data),
                              content_type='application/json',
                              headers=auth_headers)
        
        assert response.status_code == 201
        data = json.loads(response.data)
        assert data['name'] == key_data['name']
        assert data['rate_limit'] == key_data['rate_limit']
        assert 'key' in data
        assert data['is_active'] == True
    
    def test_create_api_key_unauthorized(self, client):
        """Test creating API key without authentication fails."""
        key_data = {'name': 'Test Key', 'rate_limit': 1000}
        
        response = client.post('/api/api-keys',
                              data=json.dumps(key_data),
                              content_type='application/json')
        
        assert response.status_code == 401
    
    def test_delete_api_key(self, client, auth_headers):
        """Test deleting an API key."""
        # First create a key
        key_data = {'name': 'Delete Me', 'rate_limit': 1000}
        create_response = client.post('/api/api-keys',
                                     data=json.dumps(key_data),
                                     content_type='application/json',
                                     headers=auth_headers)
        
        assert create_response.status_code == 201
        key_id = json.loads(create_response.data)['id']
        
        # Then delete it
        delete_response = client.delete(f'/api/api-keys/{key_id}',
                                       headers=auth_headers)
        
        assert delete_response.status_code == 200
        data = json.loads(delete_response.data)
        assert data['message'] == 'API key deleted successfully'

class TestGraphQLAPI:
    """Test GraphQL endpoints."""
    
    def test_public_graphql_query(self, client):
        """Test public GraphQL query."""
        query = {
            'query': '{ products { id name sku } }'
        }
        
        response = client.post('/api/graphql/public',
                              data=json.dumps(query),
                              content_type='application/json')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'data' in data
        assert 'products' in data['data']
    
    def test_public_graphql_mutation_blocked(self, client):
        """Test that mutations are blocked on public endpoint."""
        mutation = {
            'query': 'mutation { createProduct(productData: {name: "Test", sku: "TEST", price: 10.0}) { product { id } } }'
        }
        
        response = client.post('/api/graphql/public',
                              data=json.dumps(mutation),
                              content_type='application/json')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'errors' in data
        assert 'Mutations not allowed' in str(data['errors'])
    
    def test_authenticated_graphql_query(self, client, auth_headers):
        """Test authenticated GraphQL query."""
        query = {
            'query': '{ products { id name sku } }'
        }
        
        response = client.post('/api/graphql',
                              data=json.dumps(query),
                              content_type='application/json',
                              headers=auth_headers)
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'data' in data
    
    def test_authenticated_graphql_mutation(self, client, auth_headers):
        """Test authenticated GraphQL mutation."""
        mutation = {
            'query': '''
                mutation {
                    createProduct(productData: {
                        name: "Test Product",
                        sku: "TEST-001",
                        price: 29.99,
                        inventoryCount: 100
                    }) {
                        product {
                            id
                            name
                            sku
                            price
                        }
                        success
                        message
                    }
                }
            '''
        }
        
        response = client.post('/api/graphql',
                              data=json.dumps(mutation),
                              content_type='application/json',
                              headers=auth_headers)
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'data' in data
        assert data['data']['createProduct']['success'] == True

