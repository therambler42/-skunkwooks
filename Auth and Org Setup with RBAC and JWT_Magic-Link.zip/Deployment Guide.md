# Deployment Guide

## Overview

This guide covers deploying the Auth & Organization Management System to various environments including local development, staging, and production.

## Prerequisites

- Docker and Docker Compose
- Node.js 18+ (for local development)
- PostgreSQL 15+ (for local development)
- Fly.io account (for cloud deployment)
- SendGrid account (for email functionality)

## Local Development

### 1. Environment Setup

```bash
# Clone repository
git clone <repository-url>
cd auth-org-system

# Install dependencies
npm install
```

### 2. Database Setup

```bash
# Start PostgreSQL with Docker
docker run --name auth-postgres \
  -e POSTGRES_DB=auth_org_db \
  -e POSTGRES_USER=postgres \
  -e POSTGRES_PASSWORD=postgres \
  -p 5432:5432 \
  -d postgres:15-alpine

# Configure environment
cp backend/.env.example backend/.env
cp frontend/auth-frontend/.env.example frontend/auth-frontend/.env
```

### 3. Database Migration

```bash
cd backend
npm run db:generate
npm run db:migrate
npm run db:seed
```

### 4. Start Development Servers

```bash
# Start both backend and frontend
npm run dev

# Or start individually
npm run dev:backend  # Port 4000
npm run dev:frontend # Port 3000
```

## Docker Deployment

### 1. Using Docker Compose

```bash
# Build and start all services
docker-compose up --build

# Start in background
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

### 2. Environment Variables

Create `.env` file in project root:

```bash
# Database
POSTGRES_DB=auth_org_db
POSTGRES_USER=postgres
POSTGRES_PASSWORD=your-secure-password

# JWT Secrets
JWT_ACCESS_SECRET=your-super-secret-access-key-min-32-chars
JWT_REFRESH_SECRET=your-super-secret-refresh-key-min-32-chars

# SendGrid
SENDGRID_API_KEY=your-sendgrid-api-key
FROM_EMAIL=noreply@yourdomain.com

# Application
FRONTEND_URL=http://localhost:3000
CORS_ORIGIN=http://localhost:3000
```

### 3. Production Docker Build

```bash
# Build production image
docker build -t auth-org-system:latest .

# Run production container
docker run -d \
  --name auth-org-system \
  -p 4000:4000 \
  -e DATABASE_URL="postgresql://user:pass@host:5432/db" \
  -e JWT_ACCESS_SECRET="your-secret" \
  -e JWT_REFRESH_SECRET="your-secret" \
  -e SENDGRID_API_KEY="your-key" \
  auth-org-system:latest
```

## Fly.io Deployment

### 1. Initial Setup

```bash
# Install Fly CLI
curl -L https://fly.io/install.sh | sh

# Login to Fly.io
flyctl auth login

# Initialize app
flyctl launch
```

### 2. Configure Secrets

```bash
# Set required secrets
flyctl secrets set JWT_ACCESS_SECRET="your-super-secret-access-key"
flyctl secrets set JWT_REFRESH_SECRET="your-super-secret-refresh-key"
flyctl secrets set SENDGRID_API_KEY="your-sendgrid-api-key"
flyctl secrets set FROM_EMAIL="noreply@yourdomain.com"
```

### 3. Database Setup

```bash
# Create PostgreSQL database
flyctl postgres create --name auth-org-db

# Attach database to app
flyctl postgres attach auth-org-db

# Run migrations
flyctl ssh console
cd backend && npx prisma migrate deploy
```

### 4. Deploy Application

```bash
# Deploy to Fly.io
flyctl deploy

# Check deployment status
flyctl status

# View logs
flyctl logs

# Open application
flyctl open
```

### 5. Custom Domain (Optional)

```bash
# Add custom domain
flyctl certs create yourdomain.com

# Add DNS record
# A record: yourdomain.com -> fly.io IP
# CNAME record: www.yourdomain.com -> yourdomain.com
```

## AWS Deployment

### 1. ECS with Fargate

```yaml
# docker-compose.aws.yml
version: '3.8'
services:
  app:
    image: your-registry/auth-org-system:latest
    ports:
      - "4000:4000"
    environment:
      - DATABASE_URL=${DATABASE_URL}
      - JWT_ACCESS_SECRET=${JWT_ACCESS_SECRET}
      - JWT_REFRESH_SECRET=${JWT_REFRESH_SECRET}
      - SENDGRID_API_KEY=${SENDGRID_API_KEY}
    depends_on:
      - postgres
  
  postgres:
    image: postgres:15-alpine
    environment:
      - POSTGRES_DB=auth_org_db
      - POSTGRES_USER=postgres
      - POSTGRES_PASSWORD=${POSTGRES_PASSWORD}
    volumes:
      - postgres_data:/var/lib/postgresql/data

volumes:
  postgres_data:
```

### 2. RDS Database

```bash
# Create RDS PostgreSQL instance
aws rds create-db-instance \
  --db-instance-identifier auth-org-db \
  --db-instance-class db.t3.micro \
  --engine postgres \
  --engine-version 15.4 \
  --master-username postgres \
  --master-user-password your-password \
  --allocated-storage 20
```

## Google Cloud Platform

### 1. Cloud Run Deployment

```bash
# Build and push to Container Registry
docker build -t gcr.io/your-project/auth-org-system .
docker push gcr.io/your-project/auth-org-system

# Deploy to Cloud Run
gcloud run deploy auth-org-system \
  --image gcr.io/your-project/auth-org-system \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --set-env-vars DATABASE_URL="postgresql://..." \
  --set-env-vars JWT_ACCESS_SECRET="..." \
  --set-env-vars SENDGRID_API_KEY="..."
```

### 2. Cloud SQL Database

```bash
# Create Cloud SQL PostgreSQL instance
gcloud sql instances create auth-org-db \
  --database-version POSTGRES_15 \
  --tier db-f1-micro \
  --region us-central1

# Create database
gcloud sql databases create auth_org_db --instance auth-org-db
```

## Environment Configuration

### Development Environment

```bash
# backend/.env
NODE_ENV=development
PORT=4000
DATABASE_URL="postgresql://postgres:postgres@localhost:5432/auth_org_db"
JWT_ACCESS_SECRET="dev-access-secret-min-32-characters"
JWT_REFRESH_SECRET="dev-refresh-secret-min-32-characters"
SENDGRID_API_KEY="your-sendgrid-sandbox-key"
FROM_EMAIL="noreply@localhost"
FRONTEND_URL="http://localhost:3000"
CORS_ORIGIN="http://localhost:3000"

# frontend/auth-frontend/.env
VITE_GRAPHQL_URL="http://localhost:4000/api/graphql"
VITE_APP_NAME="Auth System (Dev)"
```

### Staging Environment

```bash
# Staging secrets
JWT_ACCESS_SECRET="staging-access-secret-min-32-characters"
JWT_REFRESH_SECRET="staging-refresh-secret-min-32-characters"
SENDGRID_API_KEY="your-sendgrid-api-key"
FROM_EMAIL="noreply@staging.yourdomain.com"
FRONTEND_URL="https://staging.yourdomain.com"
CORS_ORIGIN="https://staging.yourdomain.com"
DATABASE_URL="postgresql://user:pass@staging-db:5432/auth_org_db"
```

### Production Environment

```bash
# Production secrets (use secure secret management)
JWT_ACCESS_SECRET="production-access-secret-min-32-characters"
JWT_REFRESH_SECRET="production-refresh-secret-min-32-characters"
SENDGRID_API_KEY="your-production-sendgrid-api-key"
FROM_EMAIL="noreply@yourdomain.com"
FRONTEND_URL="https://yourdomain.com"
CORS_ORIGIN="https://yourdomain.com"
DATABASE_URL="postgresql://user:pass@prod-db:5432/auth_org_db"
```

## SSL/TLS Configuration

### 1. Let's Encrypt with Nginx

```nginx
server {
    listen 80;
    server_name yourdomain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name yourdomain.com;
    
    ssl_certificate /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;
    
    location / {
        proxy_pass http://localhost:4000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

### 2. Cloudflare SSL

```bash
# Set Cloudflare SSL mode to "Full (strict)"
# Configure origin certificates in Cloudflare dashboard
# Update DNS records to proxy through Cloudflare
```

## Monitoring and Logging

### 1. Health Checks

```bash
# Application health check
curl https://yourdomain.com/api/health

# Database health check
curl https://yourdomain.com/api/health/db
```

### 2. Logging Configuration

```typescript
// backend/src/main.ts
import { Logger } from '@nestjs/common';

const logger = new Logger('Bootstrap');

// Configure logging level based on environment
const logLevel = process.env.NODE_ENV === 'production' 
  ? ['error', 'warn'] 
  : ['log', 'error', 'warn', 'debug', 'verbose'];
```

### 3. Monitoring with Prometheus

```yaml
# docker-compose.monitoring.yml
version: '3.8'
services:
  prometheus:
    image: prom/prometheus
    ports:
      - "9090:9090"
    volumes:
      - ./prometheus.yml:/etc/prometheus/prometheus.yml
  
  grafana:
    image: grafana/grafana
    ports:
      - "3001:3000"
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=admin
```

## Backup and Recovery

### 1. Database Backup

```bash
# Create backup
pg_dump $DATABASE_URL > backup_$(date +%Y%m%d_%H%M%S).sql

# Restore backup
psql $DATABASE_URL < backup_20231208_120000.sql
```

### 2. Automated Backups

```bash
#!/bin/bash
# backup.sh
BACKUP_DIR="/backups"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="$BACKUP_DIR/auth_org_backup_$TIMESTAMP.sql"

pg_dump $DATABASE_URL > $BACKUP_FILE
gzip $BACKUP_FILE

# Upload to S3
aws s3 cp $BACKUP_FILE.gz s3://your-backup-bucket/
```

## Security Considerations

### 1. Environment Security

- Use strong, unique secrets for JWT tokens
- Rotate secrets regularly
- Use environment-specific configurations
- Enable database SSL connections
- Implement rate limiting
- Use HTTPS in production

### 2. Network Security

```bash
# Firewall rules (example for Ubuntu)
ufw allow 22/tcp    # SSH
ufw allow 80/tcp    # HTTP
ufw allow 443/tcp   # HTTPS
ufw deny 4000/tcp   # Block direct API access
ufw enable
```

### 3. Container Security

```dockerfile
# Use non-root user
USER nestjs

# Read-only filesystem
--read-only --tmpfs /tmp

# Drop capabilities
--cap-drop ALL
```

## Troubleshooting

### Common Issues

1. **Database Connection Failed**
   ```bash
   # Check database connectivity
   pg_isready -h localhost -p 5432
   
   # Verify connection string
   echo $DATABASE_URL
   ```

2. **JWT Token Issues**
   ```bash
   # Verify JWT secrets are set
   echo $JWT_ACCESS_SECRET | wc -c  # Should be > 32
   ```

3. **Email Delivery Issues**
   ```bash
   # Test SendGrid API key
   curl -X POST https://api.sendgrid.com/v3/mail/send \
     -H "Authorization: Bearer $SENDGRID_API_KEY" \
     -H "Content-Type: application/json"
   ```

4. **CORS Issues**
   ```bash
   # Check CORS configuration
   curl -H "Origin: http://localhost:3000" \
     -H "Access-Control-Request-Method: POST" \
     -H "Access-Control-Request-Headers: X-Requested-With" \
     -X OPTIONS \
     http://localhost:4000/api/graphql
   ```

### Performance Optimization

1. **Database Optimization**
   ```sql
   -- Add indexes for common queries
   CREATE INDEX idx_users_email ON users(email);
   CREATE INDEX idx_org_members_user_org ON organization_members(userId, organizationId);
   CREATE INDEX idx_magic_links_token ON magic_links(token);
   ```

2. **Caching**
   ```typescript
   // Redis caching for frequently accessed data
   @Cacheable('user', 300) // 5 minutes
   async getUser(id: string): Promise<User> {
     return this.userService.findById(id);
   }
   ```

3. **CDN Configuration**
   ```bash
   # Configure CDN for static assets
   # CloudFront, Cloudflare, or similar
   ```

## Scaling Considerations

### Horizontal Scaling

```yaml
# docker-compose.scale.yml
version: '3.8'
services:
  app:
    image: auth-org-system:latest
    deploy:
      replicas: 3
    environment:
      - DATABASE_URL=${DATABASE_URL}
  
  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
    depends_on:
      - app
```

### Load Balancing

```nginx
upstream backend {
    server app1:4000;
    server app2:4000;
    server app3:4000;
}

server {
    location / {
        proxy_pass http://backend;
    }
}
```

This deployment guide provides comprehensive instructions for deploying the Auth & Organization Management System across various platforms and environments.

