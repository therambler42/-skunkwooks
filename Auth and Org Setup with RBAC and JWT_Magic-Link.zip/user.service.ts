import { Injectable } from '@nestjs/common';
import { PrismaService } from '../common/prisma.service';
import { User } from '@prisma/client';

export interface UpdateUserDto {
  firstName?: string;
  lastName?: string;
  email?: string;
}

@Injectable()
export class UserService {
  constructor(private readonly prisma: PrismaService) {}

  async getUserById(id: string): Promise<User | null> {
    return this.prisma.user.findUnique({
      where: { id },
    });
  }

  async getUserByEmail(email: string): Promise<User | null> {
    return this.prisma.user.findUnique({
      where: { email },
    });
  }

  async updateUser(id: string, data: UpdateUserDto): Promise<User> {
    if (data.email) {
      // Check if email is already taken
      const existingUser = await this.prisma.user.findFirst({
        where: {
          email: data.email,
          NOT: { id },
        },
      });

      if (existingUser) {
        throw new Error('Email already in use');
      }
    }

    return this.prisma.user.update({
      where: { id },
      data,
    });
  }

  async deactivateUser(id: string): Promise<User> {
    return this.prisma.user.update({
      where: { id },
      data: { isActive: false },
    });
  }

  async reactivateUser(id: string): Promise<User> {
    return this.prisma.user.update({
      where: { id },
      data: { isActive: true },
    });
  }

  async getUserWithOrganizations(id: string) {
    return this.prisma.user.findUnique({
      where: { id },
      include: {
        organizationMemberships: {
          where: { isActive: true },
          include: {
            organization: true,
          },
        },
      },
    });
  }
}

