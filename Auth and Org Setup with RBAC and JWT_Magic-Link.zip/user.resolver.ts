import { Resolver, Query, Mutation, Args, Context } from '@nestjs/graphql';
import { UseGuards } from '@nestjs/common';
import { UserService, UpdateUserDto } from './user.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { User } from '@prisma/client';

@Resolver()
export class UserResolver {
  constructor(private readonly userService: UserService) {}

  @UseGuards(JwtAuthGuard)
  @Query(() => User)
  async me(@Context() context: any): Promise<User> {
    const userId = context.req.user.userId;
    const user = await this.userService.getUserById(userId);
    
    if (!user) {
      throw new Error('User not found');
    }
    
    return user;
  }

  @UseGuards(JwtAuthGuard)
  @Query(() => User)
  async userProfile(@Context() context: any) {
    const userId = context.req.user.userId;
    return this.userService.getUserWithOrganizations(userId);
  }

  @UseGuards(JwtAuthGuard)
  @Mutation(() => User)
  async updateProfile(
    @Args('input') input: UpdateUserDto,
    @Context() context: any,
  ): Promise<User> {
    const userId = context.req.user.userId;
    return this.userService.updateUser(userId, input);
  }

  @UseGuards(JwtAuthGuard)
  @Mutation(() => Boolean)
  async deactivateAccount(@Context() context: any): Promise<boolean> {
    const userId = context.req.user.userId;
    await this.userService.deactivateUser(userId);
    return true;
  }
}

