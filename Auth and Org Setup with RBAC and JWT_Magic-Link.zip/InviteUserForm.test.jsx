import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { MockedProvider } from '@apollo/client/testing';
import { InviteUserForm } from '../../src/components/auth/InviteUserForm';
import { INVITE_USER } from '../../src/lib/graphql';
import { AuthProvider } from '../../src/contexts/AuthContext';

const mockAuthContext = {
  organizationId: 'org1',
  role: 'ADMIN',
  user: { id: 'user1', email: 'admin@example.com' },
  isAuthenticated: true,
  isLoading: false,
};

// Mock the useAuth hook
jest.mock('../../src/contexts/AuthContext', () => ({
  ...jest.requireActual('../../src/contexts/AuthContext'),
  useAuth: () => mockAuthContext,
}));

const successMocks = [
  {
    request: {
      query: INVITE_USER,
      variables: {
        input: {
          email: 'newuser@example.com',
          role: 'MANAGER',
          organizationId: 'org1',
        },
      },
    },
    result: {
      data: {
        inviteUser: 'invitation-token',
      },
    },
  },
];

const errorMocks = [
  {
    request: {
      query: INVITE_USER,
      variables: {
        input: {
          email: 'error@example.com',
          role: 'MANAGER',
          organizationId: 'org1',
        },
      },
    },
    error: new Error('Failed to send invitation'),
  },
];

const renderInviteUserForm = (mocks = []) => {
  return render(
    <MockedProvider mocks={mocks} addTypename={false}>
      <InviteUserForm />
    </MockedProvider>
  );
};

describe('InviteUserForm', () => {
  it('renders invite form correctly', () => {
    renderInviteUserForm();

    expect(screen.getByText('Invite User')).toBeInTheDocument();
    expect(screen.getByPlaceholderText('user@example.com')).toBeInTheDocument();
    expect(screen.getByText('Select a role')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /send invitation/i })).toBeInTheDocument();
  });

  it('validates email input', async () => {
    renderInviteUserForm();

    const emailInput = screen.getByPlaceholderText('user@example.com');
    const submitButton = screen.getByRole('button', { name: /send invitation/i });

    // Test invalid email
    fireEvent.change(emailInput, { target: { value: 'invalid-email' } });
    fireEvent.click(submitButton);

    await waitFor(() => {
      expect(screen.getByText('Please enter a valid email address')).toBeInTheDocument();
    });
  });

  it('validates role selection', async () => {
    renderInviteUserForm();

    const emailInput = screen.getByPlaceholderText('user@example.com');
    const submitButton = screen.getByRole('button', { name: /send invitation/i });

    fireEvent.change(emailInput, { target: { value: 'test@example.com' } });
    fireEvent.click(submitButton);

    await waitFor(() => {
      expect(screen.getByText('Please select a role')).toBeInTheDocument();
    });
  });

  it('sends invitation successfully', async () => {
    renderInviteUserForm(successMocks);

    const emailInput = screen.getByPlaceholderText('user@example.com');
    const roleSelect = screen.getByRole('combobox');
    const submitButton = screen.getByRole('button', { name: /send invitation/i });

    fireEvent.change(emailInput, { target: { value: 'newuser@example.com' } });
    
    // Open role dropdown and select Manager
    fireEvent.click(roleSelect);
    await waitFor(() => {
      const managerOption = screen.getByText('Manager');
      fireEvent.click(managerOption);
    });

    fireEvent.click(submitButton);

    await waitFor(() => {
      expect(screen.getByText(/Invitation sent successfully/)).toBeInTheDocument();
    });
  });

  it('handles invitation error', async () => {
    renderInviteUserForm(errorMocks);

    const emailInput = screen.getByPlaceholderText('user@example.com');
    const roleSelect = screen.getByRole('combobox');
    const submitButton = screen.getByRole('button', { name: /send invitation/i });

    fireEvent.change(emailInput, { target: { value: 'error@example.com' } });
    
    fireEvent.click(roleSelect);
    await waitFor(() => {
      const managerOption = screen.getByText('Manager');
      fireEvent.click(managerOption);
    });

    fireEvent.click(submitButton);

    await waitFor(() => {
      expect(screen.getByText(/Failed to send invitation/)).toBeInTheDocument();
    });
  });

  it('shows role descriptions', async () => {
    renderInviteUserForm();

    const roleSelect = screen.getByRole('combobox');
    fireEvent.click(roleSelect);

    await waitFor(() => {
      expect(screen.getByText('Full access to organization settings')).toBeInTheDocument();
      expect(screen.getByText('Manage teams and operations')).toBeInTheDocument();
      expect(screen.getByText('Execute daily operations')).toBeInTheDocument();
      expect(screen.getByText('Limited access for suppliers')).toBeInTheDocument();
    });
  });

  it('disables form during submission', async () => {
    renderInviteUserForm(successMocks);

    const emailInput = screen.getByPlaceholderText('user@example.com');
    const roleSelect = screen.getByRole('combobox');
    const submitButton = screen.getByRole('button', { name: /send invitation/i });

    fireEvent.change(emailInput, { target: { value: 'newuser@example.com' } });
    
    fireEvent.click(roleSelect);
    await waitFor(() => {
      const managerOption = screen.getByText('Manager');
      fireEvent.click(managerOption);
    });

    fireEvent.click(submitButton);

    expect(screen.getByText('Sending invitation...')).toBeInTheDocument();
    expect(emailInput).toBeDisabled();
  });
});

