# Health check endpoint for Docker and deployment monitoring
import { Injectable } from '@nestjs/common';

@Injectable()
export class HealthService {
  check(): { status: string; timestamp: string; uptime: number } {
    return {
      status: 'healthy',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
    };
  }
}

