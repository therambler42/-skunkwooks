import { Resolver, Query, Mutation, Args, Context } from '@nestjs/graphql';
import { UseGuards } from '@nestjs/common';
import { OrganizationService, CreateOrganizationDto, InviteUserDto } from './organization.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { 
  RolesGuard, 
  Roles, 
  MinRole, 
  MinRoleGuard,
  OrganizationOwnerGuard,
  OrganizationAdminGuard 
} from '../common/guards/roles.guard';
import { Organization, OrganizationMember, Role } from '@prisma/client';

@Resolver()
export class OrganizationResolver {
  constructor(private readonly organizationService: OrganizationService) {}

  @UseGuards(JwtAuthGuard)
  @Mutation(() => Organization)
  async createOrganization(
    @Args('input') input: CreateOrganizationDto,
    @Context() context: any,
  ): Promise<Organization> {
    const userId = context.req.user.userId;
    return this.organizationService.createOrganization(input, userId);
  }

  @UseGuards(JwtAuthGuard, MinRoleGuard)
  @MinRole(Role.OPERATOR)
  @Query(() => Organization)
  async organization(@Args('id') id: string): Promise<Organization> {
    const org = await this.organizationService.getOrganization(id);
    if (!org) {
      throw new Error('Organization not found');
    }
    return org;
  }

  @UseGuards(JwtAuthGuard, OrganizationAdminGuard)
  @Mutation(() => Organization)
  async updateOrganization(
    @Args('id') id: string,
    @Args('input') input: Partial<CreateOrganizationDto>,
    @Context() context: any,
  ): Promise<Organization> {
    // Verify user has admin access to this organization
    const userId = context.req.user.userId;
    const organizationId = context.req.user.organizationId;
    
    if (id !== organizationId) {
      throw new Error('Access denied');
    }

    return this.organizationService.updateOrganization(id, input);
  }

  @UseGuards(JwtAuthGuard, OrganizationOwnerGuard)
  @Mutation(() => Boolean)
  async deleteOrganization(
    @Args('id') id: string,
    @Context() context: any,
  ): Promise<boolean> {
    const organizationId = context.req.user.organizationId;
    
    if (id !== organizationId) {
      throw new Error('Access denied');
    }

    await this.organizationService.deleteOrganization(id);
    return true;
  }

  @UseGuards(JwtAuthGuard, OrganizationAdminGuard)
  @Mutation(() => String)
  async inviteUser(
    @Args('input') input: InviteUserDto,
    @Context() context: any,
  ): Promise<string> {
    const senderId = context.req.user.userId;
    const organizationId = context.req.user.organizationId;

    // Ensure invitation is for current organization
    if (input.organizationId !== organizationId) {
      throw new Error('Access denied');
    }

    return this.organizationService.inviteUser(input, senderId);
  }

  @Mutation(() => OrganizationMember)
  async acceptInvitation(@Args('token') token: string): Promise<OrganizationMember> {
    return this.organizationService.acceptInvitation(token);
  }

  @UseGuards(JwtAuthGuard, MinRoleGuard)
  @MinRole(Role.MANAGER)
  @Query(() => [OrganizationMember])
  async organizationMembers(
    @Context() context: any,
  ): Promise<OrganizationMember[]> {
    const organizationId = context.req.user.organizationId;
    return this.organizationService.getOrganizationMembers(organizationId);
  }

  @UseGuards(JwtAuthGuard, OrganizationAdminGuard)
  @Mutation(() => OrganizationMember)
  async updateMemberRole(
    @Args('userId') userId: string,
    @Args('role') role: Role,
    @Context() context: any,
  ): Promise<OrganizationMember> {
    const organizationId = context.req.user.organizationId;
    const currentUserRole = context.req.user.role;

    // Prevent non-owners from creating owners
    if (role === Role.OWNER && currentUserRole !== Role.OWNER) {
      throw new Error('Only owners can assign owner role');
    }

    return this.organizationService.updateMemberRole(organizationId, userId, role);
  }

  @UseGuards(JwtAuthGuard, OrganizationAdminGuard)
  @Mutation(() => Boolean)
  async removeMember(
    @Args('userId') userId: string,
    @Context() context: any,
  ): Promise<boolean> {
    const organizationId = context.req.user.organizationId;
    const currentUserId = context.req.user.userId;

    // Prevent self-removal
    if (userId === currentUserId) {
      throw new Error('Cannot remove yourself from organization');
    }

    await this.organizationService.removeMember(organizationId, userId);
    return true;
  }

  @UseGuards(JwtAuthGuard)
  @Query(() => [OrganizationMember])
  async myOrganizations(@Context() context: any): Promise<OrganizationMember[]> {
    const userId = context.req.user.userId;
    return this.organizationService.getUserOrganizations(userId);
  }
}

