import { Injectable } from '@nestjs/common';
import { TokenService } from './token.service';
import { MagicLinkService } from './magic-link.service';
import { PrismaService } from '../common/prisma.service';
import { User, Role } from '@prisma/client';

export interface LoginResponse {
  user: User;
  accessToken: string;
  refreshToken: string;
  organizationId?: string;
  role?: Role;
}

@Injectable()
export class AuthService {
  constructor(
    private readonly tokenService: TokenService,
    private readonly magicLinkService: MagicLinkService,
    private readonly prisma: PrismaService,
  ) {}

  async sendMagicLink(email: string): Promise<{ message: string }> {
    await this.magicLinkService.generateMagicLink(email);
    return { message: 'Magic link sent to your email' };
  }

  async verifyMagicLink(token: string): Promise<LoginResponse> {
    const user = await this.magicLinkService.verifyMagicLink(token);

    // Get user's primary organization (first active membership)
    const membership = await this.prisma.organizationMember.findFirst({
      where: {
        userId: user.id,
        isActive: true,
      },
      include: {
        organization: true,
      },
      orderBy: {
        joinedAt: 'asc',
      },
    });

    const organizationId = membership?.organizationId;
    const role = membership?.role;

    const tokens = await this.tokenService.generateTokenPair(
      user,
      organizationId,
      role,
    );

    return {
      user,
      accessToken: tokens.accessToken,
      refreshToken: tokens.refreshToken,
      organizationId,
      role,
    };
  }

  async refreshTokens(refreshToken: string): Promise<LoginResponse> {
    const tokens = await this.tokenService.refreshTokens(refreshToken);

    // Decode the new access token to get user info
    const payload = JSON.parse(
      Buffer.from(tokens.accessToken.split('.')[1], 'base64').toString(),
    );

    const user = await this.prisma.user.findUnique({
      where: { id: payload.sub },
    });

    if (!user) {
      throw new Error('User not found');
    }

    return {
      user,
      accessToken: tokens.accessToken,
      refreshToken: tokens.refreshToken,
      organizationId: payload.organizationId,
      role: payload.role,
    };
  }

  async logout(refreshToken: string): Promise<{ message: string }> {
    await this.tokenService.revokeRefreshToken(refreshToken);
    return { message: 'Logged out successfully' };
  }

  async switchOrganization(
    userId: string,
    organizationId: string,
  ): Promise<{ accessToken: string; refreshToken: string; role: Role }> {
    // Verify user has access to this organization
    const membership = await this.prisma.organizationMember.findUnique({
      where: {
        userId_organizationId: {
          userId,
          organizationId,
        },
      },
      include: {
        user: true,
      },
    });

    if (!membership || !membership.isActive) {
      throw new Error('User does not have access to this organization');
    }

    // Generate new tokens with the new organization context
    const tokens = await this.tokenService.generateTokenPair(
      membership.user,
      organizationId,
      membership.role,
    );

    return {
      accessToken: tokens.accessToken,
      refreshToken: tokens.refreshToken,
      role: membership.role,
    };
  }

  async getCurrentUser(userId: string): Promise<User> {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
    });

    if (!user || !user.isActive) {
      throw new Error('User not found or inactive');
    }

    return user;
  }

  async getUserOrganizations(userId: string) {
    return this.prisma.organizationMember.findMany({
      where: {
        userId,
        isActive: true,
      },
      include: {
        organization: true,
      },
      orderBy: {
        joinedAt: 'asc',
      },
    });
  }
}

