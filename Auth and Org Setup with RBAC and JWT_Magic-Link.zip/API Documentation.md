# API Documentation

## GraphQL Schema Reference

### Authentication Types

```graphql
type User {
  id: ID!
  email: String!
  firstName: String
  lastName: String
  isActive: Boolean!
  createdAt: DateTime!
  updatedAt: DateTime!
}

type LoginResponse {
  user: User!
  accessToken: String!
  refreshToken: String!
  organizationId: String
  role: Role
}

type SwitchOrganizationResponse {
  accessToken: String!
  refreshToken: String!
  role: Role!
}

enum Role {
  OWNER
  ADMIN
  MANAGER
  OPERATOR
  SUPPLIER
}
```

### Organization Types

```graphql
type Organization {
  id: ID!
  name: String!
  slug: String!
  description: String
  isActive: Boolean!
  createdAt: DateTime!
  updatedAt: DateTime!
  members: [OrganizationMember!]!
}

type OrganizationMember {
  id: ID!
  userId: String!
  organizationId: String!
  role: Role!
  isActive: Boolean!
  joinedAt: DateTime!
  updatedAt: DateTime!
  user: User!
  organization: Organization!
}

input CreateOrganizationInput {
  name: String!
  slug: String!
  description: String
}

input InviteUserInput {
  email: String!
  role: Role!
  organizationId: String!
}
```

### Mutations

#### Authentication Mutations

```graphql
# Send magic link to user's email
sendMagicLink(email: String!): String!

# Verify magic link token and authenticate user
verifyMagicLink(token: String!): LoginResponse!

# Refresh access token using refresh token
refreshTokens(refreshToken: String!): LoginResponse!

# Logout user and revoke refresh token
logout(refreshToken: String!): String!

# Switch user's active organization
switchOrganization(organizationId: String!): SwitchOrganizationResponse!
```

#### Organization Mutations

```graphql
# Create new organization (user becomes owner)
createOrganization(input: CreateOrganizationInput!): Organization!

# Invite user to organization with specific role
inviteUser(input: InviteUserInput!): String!

# Update organization details (requires ADMIN or OWNER)
updateOrganization(id: String!, input: UpdateOrganizationInput!): Organization!

# Remove user from organization (requires ADMIN or OWNER)
removeUserFromOrganization(userId: String!, organizationId: String!): Boolean!

# Update user role in organization (requires ADMIN or OWNER)
updateUserRole(userId: String!, organizationId: String!, role: Role!): OrganizationMember!
```

### Queries

#### User Queries

```graphql
# Get current authenticated user
me: User!

# Get user's organizations and roles
myOrganizations: [OrganizationMember!]!

# Get user profile by ID (requires appropriate permissions)
user(id: String!): User
```

#### Organization Queries

```graphql
# Get organization details (requires membership)
organization(id: String!): Organization!

# Get organization members (requires MANAGER role or above)
organizationMembers(organizationId: String!): [OrganizationMember!]!

# Get organizations user has access to
organizations: [Organization!]!
```

### Error Handling

The API returns structured errors with the following format:

```graphql
type Error {
  message: String!
  code: String!
  path: [String!]
  extensions: ErrorExtensions
}

type ErrorExtensions {
  code: String!
  statusCode: Int
  timestamp: String
  path: String
}
```

#### Common Error Codes

- `UNAUTHENTICATED`: User not authenticated
- `FORBIDDEN`: Insufficient permissions
- `NOT_FOUND`: Resource not found
- `BAD_USER_INPUT`: Invalid input data
- `INTERNAL_SERVER_ERROR`: Server error

### Rate Limiting

API endpoints are rate-limited to prevent abuse:

- **Magic Link Requests**: 5 per hour per email
- **Authentication**: 10 attempts per minute per IP
- **General API**: 1000 requests per hour per user

### Authentication Headers

Include JWT token in requests:

```http
Authorization: Bearer <access_token>
```

### Example Requests

#### Send Magic Link

```graphql
mutation {
  sendMagicLink(email: "user@example.com")
}
```

#### Verify Magic Link

```graphql
mutation {
  verifyMagicLink(token: "magic-link-token") {
    user {
      id
      email
      firstName
      lastName
    }
    accessToken
    refreshToken
    organizationId
    role
  }
}
```

#### Create Organization

```graphql
mutation {
  createOrganization(input: {
    name: "My Company"
    slug: "my-company"
    description: "A great company"
  }) {
    id
    name
    slug
  }
}
```

#### Invite User

```graphql
mutation {
  inviteUser(input: {
    email: "newuser@example.com"
    role: MANAGER
    organizationId: "org-id"
  })
}
```

#### Switch Organization

```graphql
mutation {
  switchOrganization(organizationId: "new-org-id") {
    accessToken
    refreshToken
    role
  }
}
```

### Subscriptions

Real-time updates for organization changes:

```graphql
subscription {
  organizationUpdated(organizationId: "org-id") {
    id
    name
    members {
      id
      role
      user {
        email
      }
    }
  }
}
```

### Pagination

Large result sets use cursor-based pagination:

```graphql
type PageInfo {
  hasNextPage: Boolean!
  hasPreviousPage: Boolean!
  startCursor: String
  endCursor: String
}

type OrganizationConnection {
  edges: [OrganizationEdge!]!
  pageInfo: PageInfo!
  totalCount: Int!
}

type OrganizationEdge {
  node: Organization!
  cursor: String!
}
```

### Filtering and Sorting

```graphql
enum SortOrder {
  ASC
  DESC
}

input OrganizationFilter {
  name: String
  isActive: Boolean
}

input OrganizationSort {
  field: OrganizationSortField!
  order: SortOrder!
}

enum OrganizationSortField {
  NAME
  CREATED_AT
  UPDATED_AT
}
```

