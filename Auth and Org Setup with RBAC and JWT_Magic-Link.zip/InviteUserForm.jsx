import { useState } from 'react';
import { useMutation } from '@apollo/client';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { UserPlus, Send } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Alert, AlertDescription } from '../ui/alert';
import { INVITE_USER } from '../../lib/graphql';
import { useAuth } from '../../contexts/AuthContext';

const inviteSchema = z.object({
  email: z.string().email('Please enter a valid email address'),
  role: z.enum(['ADMIN', 'MANAGER', 'OPERATOR', 'SUPPLIER'], {
    required_error: 'Please select a role',
  }),
});

const roleOptions = [
  { value: 'ADMIN', label: 'Admin', description: 'Full access to organization settings' },
  { value: 'MANAGER', label: 'Manager', description: 'Manage teams and operations' },
  { value: 'OPERATOR', label: 'Operator', description: 'Execute daily operations' },
  { value: 'SUPPLIER', label: 'Supplier', description: 'Limited access for suppliers' },
];

export function InviteUserForm() {
  const [isSubmitted, setIsSubmitted] = useState(false);
  const { organizationId } = useAuth();
  const [inviteUser, { loading, error }] = useMutation(INVITE_USER);

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    watch,
    reset,
  } = useForm({
    resolver: zodResolver(inviteSchema),
  });

  const selectedRole = watch('role');

  const onSubmit = async (data) => {
    try {
      await inviteUser({
        variables: {
          input: {
            email: data.email,
            role: data.role,
            organizationId,
          },
        },
      });
      setIsSubmitted(true);
      reset();
      
      // Reset form after showing success message
      setTimeout(() => {
        setIsSubmitted(false);
      }, 3000);
    } catch (err) {
      console.error('Error inviting user:', err);
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <div className="flex items-center space-x-2">
          <UserPlus className="w-5 h-5 text-blue-600" />
          <CardTitle>Invite User</CardTitle>
        </div>
        <CardDescription>
          Send an invitation to join your organization
        </CardDescription>
      </CardHeader>
      <CardContent>
        {isSubmitted ? (
          <Alert>
            <Send className="w-4 h-4" />
            <AlertDescription>
              Invitation sent successfully! The user will receive an email with instructions to join.
            </AlertDescription>
          </Alert>
        ) : (
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Email Address</label>
              <Input
                type="email"
                placeholder="user@example.com"
                {...register('email')}
                disabled={loading}
              />
              {errors.email && (
                <p className="text-sm text-destructive">{errors.email.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Role</label>
              <Select
                onValueChange={(value) => setValue('role', value)}
                disabled={loading}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a role" />
                </SelectTrigger>
                <SelectContent>
                  {roleOptions.map((role) => (
                    <SelectItem key={role.value} value={role.value}>
                      <div className="flex flex-col">
                        <span className="font-medium">{role.label}</span>
                        <span className="text-xs text-muted-foreground">
                          {role.description}
                        </span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.role && (
                <p className="text-sm text-destructive">{errors.role.message}</p>
              )}
            </div>

            {selectedRole && (
              <div className="p-3 bg-muted rounded-md">
                <p className="text-sm">
                  <strong>Selected Role:</strong>{' '}
                  {roleOptions.find(r => r.value === selectedRole)?.label}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  {roleOptions.find(r => r.value === selectedRole)?.description}
                </p>
              </div>
            )}

            {error && (
              <Alert variant="destructive">
                <AlertDescription>
                  {error.message || 'Failed to send invitation. Please try again.'}
                </AlertDescription>
              </Alert>
            )}

            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? (
                'Sending invitation...'
              ) : (
                <>
                  Send Invitation
                  <Send className="w-4 h-4 ml-2" />
                </>
              )}
            </Button>
          </form>
        )}
      </CardContent>
    </Card>
  );
}

