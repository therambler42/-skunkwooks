import { PrismaClient, Role } from '@prisma/client';
import { v4 as uuidv4 } from 'uuid';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Starting database seed...');

  // Create sample organization
  const organization = await prisma.organization.create({
    data: {
      id: 'org_sample_123',
      name: 'Acme Corporation',
      slug: 'acme-corp',
      description: 'A sample organization for testing purposes',
    },
  });

  console.log('✅ Created organization:', organization.name);

  // Create sample users
  const users = await Promise.all([
    prisma.user.create({
      data: {
        id: 'user_owner_123',
        email: 'owner@acme.com',
        firstName: 'John',
        lastName: 'Owner',
      },
    }),
    prisma.user.create({
      data: {
        id: 'user_manager_123',
        email: 'manager@acme.com',
        firstName: 'Jane',
        lastName: 'Manager',
      },
    }),
    prisma.user.create({
      data: {
        id: 'user_supplier_123',
        email: 'supplier@acme.com',
        firstName: 'Bob',
        lastName: 'Supplier',
      },
    }),
  ]);

  console.log('✅ Created users:', users.map(u => u.email).join(', '));

  // Create organization memberships
  const memberships = await Promise.all([
    prisma.organizationMember.create({
      data: {
        userId: users[0].id, // Owner
        organizationId: organization.id,
        role: Role.OWNER,
      },
    }),
    prisma.organizationMember.create({
      data: {
        userId: users[1].id, // Manager
        organizationId: organization.id,
        role: Role.MANAGER,
      },
    }),
    prisma.organizationMember.create({
      data: {
        userId: users[2].id, // Supplier
        organizationId: organization.id,
        role: Role.SUPPLIER,
      },
    }),
  ]);

  console.log('✅ Created organization memberships');

  // Create some sample invitations
  const invitations = await Promise.all([
    prisma.invitation.create({
      data: {
        email: 'admin@acme.com',
        role: Role.ADMIN,
        organizationId: organization.id,
        senderId: users[0].id, // Sent by owner
        token: uuidv4(),
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
      },
    }),
    prisma.invitation.create({
      data: {
        email: 'operator@acme.com',
        role: Role.OPERATOR,
        organizationId: organization.id,
        senderId: users[0].id, // Sent by owner
        token: uuidv4(),
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
      },
    }),
  ]);

  console.log('✅ Created sample invitations');

  console.log('🎉 Database seeding completed!');
  console.log('\nSample data created:');
  console.log('Organization: Acme Corporation (acme-corp)');
  console.log('Users:');
  console.log('  - owner@acme.com (Owner)');
  console.log('  - manager@acme.com (Manager)');
  console.log('  - supplier@acme.com (Supplier)');
  console.log('Pending invitations:');
  console.log('  - admin@acme.com (Admin)');
  console.log('  - operator@acme.com (Operator)');
}

main()
  .catch((e) => {
    console.error('❌ Error during seeding:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

