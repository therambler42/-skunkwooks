import { createContext, useContext, useReducer, useEffect } from 'react';
import { apolloClient } from '../lib/apollo';

const AuthContext = createContext();

const initialState = {
  user: null,
  accessToken: null,
  refreshToken: null,
  organizationId: null,
  role: null,
  organizations: [],
  isAuthenticated: false,
  isLoading: true,
};

function authReducer(state, action) {
  switch (action.type) {
    case 'LOGIN':
      return {
        ...state,
        user: action.payload.user,
        accessToken: action.payload.accessToken,
        refreshToken: action.payload.refreshToken,
        organizationId: action.payload.organizationId,
        role: action.payload.role,
        isAuthenticated: true,
        isLoading: false,
      };
    case 'LOGOUT':
      return {
        ...initialState,
        isLoading: false,
      };
    case 'SET_ORGANIZATIONS':
      return {
        ...state,
        organizations: action.payload,
      };
    case 'SWITCH_ORGANIZATION':
      return {
        ...state,
        accessToken: action.payload.accessToken,
        refreshToken: action.payload.refreshToken,
        organizationId: action.payload.organizationId,
        role: action.payload.role,
      };
    case 'SET_LOADING':
      return {
        ...state,
        isLoading: action.payload,
      };
    case 'UPDATE_TOKENS':
      return {
        ...state,
        accessToken: action.payload.accessToken,
        refreshToken: action.payload.refreshToken,
      };
    default:
      return state;
  }
}

export function AuthProvider({ children }) {
  const [state, dispatch] = useReducer(authReducer, initialState);

  useEffect(() => {
    // Check for existing tokens on app load
    const accessToken = localStorage.getItem('accessToken');
    const refreshToken = localStorage.getItem('refreshToken');
    const user = localStorage.getItem('user');
    const organizationId = localStorage.getItem('organizationId');
    const role = localStorage.getItem('role');

    if (accessToken && refreshToken && user) {
      dispatch({
        type: 'LOGIN',
        payload: {
          user: JSON.parse(user),
          accessToken,
          refreshToken,
          organizationId,
          role,
        },
      });
    } else {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  }, []);

  const login = (loginData) => {
    localStorage.setItem('accessToken', loginData.accessToken);
    localStorage.setItem('refreshToken', loginData.refreshToken);
    localStorage.setItem('user', JSON.stringify(loginData.user));
    if (loginData.organizationId) {
      localStorage.setItem('organizationId', loginData.organizationId);
    }
    if (loginData.role) {
      localStorage.setItem('role', loginData.role);
    }

    dispatch({
      type: 'LOGIN',
      payload: loginData,
    });
  };

  const logout = async () => {
    try {
      // Call logout mutation if refresh token exists
      if (state.refreshToken) {
        // TODO: Call logout mutation
      }
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      localStorage.removeItem('accessToken');
      localStorage.removeItem('refreshToken');
      localStorage.removeItem('user');
      localStorage.removeItem('organizationId');
      localStorage.removeItem('role');
      
      // Clear Apollo cache
      await apolloClient.clearStore();
      
      dispatch({ type: 'LOGOUT' });
    }
  };

  const switchOrganization = (organizationData) => {
    localStorage.setItem('accessToken', organizationData.accessToken);
    localStorage.setItem('refreshToken', organizationData.refreshToken);
    localStorage.setItem('organizationId', organizationData.organizationId);
    localStorage.setItem('role', organizationData.role);

    dispatch({
      type: 'SWITCH_ORGANIZATION',
      payload: organizationData,
    });
  };

  const updateTokens = (tokens) => {
    localStorage.setItem('accessToken', tokens.accessToken);
    localStorage.setItem('refreshToken', tokens.refreshToken);

    dispatch({
      type: 'UPDATE_TOKENS',
      payload: tokens,
    });
  };

  const setOrganizations = (organizations) => {
    dispatch({
      type: 'SET_ORGANIZATIONS',
      payload: organizations,
    });
  };

  const value = {
    ...state,
    login,
    logout,
    switchOrganization,
    updateTokens,
    setOrganizations,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

