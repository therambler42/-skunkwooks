import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import * as request from 'supertest';
import { AppModule } from '../src/app.module';
import { PrismaService } from '../src/common/prisma.service';

describe('AuthController (e2e)', () => {
  let app: INestApplication;
  let prismaService: PrismaService;

  beforeEach(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    prismaService = moduleFixture.get<PrismaService>(PrismaService);
    
    await app.init();
  });

  afterEach(async () => {
    await app.close();
  });

  describe('/graphql', () => {
    it('should send magic link', () => {
      const mutation = `
        mutation {
          sendMagicLink(email: "test@example.com")
        }
      `;

      return request(app.getHttpServer())
        .post('/graphql')
        .send({ query: mutation })
        .expect(200)
        .expect((res) => {
          expect(res.body.data.sendMagicLink).toBeDefined();
        });
    });

    it('should handle invalid email format', () => {
      const mutation = `
        mutation {
          sendMagicLink(email: "invalid-email")
        }
      `;

      return request(app.getHttpServer())
        .post('/graphql')
        .send({ query: mutation })
        .expect(200)
        .expect((res) => {
          expect(res.body.errors).toBeDefined();
        });
    });

    it('should require authentication for protected queries', () => {
      const query = `
        query {
          me {
            id
            email
          }
        }
      `;

      return request(app.getHttpServer())
        .post('/graphql')
        .send({ query })
        .expect(200)
        .expect((res) => {
          expect(res.body.errors).toBeDefined();
          expect(res.body.errors[0].message).toContain('Unauthorized');
        });
    });

    it('should allow access with valid JWT token', async () => {
      // This would require setting up a test user and generating a valid token
      // For now, we'll test the structure
      const query = `
        query {
          me {
            id
            email
          }
        }
      `;

      const validToken = 'Bearer valid-jwt-token'; // This would be generated in a real test

      return request(app.getHttpServer())
        .post('/graphql')
        .set('Authorization', validToken)
        .send({ query })
        .expect(200);
        // In a real test, we'd verify the response structure
    });
  });

  describe('Organization Management', () => {
    it('should create organization with owner role', async () => {
      const mutation = `
        mutation {
          createOrganization(input: {
            name: "Test Organization"
            slug: "test-org"
            description: "A test organization"
          }) {
            id
            name
            slug
          }
        }
      `;

      // This would require authentication
      const validToken = 'Bearer valid-jwt-token';

      return request(app.getHttpServer())
        .post('/graphql')
        .set('Authorization', validToken)
        .send({ query: mutation })
        .expect(200);
    });

    it('should enforce role-based access control', async () => {
      const mutation = `
        mutation {
          inviteUser(input: {
            email: "newuser@example.com"
            role: MANAGER
            organizationId: "org1"
          })
        }
      `;

      // Test with insufficient permissions
      const supplierToken = 'Bearer supplier-jwt-token';

      return request(app.getHttpServer())
        .post('/graphql')
        .set('Authorization', supplierToken)
        .send({ query: mutation })
        .expect(200)
        .expect((res) => {
          expect(res.body.errors).toBeDefined();
          expect(res.body.errors[0].message).toContain('Access denied');
        });
    });
  });

  describe('Token Refresh', () => {
    it('should refresh tokens with valid refresh token', () => {
      const mutation = `
        mutation {
          refreshTokens(refreshToken: "valid-refresh-token") {
            accessToken
            refreshToken
            user {
              id
              email
            }
          }
        }
      `;

      return request(app.getHttpServer())
        .post('/graphql')
        .send({ query: mutation })
        .expect(200);
    });

    it('should reject invalid refresh tokens', () => {
      const mutation = `
        mutation {
          refreshTokens(refreshToken: "invalid-refresh-token") {
            accessToken
            refreshToken
          }
        }
      `;

      return request(app.getHttpServer())
        .post('/graphql')
        .send({ query: mutation })
        .expect(200)
        .expect((res) => {
          expect(res.body.errors).toBeDefined();
          expect(res.body.errors[0].message).toContain('Invalid refresh token');
        });
    });
  });
});

