import { Injectable } from '@nestjs/common';
import { PrismaService } from '../common/prisma.service';
import { Organization, OrganizationMember, Role, User } from '@prisma/client';

export interface CreateOrganizationDto {
  name: string;
  slug: string;
  description?: string;
}

export interface InviteUserDto {
  email: string;
  role: Role;
  organizationId: string;
}

@Injectable()
export class OrganizationService {
  constructor(private readonly prisma: PrismaService) {}

  async createOrganization(
    data: CreateOrganizationDto,
    ownerId: string,
  ): Promise<Organization> {
    // Check if slug is already taken
    const existingOrg = await this.prisma.organization.findUnique({
      where: { slug: data.slug },
    });

    if (existingOrg) {
      throw new Error('Organization slug already exists');
    }

    // Create organization and add owner as member
    const organization = await this.prisma.organization.create({
      data: {
        name: data.name,
        slug: data.slug,
        description: data.description,
        members: {
          create: {
            userId: ownerId,
            role: Role.OWNER,
          },
        },
      },
    });

    return organization;
  }

  async getOrganization(id: string): Promise<Organization | null> {
    return this.prisma.organization.findUnique({
      where: { id },
      include: {
        members: {
          include: {
            user: true,
          },
          where: {
            isActive: true,
          },
        },
      },
    });
  }

  async getOrganizationBySlug(slug: string): Promise<Organization | null> {
    return this.prisma.organization.findUnique({
      where: { slug },
      include: {
        members: {
          include: {
            user: true,
          },
          where: {
            isActive: true,
          },
        },
      },
    });
  }

  async updateOrganization(
    id: string,
    data: Partial<CreateOrganizationDto>,
  ): Promise<Organization> {
    if (data.slug) {
      const existingOrg = await this.prisma.organization.findFirst({
        where: {
          slug: data.slug,
          NOT: { id },
        },
      });

      if (existingOrg) {
        throw new Error('Organization slug already exists');
      }
    }

    return this.prisma.organization.update({
      where: { id },
      data,
    });
  }

  async deleteOrganization(id: string): Promise<void> {
    await this.prisma.organization.update({
      where: { id },
      data: { isActive: false },
    });
  }

  async inviteUser(data: InviteUserDto, senderId: string): Promise<string> {
    // Check if user is already a member
    const existingMember = await this.prisma.organizationMember.findUnique({
      where: {
        userId_organizationId: {
          userId: data.email, // This would need to be resolved to userId
          organizationId: data.organizationId,
        },
      },
    });

    if (existingMember) {
      throw new Error('User is already a member of this organization');
    }

    // Generate invitation token
    const token = require('uuid').v4();
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 7); // 7 days

    await this.prisma.invitation.create({
      data: {
        email: data.email,
        role: data.role,
        organizationId: data.organizationId,
        senderId,
        token,
        expiresAt,
      },
    });

    // TODO: Send invitation email
    return token;
  }

  async acceptInvitation(token: string): Promise<OrganizationMember> {
    const invitation = await this.prisma.invitation.findUnique({
      where: { token },
      include: {
        organization: true,
      },
    });

    if (!invitation) {
      throw new Error('Invalid invitation token');
    }

    if (invitation.status !== 'PENDING') {
      throw new Error('Invitation already processed');
    }

    if (invitation.expiresAt < new Date()) {
      throw new Error('Invitation expired');
    }

    // Find or create user
    let user = await this.prisma.user.findUnique({
      where: { email: invitation.email },
    });

    if (!user) {
      user = await this.prisma.user.create({
        data: {
          email: invitation.email,
          isActive: true,
        },
      });
    }

    // Create organization membership
    const member = await this.prisma.organizationMember.create({
      data: {
        userId: user.id,
        organizationId: invitation.organizationId,
        role: invitation.role,
      },
    });

    // Mark invitation as accepted
    await this.prisma.invitation.update({
      where: { token },
      data: {
        status: 'ACCEPTED',
        acceptedAt: new Date(),
      },
    });

    return member;
  }

  async getOrganizationMembers(organizationId: string): Promise<OrganizationMember[]> {
    return this.prisma.organizationMember.findMany({
      where: {
        organizationId,
        isActive: true,
      },
      include: {
        user: true,
      },
      orderBy: [
        { role: 'asc' },
        { joinedAt: 'asc' },
      ],
    });
  }

  async updateMemberRole(
    organizationId: string,
    userId: string,
    role: Role,
  ): Promise<OrganizationMember> {
    return this.prisma.organizationMember.update({
      where: {
        userId_organizationId: {
          userId,
          organizationId,
        },
      },
      data: { role },
    });
  }

  async removeMember(organizationId: string, userId: string): Promise<void> {
    await this.prisma.organizationMember.update({
      where: {
        userId_organizationId: {
          userId,
          organizationId,
        },
      },
      data: { isActive: false },
    });
  }

  async getUserOrganizations(userId: string): Promise<OrganizationMember[]> {
    return this.prisma.organizationMember.findMany({
      where: {
        userId,
        isActive: true,
      },
      include: {
        organization: true,
      },
      orderBy: {
        joinedAt: 'asc',
      },
    });
  }

  async checkUserPermission(
    userId: string,
    organizationId: string,
    requiredRole: Role,
  ): Promise<boolean> {
    const member = await this.prisma.organizationMember.findUnique({
      where: {
        userId_organizationId: {
          userId,
          organizationId,
        },
      },
    });

    if (!member || !member.isActive) {
      return false;
    }

    const roleHierarchy = {
      [Role.OWNER]: 5,
      [Role.ADMIN]: 4,
      [Role.MANAGER]: 3,
      [Role.OPERATOR]: 2,
      [Role.SUPPLIER]: 1,
    };

    return roleHierarchy[member.role] >= roleHierarchy[requiredRole];
  }
}

