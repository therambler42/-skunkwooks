import { Test, TestingModule } from '@nestjs/testing';
import { AuthService } from '../../src/auth/auth.service';
import { TokenService } from '../../src/auth/token.service';
import { MagicLinkService } from '../../src/auth/magic-link.service';
import { PrismaService } from '../../src/common/prisma.service';
import { User, Role } from '@prisma/client';

describe('AuthService', () => {
  let service: AuthService;
  let tokenService: TokenService;
  let magicLinkService: MagicLinkService;
  let prismaService: PrismaService;

  const mockUser: User = {
    id: 'user1',
    email: 'test@example.com',
    firstName: 'John',
    lastName: 'Doe',
    isActive: true,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AuthService,
        {
          provide: TokenService,
          useValue: {
            generateTokenPair: jest.fn(),
            refreshTokens: jest.fn(),
            revokeRefreshToken: jest.fn(),
          },
        },
        {
          provide: MagicLinkService,
          useValue: {
            generateMagicLink: jest.fn(),
            verifyMagicLink: jest.fn(),
          },
        },
        {
          provide: PrismaService,
          useValue: {
            user: {
              findUnique: jest.fn(),
            },
            organizationMember: {
              findFirst: jest.fn(),
              findUnique: jest.fn(),
              findMany: jest.fn(),
            },
          },
        },
      ],
    }).compile();

    service = module.get<AuthService>(AuthService);
    tokenService = module.get<TokenService>(TokenService);
    magicLinkService = module.get<MagicLinkService>(MagicLinkService);
    prismaService = module.get<PrismaService>(PrismaService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('sendMagicLink', () => {
    it('should send magic link successfully', async () => {
      const email = 'test@example.com';

      jest.spyOn(magicLinkService, 'generateMagicLink').mockResolvedValue('token123');

      const result = await service.sendMagicLink(email);

      expect(result).toEqual({ message: 'Magic link sent to your email' });
      expect(magicLinkService.generateMagicLink).toHaveBeenCalledWith(email);
    });
  });

  describe('verifyMagicLink', () => {
    it('should verify magic link and return login response', async () => {
      const token = 'valid-token';
      const mockMembership = {
        id: 'member1',
        userId: mockUser.id,
        organizationId: 'org1',
        role: Role.MANAGER,
        isActive: true,
        joinedAt: new Date(),
        updatedAt: new Date(),
        organization: {
          id: 'org1',
          name: 'Test Org',
          slug: 'test-org',
        },
      };

      const mockTokens = {
        accessToken: 'access-token',
        refreshToken: 'refresh-token',
      };

      jest.spyOn(magicLinkService, 'verifyMagicLink').mockResolvedValue(mockUser);
      jest.spyOn(prismaService.organizationMember, 'findFirst').mockResolvedValue(mockMembership);
      jest.spyOn(tokenService, 'generateTokenPair').mockResolvedValue(mockTokens);

      const result = await service.verifyMagicLink(token);

      expect(result).toEqual({
        user: mockUser,
        accessToken: mockTokens.accessToken,
        refreshToken: mockTokens.refreshToken,
        organizationId: 'org1',
        role: Role.MANAGER,
      });
    });

    it('should verify magic link for user without organization', async () => {
      const token = 'valid-token';
      const mockTokens = {
        accessToken: 'access-token',
        refreshToken: 'refresh-token',
      };

      jest.spyOn(magicLinkService, 'verifyMagicLink').mockResolvedValue(mockUser);
      jest.spyOn(prismaService.organizationMember, 'findFirst').mockResolvedValue(null);
      jest.spyOn(tokenService, 'generateTokenPair').mockResolvedValue(mockTokens);

      const result = await service.verifyMagicLink(token);

      expect(result).toEqual({
        user: mockUser,
        accessToken: mockTokens.accessToken,
        refreshToken: mockTokens.refreshToken,
        organizationId: undefined,
        role: undefined,
      });
    });
  });

  describe('refreshTokens', () => {
    it('should refresh tokens successfully', async () => {
      const refreshToken = 'refresh-token';
      const mockTokens = {
        accessToken: 'new-access-token',
        refreshToken: 'new-refresh-token',
      };

      // Mock JWT payload
      const mockPayload = {
        sub: mockUser.id,
        email: mockUser.email,
        organizationId: 'org1',
        role: Role.MANAGER,
      };

      jest.spyOn(tokenService, 'refreshTokens').mockResolvedValue(mockTokens);
      jest.spyOn(prismaService.user, 'findUnique').mockResolvedValue(mockUser);

      // Mock Buffer.from and JSON.parse for JWT decoding
      const originalBufferFrom = Buffer.from;
      Buffer.from = jest.fn().mockReturnValue({
        toString: jest.fn().mockReturnValue(JSON.stringify(mockPayload)),
      });

      const result = await service.refreshTokens(refreshToken);

      expect(result).toEqual({
        user: mockUser,
        accessToken: mockTokens.accessToken,
        refreshToken: mockTokens.refreshToken,
        organizationId: 'org1',
        role: Role.MANAGER,
      });

      // Restore original Buffer.from
      Buffer.from = originalBufferFrom;
    });
  });

  describe('logout', () => {
    it('should logout successfully', async () => {
      const refreshToken = 'refresh-token';

      jest.spyOn(tokenService, 'revokeRefreshToken').mockResolvedValue();

      const result = await service.logout(refreshToken);

      expect(result).toEqual({ message: 'Logged out successfully' });
      expect(tokenService.revokeRefreshToken).toHaveBeenCalledWith(refreshToken);
    });
  });

  describe('switchOrganization', () => {
    it('should switch organization successfully', async () => {
      const userId = 'user1';
      const organizationId = 'org2';
      const mockMembership = {
        id: 'member2',
        userId,
        organizationId,
        role: Role.ADMIN,
        isActive: true,
        joinedAt: new Date(),
        updatedAt: new Date(),
        user: mockUser,
      };

      const mockTokens = {
        accessToken: 'new-access-token',
        refreshToken: 'new-refresh-token',
      };

      jest.spyOn(prismaService.organizationMember, 'findUnique').mockResolvedValue(mockMembership);
      jest.spyOn(tokenService, 'generateTokenPair').mockResolvedValue(mockTokens);

      const result = await service.switchOrganization(userId, organizationId);

      expect(result).toEqual({
        accessToken: mockTokens.accessToken,
        refreshToken: mockTokens.refreshToken,
        role: Role.ADMIN,
      });
    });

    it('should throw error for unauthorized organization access', async () => {
      const userId = 'user1';
      const organizationId = 'unauthorized-org';

      jest.spyOn(prismaService.organizationMember, 'findUnique').mockResolvedValue(null);

      await expect(service.switchOrganization(userId, organizationId))
        .rejects.toThrow('User does not have access to this organization');
    });
  });

  describe('getCurrentUser', () => {
    it('should return current user', async () => {
      const userId = 'user1';

      jest.spyOn(prismaService.user, 'findUnique').mockResolvedValue(mockUser);

      const result = await service.getCurrentUser(userId);

      expect(result).toEqual(mockUser);
    });

    it('should throw error for inactive user', async () => {
      const userId = 'user1';
      const inactiveUser = { ...mockUser, isActive: false };

      jest.spyOn(prismaService.user, 'findUnique').mockResolvedValue(inactiveUser);

      await expect(service.getCurrentUser(userId))
        .rejects.toThrow('User not found or inactive');
    });
  });

  describe('getUserOrganizations', () => {
    it('should return user organizations', async () => {
      const userId = 'user1';
      const mockOrganizations = [
        {
          id: 'member1',
          userId,
          organizationId: 'org1',
          role: Role.MANAGER,
          isActive: true,
          joinedAt: new Date(),
          updatedAt: new Date(),
          organization: {
            id: 'org1',
            name: 'Test Org 1',
            slug: 'test-org-1',
          },
        },
        {
          id: 'member2',
          userId,
          organizationId: 'org2',
          role: Role.ADMIN,
          isActive: true,
          joinedAt: new Date(),
          updatedAt: new Date(),
          organization: {
            id: 'org2',
            name: 'Test Org 2',
            slug: 'test-org-2',
          },
        },
      ];

      jest.spyOn(prismaService.organizationMember, 'findMany').mockResolvedValue(mockOrganizations);

      const result = await service.getUserOrganizations(userId);

      expect(result).toEqual(mockOrganizations);
      expect(prismaService.organizationMember.findMany).toHaveBeenCalledWith({
        where: {
          userId,
          isActive: true,
        },
        include: {
          organization: true,
        },
        orderBy: {
          joinedAt: 'asc',
        },
      });
    });
  });
});

