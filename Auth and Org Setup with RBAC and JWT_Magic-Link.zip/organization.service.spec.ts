import { Test, TestingModule } from '@nestjs/testing';
import { OrganizationService } from '../../src/organization/organization.service';
import { PrismaService } from '../../src/common/prisma.service';
import { Role } from '@prisma/client';

describe('OrganizationService', () => {
  let service: OrganizationService;
  let prismaService: PrismaService;

  const mockOrganization = {
    id: 'org1',
    name: 'Test Organization',
    slug: 'test-org',
    description: 'A test organization',
    isActive: true,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  const mockUser = {
    id: 'user1',
    email: 'test@example.com',
    firstName: 'John',
    lastName: 'Doe',
    isActive: true,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        OrganizationService,
        {
          provide: PrismaService,
          useValue: {
            organization: {
              findUnique: jest.fn(),
              findFirst: jest.fn(),
              create: jest.fn(),
              update: jest.fn(),
            },
            organizationMember: {
              findUnique: jest.fn(),
              findFirst: jest.fn(),
              findMany: jest.fn(),
              create: jest.fn(),
              update: jest.fn(),
            },
            user: {
              findUnique: jest.fn(),
              create: jest.fn(),
            },
            invitation: {
              create: jest.fn(),
              findUnique: jest.fn(),
              update: jest.fn(),
            },
          },
        },
      ],
    }).compile();

    service = module.get<OrganizationService>(OrganizationService);
    prismaService = module.get<PrismaService>(PrismaService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('createOrganization', () => {
    it('should create organization successfully', async () => {
      const createData = {
        name: 'New Organization',
        slug: 'new-org',
        description: 'A new organization',
      };
      const ownerId = 'user1';

      jest.spyOn(prismaService.organization, 'findUnique').mockResolvedValue(null);
      jest.spyOn(prismaService.organization, 'create').mockResolvedValue({
        ...mockOrganization,
        ...createData,
      });

      const result = await service.createOrganization(createData, ownerId);

      expect(result).toEqual({
        ...mockOrganization,
        ...createData,
      });

      expect(prismaService.organization.create).toHaveBeenCalledWith({
        data: {
          ...createData,
          members: {
            create: {
              userId: ownerId,
              role: Role.OWNER,
            },
          },
        },
      });
    });

    it('should throw error for duplicate slug', async () => {
      const createData = {
        name: 'New Organization',
        slug: 'existing-slug',
        description: 'A new organization',
      };
      const ownerId = 'user1';

      jest.spyOn(prismaService.organization, 'findUnique').mockResolvedValue(mockOrganization);

      await expect(service.createOrganization(createData, ownerId))
        .rejects.toThrow('Organization slug already exists');
    });
  });

  describe('getOrganization', () => {
    it('should return organization with members', async () => {
      const organizationId = 'org1';
      const mockOrgWithMembers = {
        ...mockOrganization,
        members: [
          {
            id: 'member1',
            userId: 'user1',
            organizationId,
            role: Role.OWNER,
            isActive: true,
            user: mockUser,
          },
        ],
      };

      jest.spyOn(prismaService.organization, 'findUnique').mockResolvedValue(mockOrgWithMembers);

      const result = await service.getOrganization(organizationId);

      expect(result).toEqual(mockOrgWithMembers);
      expect(prismaService.organization.findUnique).toHaveBeenCalledWith({
        where: { id: organizationId },
        include: {
          members: {
            include: {
              user: true,
            },
            where: {
              isActive: true,
            },
          },
        },
      });
    });
  });

  describe('inviteUser', () => {
    it('should create invitation successfully', async () => {
      const inviteData = {
        email: 'newuser@example.com',
        role: Role.MANAGER,
        organizationId: 'org1',
      };
      const senderId = 'user1';

      jest.spyOn(prismaService.organizationMember, 'findUnique').mockResolvedValue(null);
      jest.spyOn(prismaService.invitation, 'create').mockResolvedValue({
        id: 'invitation1',
        email: inviteData.email,
        role: inviteData.role,
        organizationId: inviteData.organizationId,
        senderId,
        token: 'mock-token',
        status: 'PENDING',
        expiresAt: new Date(),
        acceptedAt: null,
        createdAt: new Date(),
        updatedAt: new Date(),
      });

      // Mock uuid
      jest.doMock('uuid', () => ({
        v4: jest.fn().mockReturnValue('mock-token'),
      }));

      const result = await service.inviteUser(inviteData, senderId);

      expect(result).toBe('mock-token');
      expect(prismaService.invitation.create).toHaveBeenCalled();
    });

    it('should throw error for existing member', async () => {
      const inviteData = {
        email: 'existing@example.com',
        role: Role.MANAGER,
        organizationId: 'org1',
      };
      const senderId = 'user1';

      const existingMember = {
        id: 'member1',
        userId: 'user2',
        organizationId: 'org1',
        role: Role.MANAGER,
        isActive: true,
        joinedAt: new Date(),
        updatedAt: new Date(),
      };

      jest.spyOn(prismaService.organizationMember, 'findUnique').mockResolvedValue(existingMember);

      await expect(service.inviteUser(inviteData, senderId))
        .rejects.toThrow('User is already a member of this organization');
    });
  });

  describe('checkUserPermission', () => {
    it('should return true for sufficient permissions', async () => {
      const userId = 'user1';
      const organizationId = 'org1';
      const requiredRole = Role.OPERATOR;

      const mockMember = {
        id: 'member1',
        userId,
        organizationId,
        role: Role.MANAGER, // Higher than OPERATOR
        isActive: true,
        joinedAt: new Date(),
        updatedAt: new Date(),
      };

      jest.spyOn(prismaService.organizationMember, 'findUnique').mockResolvedValue(mockMember);

      const result = await service.checkUserPermission(userId, organizationId, requiredRole);

      expect(result).toBe(true);
    });

    it('should return false for insufficient permissions', async () => {
      const userId = 'user1';
      const organizationId = 'org1';
      const requiredRole = Role.ADMIN;

      const mockMember = {
        id: 'member1',
        userId,
        organizationId,
        role: Role.OPERATOR, // Lower than ADMIN
        isActive: true,
        joinedAt: new Date(),
        updatedAt: new Date(),
      };

      jest.spyOn(prismaService.organizationMember, 'findUnique').mockResolvedValue(mockMember);

      const result = await service.checkUserPermission(userId, organizationId, requiredRole);

      expect(result).toBe(false);
    });

    it('should return false for non-member', async () => {
      const userId = 'user1';
      const organizationId = 'org1';
      const requiredRole = Role.OPERATOR;

      jest.spyOn(prismaService.organizationMember, 'findUnique').mockResolvedValue(null);

      const result = await service.checkUserPermission(userId, organizationId, requiredRole);

      expect(result).toBe(false);
    });
  });
});

