import { InviteUserForm } from '../components/auth/InviteUserForm';
import { useAuth } from '../contexts/AuthContext';

export function InvitePage() {
  const { role } = useAuth();

  // Check if user has permission to invite users
  const canInvite = ['OWNER', 'ADMIN'].includes(role);

  if (!canInvite) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Access Denied</h1>
          <p className="text-gray-600">
            You don't have permission to invite users to this organization.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Invite User</h1>
          <p className="text-gray-600 mt-2">
            Add a new member to your organization
          </p>
        </div>
        <InviteUserForm />
      </div>
    </div>
  );
}

