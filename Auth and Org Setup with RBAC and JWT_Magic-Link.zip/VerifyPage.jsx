import { MagicLinkVerification } from '../components/auth/MagicLinkVerification';

export function VerifyPage() {
  return <MagicLinkVerification />;
}

