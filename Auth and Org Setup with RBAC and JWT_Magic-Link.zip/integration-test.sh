#!/bin/bash

# Integration test script for the authentication system
set -e

echo "🧪 Starting integration tests for Auth & Organization System..."

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

# Check if required tools are installed
check_dependencies() {
    echo "🔍 Checking dependencies..."
    
    if ! command -v node &> /dev/null; then
        print_error "Node.js is not installed"
        exit 1
    fi
    
    if ! command -v npm &> /dev/null; then
        print_error "npm is not installed"
        exit 1
    fi
    
    print_status "All dependencies are available"
}

# Install dependencies
install_dependencies() {
    echo "📦 Installing dependencies..."
    
    # Root dependencies
    npm install
    
    # Backend dependencies
    cd backend
    npm install
    cd ..
    
    # Frontend dependencies
    cd frontend/auth-frontend
    npm install
    cd ../..
    
    print_status "Dependencies installed"
}

# Run linting
run_linting() {
    echo "🔍 Running linting checks..."
    
    # Backend linting
    cd backend
    npm run lint
    cd ..
    
    # Frontend linting
    cd frontend/auth-frontend
    npm run lint
    cd ../..
    
    print_status "Linting passed"
}

# Run tests
run_tests() {
    echo "🧪 Running test suites..."
    
    # Backend tests
    cd backend
    npm run test
    cd ..
    
    # Frontend tests
    cd frontend/auth-frontend
    npm run test -- --watchAll=false
    cd ../..
    
    print_status "All tests passed"
}

# Build applications
build_applications() {
    echo "🏗️  Building applications..."
    
    # Generate Prisma client
    cd backend
    npm run db:generate
    cd ..
    
    # Build backend
    cd backend
    npm run build
    cd ..
    
    # Build frontend
    cd frontend/auth-frontend
    npm run build
    cd ../..
    
    print_status "Applications built successfully"
}

# Validate build outputs
validate_builds() {
    echo "✅ Validating build outputs..."
    
    # Check backend build
    if [ ! -d "backend/dist" ]; then
        print_error "Backend build directory not found"
        exit 1
    fi
    
    if [ ! -f "backend/dist/main.js" ]; then
        print_error "Backend main.js not found"
        exit 1
    fi
    
    # Check frontend build
    if [ ! -d "frontend/auth-frontend/dist" ]; then
        print_error "Frontend build directory not found"
        exit 1
    fi
    
    if [ ! -f "frontend/auth-frontend/dist/index.html" ]; then
        print_error "Frontend index.html not found"
        exit 1
    fi
    
    print_status "Build outputs validated"
}

# Test Docker build
test_docker_build() {
    echo "🐳 Testing Docker build..."
    
    if command -v docker &> /dev/null; then
        # Build Docker image
        docker build -t auth-org-system:test .
        
        print_status "Docker build successful"
    else
        print_warning "Docker not available, skipping Docker build test"
    fi
}

# Validate configuration files
validate_configs() {
    echo "⚙️  Validating configuration files..."
    
    # Check required config files exist
    local configs=(
        ".eslintrc.js"
        ".prettierrc"
        "docker-compose.yml"
        "Dockerfile"
        ".github/workflows/ci-cd.yml"
        "backend/tsconfig.json"
        "backend/package.json"
        "frontend/auth-frontend/package.json"
    )
    
    for config in "${configs[@]}"; do
        if [ ! -f "$config" ]; then
            print_error "Configuration file missing: $config"
            exit 1
        fi
    done
    
    print_status "All configuration files present"
}

# Check environment variables
check_env_vars() {
    echo "🔐 Checking environment configuration..."
    
    # Check if example env files exist
    if [ ! -f "backend/.env.example" ]; then
        print_error "Backend .env.example file missing"
        exit 1
    fi
    
    if [ ! -f "frontend/auth-frontend/.env.example" ]; then
        print_error "Frontend .env.example file missing"
        exit 1
    fi
    
    print_status "Environment configuration validated"
}

# Validate acceptance criteria
validate_acceptance_criteria() {
    echo "📋 Validating acceptance criteria..."
    
    # Check if all required components exist
    local components=(
        "backend/src/auth/auth.service.ts"
        "backend/src/auth/token.service.ts"
        "backend/src/auth/magic-link.service.ts"
        "backend/src/common/guards/roles.guard.ts"
        "backend/src/organization/organization.service.ts"
        "backend/prisma/schema.prisma"
        "backend/prisma/seed.ts"
        "frontend/auth-frontend/src/components/auth/SignInForm.jsx"
        "frontend/auth-frontend/src/components/auth/InviteUserForm.jsx"
        "frontend/auth-frontend/src/components/auth/OrganizationSwitcher.jsx"
        "frontend/auth-frontend/src/contexts/AuthContext.jsx"
    )
    
    for component in "${components[@]}"; do
        if [ ! -f "$component" ]; then
            print_error "Required component missing: $component"
            exit 1
        fi
    done
    
    print_status "All required components present"
}

# Main execution
main() {
    echo "🚀 Auth & Organization System Integration Test"
    echo "=============================================="
    
    check_dependencies
    install_dependencies
    validate_configs
    check_env_vars
    run_linting
    run_tests
    build_applications
    validate_builds
    test_docker_build
    validate_acceptance_criteria
    
    echo ""
    echo "🎉 Integration tests completed successfully!"
    echo ""
    echo "📊 Summary:"
    echo "  ✅ Dependencies installed"
    echo "  ✅ Linting passed"
    echo "  ✅ Tests passed"
    echo "  ✅ Applications built"
    echo "  ✅ Docker build tested"
    echo "  ✅ Configurations validated"
    echo "  ✅ Acceptance criteria met"
    echo ""
    echo "🚀 System is ready for deployment!"
}

# Run main function
main "$@"

