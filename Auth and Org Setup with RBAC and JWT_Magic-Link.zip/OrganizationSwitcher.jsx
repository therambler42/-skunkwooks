import { useState } from 'react';
import { useQuery, useMutation } from '@apollo/client';
import { ChevronDown, Building2, Check } from 'lucide-react';
import { Button } from '../ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '../ui/dropdown-menu';
import { Badge } from '../ui/badge';
import { GET_MY_ORGANIZATIONS, SWITCH_ORGANIZATION } from '../../lib/graphql';
import { useAuth } from '../../contexts/AuthContext';

export function OrganizationSwitcher() {
  const { organizationId, role, switchOrganization } = useAuth();
  const [isOpen, setIsOpen] = useState(false);

  const { data: organizationsData, loading } = useQuery(GET_MY_ORGANIZATIONS);
  const [switchOrgMutation, { loading: switching }] = useMutation(SWITCH_ORGANIZATION);

  const organizations = organizationsData?.myOrganizations || [];
  const currentOrg = organizations.find(org => org.organization.id === organizationId);

  const handleSwitchOrganization = async (newOrgId) => {
    if (newOrgId === organizationId) return;

    try {
      const { data } = await switchOrgMutation({
        variables: { organizationId: newOrgId },
      });

      if (data?.switchOrganization) {
        switchOrganization({
          ...data.switchOrganization,
          organizationId: newOrgId,
        });
      }
      setIsOpen(false);
    } catch (error) {
      console.error('Error switching organization:', error);
    }
  };

  if (loading || organizations.length === 0) {
    return null;
  }

  return (
    <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
      <DropdownMenuTrigger asChild>
        <Button
          variant="outline"
          className="w-full justify-between"
          disabled={switching}
        >
          <div className="flex items-center space-x-2">
            <Building2 className="w-4 h-4" />
            <div className="flex flex-col items-start">
              <span className="text-sm font-medium">
                {currentOrg?.organization.name || 'Select Organization'}
              </span>
              {role && (
                <Badge variant="secondary" className="text-xs">
                  {role.toLowerCase()}
                </Badge>
              )}
            </div>
          </div>
          <ChevronDown className="w-4 h-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-64" align="start">
        {organizations.map((org) => (
          <DropdownMenuItem
            key={org.organization.id}
            onClick={() => handleSwitchOrganization(org.organization.id)}
            className="flex items-center justify-between p-3"
          >
            <div className="flex flex-col">
              <span className="font-medium">{org.organization.name}</span>
              <span className="text-xs text-muted-foreground">
                @{org.organization.slug}
              </span>
              <Badge variant="outline" className="text-xs mt-1 w-fit">
                {org.role.toLowerCase()}
              </Badge>
            </div>
            {org.organization.id === organizationId && (
              <Check className="w-4 h-4 text-green-600" />
            )}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

