import { Resolver, Mutation, Query, Args, Context } from '@nestjs/graphql';
import { UseGuards } from '@nestjs/common';
import { AuthService, LoginResponse } from './auth.service';
import { JwtAuthGuard } from './jwt-auth.guard';
import { User } from '@prisma/client';

@Resolver()
export class AuthResolver {
  constructor(private readonly authService: AuthService) {}

  @Mutation(() => String)
  async sendMagicLink(@Args('email') email: string): Promise<string> {
    const result = await this.authService.sendMagicLink(email);
    return result.message;
  }

  @Mutation(() => LoginResponse)
  async verifyMagicLink(@Args('token') token: string): Promise<LoginResponse> {
    return this.authService.verifyMagicLink(token);
  }

  @Mutation(() => LoginResponse)
  async refreshTokens(@Args('refreshToken') refreshToken: string): Promise<LoginResponse> {
    return this.authService.refreshTokens(refreshToken);
  }

  @Mutation(() => String)
  async logout(@Args('refreshToken') refreshToken: string): Promise<string> {
    const result = await this.authService.logout(refreshToken);
    return result.message;
  }

  @UseGuards(JwtAuthGuard)
  @Mutation(() => SwitchOrganizationResponse)
  async switchOrganization(
    @Args('organizationId') organizationId: string,
    @Context() context: any,
  ): Promise<SwitchOrganizationResponse> {
    const userId = context.req.user.userId;
    return this.authService.switchOrganization(userId, organizationId);
  }

  @UseGuards(JwtAuthGuard)
  @Query(() => User)
  async me(@Context() context: any): Promise<User> {
    const userId = context.req.user.userId;
    return this.authService.getCurrentUser(userId);
  }

  @UseGuards(JwtAuthGuard)
  @Query(() => [OrganizationMembership])
  async myOrganizations(@Context() context: any) {
    const userId = context.req.user.userId;
    return this.authService.getUserOrganizations(userId);
  }
}

// GraphQL Types (these would typically be in separate files)
export class LoginResponse {
  user: User;
  accessToken: string;
  refreshToken: string;
  organizationId?: string;
  role?: string;
}

export class SwitchOrganizationResponse {
  accessToken: string;
  refreshToken: string;
  role: string;
}

export class OrganizationMembership {
  id: string;
  role: string;
  organization: {
    id: string;
    name: string;
    slug: string;
  };
}

