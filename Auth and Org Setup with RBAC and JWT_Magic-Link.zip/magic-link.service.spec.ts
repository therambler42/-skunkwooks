import { Test, TestingModule } from '@nestjs/testing';
import { ConfigService } from '@nestjs/config';
import { MagicLinkService } from '../../src/auth/magic-link.service';
import { PrismaService } from '../../src/common/prisma.service';
import { User } from '@prisma/client';

// Mock SendGrid
jest.mock('@sendgrid/mail', () => ({
  setApiKey: jest.fn(),
  send: jest.fn(),
}));

describe('MagicLinkService', () => {
  let service: MagicLinkService;
  let prismaService: PrismaService;
  let configService: ConfigService;

  const mockUser: User = {
    id: 'user1',
    email: 'test@example.com',
    firstName: 'John',
    lastName: 'Doe',
    isActive: true,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        MagicLinkService,
        {
          provide: PrismaService,
          useValue: {
            user: {
              findUnique: jest.fn(),
              create: jest.fn(),
            },
            magicLink: {
              create: jest.fn(),
              findUnique: jest.fn(),
              update: jest.fn(),
              deleteMany: jest.fn(),
            },
          },
        },
        {
          provide: ConfigService,
          useValue: {
            get: jest.fn(),
          },
        },
      ],
    }).compile();

    service = module.get<MagicLinkService>(MagicLinkService);
    prismaService = module.get<PrismaService>(PrismaService);
    configService = module.get<ConfigService>(ConfigService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('generateMagicLink', () => {
    it('should generate magic link for existing user', async () => {
      const email = 'test@example.com';

      jest.spyOn(prismaService.user, 'findUnique').mockResolvedValue(mockUser);
      jest.spyOn(prismaService.magicLink, 'create').mockResolvedValue({
        id: 'link1',
        token: 'mock-token',
        userId: mockUser.id,
        email,
        expiresAt: new Date(),
        usedAt: null,
        createdAt: new Date(),
      });

      jest.spyOn(configService, 'get')
        .mockReturnValueOnce('test-api-key')
        .mockReturnValueOnce('http://localhost:3000')
        .mockReturnValueOnce('noreply@test.com');

      const sgMail = require('@sendgrid/mail');
      sgMail.send.mockResolvedValue([{ statusCode: 202 }]);

      const result = await service.generateMagicLink(email);

      expect(result).toBeDefined();
      expect(prismaService.magicLink.create).toHaveBeenCalled();
      expect(sgMail.send).toHaveBeenCalled();
    });

    it('should create new user if not exists', async () => {
      const email = 'newuser@example.com';

      jest.spyOn(prismaService.user, 'findUnique').mockResolvedValue(null);
      jest.spyOn(prismaService.user, 'create').mockResolvedValue({
        ...mockUser,
        email,
      });
      jest.spyOn(prismaService.magicLink, 'create').mockResolvedValue({
        id: 'link1',
        token: 'mock-token',
        userId: mockUser.id,
        email,
        expiresAt: new Date(),
        usedAt: null,
        createdAt: new Date(),
      });

      jest.spyOn(configService, 'get')
        .mockReturnValueOnce('test-api-key')
        .mockReturnValueOnce('http://localhost:3000')
        .mockReturnValueOnce('noreply@test.com');

      const sgMail = require('@sendgrid/mail');
      sgMail.send.mockResolvedValue([{ statusCode: 202 }]);

      const result = await service.generateMagicLink(email);

      expect(result).toBeDefined();
      expect(prismaService.user.create).toHaveBeenCalledWith({
        data: {
          email,
          isActive: true,
        },
      });
    });

    it('should throw error for inactive user', async () => {
      const email = 'inactive@example.com';
      const inactiveUser = { ...mockUser, isActive: false };

      jest.spyOn(prismaService.user, 'findUnique').mockResolvedValue(inactiveUser);

      await expect(service.generateMagicLink(email)).rejects.toThrow('User account is deactivated');
    });
  });

  describe('verifyMagicLink', () => {
    it('should verify valid magic link', async () => {
      const token = 'valid-token';
      const mockMagicLink = {
        id: 'link1',
        token,
        userId: mockUser.id,
        email: mockUser.email,
        expiresAt: new Date(Date.now() + 900000), // 15 minutes from now
        usedAt: null,
        createdAt: new Date(),
        user: mockUser,
      };

      jest.spyOn(prismaService.magicLink, 'findUnique').mockResolvedValue(mockMagicLink);
      jest.spyOn(prismaService.magicLink, 'update').mockResolvedValue({
        ...mockMagicLink,
        usedAt: new Date(),
      });

      const result = await service.verifyMagicLink(token);

      expect(result).toEqual(mockUser);
      expect(prismaService.magicLink.update).toHaveBeenCalledWith({
        where: { token },
        data: { usedAt: expect.any(Date) },
      });
    });

    it('should throw error for invalid token', async () => {
      const token = 'invalid-token';

      jest.spyOn(prismaService.magicLink, 'findUnique').mockResolvedValue(null);

      await expect(service.verifyMagicLink(token)).rejects.toThrow('Invalid magic link');
    });

    it('should throw error for already used token', async () => {
      const token = 'used-token';
      const mockMagicLink = {
        id: 'link1',
        token,
        userId: mockUser.id,
        email: mockUser.email,
        expiresAt: new Date(Date.now() + 900000),
        usedAt: new Date(), // Already used
        createdAt: new Date(),
        user: mockUser,
      };

      jest.spyOn(prismaService.magicLink, 'findUnique').mockResolvedValue(mockMagicLink);

      await expect(service.verifyMagicLink(token)).rejects.toThrow('Magic link already used');
    });

    it('should throw error for expired token', async () => {
      const token = 'expired-token';
      const mockMagicLink = {
        id: 'link1',
        token,
        userId: mockUser.id,
        email: mockUser.email,
        expiresAt: new Date(Date.now() - 900000), // 15 minutes ago
        usedAt: null,
        createdAt: new Date(),
        user: mockUser,
      };

      jest.spyOn(prismaService.magicLink, 'findUnique').mockResolvedValue(mockMagicLink);

      await expect(service.verifyMagicLink(token)).rejects.toThrow('Magic link expired');
    });

    it('should throw error for inactive user', async () => {
      const token = 'valid-token';
      const inactiveUser = { ...mockUser, isActive: false };
      const mockMagicLink = {
        id: 'link1',
        token,
        userId: inactiveUser.id,
        email: inactiveUser.email,
        expiresAt: new Date(Date.now() + 900000),
        usedAt: null,
        createdAt: new Date(),
        user: inactiveUser,
      };

      jest.spyOn(prismaService.magicLink, 'findUnique').mockResolvedValue(mockMagicLink);

      await expect(service.verifyMagicLink(token)).rejects.toThrow('User account is deactivated');
    });
  });

  describe('cleanupExpiredMagicLinks', () => {
    it('should cleanup expired magic links', async () => {
      jest.spyOn(prismaService.magicLink, 'deleteMany').mockResolvedValue({ count: 3 });

      await service.cleanupExpiredMagicLinks();

      expect(prismaService.magicLink.deleteMany).toHaveBeenCalledWith({
        where: {
          expiresAt: {
            lt: expect.any(Date),
          },
        },
      });
    });
  });
});

