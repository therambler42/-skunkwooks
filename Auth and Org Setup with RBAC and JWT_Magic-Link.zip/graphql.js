import { gql } from '@apollo/client';

export const SEND_MAGIC_LINK = gql`
  mutation SendMagicLink($email: String!) {
    sendMagicLink(email: $email)
  }
`;

export const VERIFY_MAGIC_LINK = gql`
  mutation VerifyMagicLink($token: String!) {
    verifyMagicLink(token: $token) {
      user {
        id
        email
        firstName
        lastName
      }
      accessToken
      refreshToken
      organizationId
      role
    }
  }
`;

export const REFRESH_TOKENS = gql`
  mutation RefreshTokens($refreshToken: String!) {
    refreshTokens(refreshToken: $refreshToken) {
      user {
        id
        email
        firstName
        lastName
      }
      accessToken
      refreshToken
      organizationId
      role
    }
  }
`;

export const LOGOUT = gql`
  mutation Logout($refreshToken: String!) {
    logout(refreshToken: $refreshToken)
  }
`;

export const SWITCH_ORGANIZATION = gql`
  mutation SwitchOrganization($organizationId: String!) {
    switchOrganization(organizationId: $organizationId) {
      accessToken
      refreshToken
      role
    }
  }
`;

export const GET_ME = gql`
  query GetMe {
    me {
      id
      email
      firstName
      lastName
    }
  }
`;

export const GET_MY_ORGANIZATIONS = gql`
  query GetMyOrganizations {
    myOrganizations {
      id
      role
      organization {
        id
        name
        slug
      }
    }
  }
`;

export const INVITE_USER = gql`
  mutation InviteUser($input: InviteUserInput!) {
    inviteUser(input: $input)
  }
`;

export const GET_ORGANIZATION_MEMBERS = gql`
  query GetOrganizationMembers {
    organizationMembers {
      id
      role
      user {
        id
        email
        firstName
        lastName
      }
    }
  }
`;

