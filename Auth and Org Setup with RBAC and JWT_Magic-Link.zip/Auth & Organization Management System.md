# Auth & Organization Management System

A comprehensive authentication and organization management system built with NestJS, React, and PostgreSQL, featuring role-based access control (RBAC), JWT tokens, and magic-link authentication.

## 🚀 Features

### Authentication & Security
- **Magic Link Authentication**: Passwordless email-based login using SendGrid
- **JWT Tokens**: Access tokens (15 min) and refresh tokens (7 days)
- **Role-Based Access Control (RBAC)**: Five distinct roles with hierarchical permissions
- **Multi-tenant Architecture**: Organization-based user isolation
- **Secure Token Management**: Automatic token refresh and revocation

### Organization Management
- **Multi-Organization Support**: Users can belong to multiple organizations
- **Role Management**: Owner, Admin, Manager, Operator, and Supplier roles
- **User Invitations**: Email-based invitation system with role assignment
- **Organization Switching**: Seamless context switching between organizations

### Technical Stack
- **Backend**: NestJS with GraphQL API
- **Frontend**: React with Apollo Client and Tailwind CSS
- **Database**: PostgreSQL with Prisma ORM
- **Authentication**: JWT with magic-link flow
- **Email**: SendGrid integration
- **Testing**: Jest with 95%+ coverage
- **Deployment**: Docker with Fly.io staging environment

## 📋 Table of Contents

- [Quick Start](#quick-start)
- [Architecture](#architecture)
- [API Documentation](#api-documentation)
- [Frontend Components](#frontend-components)
- [Database Schema](#database-schema)
- [Authentication Flow](#authentication-flow)
- [Role-Based Access Control](#role-based-access-control)
- [Development](#development)
- [Testing](#testing)
- [Deployment](#deployment)
- [Environment Variables](#environment-variables)
- [Contributing](#contributing)

## 🚀 Quick Start

### Prerequisites

- Node.js 18+ and npm
- PostgreSQL 15+
- SendGrid API key (for magic-link emails)

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd auth-org-system
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   # Backend
   cp backend/.env.example backend/.env
   # Frontend
   cp frontend/auth-frontend/.env.example frontend/auth-frontend/.env
   ```

4. **Configure database**
   ```bash
   # Update DATABASE_URL in backend/.env
   cd backend
   npm run db:migrate
   npm run db:seed
   ```

5. **Start development servers**
   ```bash
   npm run dev
   ```

The application will be available at:
- Frontend: http://localhost:3000
- Backend API: http://localhost:4000/api
- GraphQL Playground: http://localhost:4000/api/graphql

## 🏗️ Architecture

### System Overview

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   React SPA     │    │   NestJS API    │    │   PostgreSQL    │
│                 │    │                 │    │                 │
│ • Auth Pages    │◄──►│ • GraphQL API   │◄──►│ • User Data     │
│ • Dashboard     │    │ • JWT Auth      │    │ • Organizations │
│ • Org Switcher  │    │ • RBAC Guards   │    │ • Permissions   │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Tailwind CSS  │    │     Prisma      │    │    SendGrid     │
│   shadcn/ui     │    │     GraphQL     │    │   Email API     │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

### Key Components

#### Backend (NestJS)
- **Auth Module**: JWT tokens, magic-link authentication, refresh logic
- **Organization Module**: Multi-tenant organization management
- **User Module**: User profile and organization membership management
- **Guards**: Role-based access control enforcement
- **GraphQL API**: Type-safe API with automatic schema generation

#### Frontend (React)
- **Authentication Pages**: Sign-in, magic-link verification, invite users
- **Dashboard**: Organization overview and member management
- **Organization Switcher**: Context switching between organizations
- **Auth Context**: Global authentication state management

## 📚 API Documentation

### GraphQL Schema

The API uses GraphQL for type-safe communication. Key operations include:

#### Authentication Mutations

```graphql
# Send magic link to email
mutation SendMagicLink($email: String!) {
  sendMagicLink(email: $email)
}

# Verify magic link and get tokens
mutation VerifyMagicLink($token: String!) {
  verifyMagicLink(token: $token) {
    user { id email firstName lastName }
    accessToken
    refreshToken
    organizationId
    role
  }
}

# Refresh access token
mutation RefreshTokens($refreshToken: String!) {
  refreshTokens(refreshToken: $refreshToken) {
    user { id email firstName lastName }
    accessToken
    refreshToken
    organizationId
    role
  }
}

# Switch organization context
mutation SwitchOrganization($organizationId: String!) {
  switchOrganization(organizationId: $organizationId) {
    accessToken
    refreshToken
    role
  }
}
```

#### Organization Management

```graphql
# Create new organization
mutation CreateOrganization($input: CreateOrganizationInput!) {
  createOrganization(input: $input) {
    id name slug description
  }
}

# Invite user to organization
mutation InviteUser($input: InviteUserInput!) {
  inviteUser(input: $input)
}

# Get organization members
query GetOrganizationMembers {
  organizationMembers {
    id role
    user { id email firstName lastName }
  }
}
```

#### User Queries

```graphql
# Get current user
query GetMe {
  me {
    id email firstName lastName
  }
}

# Get user's organizations
query GetMyOrganizations {
  myOrganizations {
    id role
    organization { id name slug }
  }
}
```

### REST Endpoints

- `GET /api/health` - Health check endpoint
- `POST /api/graphql` - GraphQL endpoint

## 🎨 Frontend Components

### Authentication Components

#### SignInForm
Magic-link authentication form with email validation and success states.

```jsx
import { SignInForm } from './components/auth/SignInForm';

// Usage
<SignInForm />
```

#### MagicLinkVerification
Handles magic-link token verification and automatic login.

```jsx
import { MagicLinkVerification } from './components/auth/MagicLinkVerification';

// Automatically handles ?token= query parameter
<MagicLinkVerification />
```

#### InviteUserForm
Role-based user invitation form with validation.

```jsx
import { InviteUserForm } from './components/auth/InviteUserForm';

// Requires ADMIN or OWNER role
<InviteUserForm />
```

#### OrganizationSwitcher
Dropdown component for switching between user's organizations.

```jsx
import { OrganizationSwitcher } from './components/auth/OrganizationSwitcher';

// Shows in navbar
<OrganizationSwitcher />
```

### Context Providers

#### AuthContext
Global authentication state management.

```jsx
import { AuthProvider, useAuth } from './contexts/AuthContext';

// Wrap app
<AuthProvider>
  <App />
</AuthProvider>

// Use in components
const { user, isAuthenticated, login, logout } = useAuth();
```

### Protected Routes

```jsx
import { ProtectedRoute } from './components/ProtectedRoute';

<ProtectedRoute>
  <DashboardPage />
</ProtectedRoute>
```

## 🗄️ Database Schema

### Core Tables

#### Users
```sql
CREATE TABLE users (
  id TEXT PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  firstName TEXT,
  lastName TEXT,
  isActive BOOLEAN DEFAULT true,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### Organizations
```sql
CREATE TABLE organizations (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  description TEXT,
  isActive BOOLEAN DEFAULT true,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### Organization Members
```sql
CREATE TABLE organization_members (
  id TEXT PRIMARY KEY,
  userId TEXT REFERENCES users(id),
  organizationId TEXT REFERENCES organizations(id),
  role Role NOT NULL,
  isActive BOOLEAN DEFAULT true,
  joinedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(userId, organizationId)
);
```

### Authentication Tables

#### Magic Links
```sql
CREATE TABLE magic_links (
  id TEXT PRIMARY KEY,
  token TEXT UNIQUE NOT NULL,
  userId TEXT REFERENCES users(id),
  email TEXT NOT NULL,
  expiresAt TIMESTAMP NOT NULL,
  usedAt TIMESTAMP,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### Refresh Tokens
```sql
CREATE TABLE refresh_tokens (
  id TEXT PRIMARY KEY,
  token TEXT UNIQUE NOT NULL,
  userId TEXT NOT NULL,
  expiresAt TIMESTAMP NOT NULL,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### Invitations
```sql
CREATE TABLE invitations (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL,
  role Role NOT NULL,
  organizationId TEXT REFERENCES organizations(id),
  senderId TEXT REFERENCES users(id),
  token TEXT UNIQUE NOT NULL,
  status InvitationStatus DEFAULT 'PENDING',
  expiresAt TIMESTAMP NOT NULL,
  acceptedAt TIMESTAMP,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Enums

```sql
CREATE TYPE Role AS ENUM ('OWNER', 'ADMIN', 'MANAGER', 'OPERATOR', 'SUPPLIER');
CREATE TYPE InvitationStatus AS ENUM ('PENDING', 'ACCEPTED', 'EXPIRED', 'REVOKED');
```

## 🔐 Authentication Flow

### Magic Link Flow

1. **Request Magic Link**
   - User enters email address
   - System generates unique token
   - Email sent via SendGrid with magic link

2. **Verify Magic Link**
   - User clicks link with token
   - Token validated (not expired, not used)
   - User authenticated and tokens generated

3. **Token Management**
   - Access token (15 minutes) for API requests
   - Refresh token (7 days) for token renewal
   - Automatic refresh before expiration

### Token Structure

```typescript
interface JwtPayload {
  sub: string;        // User ID
  email: string;      // User email
  organizationId?: string; // Current organization
  role?: Role;        // Current role
  type: 'access' | 'refresh';
}
```

### Organization Context

When users switch organizations:
1. New tokens generated with organization context
2. Role updated based on membership
3. Frontend state updated automatically
4. API requests use new organization context

## 🛡️ Role-Based Access Control

### Role Hierarchy

```
OWNER (Level 5)
├── Full organization control
├── Manage all users and roles
└── Delete organization

ADMIN (Level 4)
├── Manage users (except owners)
├── Organization settings
└── Invite users

MANAGER (Level 3)
├── View organization members
├── Manage operations
└── Limited user management

OPERATOR (Level 2)
├── Execute daily operations
├── View assigned data
└── Basic functionality

SUPPLIER (Level 1)
├── Limited access
├── Supplier-specific features
└── Read-only access
```

### Guard Implementation

#### Role Guards
```typescript
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles(Role.ADMIN, Role.OWNER)
async inviteUser() {
  // Only admins and owners can invite users
}
```

#### Minimum Role Guards
```typescript
@UseGuards(JwtAuthGuard, MinRoleGuard)
@MinRole(Role.MANAGER)
async getOrganizationData() {
  // Managers and above can access
}
```

#### Organization Guards
```typescript
@UseGuards(JwtAuthGuard, OrganizationMemberGuard)
async getOrganizationMembers() {
  // Must be organization member
}
```

### Permission Matrix

| Action | Owner | Admin | Manager | Operator | Supplier |
|--------|-------|-------|---------|----------|----------|
| Create Organization | ✅ | ❌ | ❌ | ❌ | ❌ |
| Delete Organization | ✅ | ❌ | ❌ | ❌ | ❌ |
| Invite Users | ✅ | ✅ | ❌ | ❌ | ❌ |
| Manage Roles | ✅ | ✅* | ❌ | ❌ | ❌ |
| View Members | ✅ | ✅ | ✅ | ❌ | ❌ |
| Organization Settings | ✅ | ✅ | ❌ | ❌ | ❌ |
| Basic Operations | ✅ | ✅ | ✅ | ✅ | ✅ |

*Admins cannot manage owner roles

## 🛠️ Development

### Project Structure

```
auth-org-system/
├── backend/                 # NestJS backend
│   ├── src/
│   │   ├── auth/           # Authentication module
│   │   ├── organization/   # Organization management
│   │   ├── user/          # User management
│   │   ├── common/        # Shared utilities and guards
│   │   └── health/        # Health check endpoint
│   ├── prisma/            # Database schema and migrations
│   └── test/              # E2E tests
├── frontend/
│   └── auth-frontend/     # React frontend
│       ├── src/
│       │   ├── components/ # React components
│       │   ├── contexts/   # React contexts
│       │   ├── pages/      # Page components
│       │   └── lib/        # Utilities and GraphQL
├── .github/
│   └── workflows/         # CI/CD pipelines
├── scripts/               # Build and deployment scripts
└── docs/                  # Documentation
```

### Development Commands

```bash
# Start development servers
npm run dev

# Backend only
npm run dev:backend

# Frontend only
npm run dev:frontend

# Build applications
npm run build

# Run tests
npm run test

# Run linting
npm run lint

# Format code
npm run format

# Database operations
npm run db:generate    # Generate Prisma client
npm run db:migrate     # Run migrations
npm run db:seed        # Seed database
npm run db:studio      # Open Prisma Studio
```

### Code Quality

The project enforces strict code quality standards:

- **ESLint**: Strict TypeScript rules for backend, React rules for frontend
- **Prettier**: Consistent code formatting
- **Pre-commit hooks**: Automatic linting and formatting
- **Type safety**: Full TypeScript coverage
- **Test coverage**: 95%+ coverage requirement

## 🧪 Testing

### Test Structure

```
├── Backend Tests
│   ├── Unit Tests
│   │   ├── Auth Services (token.service.spec.ts)
│   │   ├── Magic Link (magic-link.service.spec.ts)
│   │   ├── Guards (roles.guard.spec.ts)
│   │   └── Organization (organization.service.spec.ts)
│   └── E2E Tests
│       └── API Integration (auth.e2e-spec.ts)
└── Frontend Tests
    ├── Component Tests
    │   ├── SignInForm.test.jsx
    │   ├── MagicLinkVerification.test.jsx
    │   └── InviteUserForm.test.jsx
    └── Integration Tests
        └── Auth Flow Tests
```

### Running Tests

```bash
# All tests
npm run test

# Backend tests with coverage
cd backend && npm run test:cov

# Frontend tests with coverage
cd frontend/auth-frontend && npm run test -- --coverage

# E2E tests
cd backend && npm run test:e2e

# Watch mode
npm run test:watch
```

### Test Coverage

The project maintains 95%+ test coverage across:
- Authentication services
- Authorization guards
- Organization management
- User interface components
- API endpoints

## 🚀 Deployment

### Docker Deployment

```bash
# Build and run with Docker Compose
docker-compose up --build

# Production build
docker build -t auth-org-system .
docker run -p 4000:4000 auth-org-system
```

### Fly.io Deployment

```bash
# Install Fly CLI
curl -L https://fly.io/install.sh | sh

# Deploy to staging
flyctl deploy

# Set secrets
flyctl secrets set JWT_ACCESS_SECRET=your-secret
flyctl secrets set SENDGRID_API_KEY=your-key
```

### CI/CD Pipeline

The GitHub Actions pipeline includes:

1. **Lint & Format Check**
   - ESLint validation
   - Prettier formatting check
   - TypeScript type checking

2. **Testing**
   - Unit tests with coverage
   - Integration tests
   - E2E tests

3. **Build**
   - Backend compilation
   - Frontend build
   - Docker image creation

4. **Security**
   - Vulnerability scanning
   - Dependency auditing

5. **Deploy**
   - Automatic staging deployment
   - Production deployment on release

## 🔧 Environment Variables

### Backend (.env)

```bash
# Database
DATABASE_URL="postgresql://username:password@localhost:5432/auth_org_db"

# JWT Secrets
JWT_ACCESS_SECRET="your-super-secret-access-key"
JWT_REFRESH_SECRET="your-super-secret-refresh-key"

# SendGrid
SENDGRID_API_KEY="your-sendgrid-api-key"
FROM_EMAIL="noreply@yourdomain.com"

# Application
NODE_ENV="development"
PORT=4000
FRONTEND_URL="http://localhost:3000"
CORS_ORIGIN="http://localhost:3000"
```

### Frontend (.env)

```bash
# API Configuration
VITE_GRAPHQL_URL="http://localhost:4000/api/graphql"

# Application
VITE_APP_NAME="Auth & Organization Management"
VITE_APP_VERSION="1.0.0"
```

### Production Secrets

For production deployment, set these secrets in your deployment platform:

- `JWT_ACCESS_SECRET`: Strong random string for access tokens
- `JWT_REFRESH_SECRET`: Strong random string for refresh tokens
- `SENDGRID_API_KEY`: SendGrid API key for email delivery
- `DATABASE_URL`: PostgreSQL connection string
- `FROM_EMAIL`: Sender email address for magic links

## 📝 Contributing

### Development Workflow

1. **Fork and Clone**
   ```bash
   git clone <your-fork>
   cd auth-org-system
   ```

2. **Create Feature Branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```

3. **Development**
   ```bash
   npm install
   npm run dev
   ```

4. **Testing**
   ```bash
   npm run test
   npm run lint
   ```

5. **Commit and Push**
   ```bash
   git add .
   git commit -m "feat: your feature description"
   git push origin feature/your-feature-name
   ```

6. **Create Pull Request**

### Code Standards

- Follow existing code style and patterns
- Write comprehensive tests for new features
- Update documentation for API changes
- Ensure all CI checks pass
- Use conventional commit messages

### Pull Request Guidelines

- Provide clear description of changes
- Include test coverage for new code
- Update documentation if needed
- Ensure backward compatibility
- Request review from maintainers

## 📄 License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.

## 🤝 Support

For questions, issues, or contributions:

- **Issues**: [GitHub Issues](https://github.com/your-repo/issues)
- **Discussions**: [GitHub Discussions](https://github.com/your-repo/discussions)
- **Email**: support@yourdomain.com

## 🙏 Acknowledgments

- **NestJS**: Powerful Node.js framework
- **React**: Frontend library
- **Prisma**: Database toolkit
- **Tailwind CSS**: Utility-first CSS framework
- **shadcn/ui**: Beautiful UI components
- **SendGrid**: Email delivery service

---

Built with ❤️ by the Manus team

