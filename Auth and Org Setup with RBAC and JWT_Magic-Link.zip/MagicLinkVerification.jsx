import { useEffect, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { useMutation } from '@apollo/client';
import { Loader2, CheckCircle, XCircle } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { VERIFY_MAGIC_LINK } from '../../lib/graphql';
import { useAuth } from '../../contexts/AuthContext';

export function MagicLinkVerification() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { login } = useAuth();
  const [status, setStatus] = useState('verifying'); // verifying, success, error
  const [errorMessage, setErrorMessage] = useState('');

  const [verifyMagicLink] = useMutation(VERIFY_MAGIC_LINK);

  useEffect(() => {
    const token = searchParams.get('token');
    
    if (!token) {
      setStatus('error');
      setErrorMessage('Invalid magic link - no token provided');
      return;
    }

    const verifyToken = async () => {
      try {
        const { data } = await verifyMagicLink({
          variables: { token },
        });

        if (data?.verifyMagicLink) {
          login(data.verifyMagicLink);
          setStatus('success');
          
          // Redirect to dashboard after a short delay
          setTimeout(() => {
            navigate('/dashboard');
          }, 2000);
        }
      } catch (error) {
        console.error('Magic link verification error:', error);
        setStatus('error');
        setErrorMessage(
          error.message || 'Failed to verify magic link. It may have expired.'
        );
      }
    };

    verifyToken();
  }, [searchParams, verifyMagicLink, login, navigate]);

  const renderContent = () => {
    switch (status) {
      case 'verifying':
        return (
          <>
            <div className="mx-auto mb-4 w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
              <Loader2 className="w-6 h-6 text-blue-600 animate-spin" />
            </div>
            <CardTitle>Verifying your magic link...</CardTitle>
            <CardDescription>
              Please wait while we sign you in
            </CardDescription>
          </>
        );

      case 'success':
        return (
          <>
            <div className="mx-auto mb-4 w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
            <CardTitle>Successfully signed in!</CardTitle>
            <CardDescription>
              Redirecting you to your dashboard...
            </CardDescription>
          </>
        );

      case 'error':
        return (
          <>
            <div className="mx-auto mb-4 w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
              <XCircle className="w-6 h-6 text-red-600" />
            </div>
            <CardTitle>Sign in failed</CardTitle>
            <CardDescription>
              {errorMessage}
            </CardDescription>
          </>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
      <Card className="w-full max-w-md mx-auto">
        <CardHeader className="text-center">
          {renderContent()}
        </CardHeader>
        {status === 'error' && (
          <CardContent>
            <Button
              className="w-full"
              onClick={() => navigate('/auth/signin')}
            >
              Try signing in again
            </Button>
          </CardContent>
        )}
      </Card>
    </div>
  );
}

