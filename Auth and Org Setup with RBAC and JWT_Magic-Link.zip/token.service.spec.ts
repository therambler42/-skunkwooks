import { Test, TestingModule } from '@nestjs/testing';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import { TokenService } from '../../src/auth/token.service';
import { PrismaService } from '../../src/common/prisma.service';
import { User, Role } from '@prisma/client';

describe('TokenService', () => {
  let service: TokenService;
  let prismaService: PrismaService;
  let jwtService: JwtService;
  let configService: ConfigService;

  const mockUser: User = {
    id: 'user1',
    email: 'test@example.com',
    firstName: 'John',
    lastName: 'Doe',
    isActive: true,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        TokenService,
        {
          provide: PrismaService,
          useValue: {
            refreshToken: {
              create: jest.fn(),
              findUnique: jest.fn(),
              delete: jest.fn(),
              deleteMany: jest.fn(),
            },
            user: {
              findUnique: jest.fn(),
            },
          },
        },
        {
          provide: JwtService,
          useValue: {
            sign: jest.fn(),
          },
        },
        {
          provide: ConfigService,
          useValue: {
            get: jest.fn(),
          },
        },
      ],
    }).compile();

    service = module.get<TokenService>(TokenService);
    prismaService = module.get<PrismaService>(PrismaService);
    jwtService = module.get<JwtService>(JwtService);
    configService = module.get<ConfigService>(ConfigService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('generateTokenPair', () => {
    it('should generate access and refresh tokens', async () => {
      const mockAccessToken = 'mock-access-token';
      const mockRefreshToken = 'mock-refresh-token';

      jest.spyOn(configService, 'get')
        .mockReturnValueOnce('access-secret')
        .mockReturnValueOnce('refresh-secret');

      jest.spyOn(jwtService, 'sign')
        .mockReturnValueOnce(mockAccessToken)
        .mockReturnValueOnce(mockRefreshToken);

      jest.spyOn(prismaService.refreshToken, 'create').mockResolvedValue({
        id: 'token1',
        token: mockRefreshToken,
        userId: mockUser.id,
        expiresAt: new Date(),
        createdAt: new Date(),
      });

      const result = await service.generateTokenPair(mockUser, 'org1', Role.MANAGER);

      expect(result).toEqual({
        accessToken: mockAccessToken,
        refreshToken: mockRefreshToken,
      });

      expect(jwtService.sign).toHaveBeenCalledTimes(2);
      expect(prismaService.refreshToken.create).toHaveBeenCalledWith({
        data: {
          token: mockRefreshToken,
          userId: mockUser.id,
          expiresAt: expect.any(Date),
        },
      });
    });
  });

  describe('refreshTokens', () => {
    it('should refresh tokens successfully', async () => {
      const mockRefreshToken = 'mock-refresh-token';
      const mockNewAccessToken = 'new-access-token';
      const mockNewRefreshToken = 'new-refresh-token';

      // Mock jwt.verify
      const mockPayload = {
        sub: mockUser.id,
        email: mockUser.email,
        type: 'refresh',
        organizationId: 'org1',
        role: Role.MANAGER,
      };

      jest.doMock('jsonwebtoken', () => ({
        verify: jest.fn().mockReturnValue(mockPayload),
      }));

      jest.spyOn(configService, 'get').mockReturnValue('refresh-secret');

      jest.spyOn(prismaService.refreshToken, 'findUnique').mockResolvedValue({
        id: 'token1',
        token: mockRefreshToken,
        userId: mockUser.id,
        expiresAt: new Date(Date.now() + 86400000), // Future date
        createdAt: new Date(),
      });

      jest.spyOn(prismaService.user, 'findUnique').mockResolvedValue(mockUser);

      jest.spyOn(prismaService.refreshToken, 'delete').mockResolvedValue({
        id: 'token1',
        token: mockRefreshToken,
        userId: mockUser.id,
        expiresAt: new Date(),
        createdAt: new Date(),
      });

      jest.spyOn(service, 'generateTokenPair').mockResolvedValue({
        accessToken: mockNewAccessToken,
        refreshToken: mockNewRefreshToken,
      });

      const result = await service.refreshTokens(mockRefreshToken);

      expect(result).toEqual({
        accessToken: mockNewAccessToken,
        refreshToken: mockNewRefreshToken,
      });
    });

    it('should throw error for invalid refresh token', async () => {
      const mockRefreshToken = 'invalid-token';

      jest.spyOn(configService, 'get').mockReturnValue('refresh-secret');

      // Mock jwt.verify to throw error
      jest.doMock('jsonwebtoken', () => ({
        verify: jest.fn().mockImplementation(() => {
          throw new Error('Invalid token');
        }),
      }));

      await expect(service.refreshTokens(mockRefreshToken)).rejects.toThrow('Invalid refresh token');
    });
  });

  describe('revokeRefreshToken', () => {
    it('should revoke refresh token', async () => {
      const mockToken = 'token-to-revoke';

      jest.spyOn(prismaService.refreshToken, 'deleteMany').mockResolvedValue({ count: 1 });

      await service.revokeRefreshToken(mockToken);

      expect(prismaService.refreshToken.deleteMany).toHaveBeenCalledWith({
        where: { token: mockToken },
      });
    });
  });

  describe('revokeAllUserTokens', () => {
    it('should revoke all user tokens', async () => {
      const userId = 'user1';

      jest.spyOn(prismaService.refreshToken, 'deleteMany').mockResolvedValue({ count: 3 });

      await service.revokeAllUserTokens(userId);

      expect(prismaService.refreshToken.deleteMany).toHaveBeenCalledWith({
        where: { userId },
      });
    });
  });

  describe('cleanupExpiredTokens', () => {
    it('should cleanup expired tokens', async () => {
      jest.spyOn(prismaService.refreshToken, 'deleteMany').mockResolvedValue({ count: 5 });

      await service.cleanupExpiredTokens();

      expect(prismaService.refreshToken.deleteMany).toHaveBeenCalledWith({
        where: {
          expiresAt: {
            lt: expect.any(Date),
          },
        },
      });
    });
  });
});

