import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { MockedProvider } from '@apollo/client/testing';
import { BrowserRouter } from 'react-router-dom';
import { SignInForm } from '../../src/components/auth/SignInForm';
import { SEND_MAGIC_LINK } from '../../src/lib/graphql';

const mocks = [
  {
    request: {
      query: SEND_MAGIC_LINK,
      variables: {
        email: 'test@example.com',
      },
    },
    result: {
      data: {
        sendMagicLink: 'Magic link sent to your email',
      },
    },
  },
];

const errorMocks = [
  {
    request: {
      query: SEND_MAGIC_LINK,
      variables: {
        email: 'error@example.com',
      },
    },
    error: new Error('Failed to send magic link'),
  },
];

const renderSignInForm = (mocks = []) => {
  return render(
    <MockedProvider mocks={mocks} addTypename={false}>
      <BrowserRouter>
        <SignInForm />
      </BrowserRouter>
    </MockedProvider>
  );
};

describe('SignInForm', () => {
  it('renders sign in form correctly', () => {
    renderSignInForm();

    expect(screen.getByText('Sign in to your account')).toBeInTheDocument();
    expect(screen.getByPlaceholderText('Enter your email')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /send magic link/i })).toBeInTheDocument();
  });

  it('validates email input', async () => {
    renderSignInForm();

    const emailInput = screen.getByPlaceholderText('Enter your email');
    const submitButton = screen.getByRole('button', { name: /send magic link/i });

    // Test invalid email
    fireEvent.change(emailInput, { target: { value: 'invalid-email' } });
    fireEvent.click(submitButton);

    await waitFor(() => {
      expect(screen.getByText('Please enter a valid email address')).toBeInTheDocument();
    });
  });

  it('sends magic link successfully', async () => {
    renderSignInForm(mocks);

    const emailInput = screen.getByPlaceholderText('Enter your email');
    const submitButton = screen.getByRole('button', { name: /send magic link/i });

    fireEvent.change(emailInput, { target: { value: 'test@example.com' } });
    fireEvent.click(submitButton);

    await waitFor(() => {
      expect(screen.getByText('Check your email')).toBeInTheDocument();
      expect(screen.getByText(/We've sent a magic link to/)).toBeInTheDocument();
    });
  });

  it('handles error when sending magic link', async () => {
    renderSignInForm(errorMocks);

    const emailInput = screen.getByPlaceholderText('Enter your email');
    const submitButton = screen.getByRole('button', { name: /send magic link/i });

    fireEvent.change(emailInput, { target: { value: 'error@example.com' } });
    fireEvent.click(submitButton);

    await waitFor(() => {
      expect(screen.getByText(/Failed to send magic link/)).toBeInTheDocument();
    });
  });

  it('allows sending another link after success', async () => {
    renderSignInForm(mocks);

    const emailInput = screen.getByPlaceholderText('Enter your email');
    const submitButton = screen.getByRole('button', { name: /send magic link/i });

    fireEvent.change(emailInput, { target: { value: 'test@example.com' } });
    fireEvent.click(submitButton);

    await waitFor(() => {
      expect(screen.getByText('Check your email')).toBeInTheDocument();
    });

    const sendAnotherButton = screen.getByRole('button', { name: /send another link/i });
    fireEvent.click(sendAnotherButton);

    await waitFor(() => {
      expect(screen.getByText('Sign in to your account')).toBeInTheDocument();
    });
  });

  it('disables form during submission', async () => {
    renderSignInForm(mocks);

    const emailInput = screen.getByPlaceholderText('Enter your email');
    const submitButton = screen.getByRole('button', { name: /send magic link/i });

    fireEvent.change(emailInput, { target: { value: 'test@example.com' } });
    fireEvent.click(submitButton);

    // Check that button shows loading state
    expect(screen.getByText('Sending...')).toBeInTheDocument();
    expect(emailInput).toBeDisabled();
  });
});

