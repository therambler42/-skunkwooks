import { render, screen, waitFor } from '@testing-library/react';
import { MockedProvider } from '@apollo/client/testing';
import { BrowserRouter, MemoryRouter } from 'react-router-dom';
import { MagicLinkVerification } from '../../src/components/auth/MagicLinkVerification';
import { VERIFY_MAGIC_LINK } from '../../src/lib/graphql';
import { AuthProvider } from '../../src/contexts/AuthContext';

const mockUser = {
  id: 'user1',
  email: 'test@example.com',
  firstName: 'John',
  lastName: 'Doe',
};

const successMocks = [
  {
    request: {
      query: VERIFY_MAGIC_LINK,
      variables: {
        token: 'valid-token',
      },
    },
    result: {
      data: {
        verifyMagicLink: {
          user: mockUser,
          accessToken: 'access-token',
          refreshToken: 'refresh-token',
          organizationId: 'org1',
          role: 'MANAGER',
        },
      },
    },
  },
];

const errorMocks = [
  {
    request: {
      query: VERIFY_MAGIC_LINK,
      variables: {
        token: 'invalid-token',
      },
    },
    error: new Error('Invalid magic link'),
  },
];

const renderMagicLinkVerification = (mocks = [], initialEntries = ['/auth/verify?token=valid-token']) => {
  return render(
    <MockedProvider mocks={mocks} addTypename={false}>
      <AuthProvider>
        <MemoryRouter initialEntries={initialEntries}>
          <MagicLinkVerification />
        </MemoryRouter>
      </AuthProvider>
    </MockedProvider>
  );
};

describe('MagicLinkVerification', () => {
  it('shows verifying state initially', () => {
    renderMagicLinkVerification(successMocks);

    expect(screen.getByText('Verifying your magic link...')).toBeInTheDocument();
    expect(screen.getByText('Please wait while we sign you in')).toBeInTheDocument();
  });

  it('shows success state after successful verification', async () => {
    renderMagicLinkVerification(successMocks);

    await waitFor(() => {
      expect(screen.getByText('Successfully signed in!')).toBeInTheDocument();
      expect(screen.getByText('Redirecting you to your dashboard...')).toBeInTheDocument();
    });
  });

  it('shows error state for invalid token', async () => {
    renderMagicLinkVerification(errorMocks, ['/auth/verify?token=invalid-token']);

    await waitFor(() => {
      expect(screen.getByText('Sign in failed')).toBeInTheDocument();
      expect(screen.getByText('Invalid magic link')).toBeInTheDocument();
      expect(screen.getByRole('button', { name: /try signing in again/i })).toBeInTheDocument();
    });
  });

  it('shows error for missing token', () => {
    renderMagicLinkVerification([], ['/auth/verify']);

    expect(screen.getByText('Sign in failed')).toBeInTheDocument();
    expect(screen.getByText('Invalid magic link - no token provided')).toBeInTheDocument();
  });

  it('handles verification error gracefully', async () => {
    const consoleSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
    
    renderMagicLinkVerification(errorMocks, ['/auth/verify?token=invalid-token']);

    await waitFor(() => {
      expect(screen.getByText('Sign in failed')).toBeInTheDocument();
    });

    consoleSpy.mockRestore();
  });
});

