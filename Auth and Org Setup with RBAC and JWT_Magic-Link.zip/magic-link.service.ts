import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../common/prisma.service';
import { User } from '@prisma/client';
import * as sgMail from '@sendgrid/mail';
import { v4 as uuidv4 } from 'uuid';

@Injectable()
export class MagicLinkService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly configService: ConfigService,
  ) {
    // Initialize SendGrid
    sgMail.setApiKey(this.configService.get('SENDGRID_API_KEY'));
  }

  async generateMagicLink(email: string): Promise<string> {
    // Find or create user
    let user = await this.prisma.user.findUnique({
      where: { email },
    });

    if (!user) {
      user = await this.prisma.user.create({
        data: {
          email,
          isActive: true,
        },
      });
    }

    if (!user.isActive) {
      throw new Error('User account is deactivated');
    }

    // Generate unique token
    const token = uuidv4();
    const expiresAt = new Date();
    expiresAt.setMinutes(expiresAt.getMinutes() + 15); // 15 minutes

    // Store magic link
    await this.prisma.magicLink.create({
      data: {
        token,
        userId: user.id,
        email,
        expiresAt,
      },
    });

    // Generate magic link URL
    const baseUrl = this.configService.get('FRONTEND_URL') || 'http://localhost:3000';
    const magicLinkUrl = `${baseUrl}/auth/verify?token=${token}`;

    // Send email
    await this.sendMagicLinkEmail(email, magicLinkUrl);

    return token;
  }

  async verifyMagicLink(token: string): Promise<User> {
    const magicLink = await this.prisma.magicLink.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!magicLink) {
      throw new Error('Invalid magic link');
    }

    if (magicLink.usedAt) {
      throw new Error('Magic link already used');
    }

    if (magicLink.expiresAt < new Date()) {
      throw new Error('Magic link expired');
    }

    if (!magicLink.user.isActive) {
      throw new Error('User account is deactivated');
    }

    // Mark magic link as used
    await this.prisma.magicLink.update({
      where: { token },
      data: { usedAt: new Date() },
    });

    return magicLink.user;
  }

  private async sendMagicLinkEmail(email: string, magicLinkUrl: string): Promise<void> {
    const msg = {
      to: email,
      from: this.configService.get('FROM_EMAIL') || 'noreply@example.com',
      subject: 'Sign in to your account',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2>Sign in to your account</h2>
          <p>Click the button below to sign in to your account. This link will expire in 15 minutes.</p>
          <div style="text-align: center; margin: 30px 0;">
            <a href="${magicLinkUrl}" 
               style="background-color: #007bff; color: white; padding: 12px 24px; 
                      text-decoration: none; border-radius: 4px; display: inline-block;">
              Sign In
            </a>
          </div>
          <p>If the button doesn't work, you can copy and paste this link into your browser:</p>
          <p style="word-break: break-all; color: #666;">${magicLinkUrl}</p>
          <hr style="margin: 30px 0; border: none; border-top: 1px solid #eee;">
          <p style="color: #666; font-size: 12px;">
            If you didn't request this email, you can safely ignore it.
          </p>
        </div>
      `,
    };

    try {
      await sgMail.send(msg);
    } catch (error) {
      console.error('Failed to send magic link email:', error);
      throw new Error('Failed to send magic link email');
    }
  }

  async cleanupExpiredMagicLinks(): Promise<void> {
    await this.prisma.magicLink.deleteMany({
      where: {
        expiresAt: {
          lt: new Date(),
        },
      },
    });
  }
}

