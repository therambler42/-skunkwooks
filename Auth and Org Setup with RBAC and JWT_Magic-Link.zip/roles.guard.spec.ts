import { Test, TestingModule } from '@nestjs/testing';
import { ExecutionContext } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { GqlExecutionContext } from '@nestjs/graphql';
import { Role } from '@prisma/client';
import {
  RolesGuard,
  MinRoleGuard,
  OrganizationMemberGuard,
  OrganizationOwnerGuard,
  OrganizationAdminGuard,
} from '../../src/common/guards/roles.guard';

describe('RolesGuard', () => {
  let guard: RolesGuard;
  let reflector: Reflector;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        RolesGuard,
        {
          provide: Reflector,
          useValue: {
            getAllAndOverride: jest.fn(),
          },
        },
      ],
    }).compile();

    guard = module.get<RolesGuard>(RolesGuard);
    reflector = module.get<Reflector>(Reflector);
  });

  const createMockContext = (user: any) => {
    const mockContext = {
      getHandler: jest.fn(),
      getClass: jest.fn(),
    } as unknown as ExecutionContext;

    jest.spyOn(GqlExecutionContext, 'create').mockReturnValue({
      getContext: () => ({
        req: { user },
      }),
    } as any);

    return mockContext;
  };

  it('should be defined', () => {
    expect(guard).toBeDefined();
  });

  it('should allow access when no roles are required', () => {
    const context = createMockContext({ role: Role.SUPPLIER });
    jest.spyOn(reflector, 'getAllAndOverride').mockReturnValue(undefined);

    const result = guard.canActivate(context);

    expect(result).toBe(true);
  });

  it('should allow access when user has required role', () => {
    const context = createMockContext({ role: Role.ADMIN });
    jest.spyOn(reflector, 'getAllAndOverride').mockReturnValue([Role.ADMIN, Role.MANAGER]);

    const result = guard.canActivate(context);

    expect(result).toBe(true);
  });

  it('should deny access when user does not have required role', () => {
    const context = createMockContext({ role: Role.SUPPLIER });
    jest.spyOn(reflector, 'getAllAndOverride').mockReturnValue([Role.ADMIN, Role.MANAGER]);

    const result = guard.canActivate(context);

    expect(result).toBe(false);
  });

  it('should deny access when user has no role', () => {
    const context = createMockContext({ userId: 'user1' });
    jest.spyOn(reflector, 'getAllAndOverride').mockReturnValue([Role.ADMIN]);

    const result = guard.canActivate(context);

    expect(result).toBe(false);
  });

  it('should deny access when no user is present', () => {
    const context = createMockContext(null);
    jest.spyOn(reflector, 'getAllAndOverride').mockReturnValue([Role.ADMIN]);

    const result = guard.canActivate(context);

    expect(result).toBe(false);
  });
});

describe('MinRoleGuard', () => {
  let guard: MinRoleGuard;
  let reflector: Reflector;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        MinRoleGuard,
        {
          provide: Reflector,
          useValue: {
            getAllAndOverride: jest.fn(),
          },
        },
      ],
    }).compile();

    guard = module.get<MinRoleGuard>(MinRoleGuard);
    reflector = module.get<Reflector>(Reflector);
  });

  const createMockContext = (user: any) => {
    const mockContext = {
      getHandler: jest.fn(),
      getClass: jest.fn(),
    } as unknown as ExecutionContext;

    jest.spyOn(GqlExecutionContext, 'create').mockReturnValue({
      getContext: () => ({
        req: { user },
      }),
    } as any);

    return mockContext;
  };

  it('should allow access when no minimum role is required', () => {
    const context = createMockContext({ role: Role.SUPPLIER });
    jest.spyOn(reflector, 'getAllAndOverride').mockReturnValue(undefined);

    const result = guard.canActivate(context);

    expect(result).toBe(true);
  });

  it('should allow access when user role meets minimum requirement', () => {
    const context = createMockContext({ role: Role.ADMIN });
    jest.spyOn(reflector, 'getAllAndOverride').mockReturnValue(Role.MANAGER);

    const result = guard.canActivate(context);

    expect(result).toBe(true);
  });

  it('should allow access when user role exceeds minimum requirement', () => {
    const context = createMockContext({ role: Role.OWNER });
    jest.spyOn(reflector, 'getAllAndOverride').mockReturnValue(Role.OPERATOR);

    const result = guard.canActivate(context);

    expect(result).toBe(true);
  });

  it('should deny access when user role is below minimum requirement', () => {
    const context = createMockContext({ role: Role.SUPPLIER });
    jest.spyOn(reflector, 'getAllAndOverride').mockReturnValue(Role.MANAGER);

    const result = guard.canActivate(context);

    expect(result).toBe(false);
  });
});

describe('OrganizationMemberGuard', () => {
  let guard: OrganizationMemberGuard;

  beforeEach(() => {
    guard = new OrganizationMemberGuard();
  });

  const createMockContext = (user: any) => {
    const mockContext = {} as ExecutionContext;

    jest.spyOn(GqlExecutionContext, 'create').mockReturnValue({
      getContext: () => ({
        req: { user },
      }),
    } as any);

    return mockContext;
  };

  it('should allow access when user has organization ID', () => {
    const context = createMockContext({
      userId: 'user1',
      organizationId: 'org1',
      role: Role.MANAGER,
    });

    const result = guard.canActivate(context);

    expect(result).toBe(true);
  });

  it('should deny access when user has no organization ID', () => {
    const context = createMockContext({
      userId: 'user1',
      role: Role.MANAGER,
    });

    const result = guard.canActivate(context);

    expect(result).toBe(false);
  });

  it('should deny access when no user is present', () => {
    const context = createMockContext(null);

    const result = guard.canActivate(context);

    expect(result).toBe(false);
  });
});

describe('OrganizationOwnerGuard', () => {
  let guard: OrganizationOwnerGuard;

  beforeEach(() => {
    guard = new OrganizationOwnerGuard();
  });

  const createMockContext = (user: any) => {
    const mockContext = {} as ExecutionContext;

    jest.spyOn(GqlExecutionContext, 'create').mockReturnValue({
      getContext: () => ({
        req: { user },
      }),
    } as any);

    return mockContext;
  };

  it('should allow access when user is owner', () => {
    const context = createMockContext({
      userId: 'user1',
      organizationId: 'org1',
      role: Role.OWNER,
    });

    const result = guard.canActivate(context);

    expect(result).toBe(true);
  });

  it('should deny access when user is not owner', () => {
    const context = createMockContext({
      userId: 'user1',
      organizationId: 'org1',
      role: Role.ADMIN,
    });

    const result = guard.canActivate(context);

    expect(result).toBe(false);
  });
});

describe('OrganizationAdminGuard', () => {
  let guard: OrganizationAdminGuard;

  beforeEach(() => {
    guard = new OrganizationAdminGuard();
  });

  const createMockContext = (user: any) => {
    const mockContext = {} as ExecutionContext;

    jest.spyOn(GqlExecutionContext, 'create').mockReturnValue({
      getContext: () => ({
        req: { user },
      }),
    } as any);

    return mockContext;
  };

  it('should allow access when user is owner', () => {
    const context = createMockContext({
      userId: 'user1',
      organizationId: 'org1',
      role: Role.OWNER,
    });

    const result = guard.canActivate(context);

    expect(result).toBe(true);
  });

  it('should allow access when user is admin', () => {
    const context = createMockContext({
      userId: 'user1',
      organizationId: 'org1',
      role: Role.ADMIN,
    });

    const result = guard.canActivate(context);

    expect(result).toBe(true);
  });

  it('should deny access when user is not admin or owner', () => {
    const context = createMockContext({
      userId: 'user1',
      organizationId: 'org1',
      role: Role.MANAGER,
    });

    const result = guard.canActivate(context);

    expect(result).toBe(false);
  });
});

