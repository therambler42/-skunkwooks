from flask import Blueprint, request, jsonify
from datetime import datetime, date
from src.models.database import db, Organization, ProductionLine, Lot
import re

batch_bp = Blueprint('batch', __name__)

def generate_batch_code(organization_id, production_line_id, production_date=None):
    """
    Generate batch code in format YYYYMMDD-LINE-SEQ
    Ensures uniqueness per day and line
    """
    if production_date is None:
        production_date = date.today()
    
    # Get organization and production line
    org = Organization.query.get(organization_id)
    line = ProductionLine.query.get(production_line_id)
    
    if not org or not line:
        raise ValueError("Invalid organization or production line")
    
    # Format date part
    date_str = production_date.strftime('%Y%m%d')
    
    # Get line code
    line_code = line.code
    
    # Find the next sequence number for this date and line
    existing_lots = Lot.query.filter(
        Lot.organization_id == organization_id,
        Lot.production_line_id == production_line_id,
        Lot.production_date == production_date
    ).all()
    
    # Extract sequence numbers from existing batch codes
    seq_numbers = []
    pattern = rf"{date_str}-{line_code}-(\d+)"
    
    for lot in existing_lots:
        match = re.search(pattern, lot.batch_code)
        if match:
            seq_numbers.append(int(match.group(1)))
    
    # Get next sequence number
    next_seq = max(seq_numbers, default=0) + 1
    
    # Generate batch code
    batch_code = f"{date_str}-{line_code}-{next_seq:03d}"
    
    return batch_code

@batch_bp.route('/organizations', methods=['GET'])
def get_organizations():
    """Get all organizations"""
    organizations = Organization.query.all()
    return jsonify([org.to_dict() for org in organizations])

@batch_bp.route('/organizations', methods=['POST'])
def create_organization():
    """Create a new organization"""
    data = request.get_json()
    
    if not data or 'name' not in data:
        return jsonify({'error': 'Organization name is required'}), 400
    
    org = Organization(
        name=data['name'],
        batch_code_format=data.get('batch_code_format', 'YYYYMMDD-LINE-SEQ')
    )
    
    db.session.add(org)
    db.session.commit()
    
    return jsonify(org.to_dict()), 201

@batch_bp.route('/organizations/<int:org_id>/lines', methods=['GET'])
def get_production_lines(org_id):
    """Get production lines for an organization"""
    lines = ProductionLine.query.filter_by(organization_id=org_id).all()
    return jsonify([line.to_dict() for line in lines])

@batch_bp.route('/organizations/<int:org_id>/lines', methods=['POST'])
def create_production_line(org_id):
    """Create a new production line"""
    data = request.get_json()
    
    if not data or 'name' not in data or 'code' not in data:
        return jsonify({'error': 'Line name and code are required'}), 400
    
    # Validate organization exists
    org = Organization.query.get(org_id)
    if not org:
        return jsonify({'error': 'Organization not found'}), 404
    
    # Check if line code is unique within organization
    existing_line = ProductionLine.query.filter_by(
        organization_id=org_id,
        code=data['code']
    ).first()
    
    if existing_line:
        return jsonify({'error': 'Line code already exists in this organization'}), 400
    
    line = ProductionLine(
        organization_id=org_id,
        name=data['name'],
        code=data['code'].upper()
    )
    
    db.session.add(line)
    db.session.commit()
    
    return jsonify(line.to_dict()), 201

@batch_bp.route('/lots', methods=['POST'])
def create_lot():
    """Create a new lot with auto-generated batch code"""
    data = request.get_json()
    
    required_fields = ['organization_id', 'production_line_id', 'product_name', 'quantity']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'{field} is required'}), 400
    
    try:
        # Parse production date if provided
        production_date = date.today()
        if 'production_date' in data:
            production_date = datetime.strptime(data['production_date'], '%Y-%m-%d').date()
        
        # Parse expiry date if provided
        expiry_date = None
        if 'expiry_date' in data:
            expiry_date = datetime.strptime(data['expiry_date'], '%Y-%m-%d').date()
        
        # Generate batch code
        batch_code = generate_batch_code(
            data['organization_id'],
            data['production_line_id'],
            production_date
        )
        
        # Create lot
        lot = Lot(
            batch_code=batch_code,
            organization_id=data['organization_id'],
            production_line_id=data['production_line_id'],
            product_name=data['product_name'],
            quantity=data['quantity'],
            production_date=production_date,
            expiry_date=expiry_date,
            status=data.get('status', 'active')
        )
        
        db.session.add(lot)
        db.session.commit()
        
        return jsonify(lot.to_dict()), 201
        
    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Failed to create lot'}), 500

@batch_bp.route('/lots', methods=['GET'])
def get_lots():
    """Get lots with optional filtering"""
    organization_id = request.args.get('organization_id', type=int)
    production_line_id = request.args.get('production_line_id', type=int)
    status = request.args.get('status')
    
    query = Lot.query
    
    if organization_id:
        query = query.filter_by(organization_id=organization_id)
    if production_line_id:
        query = query.filter_by(production_line_id=production_line_id)
    if status:
        query = query.filter_by(status=status)
    
    lots = query.order_by(Lot.created_at.desc()).all()
    return jsonify([lot.to_dict() for lot in lots])

@batch_bp.route('/lots/<batch_code>', methods=['GET'])
def get_lot_by_batch_code(batch_code):
    """Get lot by batch code"""
    lot = Lot.query.filter_by(batch_code=batch_code).first()
    
    if not lot:
        return jsonify({'error': 'Lot not found'}), 404
    
    return jsonify(lot.to_dict())

@batch_bp.route('/lots/<int:lot_id>', methods=['PUT'])
def update_lot(lot_id):
    """Update lot information"""
    lot = Lot.query.get(lot_id)
    
    if not lot:
        return jsonify({'error': 'Lot not found'}), 404
    
    data = request.get_json()
    
    # Update allowed fields
    if 'product_name' in data:
        lot.product_name = data['product_name']
    if 'quantity' in data:
        lot.quantity = data['quantity']
    if 'status' in data:
        lot.status = data['status']
    if 'expiry_date' in data:
        if data['expiry_date']:
            lot.expiry_date = datetime.strptime(data['expiry_date'], '%Y-%m-%d').date()
        else:
            lot.expiry_date = None
    
    db.session.commit()
    
    return jsonify(lot.to_dict())

@batch_bp.route('/generate-code', methods=['POST'])
def preview_batch_code():
    """Preview batch code generation without creating a lot"""
    data = request.get_json()
    
    required_fields = ['organization_id', 'production_line_id']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'{field} is required'}), 400
    
    try:
        production_date = date.today()
        if 'production_date' in data:
            production_date = datetime.strptime(data['production_date'], '%Y-%m-%d').date()
        
        batch_code = generate_batch_code(
            data['organization_id'],
            data['production_line_id'],
            production_date
        )
        
        return jsonify({
            'batch_code': batch_code,
            'production_date': production_date.isoformat()
        })
        
    except ValueError as e:
        return jsonify({'error': str(e)}), 400

