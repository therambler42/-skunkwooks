import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Clock, Package, Truck, CheckCircle, AlertCircle, Trash2 } from 'lucide-react'

const ScanHistory = ({ scans }) => {
  const getActionIcon = (action) => {
    switch (action) {
      case 'receiving':
        return <Package className="h-4 w-4" />
      case 'issuing':
        return <CheckCircle className="h-4 w-4" />
      case 'shipping':
        return <Truck className="h-4 w-4" />
      default:
        return <Clock className="h-4 w-4" />
    }
  }

  const getActionColor = (action) => {
    switch (action) {
      case 'receiving':
        return 'bg-green-100 text-green-800'
      case 'issuing':
        return 'bg-blue-100 text-blue-800'
      case 'shipping':
        return 'bg-purple-100 text-purple-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800'
      case 'offline':
        return 'bg-yellow-100 text-yellow-800'
      case 'pending':
        return 'bg-blue-100 text-blue-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  const formatTime = (timestamp) => {
    return new Date(timestamp).toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    })
  }

  const formatDate = (timestamp) => {
    const date = new Date(timestamp)
    const today = new Date()
    const yesterday = new Date(today)
    yesterday.setDate(yesterday.getDate() - 1)

    if (date.toDateString() === today.toDateString()) {
      return 'Today'
    } else if (date.toDateString() === yesterday.toDateString()) {
      return 'Yesterday'
    } else {
      return date.toLocaleDateString()
    }
  }

  const clearHistory = () => {
    if (confirm('Are you sure you want to clear scan history?')) {
      // In a real app, this would update the parent state
      console.log('Clear history requested')
    }
  }

  if (!scans || scans.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Clock className="h-5 w-5" />
            <span>Scan History</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-gray-500">
            <Clock className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No scans recorded yet</p>
            <p className="text-sm mt-2">Start scanning barcodes to see history here</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  // Group scans by date
  const groupedScans = scans.reduce((groups, scan) => {
    const date = formatDate(scan.timestamp)
    if (!groups[date]) {
      groups[date] = []
    }
    groups[date].push(scan)
    return groups
  }, {})

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Clock className="h-5 w-5" />
            <span>Scan History</span>
            <Badge variant="outline">{scans.length}</Badge>
          </div>
          {scans.length > 0 && (
            <Button 
              variant="outline" 
              size="sm" 
              onClick={clearHistory}
              className="flex items-center space-x-1 text-red-600 hover:text-red-700"
            >
              <Trash2 className="h-3 w-3" />
              <span>Clear</span>
            </Button>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {Object.entries(groupedScans).map(([date, dateScans]) => (
            <div key={date}>
              <h3 className="text-sm font-medium text-gray-500 mb-3 sticky top-0 bg-white py-1">
                {date}
              </h3>
              <div className="space-y-3">
                {dateScans.map((scan) => (
                  <div 
                    key={scan.id}
                    className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-center space-x-3 flex-1">
                      <div className="flex-shrink-0">
                        {scan.action ? getActionIcon(scan.action) : <Clock className="h-4 w-4" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate">
                          {scan.batchCode}
                        </p>
                        <p className="text-xs text-gray-500">
                          {formatTime(scan.timestamp)}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      {scan.action && (
                        <Badge className={getActionColor(scan.action)}>
                          {scan.action}
                        </Badge>
                      )}
                      <Badge className={getStatusColor(scan.status)}>
                        {scan.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Summary Stats */}
        <div className="mt-6 pt-4 border-t">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <p className="text-2xl font-bold text-green-600">
                {scans.filter(s => s.status === 'completed').length}
              </p>
              <p className="text-xs text-gray-500">Completed</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-yellow-600">
                {scans.filter(s => s.status === 'offline').length}
              </p>
              <p className="text-xs text-gray-500">Offline</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-blue-600">
                {scans.filter(s => s.status === 'pending').length}
              </p>
              <p className="text-xs text-gray-500">Pending</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default ScanHistory

