import { useEffect, useRef, useState } from 'react'
import Quagga from 'quagga'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent } from '@/components/ui/card.jsx'
import { Camera, CameraOff, RotateCcw } from 'lucide-react'

const BarcodeScanner = ({ onScanResult }) => {
  const scannerRef = useRef(null)
  const [isScanning, setIsScanning] = useState(false)
  const [error, setError] = useState(null)
  const [lastScan, setLastScan] = useState(null)

  const startScanner = async () => {
    try {
      setError(null)
      setIsScanning(true)

      // Check if camera is available
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Camera not supported on this device')
      }

      const config = {
        inputStream: {
          name: "Live",
          type: "LiveStream",
          target: scannerRef.current,
          constraints: {
            width: { min: 640 },
            height: { min: 480 },
            facingMode: "environment", // Use back camera
            aspectRatio: { min: 1, max: 2 }
          }
        },
        locator: {
          patchSize: "medium",
          halfSample: true
        },
        numOfWorkers: 2,
        frequency: 10,
        decoder: {
          readers: [
            "code_128_reader",
            "ean_reader",
            "ean_8_reader",
            "code_39_reader",
            "code_39_vin_reader",
            "codabar_reader",
            "upc_reader",
            "upc_e_reader",
            "i2of5_reader"
          ]
        },
        locate: true
      }

      await new Promise((resolve, reject) => {
        Quagga.init(config, (err) => {
          if (err) {
            console.error('QuaggaJS initialization error:', err)
            reject(err)
            return
          }
          resolve()
        })
      })

      Quagga.start()

      // Set up detection handler
      Quagga.onDetected((result) => {
        const code = result.codeResult.code
        
        // Prevent duplicate scans within 2 seconds
        if (lastScan && Date.now() - lastScan.timestamp < 2000 && lastScan.code === code) {
          return
        }

        setLastScan({ code, timestamp: Date.now() })
        
        // Provide feedback
        if (navigator.vibrate) {
          navigator.vibrate(200)
        }
        
        // Play success sound
        try {
          const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTYIG2m98OScTgwOUarm7blmGgU7k9n1unEiBC13yO/eizEIHWq+8+OWT')
          audio.play().catch(() => {}) // Ignore audio errors
        } catch (e) {}

        onScanResult(code)
      })

    } catch (err) {
      console.error('Scanner start error:', err)
      setError(err.message || 'Failed to start camera')
      setIsScanning(false)
    }
  }

  const stopScanner = () => {
    try {
      Quagga.stop()
      setIsScanning(false)
    } catch (err) {
      console.error('Scanner stop error:', err)
    }
  }

  const resetScanner = () => {
    stopScanner()
    setTimeout(() => {
      startScanner()
    }, 100)
  }

  useEffect(() => {
    return () => {
      if (isScanning) {
        stopScanner()
      }
    }
  }, [isScanning])

  return (
    <div className="space-y-4">
      {/* Scanner Controls */}
      <div className="flex space-x-2">
        {!isScanning ? (
          <Button onClick={startScanner} className="flex items-center space-x-2">
            <Camera className="h-4 w-4" />
            <span>Start Scanner</span>
          </Button>
        ) : (
          <>
            <Button onClick={stopScanner} variant="destructive" className="flex items-center space-x-2">
              <CameraOff className="h-4 w-4" />
              <span>Stop Scanner</span>
            </Button>
            <Button onClick={resetScanner} variant="outline" className="flex items-center space-x-2">
              <RotateCcw className="h-4 w-4" />
              <span>Reset</span>
            </Button>
          </>
        )}
      </div>

      {/* Error Display */}
      {error && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="pt-6">
            <p className="text-red-600">{error}</p>
            <p className="text-sm text-red-500 mt-2">
              Make sure your device has a camera and you've granted camera permissions.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Scanner Viewport */}
      <Card className="overflow-hidden">
        <CardContent className="p-0">
          <div 
            ref={scannerRef}
            data-testid="scanner-viewport"
            className="relative w-full h-64 bg-gray-900 flex items-center justify-center"
          >
            {!isScanning && !error && (
              <div className="text-white text-center">
                <Camera className="h-12 w-12 mx-auto mb-2 opacity-50" />
                <p className="text-sm opacity-75">Click "Start Scanner" to begin</p>
              </div>
            )}
            
            {isScanning && (
              <div className="absolute inset-0 pointer-events-none">
                {/* Scanning overlay */}
                <div className="absolute inset-4 border-2 border-white border-dashed rounded-lg opacity-50"></div>
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <div className="w-48 h-1 bg-red-500 opacity-75 animate-pulse"></div>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Instructions */}
      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="pt-6">
          <h3 className="font-semibold text-blue-900 mb-2">Scanning Instructions</h3>
          <ul className="text-sm text-blue-700 space-y-1">
            <li>• Hold the barcode steady within the scanning area</li>
            <li>• Ensure good lighting for best results</li>
            <li>• Keep the camera 6-12 inches from the barcode</li>
            <li>• The scanner will automatically detect and process barcodes</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}

export default BarcodeScanner

