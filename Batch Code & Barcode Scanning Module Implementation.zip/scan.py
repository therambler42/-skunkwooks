from flask import Blueprint, request, jsonify
from datetime import datetime
from src.models.database import db, ScanEvent, Lot
from sqlalchemy import desc

scan_bp = Blueprint('scan', __name__)

@scan_bp.route('/event', methods=['POST'])
def create_scan_event():
    """Create a new scan event"""
    data = request.get_json()
    
    required_fields = ['batch_code', 'action', 'user_id']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'{field} is required'}), 400
    
    # Validate action type
    valid_actions = ['receiving', 'issuing', 'shipping', 'inspection']
    if data['action'] not in valid_actions:
        return jsonify({'error': f'Invalid action. Must be one of: {", ".join(valid_actions)}'}), 400
    
    # Find the lot by batch code
    lot = Lot.query.filter_by(batch_code=data['batch_code']).first()
    if not lot:
        return jsonify({'error': 'Lot not found'}), 404
    
    try:
        # Create scan event
        scan_event = ScanEvent(
            lot_id=lot.id,
            action=data['action'],
            user_id=data['user_id'],
            location=data.get('location'),
            notes=data.get('notes'),
            timestamp=datetime.utcnow()
        )
        
        db.session.add(scan_event)
        db.session.commit()
        
        return jsonify({
            'id': scan_event.id,
            'message': 'Scan event recorded successfully',
            'event': scan_event.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Failed to record scan event'}), 500

@scan_bp.route('/events', methods=['GET'])
def get_scan_events():
    """Get scan events with optional filtering"""
    lot_id = request.args.get('lot_id', type=int)
    batch_code = request.args.get('batch_code')
    action = request.args.get('action')
    user_id = request.args.get('user_id')
    limit = request.args.get('limit', default=100, type=int)
    
    query = ScanEvent.query
    
    # Apply filters
    if lot_id:
        query = query.filter_by(lot_id=lot_id)
    elif batch_code:
        lot = Lot.query.filter_by(batch_code=batch_code).first()
        if lot:
            query = query.filter_by(lot_id=lot.id)
        else:
            return jsonify([])  # No events for non-existent lot
    
    if action:
        query = query.filter_by(action=action)
    if user_id:
        query = query.filter_by(user_id=user_id)
    
    # Order by timestamp descending and limit results
    events = query.order_by(desc(ScanEvent.timestamp)).limit(limit).all()
    
    # Include lot information in response
    result = []
    for event in events:
        event_dict = event.to_dict()
        event_dict['lot'] = event.lot.to_dict()
        result.append(event_dict)
    
    return jsonify(result)

@scan_bp.route('/events/<int:event_id>', methods=['GET'])
def get_scan_event(event_id):
    """Get a specific scan event"""
    event = ScanEvent.query.get(event_id)
    
    if not event:
        return jsonify({'error': 'Scan event not found'}), 404
    
    event_dict = event.to_dict()
    event_dict['lot'] = event.lot.to_dict()
    
    return jsonify(event_dict)

@scan_bp.route('/events/<int:event_id>', methods=['PUT'])
def update_scan_event(event_id):
    """Update a scan event (for corrections)"""
    event = ScanEvent.query.get(event_id)
    
    if not event:
        return jsonify({'error': 'Scan event not found'}), 404
    
    data = request.get_json()
    
    # Update allowed fields
    if 'location' in data:
        event.location = data['location']
    if 'notes' in data:
        event.notes = data['notes']
    
    db.session.commit()
    
    event_dict = event.to_dict()
    event_dict['lot'] = event.lot.to_dict()
    
    return jsonify(event_dict)

@scan_bp.route('/stats', methods=['GET'])
def get_scan_stats():
    """Get scan event statistics"""
    from sqlalchemy import func
    
    # Get date range for filtering (default to last 30 days)
    days = request.args.get('days', default=30, type=int)
    start_date = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    start_date = start_date.replace(day=start_date.day - days + 1) if start_date.day > days else start_date.replace(month=start_date.month - 1, day=30 - (days - start_date.day))
    
    # Total events
    total_events = ScanEvent.query.filter(ScanEvent.timestamp >= start_date).count()
    
    # Events by action
    action_stats = db.session.query(
        ScanEvent.action,
        func.count(ScanEvent.id).label('count')
    ).filter(
        ScanEvent.timestamp >= start_date
    ).group_by(ScanEvent.action).all()
    
    # Events by day
    daily_stats = db.session.query(
        func.date(ScanEvent.timestamp).label('date'),
        func.count(ScanEvent.id).label('count')
    ).filter(
        ScanEvent.timestamp >= start_date
    ).group_by(func.date(ScanEvent.timestamp)).all()
    
    # Top users
    user_stats = db.session.query(
        ScanEvent.user_id,
        func.count(ScanEvent.id).label('count')
    ).filter(
        ScanEvent.timestamp >= start_date
    ).group_by(ScanEvent.user_id).order_by(desc(func.count(ScanEvent.id))).limit(10).all()
    
    return jsonify({
        'period_days': days,
        'start_date': start_date.isoformat(),
        'total_events': total_events,
        'by_action': [{'action': action, 'count': count} for action, count in action_stats],
        'by_day': [{'date': str(date), 'count': count} for date, count in daily_stats],
        'top_users': [{'user_id': user_id, 'count': count} for user_id, count in user_stats]
    })

@scan_bp.route('/health', methods=['GET'])
def scan_health():
    return {'status': 'ok', 'service': 'scan'}

