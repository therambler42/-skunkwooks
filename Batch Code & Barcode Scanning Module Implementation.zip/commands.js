// cypress/support/commands.js

// Custom commands for the scanner PWA

Cypress.Commands.add('mockScan', (batchCode) => {
  cy.window().then((win) => {
    // Mock the scan result by directly calling the handler
    if (win.handleScanResult) {
      win.handleScanResult(batchCode)
    } else {
      // Fallback: dispatch a custom event
      win.dispatchEvent(new CustomEvent('mockScan', { detail: { batchCode } }))
    }
  })
})

Cypress.Commands.add('goOffline', () => {
  cy.window().then((win) => {
    win.navigator.onLine = false
    win.dispatchEvent(new Event('offline'))
  })
})

Cypress.Commands.add('goOnline', () => {
  cy.window().then((win) => {
    win.navigator.onLine = true
    win.dispatchEvent(new Event('online'))
  })
})

Cypress.Commands.add('waitForScanResult', (batchCode, timeout = 5000) => {
  cy.contains(batchCode, { timeout }).should('be.visible')
})

Cypress.Commands.add('performScanAction', (action) => {
  cy.contains(action).click()
  cy.contains('Action recorded', { timeout: 10000 }).should('be.visible')
})

