// cypress/support/e2e.js

// Import commands.js using ES2015 syntax:
import './commands'

// Alternatively you can use CommonJS syntax:
// require('./commands')

// Add global configuration
Cypress.on('uncaught:exception', (err, runnable) => {
  // Prevent Cypress from failing on uncaught exceptions
  // This is useful for handling QuaggaJS camera errors in headless mode
  if (err.message.includes('Camera') || err.message.includes('getUserMedia')) {
    return false
  }
  return true
})

