import pytest
import json
from datetime import date
from src.main import app
from src.models.database import db, Organization, ProductionLine, Lot, ScanEvent

@pytest.fixture
def app_instance():
    """Create Flask app instance for testing"""
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    with app.app_context():
        db.create_all()
        yield app
        db.drop_all()

@pytest.fixture
def client(app_instance):
    """Create test client"""
    return app_instance.test_client()

@pytest.fixture
def sample_data(app_instance):
    """Create sample data for testing"""
    with app_instance.app_context():
        # Create organization
        org = Organization(name="Test Org", batch_code_format="YYYYMMDD-LINE-SEQ")
        db.session.add(org)
        db.session.flush()
        
        # Create production line
        line = ProductionLine(organization_id=org.id, name="Test Line", code="TL")
        db.session.add(line)
        db.session.flush()
        
        # Create lot
        lot = Lot(
            batch_code="20250608-TL-001",
            organization_id=org.id,
            production_line_id=line.id,
            product_name="Test Product",
            quantity=100,
            production_date=date.today()
        )
        db.session.add(lot)
        db.session.commit()
        
        return {
            'organization_id': org.id,
            'production_line_id': line.id,
            'lot_id': lot.id,
            'batch_code': lot.batch_code
        }

class TestBatchAPI:
    """Test batch management API endpoints"""
    
    def test_create_organization(self, client):
        """Test organization creation"""
        response = client.post('/api/batch/organizations', 
                             json={'name': 'Test Organization'})
        
        assert response.status_code == 201
        data = json.loads(response.data)
        assert data['name'] == 'Test Organization'
        assert data['batch_code_format'] == 'YYYYMMDD-LINE-SEQ'
    
    def test_create_organization_missing_name(self, client):
        """Test organization creation with missing name"""
        response = client.post('/api/batch/organizations', json={})
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert 'error' in data
    
    def test_get_organizations(self, client, sample_data):
        """Test getting organizations"""
        response = client.get('/api/batch/organizations')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert len(data) == 1
        assert data[0]['name'] == 'Test Org'
    
    def test_create_production_line(self, client, sample_data):
        """Test production line creation"""
        org_id = sample_data['organization_id']
        response = client.post(f'/api/batch/organizations/{org_id}/lines',
                             json={'name': 'New Line', 'code': 'NL'})
        
        assert response.status_code == 201
        data = json.loads(response.data)
        assert data['name'] == 'New Line'
        assert data['code'] == 'NL'
    
    def test_create_lot(self, client, sample_data):
        """Test lot creation with batch code generation"""
        org_id = sample_data['organization_id']
        line_id = sample_data['production_line_id']
        
        response = client.post('/api/batch/lots', json={
            'organization_id': org_id,
            'production_line_id': line_id,
            'product_name': 'New Product',
            'quantity': 200
        })
        
        assert response.status_code == 201
        data = json.loads(response.data)
        assert data['product_name'] == 'New Product'
        assert data['quantity'] == 200
        assert 'TL' in data['batch_code']  # Should contain line code
    
    def test_get_lot_by_batch_code(self, client, sample_data):
        """Test getting lot by batch code"""
        batch_code = sample_data['batch_code']
        response = client.get(f'/api/batch/lots/{batch_code}')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['batch_code'] == batch_code
        assert data['product_name'] == 'Test Product'
    
    def test_batch_code_preview(self, client, sample_data):
        """Test batch code preview generation"""
        org_id = sample_data['organization_id']
        line_id = sample_data['production_line_id']
        
        response = client.post('/api/batch/generate-code', json={
            'organization_id': org_id,
            'production_line_id': line_id
        })
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'batch_code' in data
        assert 'TL' in data['batch_code']

class TestScanAPI:
    """Test scan events API endpoints"""
    
    def test_create_scan_event(self, client, sample_data):
        """Test creating a scan event"""
        batch_code = sample_data['batch_code']
        
        response = client.post('/api/scan/event', json={
            'batch_code': batch_code,
            'action': 'receiving',
            'user_id': 'test-user',
            'location': 'Warehouse A',
            'notes': 'Test scan'
        })
        
        assert response.status_code == 201
        data = json.loads(response.data)
        assert data['message'] == 'Scan event recorded successfully'
        assert data['event']['action'] == 'receiving'
        assert data['event']['user_id'] == 'test-user'
    
    def test_create_scan_event_invalid_action(self, client, sample_data):
        """Test creating scan event with invalid action"""
        batch_code = sample_data['batch_code']
        
        response = client.post('/api/scan/event', json={
            'batch_code': batch_code,
            'action': 'invalid_action',
            'user_id': 'test-user'
        })
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert 'Invalid action' in data['error']
    
    def test_create_scan_event_nonexistent_lot(self, client):
        """Test creating scan event for non-existent lot"""
        response = client.post('/api/scan/event', json={
            'batch_code': 'NONEXISTENT-001',
            'action': 'receiving',
            'user_id': 'test-user'
        })
        
        assert response.status_code == 404
        data = json.loads(response.data)
        assert data['error'] == 'Lot not found'
    
    def test_get_scan_events(self, client, sample_data):
        """Test getting scan events"""
        # Create a scan event first
        batch_code = sample_data['batch_code']
        client.post('/api/scan/event', json={
            'batch_code': batch_code,
            'action': 'receiving',
            'user_id': 'test-user'
        })
        
        response = client.get('/api/scan/events')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert len(data) == 1
        assert data[0]['action'] == 'receiving'
        assert 'lot' in data[0]  # Should include lot information

class TestLabelAPI:
    """Test label generation API endpoints"""
    
    def test_generate_zpl_label(self, client, sample_data):
        """Test ZPL label generation"""
        batch_code = sample_data['batch_code']
        
        response = client.get(f'/api/label/zpl/{batch_code}')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['batch_code'] == batch_code
        assert 'zpl_content' in data
        assert '^XA' in data['zpl_content']  # ZPL start command
        assert '^XZ' in data['zpl_content']  # ZPL end command
    
    def test_generate_label_preview(self, client, sample_data):
        """Test label preview generation"""
        batch_code = sample_data['batch_code']
        
        response = client.get(f'/api/label/preview/{batch_code}')
        
        assert response.status_code == 200
        assert response.content_type == 'image/png'
    
    def test_generate_label_nonexistent_lot(self, client):
        """Test label generation for non-existent lot"""
        response = client.get('/api/label/zpl/NONEXISTENT-001')
        
        assert response.status_code == 404
        data = json.loads(response.data)
        assert data['error'] == 'Lot not found'

class TestRecallAPI:
    """Test recall trace API endpoints"""
    
    def test_trace_by_batch_code(self, client, sample_data):
        """Test recall trace by batch code"""
        batch_code = sample_data['batch_code']
        
        # Create some scan events first
        client.post('/api/scan/event', json={
            'batch_code': batch_code,
            'action': 'receiving',
            'user_id': 'user1',
            'location': 'Warehouse A'
        })
        
        client.post('/api/scan/event', json={
            'batch_code': batch_code,
            'action': 'shipping',
            'user_id': 'user2',
            'location': 'Dock B'
        })
        
        response = client.get(f'/api/recall/trace/{batch_code}')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        
        assert 'primary_lot' in data
        assert 'events' in data
        assert 'timeline' in data
        assert 'performance' in data
        
        assert data['primary_lot']['batch_code'] == batch_code
        assert len(data['events']) == 2
        assert len(data['timeline']) == 2
        
        # Check performance requirement
        assert data['performance']['query_time_seconds'] < 2.0
    
    def test_performance_test(self, client, sample_data):
        """Test recall trace performance"""
        response = client.get('/api/recall/performance-test')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        
        assert 'performance' in data
        assert 'test_lot' in data
        assert data['performance']['meets_requirement'] == True
        assert data['performance']['query_time_seconds'] < 2.0
    
    def test_trace_nonexistent_lot(self, client):
        """Test trace for non-existent lot"""
        response = client.get('/api/recall/trace/NONEXISTENT-001')
        
        assert response.status_code == 404
        data = json.loads(response.data)
        assert data['error'] == 'Lot not found'

class TestHealthEndpoints:
    """Test health check endpoints"""
    
    def test_batch_health(self, client):
        """Test batch service health"""
        # Note: batch service doesn't have a health endpoint, testing via organizations
        response = client.get('/api/batch/organizations')
        assert response.status_code == 200
    
    def test_scan_health(self, client):
        """Test scan service health"""
        response = client.get('/api/scan/health')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['status'] == 'ok'
        assert data['service'] == 'scan'
    
    def test_label_health(self, client):
        """Test label service health"""
        response = client.get('/api/label/health')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['status'] == 'ok'
        assert data['service'] == 'label'
    
    def test_recall_health(self, client):
        """Test recall service health"""
        response = client.get('/api/recall/health')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['status'] == 'ok'
        assert data['service'] == 'recall'

class TestIntegration:
    """Integration tests for complete workflows"""
    
    def test_complete_workflow(self, client):
        """Test complete workflow from organization to recall trace"""
        # 1. Create organization
        org_response = client.post('/api/batch/organizations', 
                                 json={'name': 'Integration Test Org'})
        assert org_response.status_code == 201
        org_data = json.loads(org_response.data)
        org_id = org_data['id']
        
        # 2. Create production line
        line_response = client.post(f'/api/batch/organizations/{org_id}/lines',
                                  json={'name': 'Integration Line', 'code': 'IL'})
        assert line_response.status_code == 201
        line_data = json.loads(line_response.data)
        line_id = line_data['id']
        
        # 3. Create lot
        lot_response = client.post('/api/batch/lots', json={
            'organization_id': org_id,
            'production_line_id': line_id,
            'product_name': 'Integration Product',
            'quantity': 500
        })
        assert lot_response.status_code == 201
        lot_data = json.loads(lot_response.data)
        batch_code = lot_data['batch_code']
        
        # 4. Generate label
        label_response = client.get(f'/api/label/zpl/{batch_code}')
        assert label_response.status_code == 200
        
        # 5. Create scan events
        events = [
            {'action': 'receiving', 'user_id': 'user1', 'location': 'Warehouse'},
            {'action': 'issuing', 'user_id': 'user2', 'location': 'Production'},
            {'action': 'shipping', 'user_id': 'user3', 'location': 'Dock'}
        ]
        
        for event in events:
            event_response = client.post('/api/scan/event', json={
                'batch_code': batch_code,
                **event
            })
            assert event_response.status_code == 201
        
        # 6. Perform recall trace
        trace_response = client.get(f'/api/recall/trace/{batch_code}')
        assert trace_response.status_code == 200
        trace_data = json.loads(trace_response.data)
        
        # Verify complete trace
        assert len(trace_data['events']) == 3
        assert len(trace_data['timeline']) == 3
        assert len(trace_data['locations']) == 3
        assert len(trace_data['users']) == 3
        
        # Verify performance
        assert trace_data['performance']['query_time_seconds'] < 2.0

