import { useState, useEffect } from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { QrCode, Package, Truck, CheckCircle, AlertCircle, Camera } from 'lucide-react'
import BarcodeScanner from './components/BarcodeScanner'
import ScanHistory from './components/ScanHistory'
import LotDetails from './components/LotDetails'
import './App.css'

function App() {
  const [currentScan, setCurrentScan] = useState(null)
  const [scanHistory, setScanHistory] = useState([])
  const [isOnline, setIsOnline] = useState(navigator.onLine)

  useEffect(() => {
    const handleOnline = () => setIsOnline(true)
    const handleOffline = () => setIsOnline(false)

    window.addEventListener('online', handleOnline)
    window.addEventListener('offline', handleOffline)

    return () => {
      window.removeEventListener('online', handleOnline)
      window.removeEventListener('offline', handleOffline)
    }
  }, [])

  const handleScanResult = (result) => {
    const scanData = {
      id: Date.now(),
      batchCode: result,
      timestamp: new Date().toISOString(),
      status: 'pending'
    }
    
    setCurrentScan(scanData)
    setScanHistory(prev => [scanData, ...prev.slice(0, 49)]) // Keep last 50 scans
  }

  // Expose handleScanResult globally for testing
  useEffect(() => {
    window.handleScanResult = handleScanResult
    return () => {
      delete window.handleScanResult
    }
  }, [])

  const handleScanAction = async (action, notes = '') => {
    if (!currentScan) return

    try {
      const response = await fetch('https://r3dhkilc5kxw.manus.space/api/scan/event', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          batch_code: currentScan.batchCode,
          action: action,
          user_id: 'scanner-user', // In real app, this would be from auth
          notes: notes
        })
      })

      if (response.ok) {
        const updatedScan = {
          ...currentScan,
          status: 'completed',
          action: action,
          notes: notes
        }
        
        setCurrentScan(updatedScan)
        setScanHistory(prev => 
          prev.map(scan => 
            scan.id === currentScan.id ? updatedScan : scan
          )
        )
      } else {
        throw new Error('Failed to record scan event')
      }
    } catch (error) {
      console.error('Error recording scan:', error)
      // In offline mode, store locally
      const updatedScan = {
        ...currentScan,
        status: 'offline',
        action: action,
        notes: notes
      }
      
      setCurrentScan(updatedScan)
      setScanHistory(prev => 
        prev.map(scan => 
          scan.id === currentScan.id ? updatedScan : scan
        )
      )
    }
  }

  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-blue-600 text-white p-4 shadow-lg">
          <div className="max-w-4xl mx-auto flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <QrCode className="h-8 w-8" />
              <h1 className="text-xl font-bold">Batch Scanner</h1>
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant={isOnline ? "default" : "destructive"}>
                {isOnline ? "Online" : "Offline"}
              </Badge>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="max-w-4xl mx-auto p-4">
          <Routes>
            <Route path="/" element={
              <div className="space-y-6">
                {/* Scanner Section */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Camera className="h-5 w-5" />
                      <span>Barcode Scanner</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <BarcodeScanner onScanResult={handleScanResult} />
                  </CardContent>
                </Card>

                {/* Current Scan Actions */}
                {currentScan && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Scanned: {currentScan.batchCode}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <LotDetails batchCode={currentScan.batchCode} />
                        
                        {currentScan.status === 'pending' && (
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <Button 
                              onClick={() => handleScanAction('receiving')}
                              className="flex items-center space-x-2 bg-green-600 hover:bg-green-700"
                            >
                              <Package className="h-4 w-4" />
                              <span>Receiving</span>
                            </Button>
                            <Button 
                              onClick={() => handleScanAction('issuing')}
                              className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700"
                            >
                              <CheckCircle className="h-4 w-4" />
                              <span>Issuing</span>
                            </Button>
                            <Button 
                              onClick={() => handleScanAction('shipping')}
                              className="flex items-center space-x-2 bg-purple-600 hover:bg-purple-700"
                            >
                              <Truck className="h-4 w-4" />
                              <span>Shipping</span>
                            </Button>
                          </div>
                        )}

                        {currentScan.status !== 'pending' && (
                          <div className="flex items-center space-x-2 text-green-600">
                            <CheckCircle className="h-5 w-5" />
                            <span>Action recorded: {currentScan.action}</span>
                            {currentScan.status === 'offline' && (
                              <Badge variant="outline">Stored Offline</Badge>
                            )}
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Tabs for History and Settings */}
                <Tabs defaultValue="history" className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="history">Scan History</TabsTrigger>
                    <TabsTrigger value="settings">Settings</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="history">
                    <ScanHistory scans={scanHistory} />
                  </TabsContent>
                  
                  <TabsContent value="settings">
                    <Card>
                      <CardHeader>
                        <CardTitle>Scanner Settings</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div className="flex items-center justify-between">
                            <span>Auto-focus</span>
                            <Badge variant="outline">Enabled</Badge>
                          </div>
                          <div className="flex items-center justify-between">
                            <span>Sound feedback</span>
                            <Badge variant="outline">Enabled</Badge>
                          </div>
                          <div className="flex items-center justify-between">
                            <span>Vibration feedback</span>
                            <Badge variant="outline">Enabled</Badge>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>
                </Tabs>
              </div>
            } />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
      </div>
    </Router>
  )
}

export default App

