from flask import Blueprint, request, jsonify
from datetime import datetime, timedelta
from src.models.database import db, ScanEvent, Lot, Organization, ProductionLine
from sqlalchemy import desc, and_, or_
import time

recall_bp = Blueprint('recall', __name__)

def trace_lot_chain(lot_id, max_depth=10):
    """
    Trace the complete chain of events for a lot and related lots
    Returns a comprehensive trace for recall purposes
    """
    start_time = time.time()
    
    # Get the primary lot
    primary_lot = Lot.query.get(lot_id)
    if not primary_lot:
        return None
    
    # Get all events for this lot
    lot_events = ScanEvent.query.filter_by(lot_id=lot_id).order_by(ScanEvent.timestamp).all()
    
    # Build the trace chain
    trace_chain = {
        'primary_lot': primary_lot.to_dict(),
        'events': [event.to_dict() for event in lot_events],
        'related_lots': [],
        'locations': set(),
        'users': set(),
        'timeline': []
    }
    
    # Extract locations and users from events
    for event in lot_events:
        if event.location:
            trace_chain['locations'].add(event.location)
        trace_chain['users'].add(event.user_id)
        
        trace_chain['timeline'].append({
            'timestamp': event.timestamp.isoformat(),
            'action': event.action,
            'lot_id': lot_id,
            'batch_code': primary_lot.batch_code,
            'location': event.location,
            'user_id': event.user_id,
            'notes': event.notes
        })
    
    # Find related lots (same production line, same day, or cross-contamination risk)
    related_lots_query = Lot.query.filter(
        and_(
            Lot.id != lot_id,
            or_(
                # Same production line and date
                and_(
                    Lot.production_line_id == primary_lot.production_line_id,
                    Lot.production_date == primary_lot.production_date
                ),
                # Lots processed in same locations
                Lot.id.in_(
                    db.session.query(ScanEvent.lot_id).filter(
                        ScanEvent.location.in_([loc for loc in trace_chain['locations'] if loc])
                    ).distinct()
                ) if trace_chain['locations'] else False
            )
        )
    ).limit(50)  # Limit to prevent excessive queries
    
    related_lots = related_lots_query.all()
    
    for related_lot in related_lots:
        related_events = ScanEvent.query.filter_by(lot_id=related_lot.id).order_by(ScanEvent.timestamp).all()
        
        trace_chain['related_lots'].append({
            'lot': related_lot.to_dict(),
            'events': [event.to_dict() for event in related_events],
            'relationship': 'same_line_date' if (
                related_lot.production_line_id == primary_lot.production_line_id and
                related_lot.production_date == primary_lot.production_date
            ) else 'location_overlap'
        })
        
        # Add related lot events to timeline
        for event in related_events:
            trace_chain['timeline'].append({
                'timestamp': event.timestamp.isoformat(),
                'action': event.action,
                'lot_id': related_lot.id,
                'batch_code': related_lot.batch_code,
                'location': event.location,
                'user_id': event.user_id,
                'notes': event.notes
            })
    
    # Sort timeline by timestamp
    trace_chain['timeline'].sort(key=lambda x: x['timestamp'])
    
    # Convert sets to lists for JSON serialization
    trace_chain['locations'] = list(trace_chain['locations'])
    trace_chain['users'] = list(trace_chain['users'])
    
    # Add performance metrics
    end_time = time.time()
    trace_chain['performance'] = {
        'query_time_seconds': round(end_time - start_time, 3),
        'total_lots_traced': 1 + len(related_lots),
        'total_events': len(lot_events) + sum(len(rl['events']) for rl in trace_chain['related_lots'])
    }
    
    return trace_chain

@recall_bp.route('/trace/<batch_code>', methods=['GET'])
def trace_by_batch_code(batch_code):
    """Trace recall chain by batch code"""
    lot = Lot.query.filter_by(batch_code=batch_code).first()
    
    if not lot:
        return jsonify({'error': 'Lot not found'}), 404
    
    trace_result = trace_lot_chain(lot.id)
    
    if not trace_result:
        return jsonify({'error': 'Failed to generate trace'}), 500
    
    return jsonify(trace_result)

@recall_bp.route('/trace/lot/<int:lot_id>', methods=['GET'])
def trace_by_lot_id(lot_id):
    """Trace recall chain by lot ID"""
    trace_result = trace_lot_chain(lot_id)
    
    if not trace_result:
        return jsonify({'error': 'Lot not found or failed to generate trace'}), 404
    
    return jsonify(trace_result)

@recall_bp.route('/impact-analysis', methods=['POST'])
def analyze_recall_impact():
    """Analyze the potential impact of a recall"""
    data = request.get_json()
    
    if not data or 'criteria' not in data:
        return jsonify({'error': 'Recall criteria required'}), 400
    
    criteria = data['criteria']
    start_time = time.time()
    
    # Build query based on criteria
    query = Lot.query
    
    if 'production_date_start' in criteria:
        query = query.filter(Lot.production_date >= datetime.strptime(criteria['production_date_start'], '%Y-%m-%d').date())
    
    if 'production_date_end' in criteria:
        query = query.filter(Lot.production_date <= datetime.strptime(criteria['production_date_end'], '%Y-%m-%d').date())
    
    if 'production_line_ids' in criteria:
        query = query.filter(Lot.production_line_id.in_(criteria['production_line_ids']))
    
    if 'organization_id' in criteria:
        query = query.filter(Lot.organization_id == criteria['organization_id'])
    
    if 'product_name' in criteria:
        query = query.filter(Lot.product_name.ilike(f"%{criteria['product_name']}%"))
    
    affected_lots = query.all()
    
    # Analyze impact
    total_quantity = sum(lot.quantity for lot in affected_lots)
    
    # Get distribution events (shipped lots)
    shipped_lots = []
    for lot in affected_lots:
        shipping_events = ScanEvent.query.filter_by(lot_id=lot.id, action='shipping').all()
        if shipping_events:
            shipped_lots.append({
                'lot': lot.to_dict(),
                'shipping_events': [event.to_dict() for event in shipping_events]
            })
    
    # Get locations involved
    all_events = ScanEvent.query.filter(
        ScanEvent.lot_id.in_([lot.id for lot in affected_lots])
    ).all()
    
    locations = set()
    users = set()
    for event in all_events:
        if event.location:
            locations.add(event.location)
        users.add(event.user_id)
    
    end_time = time.time()
    
    impact_analysis = {
        'criteria': criteria,
        'summary': {
            'total_lots_affected': len(affected_lots),
            'total_quantity_affected': total_quantity,
            'lots_shipped': len(shipped_lots),
            'locations_involved': len(locations),
            'users_involved': len(users)
        },
        'affected_lots': [lot.to_dict() for lot in affected_lots],
        'shipped_lots': shipped_lots,
        'locations': list(locations),
        'users': list(users),
        'performance': {
            'query_time_seconds': round(end_time - start_time, 3)
        }
    }
    
    return jsonify(impact_analysis)

@recall_bp.route('/notifications', methods=['POST'])
def create_recall_notification():
    """Create recall notification for affected parties"""
    data = request.get_json()
    
    required_fields = ['lot_ids', 'message', 'severity', 'created_by']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'{field} is required'}), 400
    
    # In a real system, this would:
    # 1. Create notification records in database
    # 2. Send emails/SMS to affected parties
    # 3. Update lot statuses to 'recalled'
    # 4. Generate recall reports
    
    # For now, we'll update lot statuses and return a summary
    lot_ids = data['lot_ids']
    lots = Lot.query.filter(Lot.id.in_(lot_ids)).all()
    
    updated_lots = []
    for lot in lots:
        lot.status = 'recalled'
        updated_lots.append(lot.to_dict())
    
    db.session.commit()
    
    # Create a recall event for each lot
    for lot in lots:
        recall_event = ScanEvent(
            lot_id=lot.id,
            action='inspection',  # Using inspection as recall action
            user_id=data['created_by'],
            notes=f"RECALL: {data['message']}",
            timestamp=datetime.utcnow()
        )
        db.session.add(recall_event)
    
    db.session.commit()
    
    return jsonify({
        'message': 'Recall notification created successfully',
        'lots_updated': len(updated_lots),
        'severity': data['severity'],
        'notification_id': f"RECALL-{int(time.time())}"  # Simple ID generation
    }), 201

@recall_bp.route('/performance-test', methods=['GET'])
def performance_test():
    """Test recall trace performance with current data"""
    # Get a random lot for testing
    lot = Lot.query.first()
    
    if not lot:
        return jsonify({'error': 'No lots available for testing'}), 404
    
    start_time = time.time()
    trace_result = trace_lot_chain(lot.id)
    end_time = time.time()
    
    return jsonify({
        'test_lot': lot.to_dict(),
        'performance': {
            'query_time_seconds': round(end_time - start_time, 3),
            'meets_requirement': (end_time - start_time) < 2.0,  # <2s requirement
            'total_lots_in_db': Lot.query.count(),
            'total_events_in_db': ScanEvent.query.count()
        },
        'trace_summary': {
            'total_lots_traced': trace_result['performance']['total_lots_traced'] if trace_result else 0,
            'total_events': trace_result['performance']['total_events'] if trace_result else 0
        }
    })

@recall_bp.route('/health', methods=['GET'])
def recall_health():
    return {'status': 'ok', 'service': 'recall'}

