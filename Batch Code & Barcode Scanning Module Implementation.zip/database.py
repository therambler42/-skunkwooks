from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class Organization(db.Model):
    __tablename__ = 'organizations'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    batch_code_format = db.Column(db.String(50), default='YYYYMMDD-LINE-SEQ')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    lots = db.relationship('Lot', backref='organization', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'batch_code_format': self.batch_code_format,
            'created_at': self.created_at.isoformat()
        }

class ProductionLine(db.Model):
    __tablename__ = 'production_lines'
    
    id = db.Column(db.Integer, primary_key=True)
    organization_id = db.Column(db.Integer, db.ForeignKey('organizations.id'), nullable=False)
    name = db.Column(db.String(50), nullable=False)
    code = db.Column(db.String(10), nullable=False)  # Short code for batch generation
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    lots = db.relationship('Lot', backref='production_line', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'organization_id': self.organization_id,
            'name': self.name,
            'code': self.code,
            'created_at': self.created_at.isoformat()
        }

class Lot(db.Model):
    __tablename__ = 'lots'
    
    id = db.Column(db.Integer, primary_key=True)
    batch_code = db.Column(db.String(50), unique=True, nullable=False)
    organization_id = db.Column(db.Integer, db.ForeignKey('organizations.id'), nullable=False)
    production_line_id = db.Column(db.Integer, db.ForeignKey('production_lines.id'), nullable=False)
    product_name = db.Column(db.String(100), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    production_date = db.Column(db.Date, nullable=False)
    expiry_date = db.Column(db.Date)
    status = db.Column(db.String(20), default='active')  # active, recalled, expired
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    scan_events = db.relationship('ScanEvent', backref='lot', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'batch_code': self.batch_code,
            'organization_id': self.organization_id,
            'production_line_id': self.production_line_id,
            'product_name': self.product_name,
            'quantity': self.quantity,
            'production_date': self.production_date.isoformat() if self.production_date else None,
            'expiry_date': self.expiry_date.isoformat() if self.expiry_date else None,
            'status': self.status,
            'created_at': self.created_at.isoformat()
        }

class ScanEvent(db.Model):
    __tablename__ = 'scan_events'
    
    id = db.Column(db.Integer, primary_key=True)
    lot_id = db.Column(db.Integer, db.ForeignKey('lots.id'), nullable=False)
    action = db.Column(db.String(20), nullable=False)  # receiving, issuing, shipping, inspection
    user_id = db.Column(db.String(50), nullable=False)  # User identifier
    location = db.Column(db.String(100))  # Optional location info
    notes = db.Column(db.Text)  # Optional notes
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    
    # Add index for performance
    __table_args__ = (
        db.Index('idx_lot_timestamp', 'lot_id', 'timestamp'),
        db.Index('idx_action_timestamp', 'action', 'timestamp'),
    )
    
    def to_dict(self):
        return {
            'id': self.id,
            'lot_id': self.lot_id,
            'action': self.action,
            'user_id': self.user_id,
            'location': self.location,
            'notes': self.notes,
            'timestamp': self.timestamp.isoformat()
        }

