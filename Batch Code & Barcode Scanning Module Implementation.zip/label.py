from flask import Blueprint, request, jsonify, send_file
import base64
from io import BytesIO
from src.models.database import Lot
import os

label_bp = Blueprint('label', __name__)

def create_zpl_template(batch_code, product_name, production_date, expiry_date=None):
    """
    Create ZPL template for 4x2" label with Code-128 barcode
    ZPL dimensions: 4" = 812 dots, 2" = 406 dots at 203 DPI
    """
    
    # Format dates for display
    prod_date_str = production_date.strftime('%m/%d/%Y') if production_date else ''
    exp_date_str = expiry_date.strftime('%m/%d/%Y') if expiry_date else 'N/A'
    
    zpl_template = f"""
^XA
^CF0,30
^FO50,50^FD{product_name}^FS
^CF0,20
^FO50,100^FDLot: {batch_code}^FS
^FO50,130^FDProd: {prod_date_str}^FS
^FO50,160^FDExp: {exp_date_str}^FS
^BY2,3,50
^FO50,200^BC^FD{batch_code}^FS
^XZ
""".strip()
    
    return zpl_template

def generate_label_preview_base64(batch_code, product_name, production_date, expiry_date=None):
    """
    Generate a simple text-based preview as base64 (without PIL dependency)
    """
    # Create a simple text representation
    prod_date_str = production_date.strftime('%m/%d/%Y') if production_date else ''
    exp_date_str = expiry_date.strftime('%m/%d/%Y') if expiry_date else 'N/A'
    
    preview_text = f"""
Label Preview for {batch_code}
================================
Product: {product_name}
Lot: {batch_code}
Production Date: {prod_date_str}
Expiry Date: {exp_date_str}
Barcode: {batch_code}
================================
    """.strip()
    
    # Convert to base64
    preview_bytes = preview_text.encode('utf-8')
    preview_base64 = base64.b64encode(preview_bytes).decode('utf-8')
    
    return f"data:text/plain;base64,{preview_base64}"

@label_bp.route('/generate/<batch_code>', methods=['GET'])
def generate_label(batch_code):
    """Generate ZPL and text preview for a batch code"""
    
    # Get lot information
    lot = Lot.query.filter_by(batch_code=batch_code).first()
    if not lot:
        return jsonify({'error': 'Lot not found'}), 404
    
    try:
        # Generate ZPL template
        zpl_content = create_zpl_template(
            batch_code=lot.batch_code,
            product_name=lot.product_name,
            production_date=lot.production_date,
            expiry_date=lot.expiry_date
        )
        
        # Generate text preview
        preview_base64 = generate_label_preview_base64(
            batch_code=lot.batch_code,
            product_name=lot.product_name,
            production_date=lot.production_date,
            expiry_date=lot.expiry_date
        )
        
        return jsonify({
            'batch_code': batch_code,
            'zpl_content': zpl_content,
            'preview_base64': preview_base64,
            'preview_type': 'text',
            'lot_info': lot.to_dict()
        })
        
    except Exception as e:
        return jsonify({'error': f'Failed to generate label: {str(e)}'}), 500

@label_bp.route('/preview/<batch_code>', methods=['GET'])
def get_label_preview(batch_code):
    """Get text preview for a batch code"""
    
    lot = Lot.query.filter_by(batch_code=batch_code).first()
    if not lot:
        return jsonify({'error': 'Lot not found'}), 404
    
    try:
        # Generate text preview
        prod_date_str = lot.production_date.strftime('%m/%d/%Y') if lot.production_date else ''
        exp_date_str = lot.expiry_date.strftime('%m/%d/%Y') if lot.expiry_date else 'N/A'
        
        preview_text = f"""Label Preview for {batch_code}
================================
Product: {lot.product_name}
Lot: {batch_code}
Production Date: {prod_date_str}
Expiry Date: {exp_date_str}
Barcode: {batch_code}
================================"""
        
        return preview_text, 200, {'Content-Type': 'text/plain'}
        
    except Exception as e:
        return jsonify({'error': f'Failed to generate preview: {str(e)}'}), 500

@label_bp.route('/zpl/<batch_code>', methods=['GET'])
def get_zpl_content(batch_code):
    """Get ZPL content for a batch code"""
    
    lot = Lot.query.filter_by(batch_code=batch_code).first()
    if not lot:
        return jsonify({'error': 'Lot not found'}), 404
    
    try:
        zpl_content = create_zpl_template(
            batch_code=lot.batch_code,
            product_name=lot.product_name,
            production_date=lot.production_date,
            expiry_date=lot.expiry_date
        )
        
        return jsonify({
            'batch_code': batch_code,
            'zpl_content': zpl_content
        })
        
    except Exception as e:
        return jsonify({'error': f'Failed to generate ZPL: {str(e)}'}), 500

@label_bp.route('/batch-generate', methods=['POST'])
def batch_generate_labels():
    """Generate labels for multiple batch codes"""
    data = request.get_json()
    
    if not data or 'batch_codes' not in data:
        return jsonify({'error': 'batch_codes array is required'}), 400
    
    batch_codes = data['batch_codes']
    results = []
    
    for batch_code in batch_codes:
        lot = Lot.query.filter_by(batch_code=batch_code).first()
        if not lot:
            results.append({
                'batch_code': batch_code,
                'error': 'Lot not found'
            })
            continue
        
        try:
            zpl_content = create_zpl_template(
                batch_code=lot.batch_code,
                product_name=lot.product_name,
                production_date=lot.production_date,
                expiry_date=lot.expiry_date
            )
            
            results.append({
                'batch_code': batch_code,
                'zpl_content': zpl_content,
                'lot_info': lot.to_dict()
            })
            
        except Exception as e:
            results.append({
                'batch_code': batch_code,
                'error': f'Failed to generate label: {str(e)}'
            })
    
    return jsonify({
        'results': results,
        'total': len(batch_codes),
        'successful': len([r for r in results if 'error' not in r])
    })

@label_bp.route('/health', methods=['GET'])
def label_health():
    return {'status': 'ok', 'service': 'label'}

