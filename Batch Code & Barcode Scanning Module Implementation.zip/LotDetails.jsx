import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Package, Calendar, AlertTriangle, ExternalLink } from 'lucide-react'

const LotDetails = ({ batchCode }) => {
  const [lotData, setLotData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const fetchLotDetails = async () => {
      if (!batchCode) return

      try {
        setLoading(true)
        setError(null)

        const response = await fetch(`http://localhost:5000/api/batch/lots/${batchCode}`)
        
        if (response.ok) {
          const data = await response.json()
          setLotData(data)
        } else if (response.status === 404) {
          setError('Lot not found')
        } else {
          throw new Error('Failed to fetch lot details')
        }
      } catch (err) {
        console.error('Error fetching lot details:', err)
        setError('Unable to fetch lot details')
      } finally {
        setLoading(false)
      }
    }

    fetchLotDetails()
  }, [batchCode])

  if (loading) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="animate-pulse space-y-3">
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            <div className="h-4 bg-gray-200 rounded w-2/3"></div>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (error) {
    return (
      <Card className="border-red-200 bg-red-50">
        <CardContent className="pt-6">
          <div className="flex items-center space-x-2 text-red-600">
            <AlertTriangle className="h-5 w-5" />
            <span>{error}</span>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (!lotData) {
    return null
  }

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A'
    return new Date(dateString).toLocaleDateString()
  }

  const getStatusColor = (status) => {
    switch (status?.toLowerCase()) {
      case 'active':
        return 'bg-green-100 text-green-800'
      case 'recalled':
        return 'bg-red-100 text-red-800'
      case 'expired':
        return 'bg-yellow-100 text-yellow-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  const isExpiringSoon = () => {
    if (!lotData.expiry_date) return false
    const expiryDate = new Date(lotData.expiry_date)
    const today = new Date()
    const daysUntilExpiry = Math.ceil((expiryDate - today) / (1000 * 60 * 60 * 24))
    return daysUntilExpiry <= 30 && daysUntilExpiry > 0
  }

  const isExpired = () => {
    if (!lotData.expiry_date) return false
    const expiryDate = new Date(lotData.expiry_date)
    const today = new Date()
    return expiryDate < today
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Package className="h-5 w-5" />
            <span>Lot Details</span>
          </div>
          <Badge className={getStatusColor(lotData.status)}>
            {lotData.status}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Product Information */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="text-sm font-medium text-gray-500">Product Name</label>
            <p className="text-lg font-semibold">{lotData.product_name}</p>
          </div>
          <div>
            <label className="text-sm font-medium text-gray-500">Quantity</label>
            <p className="text-lg font-semibold">{lotData.quantity.toLocaleString()} units</p>
          </div>
        </div>

        {/* Dates */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="text-sm font-medium text-gray-500 flex items-center space-x-1">
              <Calendar className="h-4 w-4" />
              <span>Production Date</span>
            </label>
            <p className="text-sm">{formatDate(lotData.production_date)}</p>
          </div>
          <div>
            <label className="text-sm font-medium text-gray-500 flex items-center space-x-1">
              <Calendar className="h-4 w-4" />
              <span>Expiry Date</span>
            </label>
            <div className="flex items-center space-x-2">
              <p className="text-sm">{formatDate(lotData.expiry_date)}</p>
              {isExpired() && (
                <Badge variant="destructive" className="text-xs">
                  Expired
                </Badge>
              )}
              {isExpiringSoon() && !isExpired() && (
                <Badge variant="outline" className="text-xs border-yellow-500 text-yellow-700">
                  Expiring Soon
                </Badge>
              )}
            </div>
          </div>
        </div>

        {/* Warnings */}
        {(isExpired() || isExpiringSoon() || lotData.status === 'recalled') && (
          <Card className="border-yellow-200 bg-yellow-50">
            <CardContent className="pt-4">
              <div className="flex items-start space-x-2">
                <AlertTriangle className="h-5 w-5 text-yellow-600 mt-0.5" />
                <div className="space-y-1">
                  {isExpired() && (
                    <p className="text-sm text-yellow-800 font-medium">
                      This lot has expired and should not be used.
                    </p>
                  )}
                  {isExpiringSoon() && !isExpired() && (
                    <p className="text-sm text-yellow-800 font-medium">
                      This lot is expiring soon. Use with caution.
                    </p>
                  )}
                  {lotData.status === 'recalled' && (
                    <p className="text-sm text-red-800 font-medium">
                      This lot has been recalled. Do not use.
                    </p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Additional Information */}
        <div className="pt-4 border-t">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-500">Lot ID: {lotData.id}</span>
            <Button variant="outline" size="sm" className="flex items-center space-x-1">
              <ExternalLink className="h-3 w-3" />
              <span>View Full Details</span>
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default LotDetails

