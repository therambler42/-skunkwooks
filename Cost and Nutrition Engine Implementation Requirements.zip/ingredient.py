from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Ingredient(db.Model):
    __tablename__ = 'ingredients'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    supplier = db.Column(db.String(255), nullable=False)
    pack_size = db.Column(db.Float, nullable=False)  # in grams
    pack_cost = db.Column(db.Float, nullable=False)  # cost per pack
    yield_percentage = db.Column(db.Float, nullable=False, default=100.0)  # usable percentage
    unit = db.Column(db.String(50), nullable=False, default='g')
    
    # Nutrition per 100g
    calories = db.Column(db.Float, default=0)
    protein = db.Column(db.Float, default=0)
    carbs = db.Column(db.Float, default=0)
    fat = db.Column(db.Float, default=0)
    fiber = db.Column(db.Float, default=0)
    sugar = db.Column(db.Float, default=0)
    sodium = db.Column(db.Float, default=0)
    
    # Allergens (boolean flags)
    contains_gluten = db.Column(db.Boolean, default=False)
    contains_dairy = db.Column(db.Boolean, default=False)
    contains_eggs = db.Column(db.Boolean, default=False)
    contains_nuts = db.Column(db.Boolean, default=False)
    contains_soy = db.Column(db.Boolean, default=False)
    contains_fish = db.Column(db.Boolean, default=False)
    contains_shellfish = db.Column(db.Boolean, default=False)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'supplier': self.supplier,
            'pack_size': self.pack_size,
            'pack_cost': self.pack_cost,
            'yield_percentage': self.yield_percentage,
            'unit': self.unit,
            'nutrition': {
                'calories': self.calories,
                'protein': self.protein,
                'carbs': self.carbs,
                'fat': self.fat,
                'fiber': self.fiber,
                'sugar': self.sugar,
                'sodium': self.sodium
            },
            'allergens': {
                'gluten': self.contains_gluten,
                'dairy': self.contains_dairy,
                'eggs': self.contains_eggs,
                'nuts': self.contains_nuts,
                'soy': self.contains_soy,
                'fish': self.contains_fish,
                'shellfish': self.contains_shellfish
            }
        }

class Recipe(db.Model):
    __tablename__ = 'recipes'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text)
    servings = db.Column(db.Integer, nullable=False, default=1)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'servings': self.servings
        }

class RecipeIngredient(db.Model):
    __tablename__ = 'recipe_ingredients'
    
    id = db.Column(db.Integer, primary_key=True)
    recipe_id = db.Column(db.Integer, db.ForeignKey('recipes.id'), nullable=False)
    ingredient_id = db.Column(db.Integer, db.ForeignKey('ingredients.id'), nullable=False)
    quantity = db.Column(db.Float, nullable=False)  # in grams
    
    recipe = db.relationship('Recipe', backref='recipe_ingredients')
    ingredient = db.relationship('Ingredient', backref='recipe_ingredients')
    
    def to_dict(self):
        return {
            'id': self.id,
            'recipe_id': self.recipe_id,
            'ingredient_id': self.ingredient_id,
            'quantity': self.quantity,
            'ingredient': self.ingredient.to_dict() if self.ingredient else None
        }

class Menu(db.Model):
    __tablename__ = 'menus'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description
        }

class MenuRecipe(db.Model):
    __tablename__ = 'menu_recipes'
    
    id = db.Column(db.Integer, primary_key=True)
    menu_id = db.Column(db.Integer, db.ForeignKey('menus.id'), nullable=False)
    recipe_id = db.Column(db.Integer, db.ForeignKey('recipes.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False, default=1)  # number of servings
    
    menu = db.relationship('Menu', backref='menu_recipes')
    recipe = db.relationship('Recipe', backref='menu_recipes')
    
    def to_dict(self):
        return {
            'id': self.id,
            'menu_id': self.menu_id,
            'recipe_id': self.recipe_id,
            'quantity': self.quantity,
            'recipe': self.recipe.to_dict() if self.recipe else None
        }

