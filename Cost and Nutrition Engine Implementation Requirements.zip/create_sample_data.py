import sys
import os

# Add the src directory to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.models.ingredient import db, Ingredient, Recipe, RecipeIngredient
from src.main import app

def create_sample_data():
    """Create sample ingredients and recipes for testing."""
    
    with app.app_context():
        # Clear existing data
        db.drop_all()
        db.create_all()
        
        # Create sample ingredients
        ingredients = [
            Ingredient(
                id=1,
                name='All-Purpose Flour',
                supplier='Premium Foods',
                pack_size=1000.0,
                pack_cost=2.50,
                yield_percentage=95.0,
                unit='g',
                calories=364.0,
                protein=10.3,
                carbs=76.3,
                fat=1.0,
                fiber=2.7,
                sugar=0.3,
                sodium=2.0,
                contains_gluten=True
            ),
            Ingredient(
                id=2,
                name='Whole Milk',
                supplier='Fresh Dairy Co',
                pack_size=1000.0,
                pack_cost=3.20,
                yield_percentage=100.0,
                unit='ml',
                calories=61.0,
                protein=3.2,
                carbs=4.8,
                fat=3.3,
                fiber=0.0,
                sugar=4.8,
                sodium=44.0,
                contains_dairy=True
            ),
            Ingredient(
                id=3,
                name='Large Eggs',
                supplier='Farm Fresh',
                pack_size=600.0,
                pack_cost=4.80,
                yield_percentage=88.0,
                unit='g',
                calories=155.0,
                protein=13.0,
                carbs=1.1,
                fat=11.0,
                fiber=0.0,
                sugar=1.1,
                sodium=124.0,
                contains_eggs=True
            ),
            Ingredient(
                id=4,
                name='Unsalted Butter',
                supplier='Premium Dairy',
                pack_size=454.0,
                pack_cost=5.99,
                yield_percentage=100.0,
                unit='g',
                calories=717.0,
                protein=0.9,
                carbs=0.1,
                fat=81.1,
                fiber=0.0,
                sugar=0.1,
                sodium=11.0,
                contains_dairy=True
            ),
            Ingredient(
                id=5,
                name='Granulated Sugar',
                supplier='Sweet Supply',
                pack_size=2000.0,
                pack_cost=3.99,
                yield_percentage=100.0,
                unit='g',
                calories=387.0,
                protein=0.0,
                carbs=100.0,
                fat=0.0,
                fiber=0.0,
                sugar=100.0,
                sodium=0.0
            ),
            Ingredient(
                id=6,
                name='Baking Powder',
                supplier='Baker\'s Choice',
                pack_size=200.0,
                pack_cost=2.99,
                yield_percentage=100.0,
                unit='g',
                calories=53.0,
                protein=0.0,
                carbs=27.7,
                fat=0.0,
                fiber=0.0,
                sugar=0.0,
                sodium=10600.0
            )
        ]
        
        for ingredient in ingredients:
            db.session.add(ingredient)
        
        # Create sample recipes
        recipes = [
            Recipe(
                id=1,
                name='Basic Pancakes',
                description='Fluffy homemade pancakes perfect for breakfast',
                servings=4
            ),
            Recipe(
                id=2,
                name='Chocolate Chip Cookies',
                description='Classic chocolate chip cookies',
                servings=24
            )
        ]
        
        for recipe in recipes:
            db.session.add(recipe)
        
        # Create recipe ingredients for Basic Pancakes
        pancake_ingredients = [
            RecipeIngredient(recipe_id=1, ingredient_id=1, quantity=200.0),  # 200g flour
            RecipeIngredient(recipe_id=1, ingredient_id=2, quantity=250.0),  # 250ml milk
            RecipeIngredient(recipe_id=1, ingredient_id=3, quantity=100.0),  # 100g eggs
            RecipeIngredient(recipe_id=1, ingredient_id=4, quantity=30.0),   # 30g butter
            RecipeIngredient(recipe_id=1, ingredient_id=5, quantity=25.0),   # 25g sugar
            RecipeIngredient(recipe_id=1, ingredient_id=6, quantity=8.0)     # 8g baking powder
        ]
        
        # Create recipe ingredients for Chocolate Chip Cookies
        cookie_ingredients = [
            RecipeIngredient(recipe_id=2, ingredient_id=1, quantity=300.0),  # 300g flour
            RecipeIngredient(recipe_id=2, ingredient_id=4, quantity=200.0),  # 200g butter
            RecipeIngredient(recipe_id=2, ingredient_id=5, quantity=150.0),  # 150g sugar
            RecipeIngredient(recipe_id=2, ingredient_id=3, quantity=100.0)   # 100g eggs
        ]
        
        for recipe_ingredient in pancake_ingredients + cookie_ingredients:
            db.session.add(recipe_ingredient)
        
        # Commit all changes
        db.session.commit()
        
        print("Sample data created successfully!")
        print(f"Created {len(ingredients)} ingredients")
        print(f"Created {len(recipes)} recipes")
        print(f"Created {len(pancake_ingredients + cookie_ingredients)} recipe-ingredient relationships")

if __name__ == '__main__':
    create_sample_data()

