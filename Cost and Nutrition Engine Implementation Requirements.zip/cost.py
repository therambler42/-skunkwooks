from flask import Blueprint, request, jsonify
from src.services.cost_service import CostCalculator
from src.models.ingredient import Ingredient, Recipe, Menu

cost_bp = Blueprint('cost', __name__)
cost_calculator = CostCalculator()

@cost_bp.route('/ingredient/<int:ingredient_id>', methods=['GET'])
def get_ingredient_cost(ingredient_id):
    """Get cost per gram for a specific ingredient."""
    try:
        ingredient = Ingredient.query.get(ingredient_id)
        if not ingredient:
            return jsonify({'error': 'Ingredient not found'}), 404
        
        cost_per_gram = cost_calculator.calculate_ingredient_cost_per_gram(ingredient)
        
        return jsonify({
            'ingredient_id': ingredient_id,
            'ingredient_name': ingredient.name,
            'cost_per_gram': float(cost_per_gram),
            'pack_size': ingredient.pack_size,
            'pack_cost': ingredient.pack_cost,
            'yield_percentage': ingredient.yield_percentage,
            'supplier': ingredient.supplier
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@cost_bp.route('/ingredient/<int:ingredient_id>/quantity', methods=['POST'])
def calculate_ingredient_quantity_cost(ingredient_id):
    """Calculate cost for a specific quantity of an ingredient."""
    try:
        data = request.get_json()
        quantity = data.get('quantity_grams')
        
        if quantity is None:
            return jsonify({'error': 'quantity_grams is required'}), 400
        
        ingredient = Ingredient.query.get(ingredient_id)
        if not ingredient:
            return jsonify({'error': 'Ingredient not found'}), 404
        
        total_cost = cost_calculator.calculate_ingredient_cost_for_quantity(ingredient, quantity)
        cost_per_gram = cost_calculator.calculate_ingredient_cost_per_gram(ingredient)
        
        return jsonify({
            'ingredient_id': ingredient_id,
            'ingredient_name': ingredient.name,
            'quantity_grams': quantity,
            'cost_per_gram': float(cost_per_gram),
            'total_cost': float(total_cost)
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@cost_bp.route('/recipe/<int:recipe_id>', methods=['GET'])
def get_recipe_cost(recipe_id):
    """Get detailed cost breakdown for a recipe."""
    try:
        cost_data = cost_calculator.calculate_recipe_cost(recipe_id)
        return jsonify(cost_data)
    except ValueError as e:
        return jsonify({'error': str(e)}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@cost_bp.route('/recipe/<int:recipe_id>/suppliers', methods=['GET'])
def get_recipe_cost_by_supplier(recipe_id):
    """Get recipe cost breakdown grouped by supplier."""
    try:
        cost_data = cost_calculator.get_cost_breakdown_by_supplier(recipe_id)
        return jsonify(cost_data)
    except ValueError as e:
        return jsonify({'error': str(e)}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@cost_bp.route('/menu/<int:menu_id>', methods=['GET'])
def get_menu_cost(menu_id):
    """Get detailed cost breakdown for a menu."""
    try:
        cost_data = cost_calculator.calculate_menu_cost(menu_id)
        return jsonify(cost_data)
    except ValueError as e:
        return jsonify({'error': str(e)}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@cost_bp.route('/batch/recipes', methods=['POST'])
def get_batch_recipe_costs():
    """Get cost data for multiple recipes at once."""
    try:
        data = request.get_json()
        recipe_ids = data.get('recipe_ids', [])
        
        if not recipe_ids:
            return jsonify({'error': 'recipe_ids array is required'}), 400
        
        results = []
        for recipe_id in recipe_ids:
            try:
                cost_data = cost_calculator.calculate_recipe_cost(recipe_id)
                results.append(cost_data)
            except ValueError:
                results.append({
                    'recipe_id': recipe_id,
                    'error': 'Recipe not found'
                })
        
        return jsonify({'results': results})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

