import pytest
import sys
import os
from decimal import Decimal

# Add the src directory to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from src.services.cost_service import CostCalculator
from src.models.ingredient import Ingredient

class TestCostCalculator:
    
    def setup_method(self):
        """Set up test fixtures before each test method."""
        self.calculator = CostCalculator()
        
        # Create mock ingredient for testing
        self.test_ingredient = Ingredient(
            id=1,
            name="Test Flour",
            supplier="Test Supplier",
            pack_size=1000.0,  # 1kg
            pack_cost=5.00,    # $5.00
            yield_percentage=95.0,  # 95% yield
            unit="g"
        )
    
    def test_calculate_ingredient_cost_per_gram_basic(self):
        """Test basic cost per gram calculation."""
        cost_per_gram = self.calculator.calculate_ingredient_cost_per_gram(self.test_ingredient)
        
        # Expected: (5.00 / 1000) / (95/100) = 0.005 / 0.95 = 0.005263...
        expected = Decimal('0.005')  # Base cost per gram
        yield_factor = Decimal('95') / Decimal('100')
        expected_adjusted = expected / yield_factor
        
        # Allow for small rounding differences
        assert abs(cost_per_gram - expected_adjusted) < Decimal('0.001')
    
    def test_calculate_ingredient_cost_per_gram_100_percent_yield(self):
        """Test cost calculation with 100% yield."""
        ingredient = Ingredient(
            id=2,
            name="Perfect Ingredient",
            supplier="Perfect Supplier",
            pack_size=500.0,
            pack_cost=10.00,
            yield_percentage=100.0,
            unit="g"
        )
        
        cost_per_gram = self.calculator.calculate_ingredient_cost_per_gram(ingredient)
        expected = Decimal('0.020')  # 10.00 / 500 = 0.02
        
        assert cost_per_gram == expected
    
    def test_calculate_ingredient_cost_for_quantity(self):
        """Test cost calculation for specific quantity."""
        quantity = 250.0  # 250g
        total_cost = self.calculator.calculate_ingredient_cost_for_quantity(
            self.test_ingredient, quantity
        )
        
        # Calculate expected cost step by step
        cost_per_gram = self.calculator.calculate_ingredient_cost_per_gram(self.test_ingredient)
        expected = cost_per_gram * Decimal(str(quantity))
        
        # Allow for small rounding differences
        assert abs(total_cost - expected) < Decimal('0.01')
    
    def test_precision_requirements(self):
        """Test that calculations meet ±0.1% accuracy requirements."""
        # Test with various quantities
        test_quantities = [1.0, 10.0, 100.0, 500.0, 1000.0]
        
        for quantity in test_quantities:
            cost = self.calculator.calculate_ingredient_cost_for_quantity(
                self.test_ingredient, quantity
            )
            
            # Verify precision is maintained (3 decimal places)
            assert cost.as_tuple().exponent >= -3
            
            # Verify cost is positive
            assert cost > 0
    
    def test_edge_cases(self):
        """Test edge cases and boundary conditions."""
        # Very small quantity
        small_cost = self.calculator.calculate_ingredient_cost_for_quantity(
            self.test_ingredient, 0.1
        )
        assert small_cost > 0
        
        # Very large quantity
        large_cost = self.calculator.calculate_ingredient_cost_for_quantity(
            self.test_ingredient, 10000.0
        )
        assert large_cost > 0
        
        # Zero quantity should return zero
        zero_cost = self.calculator.calculate_ingredient_cost_for_quantity(
            self.test_ingredient, 0.0
        )
        assert zero_cost == 0
    
    def test_yield_percentage_impact(self):
        """Test that yield percentage correctly impacts cost."""
        # Create ingredients with different yields
        high_yield = Ingredient(
            id=3, name="High Yield", supplier="Test", pack_size=1000.0,
            pack_cost=5.00, yield_percentage=90.0, unit="g"
        )
        
        low_yield = Ingredient(
            id=4, name="Low Yield", supplier="Test", pack_size=1000.0,
            pack_cost=5.00, yield_percentage=50.0, unit="g"
        )
        
        high_yield_cost = self.calculator.calculate_ingredient_cost_per_gram(high_yield)
        low_yield_cost = self.calculator.calculate_ingredient_cost_per_gram(low_yield)
        
        # Lower yield should result in higher cost per gram
        assert low_yield_cost > high_yield_cost
        
        # Verify the relationship: cost is inversely proportional to yield
        # For 90% vs 50% yield, the ratio should be 50/90 = 0.556 (approximately)
        expected_ratio = Decimal('50') / Decimal('90')  # 0.556
        actual_ratio = high_yield_cost / low_yield_cost
        
        # Allow for larger tolerance due to rounding in Decimal calculations
        assert abs(actual_ratio - expected_ratio) < Decimal('0.1')

if __name__ == '__main__':
    pytest.main([__file__])

