import React, { useState } from 'react';
import { useQuery } from '@apollo/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, Calculator, Utensils } from 'lucide-react';
import NutritionFactsPanel from './NutritionFactsPanel';
import CostBreakdownPanel from './CostBreakdownPanel';
import { GET_FDA_NUTRITION_LABEL, GET_EU_NUTRITION_LABEL, GET_RECIPE_NUTRITION, GET_RECIPE_COST } from '@/lib/queries';

const RecipeAnalyzer = () => {
  const [recipeId, setRecipeId] = useState('');
  const [nutritionFormat, setNutritionFormat] = useState('FDA');
  const [activeTab, setActiveTab] = useState('nutrition');

  // Nutrition queries
  const { data: fdaData, loading: fdaLoading, error: fdaError } = useQuery(GET_FDA_NUTRITION_LABEL, {
    variables: { recipeId: parseInt(recipeId) },
    skip: !recipeId || nutritionFormat !== 'FDA'
  });

  const { data: euData, loading: euLoading, error: euError } = useQuery(GET_EU_NUTRITION_LABEL, {
    variables: { recipeId: parseInt(recipeId) },
    skip: !recipeId || nutritionFormat !== 'EU'
  });

  const { data: basicData, loading: basicLoading, error: basicError } = useQuery(GET_RECIPE_NUTRITION, {
    variables: { recipeId: parseInt(recipeId) },
    skip: !recipeId || nutritionFormat !== 'Basic'
  });

  // Cost query
  const { data: costData, loading: costLoading, error: costError } = useQuery(GET_RECIPE_COST, {
    variables: { recipeId: parseInt(recipeId) },
    skip: !recipeId || activeTab !== 'cost'
  });

  const handleAnalyze = () => {
    // Trigger refetch if needed
    if (recipeId) {
      // The queries will automatically run when recipeId changes
    }
  };

  const getNutritionData = () => {
    switch (nutritionFormat) {
      case 'FDA':
        return fdaData?.fdaNutritionLabel;
      case 'EU':
        return euData?.euNutritionLabel;
      case 'Basic':
        return basicData?.recipeNutrition;
      default:
        return null;
    }
  };

  const isNutritionLoading = () => {
    switch (nutritionFormat) {
      case 'FDA':
        return fdaLoading;
      case 'EU':
        return euLoading;
      case 'Basic':
        return basicLoading;
      default:
        return false;
    }
  };

  const getNutritionError = () => {
    switch (nutritionFormat) {
      case 'FDA':
        return fdaError;
      case 'EU':
        return euError;
      case 'Basic':
        return basicError;
      default:
        return null;
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="h-6 w-6" />
            Recipe Cost & Nutrition Analyzer
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="recipeId">Recipe ID</Label>
              <Input
                id="recipeId"
                type="number"
                placeholder="Enter recipe ID"
                value={recipeId}
                onChange={(e) => setRecipeId(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="format">Nutrition Format</Label>
              <Select value={nutritionFormat} onValueChange={setNutritionFormat}>
                <SelectTrigger>
                  <SelectValue placeholder="Select format" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="FDA">FDA (US)</SelectItem>
                  <SelectItem value="EU">EU</SelectItem>
                  <SelectItem value="Basic">Basic</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button onClick={handleAnalyze} disabled={!recipeId} className="w-full">
                <Utensils className="h-4 w-4 mr-2" />
                Analyze Recipe
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {recipeId && (
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="nutrition">Nutrition Analysis</TabsTrigger>
            <TabsTrigger value="cost">Cost Analysis</TabsTrigger>
          </TabsList>

          <TabsContent value="nutrition" className="space-y-4">
            {isNutritionLoading() && (
              <Card>
                <CardContent className="flex items-center justify-center p-8">
                  <Loader2 className="h-8 w-8 animate-spin mr-2" />
                  <span>Loading nutrition data...</span>
                </CardContent>
              </Card>
            )}

            {getNutritionError() && (
              <Alert variant="destructive">
                <AlertDescription>
                  Error loading nutrition data: {getNutritionError().message}
                </AlertDescription>
              </Alert>
            )}

            {!isNutritionLoading() && !getNutritionError() && getNutritionData() && (
              <div className="flex justify-center">
                <NutritionFactsPanel 
                  nutritionData={getNutritionData()} 
                  format={nutritionFormat}
                />
              </div>
            )}

            {!isNutritionLoading() && !getNutritionError() && !getNutritionData() && recipeId && (
              <Alert>
                <AlertDescription>
                  No nutrition data found for recipe ID {recipeId}. Please check if the recipe exists.
                </AlertDescription>
              </Alert>
            )}
          </TabsContent>

          <TabsContent value="cost" className="space-y-4">
            {costLoading && (
              <Card>
                <CardContent className="flex items-center justify-center p-8">
                  <Loader2 className="h-8 w-8 animate-spin mr-2" />
                  <span>Loading cost data...</span>
                </CardContent>
              </Card>
            )}

            {costError && (
              <Alert variant="destructive">
                <AlertDescription>
                  Error loading cost data: {costError.message}
                </AlertDescription>
              </Alert>
            )}

            {!costLoading && !costError && costData?.recipeCost && (
              <CostBreakdownPanel costData={costData.recipeCost} />
            )}

            {!costLoading && !costError && !costData?.recipeCost && recipeId && (
              <Alert>
                <AlertDescription>
                  No cost data found for recipe ID {recipeId}. Please check if the recipe exists.
                </AlertDescription>
              </Alert>
            )}
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
};

export default RecipeAnalyzer;

