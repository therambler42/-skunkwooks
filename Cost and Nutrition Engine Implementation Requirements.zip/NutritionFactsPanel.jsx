import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const NutritionFactsPanel = ({ nutritionData, format = 'FDA' }) => {
  if (!nutritionData) {
    return (
      <Card className="w-full max-w-md">
        <CardContent className="p-6">
          <p className="text-muted-foreground">No nutrition data available</p>
        </CardContent>
      </Card>
    );
  }

  if (format === 'FDA') {
    return <FDANutritionFacts data={nutritionData} />;
  } else if (format === 'EU') {
    return <EUNutritionFacts data={nutritionData} />;
  } else {
    return <BasicNutritionFacts data={nutritionData} />;
  }
};

const FDANutritionFacts = ({ data }) => {
  const { nutritionFacts, dailyValues, servingSize, servingsPerContainer, allergenStatement } = data;

  return (
    <Card className="w-full max-w-md bg-white border-2 border-black">
      <CardHeader className="pb-2">
        <CardTitle className="text-2xl font-bold text-center border-b-4 border-black pb-2">
          Nutrition Facts
        </CardTitle>
        <div className="text-sm">
          <div className="flex justify-between border-b border-black py-1">
            <span>Serving size</span>
            <span className="font-semibold">{servingSize}</span>
          </div>
          <div className="text-xs text-gray-600">
            Servings per container {servingsPerContainer}
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-4 space-y-1">
        <div className="border-b-8 border-black pb-2">
          <div className="flex justify-between items-end">
            <span className="text-lg font-bold">Calories</span>
            <span className="text-3xl font-bold">{Math.round(nutritionFacts.calories)}</span>
          </div>
        </div>
        
        <div className="text-xs text-right font-semibold border-b border-gray-400 pb-1">
          % Daily Value*
        </div>
        
        <NutrientRow 
          label="Total Fat" 
          amount={`${nutritionFacts.totalFat?.toFixed(1)}g`}
          dailyValue={dailyValues.fat}
          bold
        />
        
        <NutrientRow 
          label="Total Carbohydrate" 
          amount={`${nutritionFacts.totalCarbohydrate?.toFixed(1)}g`}
          dailyValue={dailyValues.carbs}
          bold
        />
        
        <NutrientRow 
          label="Dietary Fiber" 
          amount={`${nutritionFacts.dietaryFiber?.toFixed(1)}g`}
          dailyValue={dailyValues.fiber}
          indent
        />
        
        <NutrientRow 
          label="Total Sugars" 
          amount={`${nutritionFacts.totalSugars?.toFixed(1)}g`}
          dailyValue={dailyValues.sugar}
          indent
        />
        
        <NutrientRow 
          label="Protein" 
          amount={`${nutritionFacts.protein?.toFixed(1)}g`}
          dailyValue={dailyValues.protein}
          bold
        />
        
        <NutrientRow 
          label="Sodium" 
          amount={`${nutritionFacts.sodium?.toFixed(0)}mg`}
          dailyValue={dailyValues.sodium}
          bold
        />
        
        <div className="border-t-4 border-black pt-2 text-xs">
          <p>* The % Daily Value (DV) tells you how much a nutrient in a serving of food contributes to a daily diet. 2,000 calories a day is used for general nutrition advice.</p>
        </div>
        
        {allergenStatement && (
          <div className="mt-4 p-2 bg-yellow-50 border border-yellow-200 rounded">
            <p className="text-xs font-semibold text-yellow-800">{allergenStatement}</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

const EUNutritionFacts = ({ data }) => {
  const { nutritionPer100g, nutritionPerServing, referenceIntakes, servingSize, allergenStatement } = data;

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle className="text-xl font-bold">Nutrition Information</CardTitle>
        <p className="text-sm text-muted-foreground">Per 100g and per serving ({servingSize})</p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b">
                <th className="text-left py-2">Nutrient</th>
                <th className="text-right py-2">Per 100g</th>
                <th className="text-right py-2">Per Serving</th>
                <th className="text-right py-2">%RI*</th>
              </tr>
            </thead>
            <tbody className="space-y-1">
              <EUNutrientRow 
                label="Energy"
                per100g={`${Math.round(nutritionPer100g.energyKj)}kJ / ${Math.round(nutritionPer100g.energyKcal)}kcal`}
                perServing={`${Math.round(nutritionPerServing.energyKj)}kJ / ${Math.round(nutritionPerServing.energyKcal)}kcal`}
                ri={referenceIntakes.energy}
              />
              <EUNutrientRow 
                label="Fat"
                per100g={`${nutritionPer100g.fat?.toFixed(1)}g`}
                perServing={`${nutritionPerServing.fat?.toFixed(1)}g`}
                ri={referenceIntakes.fat}
              />
              <EUNutrientRow 
                label="Carbohydrate"
                per100g={`${nutritionPer100g.carbohydrate?.toFixed(1)}g`}
                perServing={`${nutritionPerServing.carbohydrate?.toFixed(1)}g`}
                ri={referenceIntakes.carbs}
              />
              <EUNutrientRow 
                label="- of which sugars"
                per100g={`${nutritionPer100g.sugars?.toFixed(1)}g`}
                perServing={`${nutritionPerServing.sugars?.toFixed(1)}g`}
                ri={referenceIntakes.sugar}
                indent
              />
              <EUNutrientRow 
                label="Fibre"
                per100g={`${nutritionPer100g.fibre?.toFixed(1)}g`}
                perServing={`${nutritionPerServing.fibre?.toFixed(1)}g`}
                ri={null}
              />
              <EUNutrientRow 
                label="Protein"
                per100g={`${nutritionPer100g.protein?.toFixed(1)}g`}
                perServing={`${nutritionPerServing.protein?.toFixed(1)}g`}
                ri={referenceIntakes.protein}
              />
              <EUNutrientRow 
                label="Salt"
                per100g={`${nutritionPer100g.salt?.toFixed(2)}g`}
                perServing={`${nutritionPerServing.salt?.toFixed(2)}g`}
                ri={referenceIntakes.salt}
              />
            </tbody>
          </table>
        </div>
        
        <div className="text-xs text-muted-foreground">
          <p>*Reference intake of an average adult (8400 kJ/2000 kcal)</p>
        </div>
        
        {allergenStatement && (
          <div className="p-2 bg-yellow-50 border border-yellow-200 rounded">
            <p className="text-xs font-semibold text-yellow-800">{allergenStatement}</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

const BasicNutritionFacts = ({ data }) => {
  const { nutritionPerServing, allergens, recipeName } = data;

  const allergenList = Object.entries(allergens || {})
    .filter(([_, present]) => present)
    .map(([allergen, _]) => allergen);

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle className="text-xl font-bold">Nutrition Information</CardTitle>
        <p className="text-sm text-muted-foreground">{recipeName} - Per Serving</p>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center p-3 bg-blue-50 rounded">
            <div className="text-2xl font-bold text-blue-600">{Math.round(nutritionPerServing.calories)}</div>
            <div className="text-sm text-blue-600">Calories</div>
          </div>
          <div className="text-center p-3 bg-green-50 rounded">
            <div className="text-2xl font-bold text-green-600">{nutritionPerServing.protein?.toFixed(1)}g</div>
            <div className="text-sm text-green-600">Protein</div>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center p-3 bg-orange-50 rounded">
            <div className="text-2xl font-bold text-orange-600">{nutritionPerServing.carbs?.toFixed(1)}g</div>
            <div className="text-sm text-orange-600">Carbs</div>
          </div>
          <div className="text-center p-3 bg-purple-50 rounded">
            <div className="text-2xl font-bold text-purple-600">{nutritionPerServing.fat?.toFixed(1)}g</div>
            <div className="text-sm text-purple-600">Fat</div>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center p-3 bg-gray-50 rounded">
            <div className="text-lg font-bold text-gray-600">{nutritionPerServing.fiber?.toFixed(1)}g</div>
            <div className="text-sm text-gray-600">Fiber</div>
          </div>
          <div className="text-center p-3 bg-red-50 rounded">
            <div className="text-lg font-bold text-red-600">{nutritionPerServing.sodium?.toFixed(0)}mg</div>
            <div className="text-sm text-red-600">Sodium</div>
          </div>
        </div>
        
        {allergenList.length > 0 && (
          <div className="mt-4">
            <h4 className="text-sm font-semibold mb-2">Allergens:</h4>
            <div className="flex flex-wrap gap-1">
              {allergenList.map((allergen) => (
                <Badge key={allergen} variant="destructive" className="text-xs">
                  {allergen.charAt(0).toUpperCase() + allergen.slice(1)}
                </Badge>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

const NutrientRow = ({ label, amount, dailyValue, bold = false, indent = false }) => (
  <div className={`flex justify-between border-b border-gray-300 py-1 ${bold ? 'font-bold' : ''} ${indent ? 'pl-4' : ''}`}>
    <span>{label}</span>
    <div className="flex items-center gap-2">
      <span>{amount}</span>
      {dailyValue !== null && dailyValue !== undefined && (
        <span className="font-bold w-8 text-right">{Math.round(dailyValue)}%</span>
      )}
    </div>
  </div>
);

const EUNutrientRow = ({ label, per100g, perServing, ri, indent = false }) => (
  <tr className="border-b border-gray-200">
    <td className={`py-2 ${indent ? 'pl-4' : ''}`}>{label}</td>
    <td className="text-right py-2">{per100g}</td>
    <td className="text-right py-2">{perServing}</td>
    <td className="text-right py-2">{ri !== null && ri !== undefined ? `${Math.round(ri)}%` : '-'}</td>
  </tr>
);

export default NutritionFactsPanel;

