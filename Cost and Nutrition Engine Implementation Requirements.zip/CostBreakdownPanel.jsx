import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { DollarSign, Package, TrendingUp } from 'lucide-react';

const CostBreakdownPanel = ({ costData }) => {
  if (!costData) {
    return (
      <Card className="w-full">
        <CardContent className="p-6">
          <p className="text-muted-foreground">No cost data available</p>
        </CardContent>
      </Card>
    );
  }

  const { recipeName, servings, totalCost, costPerServing, ingredientCosts } = costData;

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <DollarSign className="h-5 w-5" />
          Cost Breakdown - {recipeName}
        </CardTitle>
        <div className="flex gap-4 text-sm text-muted-foreground">
          <span>Servings: {servings}</span>
          <span>Total Cost: ${totalCost?.toFixed(2)}</span>
          <span>Cost per Serving: ${costPerServing?.toFixed(2)}</span>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <div className="text-3xl font-bold text-green-600">${totalCost?.toFixed(2)}</div>
            <div className="text-sm text-green-600">Total Recipe Cost</div>
          </div>
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <div className="text-3xl font-bold text-blue-600">${costPerServing?.toFixed(2)}</div>
            <div className="text-sm text-blue-600">Cost per Serving</div>
          </div>
        </div>

        <div>
          <h4 className="font-semibold mb-3 flex items-center gap-2">
            <Package className="h-4 w-4" />
            Ingredient Breakdown
          </h4>
          <div className="space-y-2">
            {ingredientCosts?.map((ingredient, index) => (
              <IngredientCostRow key={index} ingredient={ingredient} />
            ))}
          </div>
        </div>

        <div className="pt-4 border-t">
          <h4 className="font-semibold mb-2 flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            Cost Analysis
          </h4>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-muted-foreground">Most Expensive Ingredient:</span>
              <div className="font-semibold">
                {ingredientCosts?.reduce((max, ingredient) => 
                  ingredient.totalCost > max.totalCost ? ingredient : max
                )?.ingredientName} (${ingredientCosts?.reduce((max, ingredient) => 
                  ingredient.totalCost > max.totalCost ? ingredient : max
                )?.totalCost?.toFixed(2)})
              </div>
            </div>
            <div>
              <span className="text-muted-foreground">Average Cost per Gram:</span>
              <div className="font-semibold">
                ${(ingredientCosts?.reduce((sum, ingredient) => sum + ingredient.costPerGram, 0) / ingredientCosts?.length)?.toFixed(4)}
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

const IngredientCostRow = ({ ingredient }) => {
  const costPercentage = ingredient.totalCost; // This would need the total to calculate percentage
  
  return (
    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
      <div className="flex-1">
        <div className="font-medium">{ingredient.ingredientName}</div>
        <div className="text-sm text-muted-foreground">
          {ingredient.quantityGrams}g from {ingredient.supplier}
        </div>
        <div className="text-xs text-muted-foreground">
          ${ingredient.costPerGram?.toFixed(4)}/g • {ingredient.yieldPercentage}% yield
        </div>
      </div>
      <div className="text-right">
        <div className="font-bold text-lg">${ingredient.totalCost?.toFixed(2)}</div>
        <Badge variant="secondary" className="text-xs">
          {((ingredient.totalCost / ingredient.quantityGrams) * 100).toFixed(1)}¢/g
        </Badge>
      </div>
    </div>
  );
};

export default CostBreakdownPanel;

