from decimal import Decimal, ROUND_HALF_UP
from typing import Dict, List, Tuple
from src.models.ingredient import Ingredient, Recipe, RecipeIngredient, Menu, MenuRecipe

class CostCalculator:
    """
    Cost calculation service that handles ingredient costs, recipe costs, and menu costs
    with high precision to meet ±0.1% accuracy requirements.
    """
    
    def __init__(self):
        # Use higher precision for intermediate calculations
        self.precision = Decimal('0.000001')  # 6 decimal places for high accuracy
        self.output_precision = Decimal('0.001')  # 3 decimal places for output
    
    def calculate_ingredient_cost_per_gram(self, ingredient: Ingredient) -> Decimal:
        """
        Calculate cost per gram for an ingredient considering yield percentage.
        
        Formula: (pack_cost / pack_size) / (yield_percentage / 100)
        """
        pack_cost = Decimal(str(ingredient.pack_cost))
        pack_size = Decimal(str(ingredient.pack_size))
        yield_percentage = Decimal(str(ingredient.yield_percentage))
        
        # Cost per gram before yield adjustment
        cost_per_gram_raw = pack_cost / pack_size
        
        # Adjust for yield percentage (if yield is 80%, we need more raw ingredient)
        cost_per_gram_adjusted = cost_per_gram_raw / (yield_percentage / Decimal('100'))
        
        return cost_per_gram_adjusted.quantize(self.precision, rounding=ROUND_HALF_UP)
    
    def calculate_ingredient_cost_for_quantity(self, ingredient: Ingredient, quantity_grams: float) -> Decimal:
        """
        Calculate total cost for a specific quantity of an ingredient.
        """
        cost_per_gram = self.calculate_ingredient_cost_per_gram(ingredient)
        quantity = Decimal(str(quantity_grams))
        
        total_cost = cost_per_gram * quantity
        return total_cost.quantize(self.output_precision, rounding=ROUND_HALF_UP)
    
    def calculate_recipe_cost(self, recipe_id: int) -> Dict:
        """
        Calculate total cost for a recipe including all ingredients.
        Returns detailed breakdown and total cost.
        """
        recipe_ingredients = RecipeIngredient.query.filter_by(recipe_id=recipe_id).all()
        recipe = Recipe.query.get(recipe_id)
        
        if not recipe:
            raise ValueError(f"Recipe with id {recipe_id} not found")
        
        ingredient_costs = []
        total_cost = Decimal('0')
        
        for recipe_ingredient in recipe_ingredients:
            ingredient = recipe_ingredient.ingredient
            quantity = recipe_ingredient.quantity
            
            ingredient_cost = self.calculate_ingredient_cost_for_quantity(ingredient, quantity)
            cost_per_gram = self.calculate_ingredient_cost_per_gram(ingredient)
            
            ingredient_detail = {
                'ingredient_id': ingredient.id,
                'ingredient_name': ingredient.name,
                'quantity_grams': quantity,
                'cost_per_gram': float(cost_per_gram),
                'total_cost': float(ingredient_cost),
                'supplier': ingredient.supplier,
                'yield_percentage': ingredient.yield_percentage
            }
            
            ingredient_costs.append(ingredient_detail)
            total_cost += ingredient_cost
        
        cost_per_serving = total_cost / Decimal(str(recipe.servings))
        
        return {
            'recipe_id': recipe_id,
            'recipe_name': recipe.name,
            'servings': recipe.servings,
            'ingredient_costs': ingredient_costs,
            'total_cost': float(total_cost.quantize(self.output_precision, rounding=ROUND_HALF_UP)),
            'cost_per_serving': float(cost_per_serving.quantize(self.output_precision, rounding=ROUND_HALF_UP))
        }
    
    def calculate_menu_cost(self, menu_id: int) -> Dict:
        """
        Calculate total cost for a menu including all recipes.
        Returns detailed breakdown and total cost.
        """
        menu_recipes = MenuRecipe.query.filter_by(menu_id=menu_id).all()
        menu = Menu.query.get(menu_id)
        
        if not menu:
            raise ValueError(f"Menu with id {menu_id} not found")
        
        recipe_costs = []
        total_cost = Decimal('0')
        total_servings = 0
        
        for menu_recipe in menu_recipes:
            recipe_cost_data = self.calculate_recipe_cost(menu_recipe.recipe_id)
            quantity = menu_recipe.quantity  # number of servings
            
            recipe_total_cost = Decimal(str(recipe_cost_data['cost_per_serving'])) * Decimal(str(quantity))
            
            recipe_detail = {
                'recipe_id': menu_recipe.recipe_id,
                'recipe_name': recipe_cost_data['recipe_name'],
                'servings_ordered': quantity,
                'cost_per_serving': recipe_cost_data['cost_per_serving'],
                'total_cost': float(recipe_total_cost.quantize(self.precision, rounding=ROUND_HALF_UP)),
                'recipe_details': recipe_cost_data
            }
            
            recipe_costs.append(recipe_detail)
            total_cost += recipe_total_cost
            total_servings += quantity
        
        average_cost_per_serving = total_cost / Decimal(str(total_servings)) if total_servings > 0 else Decimal('0')
        
        return {
            'menu_id': menu_id,
            'menu_name': menu.name,
            'recipe_costs': recipe_costs,
            'total_servings': total_servings,
            'total_cost': float(total_cost.quantize(self.output_precision, rounding=ROUND_HALF_UP)),
            'average_cost_per_serving': float(average_cost_per_serving.quantize(self.output_precision, rounding=ROUND_HALF_UP))
        }
    
    def get_cost_breakdown_by_supplier(self, recipe_id: int) -> Dict:
        """
        Get cost breakdown grouped by supplier for procurement insights.
        """
        recipe_cost_data = self.calculate_recipe_cost(recipe_id)
        supplier_costs = {}
        
        for ingredient_cost in recipe_cost_data['ingredient_costs']:
            supplier = ingredient_cost['supplier']
            cost = ingredient_cost['total_cost']
            
            if supplier not in supplier_costs:
                supplier_costs[supplier] = {
                    'supplier_name': supplier,
                    'total_cost': 0,
                    'ingredients': []
                }
            
            supplier_costs[supplier]['total_cost'] += cost
            supplier_costs[supplier]['ingredients'].append(ingredient_cost)
        
        # Round supplier totals
        for supplier_data in supplier_costs.values():
            supplier_data['total_cost'] = float(
                Decimal(str(supplier_data['total_cost'])).quantize(self.output_precision, rounding=ROUND_HALF_UP)
            )
        
        return {
            'recipe_id': recipe_id,
            'recipe_name': recipe_cost_data['recipe_name'],
            'supplier_breakdown': list(supplier_costs.values()),
            'total_cost': recipe_cost_data['total_cost']
        }

