import { gql } from '@apollo/client';

export const GET_RECIPE_NUTRITION = gql`
  query GetRecipeNutrition($recipeId: Int!) {
    recipeNutrition(recipeId: $recipeId) {
      recipeId
      recipeName
      servings
      totalWeightGrams
      nutritionPerServing {
        calories
        protein
        carbs
        fat
        fiber
        sugar
        sodium
      }
      nutritionPer100g {
        calories
        protein
        carbs
        fat
        fiber
        sugar
        sodium
      }
      allergens {
        gluten
        dairy
        eggs
        nuts
        soy
        fish
        shellfish
      }
    }
  }
`;

export const GET_FDA_NUTRITION_LABEL = gql`
  query GetFDANutritionLabel($recipeId: Int!) {
    fdaNutritionLabel(recipeId: $recipeId) {
      format
      recipeId
      recipeName
      servingSize
      servingsPerContainer
      nutritionFacts {
        calories
        totalFat: fat
        totalCarbohydrate: carbs
        dietaryFiber: fiber
        totalSugars: sugar
        protein
        sodium
      }
      dailyValues {
        calories
        fat
        carbs
        fiber
        sugar
        protein
        sodium
      }
      allergenStatement
      allergens {
        gluten
        dairy
        eggs
        nuts
        soy
        fish
        shellfish
      }
    }
  }
`;

export const GET_EU_NUTRITION_LABEL = gql`
  query GetEUNutritionLabel($recipeId: Int!) {
    euNutritionLabel(recipeId: $recipeId) {
      format
      recipeId
      recipeName
      servingSize
      nutritionPer100g {
        energyKj
        energyKcal
        fat
        carbohydrate
        sugars
        fibre
        protein
        salt
      }
      nutritionPerServing {
        energyKj
        energyKcal
        fat
        carbohydrate
        sugars
        fibre
        protein
        salt
      }
      referenceIntakes {
        energy
        fat
        carbs
        sugar
        protein
        salt
      }
      allergenStatement
      allergens {
        gluten
        dairy
        eggs
        nuts
        soy
        fish
        shellfish
      }
    }
  }
`;

export const GET_RECIPE_COST = gql`
  query GetRecipeCost($recipeId: Int!) {
    recipeCost(recipeId: $recipeId) {
      recipeId
      recipeName
      servings
      totalCost
      costPerServing
      ingredientCosts {
        ingredientId
        ingredientName
        quantityGrams
        costPerGram
        totalCost
        supplier
        yieldPercentage
      }
    }
  }
`;

export const GET_INGREDIENTS = gql`
  query GetIngredients {
    ingredients {
      id
      name
      supplier
      packSize
      packCost
      yieldPercentage
      unit
      costPerGram
      nutrition {
        calories
        protein
        carbs
        fat
        fiber
        sugar
        sodium
      }
      allergens {
        gluten
        dairy
        eggs
        nuts
        soy
        fish
        shellfish
      }
    }
  }
`;

