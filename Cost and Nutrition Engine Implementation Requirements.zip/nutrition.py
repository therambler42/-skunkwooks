from flask import Blueprint, request, jsonify
from src.services.nutrition_service import NutritionCalculator

nutrition_bp = Blueprint('nutrition', __name__)
nutrition_calculator = NutritionCalculator()

@nutrition_bp.route('/recipe/<int:recipe_id>', methods=['GET'])
def get_recipe_nutrition(recipe_id):
    """Get detailed nutrition information for a recipe."""
    try:
        nutrition_data = nutrition_calculator.calculate_recipe_nutrition(recipe_id)
        return jsonify(nutrition_data)
    except ValueError as e:
        return jsonify({'error': str(e)}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@nutrition_bp.route('/recipe/<int:recipe_id>/fda-label', methods=['GET'])
def get_fda_nutrition_label(recipe_id):
    """Get FDA-compliant nutrition facts label for a recipe."""
    try:
        label_data = nutrition_calculator.generate_fda_nutrition_label(recipe_id)
        return jsonify(label_data)
    except ValueError as e:
        return jsonify({'error': str(e)}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@nutrition_bp.route('/recipe/<int:recipe_id>/eu-label', methods=['GET'])
def get_eu_nutrition_label(recipe_id):
    """Get EU-compliant nutrition information for a recipe."""
    try:
        label_data = nutrition_calculator.generate_eu_nutrition_label(recipe_id)
        return jsonify(label_data)
    except ValueError as e:
        return jsonify({'error': str(e)}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@nutrition_bp.route('/allergens/summary', methods=['POST'])
def get_allergen_summary():
    """Get allergen summary for multiple recipes."""
    try:
        data = request.get_json()
        recipe_ids = data.get('recipe_ids', [])
        
        if not recipe_ids:
            return jsonify({'error': 'recipe_ids array is required'}), 400
        
        allergen_data = nutrition_calculator.get_allergen_summary(recipe_ids)
        return jsonify(allergen_data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@nutrition_bp.route('/batch/recipes', methods=['POST'])
def get_batch_nutrition():
    """Get nutrition data for multiple recipes at once."""
    try:
        data = request.get_json()
        recipe_ids = data.get('recipe_ids', [])
        format_type = data.get('format', 'basic')  # basic, fda, eu
        
        if not recipe_ids:
            return jsonify({'error': 'recipe_ids array is required'}), 400
        
        results = []
        for recipe_id in recipe_ids:
            try:
                if format_type == 'fda':
                    nutrition_data = nutrition_calculator.generate_fda_nutrition_label(recipe_id)
                elif format_type == 'eu':
                    nutrition_data = nutrition_calculator.generate_eu_nutrition_label(recipe_id)
                else:
                    nutrition_data = nutrition_calculator.calculate_recipe_nutrition(recipe_id)
                
                results.append(nutrition_data)
            except ValueError:
                results.append({
                    'recipe_id': recipe_id,
                    'error': 'Recipe not found'
                })
        
        return jsonify({'results': results})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@nutrition_bp.route('/compare', methods=['POST'])
def compare_recipes():
    """Compare nutrition information between multiple recipes."""
    try:
        data = request.get_json()
        recipe_ids = data.get('recipe_ids', [])
        
        if len(recipe_ids) < 2:
            return jsonify({'error': 'At least 2 recipe_ids are required for comparison'}), 400
        
        comparisons = []
        for recipe_id in recipe_ids:
            try:
                nutrition_data = nutrition_calculator.calculate_recipe_nutrition(recipe_id)
                comparisons.append({
                    'recipe_id': recipe_id,
                    'recipe_name': nutrition_data['recipe_name'],
                    'nutrition_per_serving': nutrition_data['nutrition_per_serving'],
                    'allergens': nutrition_data['allergens']
                })
            except ValueError:
                comparisons.append({
                    'recipe_id': recipe_id,
                    'error': 'Recipe not found'
                })
        
        # Calculate averages for comparison
        valid_recipes = [r for r in comparisons if 'error' not in r]
        if valid_recipes:
            avg_nutrition = {}
            for nutrient in ['calories', 'protein', 'carbs', 'fat', 'fiber', 'sugar', 'sodium']:
                total = sum(r['nutrition_per_serving'][nutrient] for r in valid_recipes)
                avg_nutrition[nutrient] = round(total / len(valid_recipes), 2)
        else:
            avg_nutrition = {}
        
        return jsonify({
            'comparisons': comparisons,
            'average_nutrition_per_serving': avg_nutrition,
            'recipe_count': len(valid_recipes)
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

