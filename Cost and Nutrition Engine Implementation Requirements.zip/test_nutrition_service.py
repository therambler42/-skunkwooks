import pytest
import sys
import os
from decimal import Decimal

# Add the src directory to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from src.services.nutrition_service import NutritionCalculator
from src.models.ingredient import Ingredient

class TestNutritionCalculator:
    
    def setup_method(self):
        """Set up test fixtures before each test method."""
        self.calculator = NutritionCalculator()
        
        # Create mock ingredients for testing
        self.test_ingredient_1 = Ingredient(
            id=1,
            name="Test Flour",
            supplier="Test Supplier",
            pack_size=1000.0,
            pack_cost=5.00,
            yield_percentage=100.0,
            unit="g",
            # Nutrition per 100g
            calories=364.0,
            protein=10.3,
            carbs=76.3,
            fat=1.0,
            fiber=2.7,
            sugar=0.3,
            sodium=2.0,
            # Allergens
            contains_gluten=True,
            contains_dairy=False,
            contains_eggs=False,
            contains_nuts=False,
            contains_soy=False,
            contains_fish=False,
            contains_shellfish=False
        )
        
        self.test_ingredient_2 = Ingredient(
            id=2,
            name="Test Milk",
            supplier="Test Dairy",
            pack_size=1000.0,
            pack_cost=3.50,
            yield_percentage=100.0,
            unit="ml",
            # Nutrition per 100ml
            calories=42.0,
            protein=3.4,
            carbs=5.0,
            fat=1.0,
            fiber=0.0,
            sugar=5.0,
            sodium=44.0,
            # Allergens
            contains_gluten=False,
            contains_dairy=True,
            contains_eggs=False,
            contains_nuts=False,
            contains_soy=False,
            contains_fish=False,
            contains_shellfish=False
        )
    
    def test_fda_daily_values_calculation(self):
        """Test FDA daily value percentage calculations."""
        # Test with known values
        test_nutrition = {
            'calories': 200,
            'fat': 10,
            'carbs': 30,
            'fiber': 5,
            'sugar': 10,
            'protein': 15,
            'sodium': 460
        }
        
        # Calculate expected daily values
        expected_dv = {
            'calories': (200 / 2000) * 100,  # 10%
            'fat': (10 / 65) * 100,          # ~15.4%
            'carbs': (30 / 300) * 100,       # 10%
            'fiber': (5 / 25) * 100,         # 20%
            'sugar': (10 / 50) * 100,        # 20%
            'protein': (15 / 50) * 100,      # 30%
            'sodium': (460 / 2300) * 100     # 20%
        }
        
        # Verify daily values are in expected ranges
        for nutrient, expected in expected_dv.items():
            if nutrient in self.calculator.fda_daily_values:
                calculated = (Decimal(str(test_nutrition[nutrient])) / 
                            Decimal(str(self.calculator.fda_daily_values[nutrient]))) * Decimal('100')
                assert abs(float(calculated) - expected) < 0.1
    
    def test_eu_reference_intakes_calculation(self):
        """Test EU reference intake percentage calculations."""
        # Test energy conversion (kcal to kJ)
        calories = 200
        energy_kj = calories * 4.184  # 836.8 kJ
        
        expected_ri = (energy_kj / 8400) * 100  # ~9.96%
        
        calculated_ri = (Decimal(str(energy_kj)) / 
                        Decimal(str(self.calculator.eu_reference_intakes['energy']))) * Decimal('100')
        
        assert abs(float(calculated_ri) - expected_ri) < 0.1
    
    def test_allergen_detection(self):
        """Test allergen flag detection and aggregation."""
        # Test individual allergens
        assert self.test_ingredient_1.contains_gluten == True
        assert self.test_ingredient_1.contains_dairy == False
        
        assert self.test_ingredient_2.contains_gluten == False
        assert self.test_ingredient_2.contains_dairy == True
        
        # Test allergen summary for multiple ingredients
        recipe_ids = [1, 2]  # Mock recipe IDs
        
        # This would normally query the database, but we're testing the logic
        all_allergens = {
            'gluten': False,
            'dairy': False,
            'eggs': False,
            'nuts': False,
            'soy': False,
            'fish': False,
            'shellfish': False
        }
        
        # Simulate combining allergens from both ingredients
        if self.test_ingredient_1.contains_gluten or self.test_ingredient_2.contains_gluten:
            all_allergens['gluten'] = True
        if self.test_ingredient_1.contains_dairy or self.test_ingredient_2.contains_dairy:
            all_allergens['dairy'] = True
        
        assert all_allergens['gluten'] == True  # From ingredient 1
        assert all_allergens['dairy'] == True   # From ingredient 2
        assert all_allergens['eggs'] == False   # Neither has eggs
    
    def test_nutrition_calculation_precision(self):
        """Test that nutrition calculations meet precision requirements."""
        # Test with specific quantities
        quantity_grams = 150.0
        
        # Calculate nutrition for 150g of flour (per 100g base)
        factor = Decimal(str(quantity_grams)) / Decimal('100')
        
        calculated_calories = Decimal(str(self.test_ingredient_1.calories)) * factor
        expected_calories = Decimal('364') * Decimal('1.5')  # 546
        
        assert calculated_calories == expected_calories
        
        # Verify precision (2 decimal places for nutrition)
        rounded_calories = calculated_calories.quantize(Decimal('0.01'))
        assert rounded_calories == Decimal('546.00')
    
    def test_serving_calculations(self):
        """Test per-serving nutrition calculations."""
        # Mock recipe with 4 servings, total weight 800g
        servings = 4
        total_weight = Decimal('800')
        
        # Mock total nutrition values
        total_calories = Decimal('1000')
        
        # Calculate per serving
        per_serving_calories = total_calories / Decimal(str(servings))
        expected_per_serving = Decimal('250')
        
        assert per_serving_calories == expected_per_serving
        
        # Calculate per 100g
        per_100g_calories = (total_calories / total_weight) * Decimal('100')
        expected_per_100g = Decimal('125')
        
        assert per_100g_calories == expected_per_100g
    
    def test_salt_sodium_conversion(self):
        """Test conversion between sodium (mg) and salt (g) for EU labels."""
        # Sodium in mg
        sodium_mg = Decimal('460')
        
        # Convert to salt in grams: sodium_mg / 1000 * 2.5
        salt_g = (sodium_mg / Decimal('1000')) * Decimal('2.5')
        expected_salt = Decimal('1.15')
        
        assert salt_g == expected_salt
    
    def test_accuracy_requirements(self):
        """Test that calculations meet ±0.1% accuracy requirements."""
        # Test with reference values
        reference_calories = 100.0
        calculated_calories = 100.05  # Within 0.1%
        
        accuracy_percentage = abs(calculated_calories - reference_calories) / reference_calories * 100
        assert accuracy_percentage <= 0.1
        
        # Test edge case at exactly 0.1%
        edge_case_calories = 100.1
        edge_accuracy = abs(edge_case_calories - reference_calories) / reference_calories * 100
        assert edge_accuracy <= 0.1
    
    def test_zero_and_negative_values(self):
        """Test handling of zero and edge case values."""
        # Test with zero nutrition values
        zero_ingredient = Ingredient(
            id=3, name="Zero Nutrition", supplier="Test",
            pack_size=1000.0, pack_cost=1.00, yield_percentage=100.0, unit="g",
            calories=0.0, protein=0.0, carbs=0.0, fat=0.0,
            fiber=0.0, sugar=0.0, sodium=0.0
        )
        
        # All nutrition values should be zero
        assert zero_ingredient.calories == 0.0
        assert zero_ingredient.protein == 0.0
        assert zero_ingredient.carbs == 0.0
        
        # Calculations with zero should still work
        factor = Decimal('2.5')
        calculated_calories = Decimal(str(zero_ingredient.calories)) * factor
        assert calculated_calories == Decimal('0')

if __name__ == '__main__':
    pytest.main([__file__])

