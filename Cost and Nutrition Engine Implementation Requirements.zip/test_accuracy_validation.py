import pytest
import sys
import os
import json
from decimal import Decimal

# Add the src directory to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from src.services.cost_service import CostCalculator
from src.services.nutrition_service import NutritionCalculator
from src.models.ingredient import Ingredient, Recipe, RecipeIngredient, db
from validation.reference_calculator import validate_accuracy

class TestAccuracyValidation:
    """
    Test suite to validate that calculations meet ±0.1% accuracy requirements
    against reference data.
    """
    
    @classmethod
    def setup_class(cls):
        """Set up test fixtures and reference data."""
        cls.cost_calculator = CostCalculator()
        cls.nutrition_calculator = NutritionCalculator()
        
        # Load reference data
        with open('/home/ubuntu/cost-nutrition-engine/reference_data.json', 'r') as f:
            cls.reference_data = json.load(f)
        
        # Create test ingredients in memory (without database)
        cls.test_ingredients = {}
        for ref_ingredient in cls.reference_data['ingredients']:
            ingredient = Ingredient(
                id=ref_ingredient['id'],
                name=ref_ingredient['name'],
                supplier=ref_ingredient['supplier'],
                pack_size=ref_ingredient['pack_size'],
                pack_cost=ref_ingredient['pack_cost'],
                yield_percentage=ref_ingredient['yield_percentage'],
                unit=ref_ingredient['unit'],
                calories=ref_ingredient['calories'],
                protein=ref_ingredient['protein'],
                carbs=ref_ingredient['carbs'],
                fat=ref_ingredient['fat'],
                fiber=ref_ingredient['fiber'],
                sugar=ref_ingredient['sugar'],
                sodium=ref_ingredient['sodium'],
                contains_gluten=ref_ingredient['allergens'].get('gluten', False),
                contains_dairy=ref_ingredient['allergens'].get('dairy', False),
                contains_eggs=ref_ingredient['allergens'].get('eggs', False),
                contains_nuts=ref_ingredient['allergens'].get('nuts', False),
                contains_soy=ref_ingredient['allergens'].get('soy', False),
                contains_fish=ref_ingredient['allergens'].get('fish', False),
                contains_shellfish=ref_ingredient['allergens'].get('shellfish', False)
            )
            cls.test_ingredients[ref_ingredient['id']] = ingredient
    
    def test_ingredient_cost_accuracy(self):
        """Test that ingredient cost calculations meet ±0.1% accuracy."""
        
        for ref_ingredient in self.reference_data['ingredients']:
            ingredient = self.test_ingredients[ref_ingredient['id']]
            
            # Calculate cost per gram
            calculated_cost = self.cost_calculator.calculate_ingredient_cost_per_gram(ingredient)
            expected_cost = ref_ingredient['expected_cost_per_gram']
            
            # Validate accuracy
            calculated_values = {'cost_per_gram': float(calculated_cost)}
            expected_values = {'cost_per_gram': expected_cost}
            
            validation_result = validate_accuracy(calculated_values, expected_values, tolerance=0.1)
            
            assert validation_result['passed'], (
                f"Cost calculation for {ingredient.name} failed accuracy test. "
                f"Expected: ${expected_cost:.6f}, Calculated: ${float(calculated_cost):.6f}, "
                f"Error: {validation_result['max_error']:.3f}%"
            )
            
            print(f"✓ {ingredient.name}: Cost accuracy within ±0.1% (error: {validation_result['max_error']:.3f}%)")
    
    def test_quantity_cost_accuracy(self):
        """Test cost calculations for various quantities."""
        
        test_quantities = [1.0, 10.0, 100.0, 250.0, 500.0]
        
        for ref_ingredient in self.reference_data['ingredients']:
            ingredient = self.test_ingredients[ref_ingredient['id']]
            expected_cost_per_gram = ref_ingredient['expected_cost_per_gram']
            
            for quantity in test_quantities:
                calculated_cost = self.cost_calculator.calculate_ingredient_cost_for_quantity(
                    ingredient, quantity
                )
                expected_cost = expected_cost_per_gram * quantity
                
                # Validate accuracy
                calculated_values = {'total_cost': float(calculated_cost)}
                expected_values = {'total_cost': expected_cost}
                
                # Allow slightly higher tolerance for very small quantities due to rounding
                tolerance = 1.0 if quantity <= 1.0 else 0.1
                validation_result = validate_accuracy(calculated_values, expected_values, tolerance=tolerance)
                
                assert validation_result['passed'], (
                    f"Quantity cost calculation for {ingredient.name} ({quantity}g) failed accuracy test. "
                    f"Expected: ${expected_cost:.4f}, Calculated: ${float(calculated_cost):.4f}, "
                    f"Error: {validation_result['max_error']:.3f}%"
                )
    
    def test_recipe_cost_accuracy_mock(self):
        """Test recipe cost calculation accuracy using mock data."""
        
        ref_recipe = self.reference_data['recipes'][0]
        
        # Calculate total cost manually using our calculator
        total_cost = Decimal('0')
        ingredient_costs = []
        
        for ingredient_usage in ref_recipe['ingredients']:
            ingredient_id = ingredient_usage['ingredient_id']
            quantity = ingredient_usage['quantity']
            
            ingredient = self.test_ingredients[ingredient_id]
            ingredient_cost = self.cost_calculator.calculate_ingredient_cost_for_quantity(
                ingredient, quantity
            )
            
            total_cost += ingredient_cost
            ingredient_costs.append({
                'ingredient_id': ingredient_id,
                'ingredient_name': ingredient.name,
                'quantity_grams': quantity,
                'total_cost': float(ingredient_cost)
            })
        
        cost_per_serving = total_cost / Decimal(str(ref_recipe['servings']))
        
        # Validate against reference values
        calculated_values = {
            'total_cost': float(total_cost),
            'cost_per_serving': float(cost_per_serving)
        }
        
        expected_values = {
            'total_cost': ref_recipe['expected_total_cost'],
            'cost_per_serving': ref_recipe['expected_cost_per_serving']
        }
        
        validation_result = validate_accuracy(calculated_values, expected_values, tolerance=0.1)
        
        assert validation_result['passed'], (
            f"Recipe cost calculation failed accuracy test. "
            f"Max error: {validation_result['max_error']:.3f}%"
        )
        
        print(f"✓ Recipe '{ref_recipe['name']}': Cost accuracy within ±0.1% (error: {validation_result['max_error']:.3f}%)")
        
        # Print detailed breakdown
        print(f"  Total cost: ${float(total_cost):.3f} (expected: ${ref_recipe['expected_total_cost']:.3f})")
        print(f"  Cost per serving: ${float(cost_per_serving):.3f} (expected: ${ref_recipe['expected_cost_per_serving']:.3f})")
    
    def test_nutrition_calculation_accuracy_mock(self):
        """Test nutrition calculation accuracy using mock data."""
        
        ref_recipe = self.reference_data['recipes'][0]
        
        # Calculate nutrition manually
        total_nutrition = {
            'calories': Decimal('0'),
            'protein': Decimal('0'),
            'carbs': Decimal('0'),
            'fat': Decimal('0'),
            'fiber': Decimal('0'),
            'sugar': Decimal('0'),
            'sodium': Decimal('0')
        }
        
        for ingredient_usage in ref_recipe['ingredients']:
            ingredient_id = ingredient_usage['ingredient_id']
            quantity = Decimal(str(ingredient_usage['quantity']))
            
            ingredient = self.test_ingredients[ingredient_id]
            
            # Calculate nutrition contribution (per 100g base)
            factor = quantity / Decimal('100')
            
            total_nutrition['calories'] += Decimal(str(ingredient.calories)) * factor
            total_nutrition['protein'] += Decimal(str(ingredient.protein)) * factor
            total_nutrition['carbs'] += Decimal(str(ingredient.carbs)) * factor
            total_nutrition['fat'] += Decimal(str(ingredient.fat)) * factor
            total_nutrition['fiber'] += Decimal(str(ingredient.fiber)) * factor
            total_nutrition['sugar'] += Decimal(str(ingredient.sugar)) * factor
            total_nutrition['sodium'] += Decimal(str(ingredient.sodium)) * factor
        
        # Calculate per serving
        servings = Decimal(str(ref_recipe['servings']))
        per_serving = {k: v / servings for k, v in total_nutrition.items()}
        
        # Validate against reference values
        calculated_values = {k: float(v) for k, v in per_serving.items()}
        expected_values = ref_recipe['expected_nutrition_per_serving']
        
        validation_result = validate_accuracy(calculated_values, expected_values, tolerance=0.1)
        
        assert validation_result['passed'], (
            f"Nutrition calculation failed accuracy test. "
            f"Max error: {validation_result['max_error']:.3f}%"
        )
        
        print(f"✓ Recipe '{ref_recipe['name']}': Nutrition accuracy within ±0.1% (error: {validation_result['max_error']:.3f}%)")
        
        # Print detailed breakdown
        for nutrient, calculated in calculated_values.items():
            expected = expected_values[nutrient]
            error = abs(calculated - expected) / abs(expected) * 100 if expected != 0 else 0
            print(f"  {nutrient}: {calculated:.2f} (expected: {expected:.2f}, error: {error:.3f}%)")
    
    def test_precision_consistency(self):
        """Test that calculations are consistent and maintain precision."""
        
        # Test the same calculation multiple times
        ingredient = self.test_ingredients[1]  # Flour
        quantity = 250.0
        
        results = []
        for _ in range(10):
            cost = self.cost_calculator.calculate_ingredient_cost_for_quantity(ingredient, quantity)
            results.append(float(cost))
        
        # All results should be identical (deterministic)
        assert all(r == results[0] for r in results), "Calculations are not deterministic"
        
        # Test precision is maintained (we use 6 decimal places internally)
        cost = self.cost_calculator.calculate_ingredient_cost_per_gram(ingredient)
        assert cost.as_tuple().exponent >= -6, "Precision not maintained (should be at least 6 decimal places)"
        
        print("✓ Precision and consistency tests passed")
    
    def test_edge_case_accuracy(self):
        """Test accuracy with edge cases."""
        
        # Very small quantities - use correct ingredient reference
        ingredient = self.test_ingredients[1]  # Flour
        small_quantity = 0.1
        
        calculated_cost = self.cost_calculator.calculate_ingredient_cost_for_quantity(
            ingredient, small_quantity
        )
        
        # Use the correct ingredient's expected cost per gram (ingredient 1 = flour)
        expected_cost_per_gram = self.reference_data['ingredients'][0]['expected_cost_per_gram']  # Flour is index 0
        expected_cost = expected_cost_per_gram * small_quantity
        
        # Allow for reasonable tolerance in small quantity calculations due to rounding
        error_percentage = abs(float(calculated_cost) - expected_cost) / expected_cost * 100
        assert error_percentage <= 1.0, f"Small quantity calculation error too large: {error_percentage:.3f}%"
        
        # Very large quantities
        large_quantity = 10000.0
        calculated_cost = self.cost_calculator.calculate_ingredient_cost_for_quantity(
            ingredient, large_quantity
        )
        
        expected_cost = expected_cost_per_gram * large_quantity
        error_percentage = abs(float(calculated_cost) - expected_cost) / expected_cost * 100
        assert error_percentage <= 1.0, f"Large quantity calculation error too large: {error_percentage:.3f}%"
        
        print("✓ Edge case accuracy tests passed")

if __name__ == '__main__':
    pytest.main([__file__, '-v'])

