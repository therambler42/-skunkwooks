import json
from decimal import Decimal, ROUND_HALF_UP

# Reference data for accuracy validation
# This represents known good values for testing our calculations

reference_data = {
    'ingredients': [
        {
            'id': 1,
            'name': 'All-Purpose Flour',
            'supplier': 'Premium Foods',
            'pack_size': 1000.0,  # grams
            'pack_cost': 2.50,    # USD
            'yield_percentage': 95.0,
            'unit': 'g',
            # Nutrition per 100g (USDA data)
            'calories': 364.0,
            'protein': 10.3,
            'carbs': 76.3,
            'fat': 1.0,
            'fiber': 2.7,
            'sugar': 0.3,
            'sodium': 2.0,
            # Expected cost per gram
            'expected_cost_per_gram': 2.50 / 1000 / (95/100),  # 0.002631579
            'allergens': {'gluten': True}
        },
        {
            'id': 2,
            'name': 'Whole Milk',
            'supplier': 'Fresh Dairy Co',
            'pack_size': 1000.0,  # ml
            'pack_cost': 3.20,    # USD
            'yield_percentage': 100.0,
            'unit': 'ml',
            # Nutrition per 100ml (USDA data)
            'calories': 61.0,
            'protein': 3.2,
            'carbs': 4.8,
            'fat': 3.3,
            'fiber': 0.0,
            'sugar': 4.8,
            'sodium': 44.0,
            # Expected cost per ml
            'expected_cost_per_gram': 3.20 / 1000,  # 0.0032
            'allergens': {'dairy': True}
        },
        {
            'id': 3,
            'name': 'Large Eggs',
            'supplier': 'Farm Fresh',
            'pack_size': 600.0,   # grams (12 eggs × 50g each)
            'pack_cost': 4.80,    # USD
            'yield_percentage': 88.0,  # Shell waste
            'unit': 'g',
            # Nutrition per 100g (USDA data)
            'calories': 155.0,
            'protein': 13.0,
            'carbs': 1.1,
            'fat': 11.0,
            'fiber': 0.0,
            'sugar': 1.1,
            'sodium': 124.0,
            # Expected cost per gram
            'expected_cost_per_gram': 4.80 / 600 / (88/100),  # 0.009090909
            'allergens': {'eggs': True}
        },
        {
            'id': 4,
            'name': 'Unsalted Butter',
            'supplier': 'Premium Dairy',
            'pack_size': 454.0,   # grams (1 lb)
            'pack_cost': 5.99,    # USD
            'yield_percentage': 100.0,
            'unit': 'g',
            # Nutrition per 100g (USDA data)
            'calories': 717.0,
            'protein': 0.9,
            'carbs': 0.1,
            'fat': 81.1,
            'fiber': 0.0,
            'sugar': 0.1,
            'sodium': 11.0,
            # Expected cost per gram
            'expected_cost_per_gram': 5.99 / 454,  # 0.013194053
            'allergens': {'dairy': True}
        }
    ],
    'recipes': [
        {
            'id': 1,
            'name': 'Basic Pancakes',
            'servings': 4,
            'ingredients': [
                {'ingredient_id': 1, 'quantity': 200.0},  # 200g flour
                {'ingredient_id': 2, 'quantity': 250.0},  # 250ml milk
                {'ingredient_id': 3, 'quantity': 100.0},  # 100g eggs (2 eggs)
                {'ingredient_id': 4, 'quantity': 30.0}    # 30g butter
            ],
            # Expected calculations
            'expected_total_cost': None,  # Will be calculated
            'expected_cost_per_serving': None,  # Will be calculated
            'expected_total_weight': 580.0,  # grams
            'expected_nutrition_per_serving': {
                'calories': None,  # Will be calculated
                'protein': None,
                'carbs': None,
                'fat': None,
                'fiber': None,
                'sugar': None,
                'sodium': None
            },
            'expected_allergens': {'gluten': True, 'dairy': True, 'eggs': True}
        }
    ]
}

def calculate_reference_values():
    """Calculate expected values for validation."""
    
    # Calculate recipe costs
    recipe = reference_data['recipes'][0]
    total_cost = Decimal('0')
    
    for ingredient_usage in recipe['ingredients']:
        ingredient_id = ingredient_usage['ingredient_id']
        quantity = ingredient_usage['quantity']
        
        # Find ingredient data
        ingredient = next(i for i in reference_data['ingredients'] if i['id'] == ingredient_id)
        
        # Calculate cost
        cost_per_gram = Decimal(str(ingredient['expected_cost_per_gram']))
        ingredient_cost = cost_per_gram * Decimal(str(quantity))
        total_cost += ingredient_cost
        
        print(f"{ingredient['name']}: {quantity}g × ${float(cost_per_gram):.6f}/g = ${float(ingredient_cost):.4f}")
    
    recipe['expected_total_cost'] = float(total_cost.quantize(Decimal('0.001'), rounding=ROUND_HALF_UP))
    recipe['expected_cost_per_serving'] = float((total_cost / Decimal(str(recipe['servings']))).quantize(Decimal('0.001'), rounding=ROUND_HALF_UP))
    
    print(f"\nTotal Recipe Cost: ${recipe['expected_total_cost']:.3f}")
    print(f"Cost per Serving: ${recipe['expected_cost_per_serving']:.3f}")
    
    # Calculate nutrition values
    total_nutrition = {
        'calories': 0, 'protein': 0, 'carbs': 0, 'fat': 0,
        'fiber': 0, 'sugar': 0, 'sodium': 0
    }
    
    for ingredient_usage in recipe['ingredients']:
        ingredient_id = ingredient_usage['ingredient_id']
        quantity = ingredient_usage['quantity']
        
        ingredient = next(i for i in reference_data['ingredients'] if i['id'] == ingredient_id)
        
        # Calculate nutrition contribution (per 100g base)
        factor = quantity / 100.0
        
        for nutrient in total_nutrition:
            total_nutrition[nutrient] += ingredient[nutrient] * factor
    
    # Per serving nutrition
    servings = recipe['servings']
    for nutrient in total_nutrition:
        recipe['expected_nutrition_per_serving'][nutrient] = round(total_nutrition[nutrient] / servings, 2)
    
    print(f"\nNutrition per serving:")
    for nutrient, value in recipe['expected_nutrition_per_serving'].items():
        print(f"  {nutrient}: {value}")
    
    return reference_data

def validate_accuracy(calculated_values, expected_values, tolerance=0.1):
    """
    Validate that calculated values are within ±0.1% of expected values.
    
    Args:
        calculated_values: Dict of calculated values
        expected_values: Dict of expected reference values
        tolerance: Acceptable percentage difference (default 0.1%)
    
    Returns:
        Dict with validation results
    """
    results = {
        'passed': True,
        'details': [],
        'max_error': 0.0
    }
    
    for key, expected in expected_values.items():
        if key in calculated_values and expected is not None:
            calculated = calculated_values[key]
            
            if expected != 0:
                error_percentage = abs(calculated - expected) / abs(expected) * 100
                
                passed = error_percentage <= tolerance
                results['details'].append({
                    'field': key,
                    'expected': expected,
                    'calculated': calculated,
                    'error_percentage': error_percentage,
                    'passed': passed
                })
                
                if error_percentage > results['max_error']:
                    results['max_error'] = error_percentage
                
                if not passed:
                    results['passed'] = False
            else:
                # Handle zero values
                passed = abs(calculated) <= 0.001
                results['details'].append({
                    'field': key,
                    'expected': expected,
                    'calculated': calculated,
                    'error_percentage': 0.0 if passed else float('inf'),
                    'passed': passed
                })
                
                if not passed:
                    results['passed'] = False
    
    return results

def generate_test_cases():
    """Generate comprehensive test cases for validation."""
    
    test_cases = []
    
    # Cost calculation test cases
    for ingredient in reference_data['ingredients']:
        test_cases.append({
            'type': 'ingredient_cost',
            'ingredient_id': ingredient['id'],
            'expected_cost_per_gram': ingredient['expected_cost_per_gram'],
            'test_quantities': [1.0, 10.0, 100.0, 250.0, 500.0]
        })
    
    # Recipe cost test cases
    for recipe in reference_data['recipes']:
        test_cases.append({
            'type': 'recipe_cost',
            'recipe_id': recipe['id'],
            'expected_total_cost': recipe['expected_total_cost'],
            'expected_cost_per_serving': recipe['expected_cost_per_serving']
        })
    
    # Nutrition calculation test cases
    for recipe in reference_data['recipes']:
        test_cases.append({
            'type': 'recipe_nutrition',
            'recipe_id': recipe['id'],
            'expected_nutrition': recipe['expected_nutrition_per_serving'],
            'expected_allergens': recipe['expected_allergens']
        })
    
    return test_cases

if __name__ == '__main__':
    print("Calculating reference values...")
    reference_data = calculate_reference_values()
    
    print("\nGenerating test cases...")
    test_cases = generate_test_cases()
    
    print(f"\nGenerated {len(test_cases)} test cases for validation")
    
    # Save reference data
    import json
    with open('/home/ubuntu/cost-nutrition-engine/reference_data.json', 'w') as f:
        json.dump(reference_data, f, indent=2)
    
    print("Reference data saved to reference_data.json")

