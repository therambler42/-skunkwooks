import graphene
from graphene import ObjectType, String, Float, Int, Boolean, List, Field
from src.services.cost_service import CostCalculator
from src.services.nutrition_service import NutritionCalculator
from src.models.ingredient import Ingredient, Recipe, Menu

cost_calculator = CostCalculator()
nutrition_calculator = NutritionCalculator()

# GraphQL Types
class AllergenType(ObjectType):
    gluten = Boolean()
    dairy = Boolean()
    eggs = Boolean()
    nuts = Boolean()
    soy = Boolean()
    fish = Boolean()
    shellfish = Boolean()

class NutritionType(ObjectType):
    calories = Float()
    protein = Float()
    carbs = Float()
    fat = Float()
    fiber = Float()
    sugar = Float()
    sodium = Float()

class IngredientType(ObjectType):
    id = Int()
    name = String()
    supplier = String()
    pack_size = Float()
    pack_cost = Float()
    yield_percentage = Float()
    unit = String()
    nutrition = Field(NutritionType)
    allergens = Field(AllergenType)
    cost_per_gram = Float()

class IngredientCostDetailType(ObjectType):
    ingredient_id = Int()
    ingredient_name = String()
    quantity_grams = Float()
    cost_per_gram = Float()
    total_cost = Float()
    supplier = String()
    yield_percentage = Float()

class RecipeCostType(ObjectType):
    recipe_id = Int()
    recipe_name = String()
    servings = Int()
    ingredient_costs = List(IngredientCostDetailType)
    total_cost = Float()
    cost_per_serving = Float()

class SupplierBreakdownType(ObjectType):
    supplier_name = String()
    total_cost = Float()
    ingredients = List(IngredientCostDetailType)

class RecipeCostBySupplierType(ObjectType):
    recipe_id = Int()
    recipe_name = String()
    supplier_breakdown = List(SupplierBreakdownType)
    total_cost = Float()

class NutritionDetailType(ObjectType):
    recipe_id = Int()
    recipe_name = String()
    servings = Int()
    total_weight_grams = Float()
    nutrition_per_serving = Field(NutritionType)
    nutrition_per_100g = Field(NutritionType)
    nutrition_total = Field(NutritionType)
    allergens = Field(AllergenType)

class DailyValueType(ObjectType):
    calories = Float()
    fat = Float()
    carbs = Float()
    fiber = Float()
    sugar = Float()
    protein = Float()
    sodium = Float()

class FDANutritionLabelType(ObjectType):
    format = String()
    recipe_id = Int()
    recipe_name = String()
    serving_size = String()
    servings_per_container = Int()
    nutrition_facts = Field(NutritionType)
    daily_values = Field(DailyValueType)
    allergen_statement = String()
    allergens = Field(AllergenType)

class EUNutritionType(ObjectType):
    energy_kj = Float()
    energy_kcal = Float()
    fat = Float()
    carbohydrate = Float()
    sugars = Float()
    fibre = Float()
    protein = Float()
    salt = Float()

class ReferenceIntakeType(ObjectType):
    energy = Float()
    fat = Float()
    carbs = Float()
    sugar = Float()
    protein = Float()
    salt = Float()

class EUNutritionLabelType(ObjectType):
    format = String()
    recipe_id = Int()
    recipe_name = String()
    serving_size = String()
    nutrition_per_100g = Field(EUNutritionType)
    nutrition_per_serving = Field(EUNutritionType)
    reference_intakes = Field(ReferenceIntakeType)
    allergen_statement = String()
    allergens = Field(AllergenType)

# Query resolvers
class Query(ObjectType):
    # Ingredient queries
    ingredient = Field(IngredientType, id=Int(required=True))
    ingredients = List(IngredientType)
    
    # Cost queries
    ingredient_cost = Field(Float, ingredient_id=Int(required=True))
    ingredient_cost_for_quantity = Field(Float, ingredient_id=Int(required=True), quantity_grams=Float(required=True))
    recipe_cost = Field(RecipeCostType, recipe_id=Int(required=True))
    recipe_cost_by_supplier = Field(RecipeCostBySupplierType, recipe_id=Int(required=True))
    
    # Nutrition queries
    recipe_nutrition = Field(NutritionDetailType, recipe_id=Int(required=True))
    fda_nutrition_label = Field(FDANutritionLabelType, recipe_id=Int(required=True))
    eu_nutrition_label = Field(EUNutritionLabelType, recipe_id=Int(required=True))
    
    def resolve_ingredient(self, info, id):
        ingredient = Ingredient.query.get(id)
        if not ingredient:
            return None
        
        cost_per_gram = float(cost_calculator.calculate_ingredient_cost_per_gram(ingredient))
        
        return IngredientType(
            id=ingredient.id,
            name=ingredient.name,
            supplier=ingredient.supplier,
            pack_size=ingredient.pack_size,
            pack_cost=ingredient.pack_cost,
            yield_percentage=ingredient.yield_percentage,
            unit=ingredient.unit,
            cost_per_gram=cost_per_gram,
            nutrition=NutritionType(
                calories=ingredient.calories,
                protein=ingredient.protein,
                carbs=ingredient.carbs,
                fat=ingredient.fat,
                fiber=ingredient.fiber,
                sugar=ingredient.sugar,
                sodium=ingredient.sodium
            ),
            allergens=AllergenType(
                gluten=ingredient.contains_gluten,
                dairy=ingredient.contains_dairy,
                eggs=ingredient.contains_eggs,
                nuts=ingredient.contains_nuts,
                soy=ingredient.contains_soy,
                fish=ingredient.contains_fish,
                shellfish=ingredient.contains_shellfish
            )
        )
    
    def resolve_ingredients(self, info):
        ingredients = Ingredient.query.all()
        result = []
        
        for ingredient in ingredients:
            cost_per_gram = float(cost_calculator.calculate_ingredient_cost_per_gram(ingredient))
            
            result.append(IngredientType(
                id=ingredient.id,
                name=ingredient.name,
                supplier=ingredient.supplier,
                pack_size=ingredient.pack_size,
                pack_cost=ingredient.pack_cost,
                yield_percentage=ingredient.yield_percentage,
                unit=ingredient.unit,
                cost_per_gram=cost_per_gram,
                nutrition=NutritionType(
                    calories=ingredient.calories,
                    protein=ingredient.protein,
                    carbs=ingredient.carbs,
                    fat=ingredient.fat,
                    fiber=ingredient.fiber,
                    sugar=ingredient.sugar,
                    sodium=ingredient.sodium
                ),
                allergens=AllergenType(
                    gluten=ingredient.contains_gluten,
                    dairy=ingredient.contains_dairy,
                    eggs=ingredient.contains_eggs,
                    nuts=ingredient.contains_nuts,
                    soy=ingredient.contains_soy,
                    fish=ingredient.contains_fish,
                    shellfish=ingredient.contains_shellfish
                )
            ))
        
        return result
    
    def resolve_ingredient_cost(self, info, ingredient_id):
        ingredient = Ingredient.query.get(ingredient_id)
        if not ingredient:
            return None
        return float(cost_calculator.calculate_ingredient_cost_per_gram(ingredient))
    
    def resolve_ingredient_cost_for_quantity(self, info, ingredient_id, quantity_grams):
        ingredient = Ingredient.query.get(ingredient_id)
        if not ingredient:
            return None
        return float(cost_calculator.calculate_ingredient_cost_for_quantity(ingredient, quantity_grams))
    
    def resolve_recipe_cost(self, info, recipe_id):
        try:
            cost_data = cost_calculator.calculate_recipe_cost(recipe_id)
            
            ingredient_costs = [
                IngredientCostDetailType(
                    ingredient_id=item['ingredient_id'],
                    ingredient_name=item['ingredient_name'],
                    quantity_grams=item['quantity_grams'],
                    cost_per_gram=item['cost_per_gram'],
                    total_cost=item['total_cost'],
                    supplier=item['supplier'],
                    yield_percentage=item['yield_percentage']
                ) for item in cost_data['ingredient_costs']
            ]
            
            return RecipeCostType(
                recipe_id=cost_data['recipe_id'],
                recipe_name=cost_data['recipe_name'],
                servings=cost_data['servings'],
                ingredient_costs=ingredient_costs,
                total_cost=cost_data['total_cost'],
                cost_per_serving=cost_data['cost_per_serving']
            )
        except ValueError:
            return None
    
    def resolve_recipe_cost_by_supplier(self, info, recipe_id):
        try:
            cost_data = cost_calculator.get_cost_breakdown_by_supplier(recipe_id)
            
            supplier_breakdown = []
            for supplier in cost_data['supplier_breakdown']:
                ingredients = [
                    IngredientCostDetailType(
                        ingredient_id=item['ingredient_id'],
                        ingredient_name=item['ingredient_name'],
                        quantity_grams=item['quantity_grams'],
                        cost_per_gram=item['cost_per_gram'],
                        total_cost=item['total_cost'],
                        supplier=item['supplier'],
                        yield_percentage=item['yield_percentage']
                    ) for item in supplier['ingredients']
                ]
                
                supplier_breakdown.append(SupplierBreakdownType(
                    supplier_name=supplier['supplier_name'],
                    total_cost=supplier['total_cost'],
                    ingredients=ingredients
                ))
            
            return RecipeCostBySupplierType(
                recipe_id=cost_data['recipe_id'],
                recipe_name=cost_data['recipe_name'],
                supplier_breakdown=supplier_breakdown,
                total_cost=cost_data['total_cost']
            )
        except ValueError:
            return None
    
    def resolve_recipe_nutrition(self, info, recipe_id):
        try:
            nutrition_data = nutrition_calculator.calculate_recipe_nutrition(recipe_id)
            
            return NutritionDetailType(
                recipe_id=nutrition_data['recipe_id'],
                recipe_name=nutrition_data['recipe_name'],
                servings=nutrition_data['servings'],
                total_weight_grams=nutrition_data['total_weight_grams'],
                nutrition_per_serving=NutritionType(**nutrition_data['nutrition_per_serving']),
                nutrition_per_100g=NutritionType(**nutrition_data['nutrition_per_100g']),
                nutrition_total=NutritionType(**nutrition_data['nutrition_total']),
                allergens=AllergenType(**nutrition_data['allergens'])
            )
        except ValueError:
            return None
    
    def resolve_fda_nutrition_label(self, info, recipe_id):
        try:
            label_data = nutrition_calculator.generate_fda_nutrition_label(recipe_id)
            
            return FDANutritionLabelType(
                format=label_data['format'],
                recipe_id=label_data['recipe_id'],
                recipe_name=label_data['recipe_name'],
                serving_size=label_data['serving_size'],
                servings_per_container=label_data['servings_per_container'],
                nutrition_facts=NutritionType(**label_data['nutrition_facts']),
                daily_values=DailyValueType(**{k: v for k, v in label_data['daily_values'].items() if v is not None}),
                allergen_statement=label_data['allergen_statement'],
                allergens=AllergenType(**label_data['allergens'])
            )
        except ValueError:
            return None
    
    def resolve_eu_nutrition_label(self, info, recipe_id):
        try:
            label_data = nutrition_calculator.generate_eu_nutrition_label(recipe_id)
            
            return EUNutritionLabelType(
                format=label_data['format'],
                recipe_id=label_data['recipe_id'],
                recipe_name=label_data['recipe_name'],
                serving_size=label_data['serving_size'],
                nutrition_per_100g=EUNutritionType(**label_data['nutrition_per_100g']),
                nutrition_per_serving=EUNutritionType(**label_data['nutrition_per_serving']),
                reference_intakes=ReferenceIntakeType(**label_data['reference_intakes']),
                allergen_statement=label_data['allergen_statement'],
                allergens=AllergenType(**label_data['allergens'])
            )
        except ValueError:
            return None

# Create schema
schema = graphene.Schema(query=Query)

