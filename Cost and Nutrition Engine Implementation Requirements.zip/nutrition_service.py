from decimal import Decimal, ROUND_HALF_UP
from typing import Dict, List, Optional
from src.models.ingredient import Recipe, RecipeIngredient

class NutritionCalculator:
    """
    Nutrition calculation service that generates FDA and EU compliant nutrition labels
    with allergen flags and daily value percentages.
    """
    
    def __init__(self):
        # Use Decimal for high precision calculations
        self.precision = Decimal('0.01')  # 2 decimal places for nutrition values
        
        # FDA Daily Values (2000 calorie diet)
        self.fda_daily_values = {
            'calories': 2000,
            'fat': 65,  # grams
            'saturated_fat': 20,  # grams
            'cholesterol': 300,  # mg
            'sodium': 2300,  # mg
            'carbs': 300,  # grams
            'fiber': 25,  # grams
            'sugar': 50,  # grams (added sugars)
            'protein': 50,  # grams
            'vitamin_d': 20,  # mcg
            'calcium': 1300,  # mg
            'iron': 18,  # mg
            'potassium': 4700  # mg
        }
        
        # EU Reference Intakes (average adult)
        self.eu_reference_intakes = {
            'energy': 8400,  # kJ
            'fat': 70,  # grams
            'saturated_fat': 20,  # grams
            'carbs': 260,  # grams
            'sugar': 90,  # grams
            'protein': 50,  # grams
            'salt': 6  # grams (sodium * 2.5)
        }
    
    def calculate_recipe_nutrition(self, recipe_id: int) -> Dict:
        """
        Calculate total nutrition for a recipe including all ingredients.
        Returns nutrition per serving and per 100g.
        """
        recipe_ingredients = RecipeIngredient.query.filter_by(recipe_id=recipe_id).all()
        recipe = Recipe.query.get(recipe_id)
        
        if not recipe:
            raise ValueError(f"Recipe with id {recipe_id} not found")
        
        # Initialize totals
        totals = {
            'calories': Decimal('0'),
            'protein': Decimal('0'),
            'carbs': Decimal('0'),
            'fat': Decimal('0'),
            'fiber': Decimal('0'),
            'sugar': Decimal('0'),
            'sodium': Decimal('0')
        }
        
        # Allergen flags
        allergens = {
            'gluten': False,
            'dairy': False,
            'eggs': False,
            'nuts': False,
            'soy': False,
            'fish': False,
            'shellfish': False
        }
        
        ingredient_details = []
        total_weight = Decimal('0')
        
        for recipe_ingredient in recipe_ingredients:
            ingredient = recipe_ingredient.ingredient
            quantity_grams = Decimal(str(recipe_ingredient.quantity))
            
            # Calculate nutrition for this ingredient (per 100g base)
            factor = quantity_grams / Decimal('100')
            
            ingredient_nutrition = {
                'calories': Decimal(str(ingredient.calories)) * factor,
                'protein': Decimal(str(ingredient.protein)) * factor,
                'carbs': Decimal(str(ingredient.carbs)) * factor,
                'fat': Decimal(str(ingredient.fat)) * factor,
                'fiber': Decimal(str(ingredient.fiber)) * factor,
                'sugar': Decimal(str(ingredient.sugar)) * factor,
                'sodium': Decimal(str(ingredient.sodium)) * factor
            }
            
            # Add to totals
            for key in totals:
                totals[key] += ingredient_nutrition[key]
            
            # Check allergens
            if ingredient.contains_gluten:
                allergens['gluten'] = True
            if ingredient.contains_dairy:
                allergens['dairy'] = True
            if ingredient.contains_eggs:
                allergens['eggs'] = True
            if ingredient.contains_nuts:
                allergens['nuts'] = True
            if ingredient.contains_soy:
                allergens['soy'] = True
            if ingredient.contains_fish:
                allergens['fish'] = True
            if ingredient.contains_shellfish:
                allergens['shellfish'] = True
            
            ingredient_details.append({
                'ingredient_id': ingredient.id,
                'ingredient_name': ingredient.name,
                'quantity_grams': float(quantity_grams),
                'nutrition_contribution': {k: float(v.quantize(self.precision, rounding=ROUND_HALF_UP)) 
                                         for k, v in ingredient_nutrition.items()}
            })
            
            total_weight += quantity_grams
        
        # Calculate per serving
        servings = Decimal(str(recipe.servings))
        per_serving = {k: v / servings for k, v in totals.items()}
        
        # Calculate per 100g
        per_100g = {k: (v / total_weight) * Decimal('100') for k, v in totals.items()}
        
        return {
            'recipe_id': recipe_id,
            'recipe_name': recipe.name,
            'servings': recipe.servings,
            'total_weight_grams': float(total_weight),
            'nutrition_per_serving': {k: float(v.quantize(self.precision, rounding=ROUND_HALF_UP)) 
                                    for k, v in per_serving.items()},
            'nutrition_per_100g': {k: float(v.quantize(self.precision, rounding=ROUND_HALF_UP)) 
                                 for k, v in per_100g.items()},
            'nutrition_total': {k: float(v.quantize(self.precision, rounding=ROUND_HALF_UP)) 
                              for k, v in totals.items()},
            'allergens': allergens,
            'ingredient_details': ingredient_details
        }
    
    def generate_fda_nutrition_label(self, recipe_id: int) -> Dict:
        """
        Generate FDA-compliant nutrition facts label data.
        """
        nutrition_data = self.calculate_recipe_nutrition(recipe_id)
        per_serving = nutrition_data['nutrition_per_serving']
        
        # Calculate daily value percentages
        daily_values = {}
        for nutrient, amount in per_serving.items():
            if nutrient in self.fda_daily_values:
                dv_percent = (Decimal(str(amount)) / Decimal(str(self.fda_daily_values[nutrient]))) * Decimal('100')
                daily_values[nutrient] = float(dv_percent.quantize(Decimal('1'), rounding=ROUND_HALF_UP))
            else:
                daily_values[nutrient] = None
        
        # Format allergen statement
        allergen_list = [allergen for allergen, present in nutrition_data['allergens'].items() if present]
        allergen_statement = f"Contains: {', '.join(allergen_list).title()}" if allergen_list else "No major allergens"
        
        return {
            'format': 'FDA',
            'recipe_id': recipe_id,
            'recipe_name': nutrition_data['recipe_name'],
            'serving_size': f"1 serving ({nutrition_data['total_weight_grams'] / nutrition_data['servings']:.0f}g)",
            'servings_per_container': nutrition_data['servings'],
            'nutrition_facts': {
                'calories': per_serving['calories'],
                'total_fat': per_serving['fat'],
                'total_carbohydrate': per_serving['carbs'],
                'dietary_fiber': per_serving['fiber'],
                'total_sugars': per_serving['sugar'],
                'protein': per_serving['protein'],
                'sodium': per_serving['sodium']
            },
            'daily_values': daily_values,
            'allergen_statement': allergen_statement,
            'allergens': nutrition_data['allergens']
        }
    
    def generate_eu_nutrition_label(self, recipe_id: int) -> Dict:
        """
        Generate EU-compliant nutrition information data.
        """
        nutrition_data = self.calculate_recipe_nutrition(recipe_id)
        per_100g = nutrition_data['nutrition_per_100g']
        per_serving = nutrition_data['nutrition_per_serving']
        
        # Calculate reference intake percentages
        reference_intakes = {}
        
        # Energy in kJ (calories * 4.184)
        energy_kj = Decimal(str(per_serving['calories'])) * Decimal('4.184')
        ri_energy = (energy_kj / Decimal(str(self.eu_reference_intakes['energy']))) * Decimal('100')
        reference_intakes['energy'] = float(ri_energy.quantize(Decimal('1'), rounding=ROUND_HALF_UP))
        
        # Other nutrients
        for nutrient in ['fat', 'carbs', 'sugar', 'protein']:
            if nutrient in per_serving and nutrient in self.eu_reference_intakes:
                ri_percent = (Decimal(str(per_serving[nutrient])) / Decimal(str(self.eu_reference_intakes[nutrient]))) * Decimal('100')
                reference_intakes[nutrient] = float(ri_percent.quantize(Decimal('1'), rounding=ROUND_HALF_UP))
        
        # Salt (sodium * 2.5)
        salt_grams = Decimal(str(per_serving['sodium'])) / Decimal('1000') * Decimal('2.5')
        ri_salt = (salt_grams / Decimal(str(self.eu_reference_intakes['salt']))) * Decimal('100')
        reference_intakes['salt'] = float(ri_salt.quantize(Decimal('1'), rounding=ROUND_HALF_UP))
        
        # Format allergen statement
        allergen_list = [allergen for allergen, present in nutrition_data['allergens'].items() if present]
        allergen_statement = f"Contains: {', '.join(allergen_list).title()}" if allergen_list else "No allergens"
        
        return {
            'format': 'EU',
            'recipe_id': recipe_id,
            'recipe_name': nutrition_data['recipe_name'],
            'serving_size': f"1 serving ({nutrition_data['total_weight_grams'] / nutrition_data['servings']:.0f}g)",
            'nutrition_per_100g': {
                'energy_kj': float(energy_kj.quantize(Decimal('1'), rounding=ROUND_HALF_UP)),
                'energy_kcal': per_100g['calories'],
                'fat': per_100g['fat'],
                'carbohydrate': per_100g['carbs'],
                'sugars': per_100g['sugar'],
                'fibre': per_100g['fiber'],
                'protein': per_100g['protein'],
                'salt': float((Decimal(str(per_100g['sodium'])) / Decimal('1000') * Decimal('2.5')).quantize(self.precision, rounding=ROUND_HALF_UP))
            },
            'nutrition_per_serving': {
                'energy_kj': float((Decimal(str(per_serving['calories'])) * Decimal('4.184')).quantize(Decimal('1'), rounding=ROUND_HALF_UP)),
                'energy_kcal': per_serving['calories'],
                'fat': per_serving['fat'],
                'carbohydrate': per_serving['carbs'],
                'sugars': per_serving['sugar'],
                'fibre': per_serving['fiber'],
                'protein': per_serving['protein'],
                'salt': float((Decimal(str(per_serving['sodium'])) / Decimal('1000') * Decimal('2.5')).quantize(self.precision, rounding=ROUND_HALF_UP))
            },
            'reference_intakes': reference_intakes,
            'allergen_statement': allergen_statement,
            'allergens': nutrition_data['allergens']
        }
    
    def get_allergen_summary(self, recipe_ids: List[int]) -> Dict:
        """
        Get allergen summary for multiple recipes (useful for menu planning).
        """
        all_allergens = {
            'gluten': False,
            'dairy': False,
            'eggs': False,
            'nuts': False,
            'soy': False,
            'fish': False,
            'shellfish': False
        }
        
        recipe_allergens = {}
        
        for recipe_id in recipe_ids:
            try:
                nutrition_data = self.calculate_recipe_nutrition(recipe_id)
                recipe_allergens[recipe_id] = {
                    'recipe_name': nutrition_data['recipe_name'],
                    'allergens': nutrition_data['allergens']
                }
                
                # Update overall allergen flags
                for allergen, present in nutrition_data['allergens'].items():
                    if present:
                        all_allergens[allergen] = True
                        
            except ValueError:
                recipe_allergens[recipe_id] = {
                    'recipe_name': 'Unknown',
                    'allergens': {},
                    'error': 'Recipe not found'
                }
        
        allergen_list = [allergen for allergen, present in all_allergens.items() if present]
        
        return {
            'overall_allergens': all_allergens,
            'allergen_statement': f"Contains: {', '.join(allergen_list).title()}" if allergen_list else "No major allergens",
            'recipe_details': recipe_allergens
        }

