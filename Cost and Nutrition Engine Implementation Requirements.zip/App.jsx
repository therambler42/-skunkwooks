import React from 'react';
import { ApolloProvider } from '@apollo/client';
import { client } from './lib/apollo';
import RecipeAnalyzer from './components/RecipeAnalyzer';
import './App.css';

function App() {
  return (
    <ApolloProvider client={client}>
      <div className="min-h-screen bg-background">
        <header className="border-b">
          <div className="container mx-auto px-6 py-4">
            <h1 className="text-3xl font-bold text-primary">Cost & Nutrition Engine</h1>
            <p className="text-muted-foreground mt-1">
              Analyze recipe costs and generate nutrition labels with FDA and EU compliance
            </p>
          </div>
        </header>
        
        <main className="container mx-auto px-6 py-8">
          <RecipeAnalyzer />
        </main>
        
        <footer className="border-t mt-16">
          <div className="container mx-auto px-6 py-4 text-center text-sm text-muted-foreground">
            <p>Cost & Nutrition Engine - Accurate cost calculations and nutrition labeling</p>
          </div>
        </footer>
      </div>
    </ApolloProvider>
  );
}

export default App;

