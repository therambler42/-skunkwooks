import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import { MockedProvider } from '@apollo/client/testing';
import NutritionFactsPanel from '../NutritionFactsPanel';

// Mock data for testing
const mockFDAData = {
  format: 'FDA',
  recipeId: 1,
  recipeName: 'Test Recipe',
  servingSize: '1 serving (200g)',
  servingsPerContainer: 4,
  nutritionFacts: {
    calories: 250,
    totalFat: 10,
    totalCarbohydrate: 30,
    dietaryFiber: 5,
    totalSugars: 8,
    protein: 15,
    sodium: 460
  },
  dailyValues: {
    calories: 13,
    fat: 15,
    carbs: 10,
    fiber: 20,
    sugar: 16,
    protein: 30,
    sodium: 20
  },
  allergenStatement: 'Contains: Gluten, Dairy',
  allergens: {
    gluten: true,
    dairy: true,
    eggs: false,
    nuts: false,
    soy: false,
    fish: false,
    shellfish: false
  }
};

const mockEUData = {
  format: 'EU',
  recipeId: 1,
  recipeName: 'Test Recipe',
  servingSize: '1 serving (200g)',
  nutritionPer100g: {
    energyKj: 1046,
    energyKcal: 250,
    fat: 10.0,
    carbohydrate: 30.0,
    sugars: 8.0,
    fibre: 5.0,
    protein: 15.0,
    salt: 1.15
  },
  nutritionPerServing: {
    energyKj: 2092,
    energyKcal: 500,
    fat: 20.0,
    carbohydrate: 60.0,
    sugars: 16.0,
    fibre: 10.0,
    protein: 30.0,
    salt: 2.30
  },
  referenceIntakes: {
    energy: 25,
    fat: 29,
    carbs: 23,
    sugar: 18,
    protein: 60,
    salt: 38
  },
  allergenStatement: 'Contains: Gluten, Dairy',
  allergens: {
    gluten: true,
    dairy: true,
    eggs: false,
    nuts: false,
    soy: false,
    fish: false,
    shellfish: false
  }
};

const mockBasicData = {
  recipeId: 1,
  recipeName: 'Test Recipe',
  servings: 4,
  totalWeightGrams: 800,
  nutritionPerServing: {
    calories: 250,
    protein: 15,
    carbs: 30,
    fat: 10,
    fiber: 5,
    sugar: 8,
    sodium: 460
  },
  allergens: {
    gluten: true,
    dairy: true,
    eggs: false,
    nuts: false,
    soy: false,
    fish: false,
    shellfish: false
  }
};

describe('NutritionFactsPanel', () => {
  it('renders FDA nutrition facts correctly', () => {
    render(<NutritionFactsPanel nutritionData={mockFDAData} format="FDA" />);
    
    // Check for FDA-specific elements
    expect(screen.getByText('Nutrition Facts')).toBeInTheDocument();
    expect(screen.getByText('250')).toBeInTheDocument(); // Calories
    expect(screen.getByText('Serving size')).toBeInTheDocument();
    expect(screen.getByText('1 serving (200g)')).toBeInTheDocument();
    expect(screen.getByText('% Daily Value*')).toBeInTheDocument();
    
    // Check for daily value percentages
    expect(screen.getByText('15%')).toBeInTheDocument(); // Fat DV
    expect(screen.getByText('20%')).toBeInTheDocument(); // Fiber DV
    
    // Check allergen statement
    expect(screen.getByText('Contains: Gluten, Dairy')).toBeInTheDocument();
  });

  it('renders EU nutrition facts correctly', () => {
    render(<NutritionFactsPanel nutritionData={mockEUData} format="EU" />);
    
    // Check for EU-specific elements
    expect(screen.getByText('Nutrition Information')).toBeInTheDocument();
    expect(screen.getByText('Per 100g and per serving (1 serving (200g))')).toBeInTheDocument();
    
    // Check for table headers
    expect(screen.getByText('Per 100g')).toBeInTheDocument();
    expect(screen.getByText('Per Serving')).toBeInTheDocument();
    expect(screen.getByText('%RI*')).toBeInTheDocument();
    
    // Check for energy values in both kJ and kcal
    expect(screen.getByText('1046kJ / 250kcal')).toBeInTheDocument();
    expect(screen.getByText('2092kJ / 500kcal')).toBeInTheDocument();
    
    // Check reference intake note
    expect(screen.getByText('*Reference intake of an average adult (8400 kJ/2000 kcal)')).toBeInTheDocument();
  });

  it('renders basic nutrition facts correctly', () => {
    render(<NutritionFactsPanel nutritionData={mockBasicData} format="Basic" />);
    
    // Check for basic format elements
    expect(screen.getByText('Nutrition Information')).toBeInTheDocument();
    expect(screen.getByText('Test Recipe - Per Serving')).toBeInTheDocument();
    
    // Check for nutrition values in colored boxes
    expect(screen.getByText('250')).toBeInTheDocument(); // Calories
    expect(screen.getByText('15.0g')).toBeInTheDocument(); // Protein
    expect(screen.getByText('30.0g')).toBeInTheDocument(); // Carbs
    expect(screen.getByText('10.0g')).toBeInTheDocument(); // Fat
    
    // Check for allergen badges
    expect(screen.getByText('Gluten')).toBeInTheDocument();
    expect(screen.getByText('Dairy')).toBeInTheDocument();
  });

  it('handles missing nutrition data gracefully', () => {
    render(<NutritionFactsPanel nutritionData={null} format="FDA" />);
    
    expect(screen.getByText('No nutrition data available')).toBeInTheDocument();
  });

  it('displays allergen information correctly', () => {
    render(<NutritionFactsPanel nutritionData={mockBasicData} format="Basic" />);
    
    // Check that allergens section is present
    expect(screen.getByText('Allergens:')).toBeInTheDocument();
    
    // Check that present allergens are shown
    expect(screen.getByText('Gluten')).toBeInTheDocument();
    expect(screen.getByText('Dairy')).toBeInTheDocument();
    
    // Check that absent allergens are not shown
    expect(screen.queryByText('Eggs')).not.toBeInTheDocument();
    expect(screen.queryByText('Nuts')).not.toBeInTheDocument();
  });

  it('calculates and displays daily values correctly for FDA format', () => {
    render(<NutritionFactsPanel nutritionData={mockFDAData} format="FDA" />);
    
    // Check that daily value percentages are displayed
    const dailyValueElements = screen.getAllByText(/%$/);
    expect(dailyValueElements.length).toBeGreaterThan(0);
    
    // Check specific daily values
    expect(screen.getByText('15%')).toBeInTheDocument(); // Fat
    expect(screen.getByText('20%')).toBeInTheDocument(); // Fiber and Sodium
    expect(screen.getByText('30%')).toBeInTheDocument(); // Protein
  });

  it('displays reference intakes correctly for EU format', () => {
    render(<NutritionFactsPanel nutritionData={mockEUData} format="EU" />);
    
    // Check that reference intake percentages are displayed
    expect(screen.getByText('25%')).toBeInTheDocument(); // Energy
    expect(screen.getByText('29%')).toBeInTheDocument(); // Fat
    expect(screen.getByText('60%')).toBeInTheDocument(); // Protein
    
    // Check for dash when no reference intake available
    expect(screen.getByText('-')).toBeInTheDocument(); // Fibre has no RI
  });

  it('formats nutrition values with correct precision', () => {
    render(<NutritionFactsPanel nutritionData={mockFDAData} format="FDA" />);
    
    // Check that values are formatted to 1 decimal place for grams
    expect(screen.getByText('10.0g')).toBeInTheDocument(); // Fat
    expect(screen.getByText('30.0g')).toBeInTheDocument(); // Carbs
    expect(screen.getByText('15.0g')).toBeInTheDocument(); // Protein
    
    // Check that sodium is formatted as whole number
    expect(screen.getByText('460mg')).toBeInTheDocument();
  });
});

describe('NutritionFactsPanel Accessibility', () => {
  it('has proper heading structure', () => {
    render(<NutritionFactsPanel nutritionData={mockFDAData} format="FDA" />);
    
    // Check for proper heading - the title is rendered as CardTitle, not a heading element
    const nutritionTitle = screen.getByText('Nutrition Facts');
    expect(nutritionTitle).toBeInTheDocument();
  });

  it('has readable text contrast', () => {
    render(<NutritionFactsPanel nutritionData={mockBasicData} format="Basic" />);
    
    // Check that text elements are present and readable
    const nutritionInfo = screen.getByText('Nutrition Information');
    expect(nutritionInfo).toBeInTheDocument();
    expect(nutritionInfo).toBeVisible();
  });
});

