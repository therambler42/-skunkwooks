import { Controller, Get, Render } from '@nestjs/common';

@Controller()
export class AppController {
  @Get()
  getHome() {
    return { message: 'SkunkWookS Auth Service' };
  }

  @Get('login')
  @Render('login')
  getLogin() {
    return { title: 'Login - SkunkWookS' };
  }
}

