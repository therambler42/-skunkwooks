import { Injectable, UnauthorizedException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { JwtService } from '@nestjs/jwt';
import { MagicLink } from '../entities/magic-link.entity';
import { User, UserRole } from '../entities/user.entity';
import { EmailService } from './email.service';
import * as crypto from 'crypto';

@Injectable()
export class AuthService {
  constructor(
    @InjectRepository(MagicLink)
    private magicLinkRepository: Repository<MagicLink>,
    @InjectRepository(User)
    private userRepository: Repository<User>,
    private jwtService: JwtService,
    private emailService: EmailService,
  ) {}

  async sendMagicLink(email: string): Promise<{ message: string }> {
    // Find or create user
    let user = await this.userRepository.findOne({ where: { email } });
    if (!user) {
      user = this.userRepository.create({
        email,
        role: UserRole.SUPPLIER, // Default role
      });
      await this.userRepository.save(user);
    }

    // Generate secure token
    const token = crypto.randomBytes(32).toString('hex');
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000); // 15 minutes

    // Clean up any existing magic links for this user
    await this.magicLinkRepository.delete({ userId: user.id });

    // Create new magic link
    const magicLink = this.magicLinkRepository.create({
      userId: user.id,
      token,
      expiresAt,
    });
    await this.magicLinkRepository.save(magicLink);

    // Send email
    await this.emailService.sendMagicLink(email, token);

    return { message: 'Magic link sent to your email' };
  }

  async verifyMagicLink(token: string): Promise<{ user: User; accessToken: string }> {
    const magicLink = await this.magicLinkRepository.findOne({
      where: { token },
    });

    if (!magicLink) {
      throw new UnauthorizedException('Invalid or expired magic link');
    }

    if (magicLink.expiresAt < new Date()) {
      await this.magicLinkRepository.delete({ id: magicLink.id });
      throw new UnauthorizedException('Magic link has expired');
    }

    const user = await this.userRepository.findOne({
      where: { id: magicLink.userId },
    });

    if (!user) {
      throw new UnauthorizedException('User not found');
    }

    // Clean up the used magic link
    await this.magicLinkRepository.delete({ id: magicLink.id });

    // Generate JWT token
    const payload = { sub: user.id, email: user.email, role: user.role };
    const accessToken = this.jwtService.sign(payload);

    return { user, accessToken };
  }

  getRoleRedirectUrl(role: UserRole): string {
    const baseUrl = process.env.FRONTEND_URL || 'http://localhost:3000';
    
    switch (role) {
      case UserRole.OWNER:
        return `${baseUrl}/dashboard/owner`;
      case UserRole.ADMIN:
        return `${baseUrl}/dashboard/admin`;
      case UserRole.MANAGER:
        return `${baseUrl}/dashboard/manager`;
      case UserRole.SUPPLIER:
        return `${baseUrl}/dashboard/supplier`;
      default:
        return `${baseUrl}/dashboard`;
    }
  }
}

