from flask import Flask, render_template, request, jsonify, redirect, make_response
from flask_cors import CORS
import secrets
import hashlib
import time
import os
import logging
import base64
import json

app = Flask(__name__)
app.config['SECRET_KEY'] = 'skunkwooks-super-secret-key-production-2025'

# Enable CORS
CORS(app, supports_credentials=True)

# In-memory storage for demo (replace with database in production)
users = {}
magic_links = {}

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def create_simple_token(user_data):
    """Create a simple base64 encoded token"""
    token_data = {
        'user_id': user_data['id'],
        'email': user_data['email'],
        'role': user_data['role'],
        'exp': time.time() + 86400  # 24 hours
    }
    token_json = json.dumps(token_data)
    token_b64 = base64.b64encode(token_json.encode()).decode()
    return token_b64

def verify_simple_token(token):
    """Verify a simple base64 encoded token"""
    try:
        token_json = base64.b64decode(token.encode()).decode()
        token_data = json.loads(token_json)
        
        if time.time() > token_data['exp']:
            return None
        
        return token_data
    except:
        return None

@app.route('/')
def home():
    return jsonify({"message": "SkunkWookS Auth Service"})

@app.route('/login')
def login_page():
    return render_template('login.html')

@app.route('/auth/magic-link', methods=['POST'])
def send_magic_link():
    try:
        data = request.get_json()
        email = data.get('email')
        
        if not email:
            return jsonify({"error": "Email is required"}), 400
        
        # Create or get user
        if email not in users:
            users[email] = {
                'id': hashlib.md5(email.encode()).hexdigest(),
                'email': email,
                'role': 'Supplier'  # Default role
            }
        
        # Generate magic link token
        token = secrets.token_hex(32)
        expires_at = time.time() + 900  # 15 minutes
        
        magic_links[token] = {
            'email': email,
            'expires_at': expires_at
        }
        
        # Always log magic link to console for easy access
        logger.info(f"=== MAGIC LINK GENERATED ===")
        logger.info(f"Email: {email}")
        logger.info(f"Magic Link URL: {magic_link_url}")
        logger.info(f"Token: {token}")
        logger.info(f"Expires: {time.strftime('%Y-%m-%d %H:%M:%S UTC', time.gmtime(expires_at))}")
        logger.info(f"============================")
        
        return jsonify({"message": "Magic link sent to your email"})
        
    except Exception as e:
        logger.error(f"Error sending magic link: {str(e)}")
        return jsonify({"error": "Failed to send magic link"}), 500

@app.route('/auth/verify')
def verify_magic_link():
    try:
        token = request.args.get('token')
        
        if not token or token not in magic_links:
            return jsonify({"error": "Invalid or expired magic link"}), 401
        
        link_data = magic_links[token]
        
        # Check if token is expired
        if time.time() > link_data['expires_at']:
            del magic_links[token]
            return jsonify({"error": "Magic link has expired"}), 401
        
        # Get user
        email = link_data['email']
        user = users[email]
        
        # Clean up used token
        del magic_links[token]
        
        # Create simple token
        access_token = create_simple_token(user)
        
        # Determine redirect URL based on role
        role_redirects = {
            'Owner': '/dashboard/owner',
            'Admin': '/dashboard/admin',
            'Manager': '/dashboard/manager',
            'Supplier': '/dashboard/supplier'
        }
        
        redirect_url = role_redirects.get(user['role'], '/dashboard')
        
        # Create response with token cookie
        response = make_response(redirect(redirect_url))
        response.set_cookie(
            'access_token',
            access_token,
            httponly=True,
            secure=True,
            samesite='Strict',
            max_age=86400  # 24 hours
        )
        
        return response
        
    except Exception as e:
        logger.error(f"Error verifying magic link: {str(e)}")
        return jsonify({"error": "Verification failed"}), 500

@app.route('/auth/logout', methods=['POST'])
def logout():
    response = make_response(jsonify({"message": "Logged out successfully"}))
    response.set_cookie('access_token', '', expires=0)
    return response

@app.route('/dashboard/<role>')
def dashboard(role):
    return jsonify({
        "message": f"Welcome to {role.title()} Dashboard",
        "role": role,
        "note": "This is a placeholder dashboard route"
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)

