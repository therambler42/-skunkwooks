# Slack Integration Guide

This comprehensive guide covers setting up a complete Slack integration, including app creation, authentication, bot functionality, and real-time messaging capabilities.

## Overview

Slack integration enables your application to interact with Slack workspaces, allowing you to send messages, create channels, manage users, and respond to events. The integration uses Slack's Web API, Events API, and Socket Mode for real-time communication.

## Prerequisites

Before starting, ensure you have:
- Slack workspace with admin privileges
- Node.js and TypeScript development environment
- Understanding of OAuth 2.0 flows
- HTTPS endpoint for production webhooks

## Step 1: Create Slack App

### 1.1 Access Slack API Console

1. Go to [Slack API Console](https://api.slack.com/apps)
2. Click "Create New App"
3. Choose "From scratch"
4. Enter app name and select workspace
5. Click "Create App"

### 1.2 Configure App Settings

#### Basic Information
- **App Name**: Descriptive name for your integration
- **Description**: Brief description of app functionality
- **App Icon**: Upload a 512x512 pixel icon
- **Background Color**: Choose brand color

#### OAuth & Permissions
Configure the following scopes:

**Bot Token Scopes:**
- `app_mentions:read` - View messages that directly mention your app
- `channels:history` - View messages in public channels
- `channels:read` - View basic information about public channels
- `chat:write` - Send messages as the app
- `commands` - Add shortcuts and/or slash commands
- `files:write` - Upload, edit, and delete files
- `groups:history` - View messages in private channels
- `groups:read` - View basic information about private channels
- `im:history` - View messages in direct messages
- `im:read` - View basic information about direct messages
- `im:write` - Start direct messages with people
- `mpim:history` - View messages in group direct messages
- `mpim:read` - View basic information about group direct messages
- `reactions:read` - View emoji reactions and their associated content
- `reactions:write` - Add and edit emoji reactions
- `users:read` - View people in the workspace

**User Token Scopes (if needed):**
- `identify` - View user's identity
- `channels:write` - Manage public channels

### 1.3 Note Your Credentials

Save these credentials securely:
- **Client ID**: Used for OAuth flow
- **Client Secret**: Used for token exchange
- **Signing Secret**: Used for webhook verification
- **Bot User OAuth Token**: Used for API calls

## Step 2: Environment Configuration

### 2.1 Environment Variables

Add the following variables to your `.env` file:

```bash
# Slack App Configuration
SLACK_CLIENT_ID=your_client_id_here
SLACK_CLIENT_SECRET=your_client_secret_here
SLACK_SIGNING_SECRET=your_signing_secret_here
SLACK_BOT_TOKEN=xoxb-your-bot-token

# OAuth Configuration
SLACK_REDIRECT_URI=https://your-app-domain.com/auth/slack/callback
SLACK_STATE_SECRET=your_state_secret_key

# App Configuration
SLACK_APP_TOKEN=xapp-your-app-token # For Socket Mode
SLACK_SOCKET_MODE=true # Enable for real-time events
SLACK_PORT=3000

# Webhook Configuration
SLACK_WEBHOOK_URL=https://your-app-domain.com/webhooks/slack
```

## Step 3: Implementation

### 3.1 Install Dependencies

```bash
npm install @slack/bolt @slack/web-api @slack/socket-mode @slack/oauth crypto-js express
npm install -D @types/express @types/node typescript
```

### 3.2 Slack Client Setup

```typescript
// src/slack/slack-client.ts
import { WebClient } from '@slack/web-api';
import { App } from '@slack/bolt';

export class SlackClient {
  private webClient: WebClient;
  private app: App;

  constructor(token?: string) {
    this.webClient = new WebClient(token || process.env.SLACK_BOT_TOKEN);
    
    this.app = new App({
      token: process.env.SLACK_BOT_TOKEN,
      signingSecret: process.env.SLACK_SIGNING_SECRET,
      socketMode: process.env.SLACK_SOCKET_MODE === 'true',
      appToken: process.env.SLACK_APP_TOKEN,
      port: parseInt(process.env.SLACK_PORT || '3000'),
    });

    this.setupEventHandlers();
  }

  // Get Slack app instance
  getApp(): App {
    return this.app;
  }

  // Get Web API client
  getWebClient(): WebClient {
    return this.webClient;
  }

  // Send message to channel
  async sendMessage(channel: string, text: string, blocks?: any[]): Promise<any> {
    try {
      const result = await this.webClient.chat.postMessage({
        channel,
        text,
        blocks,
      });
      return result;
    } catch (error) {
      console.error('Error sending message:', error);
      throw error;
    }
  }

  // Send direct message to user
  async sendDirectMessage(userId: string, text: string, blocks?: any[]): Promise<any> {
    try {
      // Open DM channel
      const dmChannel = await this.webClient.conversations.open({
        users: userId,
      });

      if (!dmChannel.channel?.id) {
        throw new Error('Failed to open DM channel');
      }

      return await this.sendMessage(dmChannel.channel.id, text, blocks);
    } catch (error) {
      console.error('Error sending DM:', error);
      throw error;
    }
  }

  // Get channel information
  async getChannelInfo(channelId: string): Promise<any> {
    try {
      const result = await this.webClient.conversations.info({
        channel: channelId,
      });
      return result.channel;
    } catch (error) {
      console.error('Error getting channel info:', error);
      throw error;
    }
  }

  // Get user information
  async getUserInfo(userId: string): Promise<any> {
    try {
      const result = await this.webClient.users.info({
        user: userId,
      });
      return result.user;
    } catch (error) {
      console.error('Error getting user info:', error);
      throw error;
    }
  }

  // List channels
  async listChannels(types: string = 'public_channel,private_channel'): Promise<any[]> {
    try {
      const result = await this.webClient.conversations.list({
        types,
        limit: 1000,
      });
      return result.channels || [];
    } catch (error) {
      console.error('Error listing channels:', error);
      throw error;
    }
  }

  // Create channel
  async createChannel(name: string, isPrivate: boolean = false): Promise<any> {
    try {
      const result = await this.webClient.conversations.create({
        name,
        is_private: isPrivate,
      });
      return result.channel;
    } catch (error) {
      console.error('Error creating channel:', error);
      throw error;
    }
  }

  // Invite users to channel
  async inviteToChannel(channelId: string, userIds: string[]): Promise<void> {
    try {
      await this.webClient.conversations.invite({
        channel: channelId,
        users: userIds.join(','),
      });
    } catch (error) {
      console.error('Error inviting users to channel:', error);
      throw error;
    }
  }

  // Upload file
  async uploadFile(
    channels: string,
    file: Buffer,
    filename: string,
    title?: string,
    initialComment?: string
  ): Promise<any> {
    try {
      const result = await this.webClient.files.upload({
        channels,
        file,
        filename,
        title,
        initial_comment: initialComment,
      });
      return result.file;
    } catch (error) {
      console.error('Error uploading file:', error);
      throw error;
    }
  }

  // Add reaction to message
  async addReaction(channel: string, timestamp: string, name: string): Promise<void> {
    try {
      await this.webClient.reactions.add({
        channel,
        timestamp,
        name,
      });
    } catch (error) {
      console.error('Error adding reaction:', error);
      throw error;
    }
  }

  // Setup event handlers
  private setupEventHandlers(): void {
    // Handle app mentions
    this.app.event('app_mention', async ({ event, say }) => {
      console.log('App mentioned:', event);
      await say(`Hello <@${event.user}>! You mentioned me.`);
    });

    // Handle direct messages
    this.app.message(async ({ message, say }) => {
      console.log('Direct message received:', message);
      
      if (message.subtype === undefined && message.text) {
        await say(`I received your message: "${message.text}"`);
      }
    });

    // Handle errors
    this.app.error(async (error) => {
      console.error('Slack app error:', error);
    });
  }

  // Start the app
  async start(): Promise<void> {
    try {
      await this.app.start();
      console.log('⚡️ Slack app is running!');
    } catch (error) {
      console.error('Failed to start Slack app:', error);
      throw error;
    }
  }

  // Stop the app
  async stop(): Promise<void> {
    try {
      await this.app.stop();
      console.log('Slack app stopped');
    } catch (error) {
      console.error('Error stopping Slack app:', error);
      throw error;
    }
  }
}
```

### 3.3 OAuth Implementation

```typescript
// src/slack/oauth-handler.ts
import { WebClient } from '@slack/web-api';
import crypto from 'crypto';

export interface SlackTokens {
  access_token: string;
  token_type: string;
  scope: string;
  bot_user_id: string;
  app_id: string;
  team: {
    id: string;
    name: string;
  };
  enterprise?: {
    id: string;
    name: string;
  };
  authed_user: {
    id: string;
    scope: string;
    access_token: string;
    token_type: string;
  };
}

export class SlackOAuthHandler {
  private clientId: string;
  private clientSecret: string;
  private redirectUri: string;
  private stateSecret: string;

  constructor() {
    this.clientId = process.env.SLACK_CLIENT_ID!;
    this.clientSecret = process.env.SLACK_CLIENT_SECRET!;
    this.redirectUri = process.env.SLACK_REDIRECT_URI!;
    this.stateSecret = process.env.SLACK_STATE_SECRET!;
  }

  // Generate authorization URL
  generateAuthUrl(scopes: string[], userScopes?: string[], state?: string): string {
    const stateParam = state || this.generateState();
    
    const params = new URLSearchParams({
      client_id: this.clientId,
      scope: scopes.join(','),
      redirect_uri: this.redirectUri,
      state: stateParam,
    });

    if (userScopes && userScopes.length > 0) {
      params.append('user_scope', userScopes.join(','));
    }

    return `https://slack.com/oauth/v2/authorize?${params.toString()}`;
  }

  // Exchange authorization code for tokens
  async exchangeCodeForTokens(code: string): Promise<SlackTokens> {
    const webClient = new WebClient();

    try {
      const result = await webClient.oauth.v2.access({
        client_id: this.clientId,
        client_secret: this.clientSecret,
        code,
        redirect_uri: this.redirectUri,
      });

      if (!result.ok) {
        throw new Error(`OAuth exchange failed: ${result.error}`);
      }

      return result as SlackTokens;
    } catch (error) {
      console.error('Token exchange error:', error);
      throw new Error('Failed to exchange authorization code for tokens');
    }
  }

  // Revoke tokens
  async revokeTokens(token: string): Promise<void> {
    const webClient = new WebClient(token);

    try {
      await webClient.auth.revoke();
    } catch (error) {
      console.error('Token revocation error:', error);
      throw new Error('Failed to revoke tokens');
    }
  }

  // Generate secure state parameter
  private generateState(): string {
    const timestamp = Date.now().toString();
    const random = crypto.randomBytes(16).toString('hex');
    const data = `${timestamp}:${random}`;
    
    return crypto
      .createHmac('sha256', this.stateSecret)
      .update(data)
      .digest('hex');
  }

  // Verify state parameter
  verifyState(receivedState: string, expectedState: string): boolean {
    try {
      return crypto.timingSafeEqual(
        Buffer.from(receivedState),
        Buffer.from(expectedState)
      );
    } catch (error) {
      return false;
    }
  }

  // Test token validity
  async testToken(token: string): Promise<any> {
    const webClient = new WebClient(token);

    try {
      const result = await webClient.auth.test();
      return result;
    } catch (error) {
      console.error('Token test error:', error);
      throw new Error('Invalid token');
    }
  }
}
```

### 3.4 Session Management

```typescript
// src/slack/session-manager.ts
import { SlackTokens } from './oauth-handler';
import { encrypt, decrypt } from '../utils/encryption';

export interface SlackSession {
  id: string;
  teamId: string;
  teamName: string;
  botUserId: string;
  botToken: string;
  userToken?: string;
  userId?: string;
  scope: string;
  userScope?: string;
  createdAt: Date;
  updatedAt: Date;
}

export class SlackSessionManager {
  private sessions: Map<string, SlackSession> = new Map();

  // Store session with encryption
  async storeSession(tokens: SlackTokens, userId?: string): Promise<string> {
    const sessionId = userId || `slack_${tokens.team.id}`;
    const now = new Date();

    const session: SlackSession = {
      id: sessionId,
      teamId: tokens.team.id,
      teamName: tokens.team.name,
      botUserId: tokens.bot_user_id,
      botToken: encrypt(tokens.access_token),
      userToken: tokens.authed_user.access_token ? encrypt(tokens.authed_user.access_token) : undefined,
      userId: tokens.authed_user.id,
      scope: tokens.scope,
      userScope: tokens.authed_user.scope,
      createdAt: now,
      updatedAt: now,
    };

    // Store by session ID and team ID
    this.sessions.set(sessionId, session);
    this.sessions.set(`team:${tokens.team.id}`, session);

    console.log(`Slack session stored for team: ${tokens.team.name} (${tokens.team.id})`);
    return sessionId;
  }

  // Retrieve session with decryption
  async getSession(sessionId: string): Promise<SlackSession | null> {
    const session = this.sessions.get(sessionId);
    if (!session) {
      return null;
    }

    return {
      ...session,
      botToken: decrypt(session.botToken),
      userToken: session.userToken ? decrypt(session.userToken) : undefined,
    };
  }

  // Get session by team ID
  async getSessionByTeam(teamId: string): Promise<SlackSession | null> {
    return this.getSession(`team:${teamId}`);
  }

  // Update session
  async updateSession(sessionId: string, updates: Partial<SlackSession>): Promise<void> {
    const session = this.sessions.get(sessionId);
    if (!session) {
      throw new Error('Session not found');
    }

    const updatedSession = {
      ...session,
      ...updates,
      updatedAt: new Date(),
    };

    this.sessions.set(sessionId, updatedSession);
    this.sessions.set(`team:${session.teamId}`, updatedSession);
  }

  // Delete session
  async deleteSession(sessionId: string): Promise<void> {
    const session = this.sessions.get(sessionId);
    if (session) {
      this.sessions.delete(sessionId);
      this.sessions.delete(`team:${session.teamId}`);
    }
  }

  // Get all sessions
  async getAllSessions(): Promise<SlackSession[]> {
    const sessions: SlackSession[] = [];
    for (const [key, session] of this.sessions.entries()) {
      if (!key.startsWith('team:')) {
        sessions.push({
          ...session,
          botToken: '[ENCRYPTED]',
          userToken: session.userToken ? '[ENCRYPTED]' : undefined,
        });
      }
    }
    return sessions;
  }

  // Validate session
  async validateSession(sessionId: string): Promise<SlackSession | null> {
    const session = await this.getSession(sessionId);
    if (!session) {
      return null;
    }

    // Test token validity
    try {
      const { SlackOAuthHandler } = await import('./oauth-handler');
      const oauthHandler = new SlackOAuthHandler();
      await oauthHandler.testToken(session.botToken);
      return session;
    } catch (error) {
      console.error('Session validation failed:', error);
      await this.deleteSession(sessionId);
      return null;
    }
  }
}
```

### 3.5 Message Builder

```typescript
// src/slack/message-builder.ts
export interface SlackBlock {
  type: string;
  [key: string]: any;
}

export interface SlackAttachment {
  color?: string;
  pretext?: string;
  author_name?: string;
  author_link?: string;
  author_icon?: string;
  title?: string;
  title_link?: string;
  text?: string;
  fields?: Array<{
    title: string;
    value: string;
    short?: boolean;
  }>;
  image_url?: string;
  thumb_url?: string;
  footer?: string;
  footer_icon?: string;
  ts?: number;
}

export class SlackMessageBuilder {
  private blocks: SlackBlock[] = [];
  private attachments: SlackAttachment[] = [];
  private text: string = '';

  // Set main text
  setText(text: string): SlackMessageBuilder {
    this.text = text;
    return this;
  }

  // Add header block
  addHeader(text: string): SlackMessageBuilder {
    this.blocks.push({
      type: 'header',
      text: {
        type: 'plain_text',
        text,
      },
    });
    return this;
  }

  // Add section block
  addSection(text: string, markdown: boolean = true): SlackMessageBuilder {
    this.blocks.push({
      type: 'section',
      text: {
        type: markdown ? 'mrkdwn' : 'plain_text',
        text,
      },
    });
    return this;
  }

  // Add section with accessory
  addSectionWithAccessory(text: string, accessory: any): SlackMessageBuilder {
    this.blocks.push({
      type: 'section',
      text: {
        type: 'mrkdwn',
        text,
      },
      accessory,
    });
    return this;
  }

  // Add button
  addButton(text: string, actionId: string, value?: string, style?: 'primary' | 'danger'): SlackMessageBuilder {
    const button = {
      type: 'button',
      text: {
        type: 'plain_text',
        text,
      },
      action_id: actionId,
      value,
      style,
    };

    // Find existing actions block or create new one
    let actionsBlock = this.blocks.find(block => block.type === 'actions');
    if (!actionsBlock) {
      actionsBlock = {
        type: 'actions',
        elements: [],
      };
      this.blocks.push(actionsBlock);
    }

    actionsBlock.elements.push(button);
    return this;
  }

  // Add select menu
  addSelectMenu(
    placeholder: string,
    actionId: string,
    options: Array<{ text: string; value: string }>
  ): SlackMessageBuilder {
    const selectMenu = {
      type: 'static_select',
      placeholder: {
        type: 'plain_text',
        text: placeholder,
      },
      action_id: actionId,
      options: options.map(option => ({
        text: {
          type: 'plain_text',
          text: option.text,
        },
        value: option.value,
      })),
    };

    // Find existing actions block or create new one
    let actionsBlock = this.blocks.find(block => block.type === 'actions');
    if (!actionsBlock) {
      actionsBlock = {
        type: 'actions',
        elements: [],
      };
      this.blocks.push(actionsBlock);
    }

    actionsBlock.elements.push(selectMenu);
    return this;
  }

  // Add divider
  addDivider(): SlackMessageBuilder {
    this.blocks.push({
      type: 'divider',
    });
    return this;
  }

  // Add context
  addContext(elements: string[]): SlackMessageBuilder {
    this.blocks.push({
      type: 'context',
      elements: elements.map(text => ({
        type: 'mrkdwn',
        text,
      })),
    });
    return this;
  }

  // Add image
  addImage(imageUrl: string, altText: string, title?: string): SlackMessageBuilder {
    const imageBlock: SlackBlock = {
      type: 'image',
      image_url: imageUrl,
      alt_text: altText,
    };

    if (title) {
      imageBlock.title = {
        type: 'plain_text',
        text: title,
      };
    }

    this.blocks.push(imageBlock);
    return this;
  }

  // Add fields section
  addFields(fields: Array<{ title: string; value: string; short?: boolean }>): SlackMessageBuilder {
    this.blocks.push({
      type: 'section',
      fields: fields.map(field => ({
        type: 'mrkdwn',
        text: `*${field.title}*\n${field.value}`,
      })),
    });
    return this;
  }

  // Add attachment (legacy)
  addAttachment(attachment: SlackAttachment): SlackMessageBuilder {
    this.attachments.push(attachment);
    return this;
  }

  // Build message object
  build(): any {
    const message: any = {
      text: this.text,
    };

    if (this.blocks.length > 0) {
      message.blocks = this.blocks;
    }

    if (this.attachments.length > 0) {
      message.attachments = this.attachments;
    }

    return message;
  }

  // Reset builder
  reset(): SlackMessageBuilder {
    this.blocks = [];
    this.attachments = [];
    this.text = '';
    return this;
  }

  // Create notification message
  static createNotification(
    title: string,
    message: string,
    color: 'good' | 'warning' | 'danger' = 'good'
  ): any {
    return new SlackMessageBuilder()
      .setText(title)
      .addAttachment({
        color,
        text: message,
        ts: Math.floor(Date.now() / 1000),
      })
      .build();
  }

  // Create rich message with actions
  static createRichMessage(
    title: string,
    description: string,
    actions: Array<{ text: string; actionId: string; value?: string; style?: 'primary' | 'danger' }>
  ): any {
    const builder = new SlackMessageBuilder()
      .addHeader(title)
      .addSection(description);

    actions.forEach(action => {
      builder.addButton(action.text, action.actionId, action.value, action.style);
    });

    return builder.build();
  }

  // Create status message
  static createStatusMessage(
    status: 'success' | 'warning' | 'error',
    title: string,
    details?: string
  ): any {
    const emoji = {
      success: ':white_check_mark:',
      warning: ':warning:',
      error: ':x:',
    };

    const color = {
      success: 'good',
      warning: 'warning',
      error: 'danger',
    };

    const builder = new SlackMessageBuilder()
      .addSection(`${emoji[status]} *${title}*`);

    if (details) {
      builder.addSection(details);
    }

    return builder.build();
  }
}
```

## Step 4: Express Route Handlers

### 4.1 OAuth Routes

```typescript
// src/routes/slack-auth.ts
import express from 'express';
import { SlackOAuthHandler } from '../slack/oauth-handler';
import { SlackSessionManager } from '../slack/session-manager';

const router = express.Router();
const oauthHandler = new SlackOAuthHandler();
const sessionManager = new SlackSessionManager();

// Store state for CSRF protection
const stateStore = new Map<string, { timestamp: number; userId?: string }>();

// Initiate OAuth flow
router.get('/install', async (req, res) => {
  try {
    const { userId } = req.query;
    const state = generateSecureState();
    
    // Store state
    stateStore.set(state, {
      timestamp: Date.now(),
      userId: userId as string,
    });

    // Clean up old states
    cleanupExpiredStates();

    // Define required scopes
    const botScopes = [
      'app_mentions:read',
      'channels:history',
      'channels:read',
      'chat:write',
      'commands',
      'files:write',
      'groups:history',
      'groups:read',
      'im:history',
      'im:read',
      'im:write',
      'mpim:history',
      'mpim:read',
      'reactions:read',
      'reactions:write',
      'users:read',
    ];

    const userScopes = [
      'identify',
    ];

    const authUrl = oauthHandler.generateAuthUrl(botScopes, userScopes, state);
    res.redirect(authUrl);

  } catch (error) {
    console.error('OAuth initiation error:', error);
    res.status(500).json({
      error: 'Failed to initiate Slack installation',
      message: 'Please try again or contact support'
    });
  }
});

// Handle OAuth callback
router.get('/callback', async (req, res) => {
  const { code, state, error } = req.query;

  try {
    // Handle OAuth errors
    if (error) {
      console.error('OAuth error:', error);
      return res.status(400).json({
        error: 'Slack authorization failed',
        details: error
      });
    }

    // Validate required parameters
    if (!code || !state) {
      return res.status(400).json({
        error: 'Missing required OAuth parameters'
      });
    }

    // Verify state parameter
    const stateData = stateStore.get(state as string);
    if (!stateData) {
      return res.status(400).json({
        error: 'Invalid or expired state parameter'
      });
    }

    // Clean up used state
    stateStore.delete(state as string);

    // Exchange code for tokens
    const tokens = await oauthHandler.exchangeCodeForTokens(code as string);

    // Store session
    const sessionId = await sessionManager.storeSession(tokens, stateData.userId);

    // Redirect to success page
    res.redirect(`/slack/success?session=${sessionId}&team=${tokens.team.id}`);

  } catch (error) {
    console.error('OAuth callback error:', error);
    res.status(500).json({
      error: 'Failed to complete Slack authorization',
      message: 'Please try again or contact support'
    });
  }
});

// Uninstall Slack app
router.post('/uninstall', async (req, res) => {
  try {
    const { sessionId } = req.body;

    if (!sessionId) {
      return res.status(400).json({
        error: 'Session ID is required'
      });
    }

    const session = await sessionManager.getSession(sessionId);
    if (session) {
      // Revoke tokens
      await oauthHandler.revokeTokens(session.botToken);
      
      // Delete session
      await sessionManager.deleteSession(sessionId);
    }

    res.json({
      success: true,
      message: 'Slack app uninstalled successfully'
    });

  } catch (error) {
    console.error('Uninstall error:', error);
    res.status(500).json({
      error: 'Failed to uninstall Slack app'
    });
  }
});

// Get installation status
router.get('/status/:sessionId', async (req, res) => {
  try {
    const { sessionId } = req.params;
    const session = await sessionManager.validateSession(sessionId);

    if (!session) {
      return res.json({
        installed: false,
        message: 'No active Slack installation'
      });
    }

    res.json({
      installed: true,
      teamId: session.teamId,
      teamName: session.teamName,
      botUserId: session.botUserId,
      scope: session.scope,
    });

  } catch (error) {
    console.error('Status check error:', error);
    res.status(500).json({
      error: 'Failed to check installation status'
    });
  }
});

// Helper functions
function generateSecureState(): string {
  return require('crypto').randomBytes(32).toString('hex');
}

function cleanupExpiredStates(): void {
  const tenMinutesAgo = Date.now() - (10 * 60 * 1000);
  for (const [state, data] of stateStore.entries()) {
    if (data.timestamp < tenMinutesAgo) {
      stateStore.delete(state);
    }
  }
}

export default router;
```

### 4.2 API Routes

```typescript
// src/routes/slack-api.ts
import express from 'express';
import { SlackClient } from '../slack/slack-client';
import { SlackSessionManager } from '../slack/session-manager';
import { SlackMessageBuilder } from '../slack/message-builder';

const router = express.Router();
const sessionManager = new SlackSessionManager();

// Middleware to validate session
async function validateSlackSession(req: any, res: any, next: any) {
  try {
    const sessionId = req.headers['x-slack-session'] || req.query.session;
    
    if (!sessionId) {
      return res.status(401).json({ error: 'Missing Slack session' });
    }

    const session = await sessionManager.validateSession(sessionId);
    if (!session) {
      return res.status(401).json({ error: 'Invalid or expired Slack session' });
    }

    req.slackSession = session;
    req.slackClient = new SlackClient(session.botToken);
    next();
  } catch (error) {
    res.status(500).json({ error: 'Session validation failed' });
  }
}

// Send message to channel
router.post('/message', validateSlackSession, async (req, res) => {
  try {
    const { channel, text, blocks } = req.body;
    const slackClient = req.slackClient;

    if (!channel || !text) {
      return res.status(400).json({
        error: 'Channel and text are required'
      });
    }

    const result = await slackClient.sendMessage(channel, text, blocks);
    
    res.json({
      success: true,
      message: result.message,
      timestamp: result.ts,
    });

  } catch (error) {
    console.error('Send message error:', error);
    res.status(500).json({
      error: 'Failed to send message',
      message: error.message
    });
  }
});

// Send direct message
router.post('/dm', validateSlackSession, async (req, res) => {
  try {
    const { userId, text, blocks } = req.body;
    const slackClient = req.slackClient;

    if (!userId || !text) {
      return res.status(400).json({
        error: 'User ID and text are required'
      });
    }

    const result = await slackClient.sendDirectMessage(userId, text, blocks);
    
    res.json({
      success: true,
      message: result.message,
      timestamp: result.ts,
    });

  } catch (error) {
    console.error('Send DM error:', error);
    res.status(500).json({
      error: 'Failed to send direct message',
      message: error.message
    });
  }
});

// Get channels
router.get('/channels', validateSlackSession, async (req, res) => {
  try {
    const slackClient = req.slackClient;
    const channels = await slackClient.listChannels();
    
    res.json({
      success: true,
      channels: channels.map(channel => ({
        id: channel.id,
        name: channel.name,
        is_private: channel.is_private,
        is_member: channel.is_member,
        num_members: channel.num_members,
      })),
    });

  } catch (error) {
    console.error('Get channels error:', error);
    res.status(500).json({
      error: 'Failed to get channels',
      message: error.message
    });
  }
});

// Create channel
router.post('/channels', validateSlackSession, async (req, res) => {
  try {
    const { name, isPrivate } = req.body;
    const slackClient = req.slackClient;

    if (!name) {
      return res.status(400).json({
        error: 'Channel name is required'
      });
    }

    const channel = await slackClient.createChannel(name, isPrivate);
    
    res.json({
      success: true,
      channel: {
        id: channel.id,
        name: channel.name,
        is_private: channel.is_private,
      },
    });

  } catch (error) {
    console.error('Create channel error:', error);
    res.status(500).json({
      error: 'Failed to create channel',
      message: error.message
    });
  }
});

// Upload file
router.post('/upload', validateSlackSession, async (req, res) => {
  try {
    const { channels, filename, title, initialComment } = req.body;
    const slackClient = req.slackClient;

    if (!req.file || !channels) {
      return res.status(400).json({
        error: 'File and channels are required'
      });
    }

    const file = await slackClient.uploadFile(
      channels,
      req.file.buffer,
      filename || req.file.originalname,
      title,
      initialComment
    );
    
    res.json({
      success: true,
      file: {
        id: file.id,
        name: file.name,
        url: file.url_private,
      },
    });

  } catch (error) {
    console.error('Upload file error:', error);
    res.status(500).json({
      error: 'Failed to upload file',
      message: error.message
    });
  }
});

// Send notification
router.post('/notify', validateSlackSession, async (req, res) => {
  try {
    const { channel, title, message, type } = req.body;
    const slackClient = req.slackClient;

    if (!channel || !title || !message) {
      return res.status(400).json({
        error: 'Channel, title, and message are required'
      });
    }

    const notification = SlackMessageBuilder.createNotification(title, message, type);
    const result = await slackClient.sendMessage(channel, title, notification.blocks);
    
    res.json({
      success: true,
      timestamp: result.ts,
    });

  } catch (error) {
    console.error('Send notification error:', error);
    res.status(500).json({
      error: 'Failed to send notification',
      message: error.message
    });
  }
});

export default router;
```

## Step 5: Testing and Validation

### Test Your Integration

1. **OAuth Flow**: Test complete installation process
2. **Message Sending**: Verify message delivery to channels and DMs
3. **Event Handling**: Test app mentions and direct messages
4. **File Upload**: Test file sharing functionality
5. **Interactive Components**: Test buttons and select menus

### Example Test Script

```typescript
// tests/slack-integration.test.ts
import { SlackClient } from '../src/slack/slack-client';
import { SlackMessageBuilder } from '../src/slack/message-builder';

describe('Slack Integration', () => {
  let slackClient: SlackClient;

  beforeEach(() => {
    slackClient = new SlackClient('test-token');
  });

  test('should build message with blocks', () => {
    const message = new SlackMessageBuilder()
      .addHeader('Test Header')
      .addSection('Test section content')
      .addButton('Click Me', 'test_action', 'test_value')
      .build();

    expect(message.blocks).toHaveLength(2);
    expect(message.blocks[0].type).toBe('header');
    expect(message.blocks[1].type).toBe('actions');
  });

  test('should create notification message', () => {
    const notification = SlackMessageBuilder.createNotification(
      'Test Notification',
      'This is a test message',
      'good'
    );

    expect(notification.text).toBe('Test Notification');
    expect(notification.attachments).toHaveLength(1);
    expect(notification.attachments[0].color).toBe('good');
  });
});
```

## Security Best Practices

1. **Token Storage**: Encrypt tokens at rest
2. **HTTPS Only**: Use HTTPS for all communications
3. **State Verification**: Always verify OAuth state parameter
4. **Signature Verification**: Verify webhook signatures
5. **Scope Limitation**: Request only necessary scopes
6. **Error Logging**: Log errors without exposing sensitive data

## Next Steps

- [Slack Slash Commands](./slack-commands.md) - Custom command implementation
- [Shopify Integration](./shopify.md) - E-commerce integration
- [QuickBooks Integration](./quickbooks.md) - Accounting integration

