# Integration Documentation Deployment Guide

This document provides instructions for deploying the integration documentation to your marketing site with automated CI/CD pipeline.

## Overview

The documentation is built using VitePress and deployed automatically via GitHub Actions. The deployment pipeline includes:

- **Automated builds** on every push to main branch
- **PR previews** for reviewing changes before merge
- **Accessibility testing** with Lighthouse CI (target: 90+ score)
- **Quality checks** including linting and spell checking
- **Staging and production** deployment environments

## Repository Setup

### 1. GitHub Repository Configuration

1. **Create a new repository** for your integration documentation
2. **Enable GitHub Pages** in repository settings:
   - Go to Settings → Pages
   - Source: Deploy from a branch
   - Branch: `gh-pages` / `/ (root)`
3. **Set up branch protection** for main branch (recommended)

### 2. Environment Variables

Configure the following secrets in your GitHub repository:

```bash
# Repository Settings → Secrets and variables → Actions

# Required for deployment
GITHUB_TOKEN  # Automatically provided by GitHub

# Optional: Custom domain
CNAME_DOMAIN=docs.yourcompany.com
```

### 3. Repository Structure

```
your-repo/
├── .github/
│   └── workflows/
│       ├── deploy.yml          # Main deployment workflow
│       ├── pr-preview.yml      # PR preview workflow
│       └── quality.yml         # Quality checks workflow
├── docs/
│   ├── .vitepress/
│   │   ├── config.mjs         # VitePress configuration
│   │   └── dist/              # Build output (generated)
│   ├── integrations/
│   │   ├── index.md           # Integrations overview
│   │   ├── shopify.md         # Shopify guide
│   │   ├── quickbooks.md      # QuickBooks guide
│   │   └── slack.md           # Slack guide
│   └── index.md               # Homepage
├── .lighthouserc.json         # Lighthouse CI config
├── .cspell.json              # Spell check config
├── .markdownlint.json        # Markdown linting config
└── package.json              # Node.js dependencies
```

## Deployment Workflows

### Main Deployment (deploy.yml)

Triggered on push to main branch:

1. **Build**: Installs dependencies and builds documentation
2. **Accessibility Test**: Runs axe-core accessibility tests
3. **Deploy Staging**: Deploys to `gh-pages-staging` branch
4. **Deploy Production**: Deploys to `gh-pages` branch (requires manual approval)
5. **Lighthouse CI**: Runs comprehensive performance and accessibility tests

### PR Preview (pr-preview.yml)

Triggered on pull requests:

1. **Build Preview**: Creates a preview build of the documentation
2. **Deploy Preview**: Deploys to `gh-pages-preview` branch under `/pr-{number}/`
3. **Comment PR**: Adds a comment with preview link
4. **Cleanup**: Removes preview when PR is closed

### Quality Checks (quality.yml)

Runs on all pushes and PRs:

1. **Lint**: Markdown linting and link checking
2. **Spell Check**: Spell checking with custom dictionary
3. **Accessibility**: Basic accessibility testing with axe-core
4. **Performance**: Bundle size analysis and optimization checks

## Local Development

### Prerequisites

```bash
# Install Node.js 18+
node --version  # Should be 18.0.0 or higher
npm --version   # Should be 9.0.0 or higher
```

### Setup

```bash
# Clone repository
git clone https://github.com/your-org/integrations-docs.git
cd integrations-docs

# Install dependencies
npm install

# Start development server
npm run docs:dev
```

### Available Scripts

```bash
# Development
npm run docs:dev      # Start dev server with hot reload
npm run docs:build    # Build for production
npm run docs:preview  # Preview production build
npm run docs:serve    # Serve built files on port 3000

# Quality checks (install tools first)
npm install -g markdownlint-cli markdown-link-check @axe-core/cli
markdownlint docs/**/*.md
markdown-link-check docs/**/*.md
axe http://localhost:3000/integrations/
```

## Accessibility Compliance

### Target Scores

The documentation must achieve:
- **Accessibility**: 90+ (WCAG 2.1 AA compliance)
- **Best Practices**: 90+
- **SEO**: 90+

### Accessibility Features

1. **Semantic HTML**: Proper heading hierarchy and landmarks
2. **Keyboard Navigation**: Full keyboard accessibility
3. **Screen Reader Support**: ARIA labels and descriptions
4. **Color Contrast**: WCAG AA compliant color ratios
5. **Responsive Design**: Mobile-friendly layouts
6. **Focus Management**: Visible focus indicators

### Testing Accessibility

```bash
# Install accessibility testing tools
npm install -g @axe-core/cli lighthouse

# Test specific pages
axe http://localhost:3000/integrations/
axe http://localhost:3000/integrations/integrations/shopify.html

# Run Lighthouse audit
lighthouse http://localhost:3000/integrations/ --only-categories=accessibility
```

## Deployment Environments

### Staging Environment

- **URL**: `https://your-org.github.io/integrations-docs/integrations/`
- **Branch**: `gh-pages-staging`
- **Purpose**: Testing and review before production
- **Auto-deploy**: On every push to main

### Production Environment

- **URL**: `https://docs.yourcompany.com/integrations/` (with custom domain)
- **Branch**: `gh-pages`
- **Purpose**: Live documentation for users
- **Deploy**: Manual approval required

### PR Previews

- **URL**: `https://your-org.github.io/integrations-docs/pr-{number}/integrations/`
- **Branch**: `gh-pages-preview`
- **Purpose**: Review changes before merge
- **Lifecycle**: Created on PR open, updated on push, deleted on PR close

## Custom Domain Setup

### 1. DNS Configuration

Add a CNAME record pointing to your GitHub Pages domain:

```
docs.yourcompany.com → your-org.github.io
```

### 2. GitHub Pages Configuration

1. Go to repository Settings → Pages
2. Custom domain: `docs.yourcompany.com`
3. Enforce HTTPS: ✅ (recommended)

### 3. Update Workflow

Modify `.github/workflows/deploy.yml`:

```yaml
- name: Deploy to production
  uses: peaceiris/actions-gh-pages@v3
  with:
    github_token: ${{ secrets.GITHUB_TOKEN }}
    publish_dir: ./dist
    publish_branch: gh-pages
    destination_dir: integrations
    cname: docs.yourcompany.com  # Add this line
```

## Monitoring and Maintenance

### 1. GitHub Actions Monitoring

Monitor workflow runs in the Actions tab:
- **Build failures**: Check logs for dependency or build issues
- **Accessibility failures**: Review Lighthouse reports
- **Deployment failures**: Verify permissions and branch settings

### 2. Performance Monitoring

Track key metrics:
- **Build time**: Should be under 5 minutes
- **Bundle size**: Monitor for unexpected increases
- **Lighthouse scores**: Maintain 90+ accessibility score

### 3. Content Updates

For content updates:
1. Create feature branch from main
2. Make changes to markdown files
3. Test locally with `npm run docs:dev`
4. Create pull request
5. Review PR preview
6. Merge to main for automatic deployment

## Troubleshooting

### Common Issues

1. **Build Failures**
   ```bash
   # Check Node.js version
   node --version
   
   # Clear cache and reinstall
   rm -rf node_modules package-lock.json
   npm install
   ```

2. **Accessibility Test Failures**
   ```bash
   # Run local accessibility test
   npm run docs:build
   npm run docs:serve &
   axe http://localhost:3000/integrations/
   ```

3. **Deployment Issues**
   ```bash
   # Check GitHub Pages settings
   # Verify branch permissions
   # Review workflow logs
   ```

### Getting Help

- **GitHub Issues**: Report bugs and feature requests
- **Discussions**: Ask questions and share feedback
- **Documentation**: Check VitePress documentation for advanced configuration

## Security Considerations

1. **Secrets Management**: Never commit API keys or sensitive data
2. **Branch Protection**: Require PR reviews for main branch
3. **Dependency Updates**: Regularly update npm dependencies
4. **Access Control**: Limit repository access to necessary team members

## Next Steps

1. **Customize Branding**: Update colors, logos, and styling
2. **Add Analytics**: Integrate Google Analytics or similar
3. **SEO Optimization**: Add meta tags and structured data
4. **Content Expansion**: Add more integration guides
5. **User Feedback**: Implement feedback collection system

---

*For technical support, contact the development team or create an issue in the repository.*

