# Custom Connectors Guide

This comprehensive guide explains how to build custom integrations using our connector framework, enabling you to connect with any API or service that isn't covered by our standard integrations.

## Overview

Our custom connector framework provides a standardized way to build integrations with third-party services. It includes authentication handling, data transformation, error management, and webhook support, allowing you to focus on the business logic specific to your integration.

## Prerequisites

Before building a custom connector, ensure you have:
- Node.js and TypeScript development environment
- Understanding of the target API you want to integrate
- API credentials for the target service
- Knowledge of OAuth 2.0 flows (if applicable)
- Familiarity with webhook concepts

## Architecture Overview

### Connector Components

```typescript
// Core connector interface
interface IConnector {
  // Authentication
  authenticate(credentials: any): Promise<AuthResult>;
  refreshToken?(refreshToken: string): Promise<AuthResult>;
  
  // Data operations
  getData(endpoint: string, params?: any): Promise<any>;
  postData(endpoint: string, data: any): Promise<any>;
  putData(endpoint: string, data: any): Promise<any>;
  deleteData(endpoint: string): Promise<any>;
  
  // Webhook support
  setupWebhooks?(endpoints: string[]): Promise<void>;
  handleWebhook?(payload: any): Promise<void>;
  
  // Health check
  healthCheck(): Promise<boolean>;
}
```

### Framework Structure

```
src/
├── connectors/
│   ├── base/
│   │   ├── base-connector.ts
│   │   ├── auth-handler.ts
│   │   └── webhook-handler.ts
│   ├── custom/
│   │   └── your-custom-connector/
│   │       ├── connector.ts
│   │       ├── auth.ts
│   │       ├── api-client.ts
│   │       └── webhooks.ts
│   └── registry.ts
├── types/
│   ├── connector.ts
│   └── auth.ts
└── utils/
    ├── encryption.ts
    ├── validation.ts
    └── rate-limiter.ts
```

## Step 1: Base Connector Framework

### 1.1 Base Connector Class

```typescript
// src/connectors/base/base-connector.ts
import { EventEmitter } from 'events';
import { AuthHandler } from './auth-handler';
import { WebhookHandler } from './webhook-handler';
import { RateLimiter } from '../../utils/rate-limiter';

export interface ConnectorConfig {
  name: string;
  version: string;
  baseUrl: string;
  authType: 'oauth2' | 'api_key' | 'basic' | 'custom';
  rateLimits?: {
    requests: number;
    window: number;
  };
  retryConfig?: {
    maxRetries: number;
    backoffMultiplier: number;
  };
}

export interface AuthResult {
  success: boolean;
  accessToken?: string;
  refreshToken?: string;
  expiresAt?: Date;
  error?: string;
}

export abstract class BaseConnector extends EventEmitter {
  protected config: ConnectorConfig;
  protected authHandler: AuthHandler;
  protected webhookHandler?: WebhookHandler;
  protected rateLimiter: RateLimiter;
  protected isAuthenticated: boolean = false;

  constructor(config: ConnectorConfig) {
    super();
    this.config = config;
    this.authHandler = new AuthHandler(config);
    this.rateLimiter = new RateLimiter(
      config.rateLimits?.requests || 100,
      config.rateLimits?.window || 60000
    );

    if (this.supportsWebhooks()) {
      this.webhookHandler = new WebhookHandler(config);
    }
  }

  // Abstract methods to be implemented by custom connectors
  abstract authenticate(credentials: any): Promise<AuthResult>;
  abstract getData(endpoint: string, params?: any): Promise<any>;
  abstract postData(endpoint: string, data: any): Promise<any>;

  // Optional methods with default implementations
  async putData(endpoint: string, data: any): Promise<any> {
    throw new Error('PUT operations not supported by this connector');
  }

  async deleteData(endpoint: string): Promise<any> {
    throw new Error('DELETE operations not supported by this connector');
  }

  async refreshToken(refreshToken: string): Promise<AuthResult> {
    return this.authHandler.refreshToken(refreshToken);
  }

  async healthCheck(): Promise<boolean> {
    try {
      // Default health check - override in custom connector if needed
      await this.getData('/health', {});
      return true;
    } catch (error) {
      return false;
    }
  }

  // Webhook support
  supportsWebhooks(): boolean {
    return false; // Override in custom connector
  }

  async setupWebhooks(endpoints: string[]): Promise<void> {
    if (!this.webhookHandler) {
      throw new Error('Webhooks not supported by this connector');
    }
    await this.webhookHandler.setup(endpoints);
  }

  async handleWebhook(payload: any): Promise<void> {
    if (!this.webhookHandler) {
      throw new Error('Webhooks not supported by this connector');
    }
    await this.webhookHandler.handle(payload);
  }

  // Utility methods
  protected async makeRequest(
    method: string,
    endpoint: string,
    data?: any,
    headers?: Record<string, string>
  ): Promise<any> {
    // Check rate limits
    if (!this.rateLimiter.canMakeRequest()) {
      const waitTime = this.rateLimiter.getWaitTime();
      throw new Error(`Rate limit exceeded. Wait ${waitTime}ms before retrying.`);
    }

    // Check authentication
    if (!this.isAuthenticated) {
      throw new Error('Connector not authenticated');
    }

    // Make HTTP request with retry logic
    return this.executeWithRetry(async () => {
      const response = await this.httpRequest(method, endpoint, data, headers);
      this.emit('request', { method, endpoint, status: response.status });
      return response.data;
    });
  }

  private async executeWithRetry<T>(operation: () => Promise<T>): Promise<T> {
    const maxRetries = this.config.retryConfig?.maxRetries || 3;
    const backoffMultiplier = this.config.retryConfig?.backoffMultiplier || 2;
    
    let lastError: Error;
    
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        return await operation();
      } catch (error) {
        lastError = error;
        
        if (attempt === maxRetries) {
          break;
        }

        // Check if error is retryable
        if (!this.isRetryableError(error)) {
          throw error;
        }

        // Calculate delay
        const delay = Math.pow(backoffMultiplier, attempt) * 1000;
        await this.sleep(delay);
      }
    }

    throw lastError!;
  }

  private isRetryableError(error: any): boolean {
    // Retry on network errors and 5xx status codes
    return (
      error.code === 'ECONNRESET' ||
      error.code === 'ETIMEDOUT' ||
      (error.response && error.response.status >= 500)
    );
  }

  private sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  private async httpRequest(
    method: string,
    endpoint: string,
    data?: any,
    headers?: Record<string, string>
  ): Promise<any> {
    const axios = (await import('axios')).default;
    
    const config = {
      method,
      url: `${this.config.baseUrl}${endpoint}`,
      data,
      headers: {
        'Content-Type': 'application/json',
        ...headers,
      },
    };

    return axios(config);
  }

  // Event methods
  onError(callback: (error: Error) => void): void {
    this.on('error', callback);
  }

  onRequest(callback: (details: any) => void): void {
    this.on('request', callback);
  }

  onWebhook(callback: (payload: any) => void): void {
    this.on('webhook', callback);
  }
}
```

### 1.2 Authentication Handler

```typescript
// src/connectors/base/auth-handler.ts
import { ConnectorConfig, AuthResult } from './base-connector';

export class AuthHandler {
  private config: ConnectorConfig;

  constructor(config: ConnectorConfig) {
    this.config = config;
  }

  async refreshToken(refreshToken: string): Promise<AuthResult> {
    switch (this.config.authType) {
      case 'oauth2':
        return this.refreshOAuth2Token(refreshToken);
      
      case 'api_key':
        // API keys don't typically need refresh
        return { success: true };
      
      case 'basic':
        // Basic auth doesn't need refresh
        return { success: true };
      
      default:
        throw new Error(`Unsupported auth type: ${this.config.authType}`);
    }
  }

  private async refreshOAuth2Token(refreshToken: string): Promise<AuthResult> {
    try {
      const axios = (await import('axios')).default;
      
      const response = await axios.post(`${this.config.baseUrl}/oauth/token`, {
        grant_type: 'refresh_token',
        refresh_token: refreshToken,
        client_id: process.env[`${this.config.name.toUpperCase()}_CLIENT_ID`],
        client_secret: process.env[`${this.config.name.toUpperCase()}_CLIENT_SECRET`],
      });

      const { access_token, refresh_token, expires_in } = response.data;

      return {
        success: true,
        accessToken: access_token,
        refreshToken: refresh_token,
        expiresAt: new Date(Date.now() + expires_in * 1000),
      };
    } catch (error) {
      return {
        success: false,
        error: error.message,
      };
    }
  }
}
```

### 1.3 Webhook Handler

```typescript
// src/connectors/base/webhook-handler.ts
import crypto from 'crypto';
import { ConnectorConfig } from './base-connector';

export class WebhookHandler {
  private config: ConnectorConfig;

  constructor(config: ConnectorConfig) {
    this.config = config;
  }

  async setup(endpoints: string[]): Promise<void> {
    // Override in custom connector to register webhooks
    console.log(`Setting up webhooks for ${this.config.name}:`, endpoints);
  }

  async handle(payload: any): Promise<void> {
    // Override in custom connector to process webhook payload
    console.log(`Handling webhook for ${this.config.name}:`, payload);
  }

  verifySignature(payload: string, signature: string, secret: string): boolean {
    const expectedSignature = crypto
      .createHmac('sha256', secret)
      .update(payload)
      .digest('hex');

    return crypto.timingSafeEqual(
      Buffer.from(signature),
      Buffer.from(expectedSignature)
    );
  }
}
```

## Step 2: Building a Custom Connector

### 2.1 Example: Custom CRM Connector

```typescript
// src/connectors/custom/custom-crm/connector.ts
import { BaseConnector, ConnectorConfig, AuthResult } from '../../base/base-connector';
import { CustomCRMAuth } from './auth';
import { CustomCRMClient } from './api-client';
import { CustomCRMWebhooks } from './webhooks';

export interface CustomCRMCredentials {
  apiKey: string;
  subdomain: string;
}

export interface Contact {
  id?: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  company?: string;
}

export interface Deal {
  id?: string;
  title: string;
  value: number;
  stage: string;
  contactId: string;
  closeDate?: Date;
}

export class CustomCRMConnector extends BaseConnector {
  private auth: CustomCRMAuth;
  private client: CustomCRMClient;
  private webhooks: CustomCRMWebhooks;

  constructor() {
    const config: ConnectorConfig = {
      name: 'custom-crm',
      version: '1.0.0',
      baseUrl: 'https://api.customcrm.com/v1',
      authType: 'api_key',
      rateLimits: {
        requests: 100,
        window: 60000, // 1 minute
      },
      retryConfig: {
        maxRetries: 3,
        backoffMultiplier: 2,
      },
    };

    super(config);
    
    this.auth = new CustomCRMAuth(config);
    this.client = new CustomCRMClient(config);
    this.webhooks = new CustomCRMWebhooks(config);
  }

  async authenticate(credentials: CustomCRMCredentials): Promise<AuthResult> {
    try {
      const result = await this.auth.authenticate(credentials);
      
      if (result.success) {
        this.isAuthenticated = true;
        this.client.setCredentials(credentials);
        this.emit('authenticated', { subdomain: credentials.subdomain });
      }

      return result;
    } catch (error) {
      this.emit('error', error);
      return {
        success: false,
        error: error.message,
      };
    }
  }

  async getData(endpoint: string, params?: any): Promise<any> {
    return this.makeRequest('GET', endpoint, undefined, params);
  }

  async postData(endpoint: string, data: any): Promise<any> {
    return this.makeRequest('POST', endpoint, data);
  }

  async putData(endpoint: string, data: any): Promise<any> {
    return this.makeRequest('PUT', endpoint, data);
  }

  async deleteData(endpoint: string): Promise<any> {
    return this.makeRequest('DELETE', endpoint);
  }

  // CRM-specific methods
  async getContacts(limit: number = 50, offset: number = 0): Promise<Contact[]> {
    const response = await this.getData('/contacts', { limit, offset });
    return response.contacts;
  }

  async getContact(contactId: string): Promise<Contact> {
    const response = await this.getData(`/contacts/${contactId}`);
    return response.contact;
  }

  async createContact(contact: Contact): Promise<Contact> {
    const response = await this.postData('/contacts', { contact });
    return response.contact;
  }

  async updateContact(contactId: string, updates: Partial<Contact>): Promise<Contact> {
    const response = await this.putData(`/contacts/${contactId}`, { contact: updates });
    return response.contact;
  }

  async deleteContact(contactId: string): Promise<void> {
    await this.deleteData(`/contacts/${contactId}`);
  }

  async getDeals(limit: number = 50, offset: number = 0): Promise<Deal[]> {
    const response = await this.getData('/deals', { limit, offset });
    return response.deals;
  }

  async getDeal(dealId: string): Promise<Deal> {
    const response = await this.getData(`/deals/${dealId}`);
    return response.deal;
  }

  async createDeal(deal: Deal): Promise<Deal> {
    const response = await this.postData('/deals', { deal });
    return response.deal;
  }

  async updateDeal(dealId: string, updates: Partial<Deal>): Promise<Deal> {
    const response = await this.putData(`/deals/${dealId}`, { deal: updates });
    return response.deal;
  }

  async deleteDeal(dealId: string): Promise<void> {
    await this.deleteData(`/deals/${dealId}`);
  }

  // Webhook support
  supportsWebhooks(): boolean {
    return true;
  }

  async setupWebhooks(endpoints: string[]): Promise<void> {
    await this.webhooks.setup(endpoints);
  }

  async handleWebhook(payload: any): Promise<void> {
    await this.webhooks.handle(payload);
    this.emit('webhook', payload);
  }

  async healthCheck(): Promise<boolean> {
    try {
      await this.getData('/health');
      return true;
    } catch (error) {
      return false;
    }
  }
}
```

### 2.2 Authentication Implementation

```typescript
// src/connectors/custom/custom-crm/auth.ts
import { ConnectorConfig, AuthResult } from '../../base/base-connector';
import { CustomCRMCredentials } from './connector';

export class CustomCRMAuth {
  private config: ConnectorConfig;

  constructor(config: ConnectorConfig) {
    this.config = config;
  }

  async authenticate(credentials: CustomCRMCredentials): Promise<AuthResult> {
    try {
      const axios = (await import('axios')).default;
      
      // Test API key by making a simple request
      const response = await axios.get(`${this.config.baseUrl}/auth/test`, {
        headers: {
          'Authorization': `Bearer ${credentials.apiKey}`,
          'X-Subdomain': credentials.subdomain,
        },
      });

      if (response.status === 200) {
        return {
          success: true,
          accessToken: credentials.apiKey,
        };
      } else {
        return {
          success: false,
          error: 'Invalid API key or subdomain',
        };
      }
    } catch (error) {
      return {
        success: false,
        error: error.response?.data?.message || error.message,
      };
    }
  }
}
```

### 2.3 API Client Implementation

```typescript
// src/connectors/custom/custom-crm/api-client.ts
import { ConnectorConfig } from '../../base/base-connector';
import { CustomCRMCredentials } from './connector';

export class CustomCRMClient {
  private config: ConnectorConfig;
  private credentials?: CustomCRMCredentials;

  constructor(config: ConnectorConfig) {
    this.config = config;
  }

  setCredentials(credentials: CustomCRMCredentials): void {
    this.credentials = credentials;
  }

  async makeRequest(method: string, endpoint: string, data?: any): Promise<any> {
    if (!this.credentials) {
      throw new Error('Credentials not set');
    }

    const axios = (await import('axios')).default;

    const config = {
      method,
      url: `${this.config.baseUrl}${endpoint}`,
      headers: {
        'Authorization': `Bearer ${this.credentials.apiKey}`,
        'X-Subdomain': this.credentials.subdomain,
        'Content-Type': 'application/json',
      },
      data,
    };

    const response = await axios(config);
    return response.data;
  }
}
```

### 2.4 Webhook Implementation

```typescript
// src/connectors/custom/custom-crm/webhooks.ts
import { ConnectorConfig } from '../../base/base-connector';

export class CustomCRMWebhooks {
  private config: ConnectorConfig;

  constructor(config: ConnectorConfig) {
    this.config = config;
  }

  async setup(endpoints: string[]): Promise<void> {
    const axios = (await import('axios')).default;

    for (const endpoint of endpoints) {
      try {
        await axios.post(`${this.config.baseUrl}/webhooks`, {
          url: endpoint,
          events: ['contact.created', 'contact.updated', 'deal.created', 'deal.updated'],
        });
        
        console.log(`Webhook registered: ${endpoint}`);
      } catch (error) {
        console.error(`Failed to register webhook ${endpoint}:`, error);
      }
    }
  }

  async handle(payload: any): Promise<void> {
    const { event, data } = payload;

    switch (event) {
      case 'contact.created':
        await this.handleContactCreated(data);
        break;
      
      case 'contact.updated':
        await this.handleContactUpdated(data);
        break;
      
      case 'deal.created':
        await this.handleDealCreated(data);
        break;
      
      case 'deal.updated':
        await this.handleDealUpdated(data);
        break;
      
      default:
        console.warn(`Unknown webhook event: ${event}`);
    }
  }

  private async handleContactCreated(contact: any): Promise<void> {
    console.log('Contact created:', contact);
    // Implement your business logic here
  }

  private async handleContactUpdated(contact: any): Promise<void> {
    console.log('Contact updated:', contact);
    // Implement your business logic here
  }

  private async handleDealCreated(deal: any): Promise<void> {
    console.log('Deal created:', deal);
    // Implement your business logic here
  }

  private async handleDealUpdated(deal: any): Promise<void> {
    console.log('Deal updated:', deal);
    // Implement your business logic here
  }
}
```

## Step 3: Connector Registry

### 3.1 Registry Implementation

```typescript
// src/connectors/registry.ts
import { BaseConnector } from './base/base-connector';
import { CustomCRMConnector } from './custom/custom-crm/connector';

export interface ConnectorInfo {
  name: string;
  version: string;
  description: string;
  authType: string;
  supportsWebhooks: boolean;
  constructor: new () => BaseConnector;
}

export class ConnectorRegistry {
  private static connectors = new Map<string, ConnectorInfo>();

  static register(name: string, info: ConnectorInfo): void {
    this.connectors.set(name, info);
  }

  static get(name: string): ConnectorInfo | undefined {
    return this.connectors.get(name);
  }

  static list(): ConnectorInfo[] {
    return Array.from(this.connectors.values());
  }

  static create(name: string): BaseConnector {
    const info = this.get(name);
    if (!info) {
      throw new Error(`Connector not found: ${name}`);
    }

    return new info.constructor();
  }
}

// Register built-in connectors
ConnectorRegistry.register('custom-crm', {
  name: 'custom-crm',
  version: '1.0.0',
  description: 'Custom CRM integration',
  authType: 'api_key',
  supportsWebhooks: true,
  constructor: CustomCRMConnector,
});
```

### 3.2 Connector Manager

```typescript
// src/connectors/manager.ts
import { ConnectorRegistry } from './registry';
import { BaseConnector } from './base/base-connector';

export interface ConnectorSession {
  id: string;
  connectorName: string;
  connector: BaseConnector;
  authenticated: boolean;
  createdAt: Date;
  lastUsed: Date;
}

export class ConnectorManager {
  private sessions = new Map<string, ConnectorSession>();

  async createSession(connectorName: string, credentials: any): Promise<string> {
    const connector = ConnectorRegistry.create(connectorName);
    const sessionId = this.generateSessionId();

    // Authenticate connector
    const authResult = await connector.authenticate(credentials);
    if (!authResult.success) {
      throw new Error(`Authentication failed: ${authResult.error}`);
    }

    // Create session
    const session: ConnectorSession = {
      id: sessionId,
      connectorName,
      connector,
      authenticated: true,
      createdAt: new Date(),
      lastUsed: new Date(),
    };

    this.sessions.set(sessionId, session);

    // Setup event handlers
    connector.onError((error) => {
      console.error(`Connector error (${sessionId}):`, error);
    });

    connector.onRequest((details) => {
      console.log(`Connector request (${sessionId}):`, details);
      session.lastUsed = new Date();
    });

    return sessionId;
  }

  getSession(sessionId: string): ConnectorSession | undefined {
    return this.sessions.get(sessionId);
  }

  async destroySession(sessionId: string): Promise<void> {
    const session = this.sessions.get(sessionId);
    if (session) {
      // Cleanup connector resources
      session.connector.removeAllListeners();
      this.sessions.delete(sessionId);
    }
  }

  listSessions(): ConnectorSession[] {
    return Array.from(this.sessions.values()).map(session => ({
      ...session,
      connector: undefined as any, // Don't expose connector instance
    }));
  }

  async healthCheck(sessionId: string): Promise<boolean> {
    const session = this.sessions.get(sessionId);
    if (!session) {
      return false;
    }

    return session.connector.healthCheck();
  }

  private generateSessionId(): string {
    return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
}
```

## Step 4: Express API Routes

### 4.1 Connector API Routes

```typescript
// src/routes/connectors.ts
import express from 'express';
import { ConnectorRegistry } from '../connectors/registry';
import { ConnectorManager } from '../connectors/manager';

const router = express.Router();
const connectorManager = new ConnectorManager();

// List available connectors
router.get('/', (req, res) => {
  const connectors = ConnectorRegistry.list();
  res.json({
    success: true,
    connectors: connectors.map(c => ({
      name: c.name,
      version: c.version,
      description: c.description,
      authType: c.authType,
      supportsWebhooks: c.supportsWebhooks,
    })),
  });
});

// Create connector session
router.post('/:name/sessions', async (req, res) => {
  try {
    const { name } = req.params;
    const { credentials } = req.body;

    if (!credentials) {
      return res.status(400).json({
        error: 'Credentials are required',
      });
    }

    const sessionId = await connectorManager.createSession(name, credentials);

    res.json({
      success: true,
      sessionId,
    });
  } catch (error) {
    res.status(500).json({
      error: error.message,
    });
  }
});

// Get session info
router.get('/sessions/:sessionId', (req, res) => {
  const { sessionId } = req.params;
  const session = connectorManager.getSession(sessionId);

  if (!session) {
    return res.status(404).json({
      error: 'Session not found',
    });
  }

  res.json({
    success: true,
    session: {
      id: session.id,
      connectorName: session.connectorName,
      authenticated: session.authenticated,
      createdAt: session.createdAt,
      lastUsed: session.lastUsed,
    },
  });
});

// Execute connector method
router.post('/sessions/:sessionId/execute', async (req, res) => {
  try {
    const { sessionId } = req.params;
    const { method, args } = req.body;

    const session = connectorManager.getSession(sessionId);
    if (!session) {
      return res.status(404).json({
        error: 'Session not found',
      });
    }

    // Execute method on connector
    const result = await (session.connector as any)[method](...(args || []));

    res.json({
      success: true,
      result,
    });
  } catch (error) {
    res.status(500).json({
      error: error.message,
    });
  }
});

// Health check
router.get('/sessions/:sessionId/health', async (req, res) => {
  try {
    const { sessionId } = req.params;
    const healthy = await connectorManager.healthCheck(sessionId);

    res.json({
      success: true,
      healthy,
    });
  } catch (error) {
    res.status(500).json({
      error: error.message,
    });
  }
});

// Destroy session
router.delete('/sessions/:sessionId', async (req, res) => {
  try {
    const { sessionId } = req.params;
    await connectorManager.destroySession(sessionId);

    res.json({
      success: true,
    });
  } catch (error) {
    res.status(500).json({
      error: error.message,
    });
  }
});

export default router;
```

### 4.2 Webhook Handler Routes

```typescript
// src/routes/connector-webhooks.ts
import express from 'express';
import { ConnectorManager } from '../connectors/manager';

const router = express.Router();
const connectorManager = new ConnectorManager();

// Handle webhooks for specific connector
router.post('/:connectorName', async (req, res) => {
  try {
    const { connectorName } = req.params;
    const payload = req.body;

    // Find active sessions for this connector
    const sessions = connectorManager.listSessions()
      .filter(session => session.connectorName === connectorName);

    // Process webhook for each session
    for (const sessionInfo of sessions) {
      const session = connectorManager.getSession(sessionInfo.id);
      if (session && session.connector.supportsWebhooks()) {
        try {
          await session.connector.handleWebhook(payload);
        } catch (error) {
          console.error(`Webhook processing failed for session ${session.id}:`, error);
        }
      }
    }

    res.status(200).json({ success: true });
  } catch (error) {
    console.error('Webhook handler error:', error);
    res.status(500).json({ error: error.message });
  }
});

export default router;
```

## Step 5: Testing and Deployment

### 5.1 Testing Framework

```typescript
// tests/custom-connector.test.ts
import { CustomCRMConnector } from '../src/connectors/custom/custom-crm/connector';

describe('Custom CRM Connector', () => {
  let connector: CustomCRMConnector;

  beforeEach(() => {
    connector = new CustomCRMConnector();
  });

  afterEach(async () => {
    // Cleanup
    connector.removeAllListeners();
  });

  test('should authenticate with valid credentials', async () => {
    const credentials = {
      apiKey: 'test-api-key',
      subdomain: 'test-subdomain',
    };

    const result = await connector.authenticate(credentials);
    expect(result.success).toBe(true);
  });

  test('should create and retrieve contact', async () => {
    // Setup authentication
    await connector.authenticate({
      apiKey: 'test-api-key',
      subdomain: 'test-subdomain',
    });

    // Create contact
    const contact = {
      firstName: 'John',
      lastName: 'Doe',
      email: 'john.doe@example.com',
    };

    const createdContact = await connector.createContact(contact);
    expect(createdContact.id).toBeDefined();
    expect(createdContact.firstName).toBe(contact.firstName);

    // Retrieve contact
    const retrievedContact = await connector.getContact(createdContact.id!);
    expect(retrievedContact.firstName).toBe(contact.firstName);
  });

  test('should handle webhook events', async () => {
    const webhookPayload = {
      event: 'contact.created',
      data: {
        id: '123',
        firstName: 'Jane',
        lastName: 'Smith',
        email: 'jane.smith@example.com',
      },
    };

    let webhookReceived = false;
    connector.onWebhook(() => {
      webhookReceived = true;
    });

    await connector.handleWebhook(webhookPayload);
    expect(webhookReceived).toBe(true);
  });
});
```

### 5.2 Example Usage

```typescript
// examples/custom-crm-usage.ts
import { ConnectorManager } from '../src/connectors/manager';

async function exampleUsage() {
  const manager = new ConnectorManager();

  try {
    // Create connector session
    const sessionId = await manager.createSession('custom-crm', {
      apiKey: 'your-api-key',
      subdomain: 'your-subdomain',
    });

    console.log('Session created:', sessionId);

    // Get session
    const session = manager.getSession(sessionId);
    if (!session) {
      throw new Error('Session not found');
    }

    const connector = session.connector as any; // Type assertion for example

    // Create a contact
    const contact = await connector.createContact({
      firstName: 'John',
      lastName: 'Doe',
      email: 'john.doe@example.com',
      phone: '+1234567890',
    });

    console.log('Contact created:', contact);

    // Get all contacts
    const contacts = await connector.getContacts();
    console.log('All contacts:', contacts);

    // Create a deal
    const deal = await connector.createDeal({
      title: 'New Business Opportunity',
      value: 10000,
      stage: 'proposal',
      contactId: contact.id,
    });

    console.log('Deal created:', deal);

    // Health check
    const healthy = await manager.healthCheck(sessionId);
    console.log('Connector healthy:', healthy);

    // Cleanup
    await manager.destroySession(sessionId);

  } catch (error) {
    console.error('Example failed:', error);
  }
}

exampleUsage();
```

## Best Practices

### 1. Error Handling
- Implement comprehensive error handling for all API calls
- Use specific error types for different failure scenarios
- Provide meaningful error messages to users
- Log errors for debugging and monitoring

### 2. Rate Limiting
- Respect API rate limits of the target service
- Implement exponential backoff for retries
- Queue requests when rate limits are exceeded
- Monitor rate limit usage and adjust accordingly

### 3. Security
- Encrypt sensitive credentials at rest
- Use HTTPS for all API communications
- Validate webhook signatures
- Implement proper authentication flows

### 4. Performance
- Cache frequently accessed data when appropriate
- Use connection pooling for HTTP requests
- Implement pagination for large data sets
- Monitor and optimize API response times

### 5. Testing
- Write comprehensive unit tests for all connector methods
- Test error scenarios and edge cases
- Mock external API calls in tests
- Implement integration tests with real API endpoints

### 6. Documentation
- Document all connector methods and parameters
- Provide usage examples and code samples
- Document webhook event formats
- Maintain API compatibility documentation

## Deployment Considerations

### Environment Configuration
```bash
# Custom CRM Configuration
CUSTOM_CRM_CLIENT_ID=your_client_id
CUSTOM_CRM_CLIENT_SECRET=your_client_secret
CUSTOM_CRM_WEBHOOK_SECRET=your_webhook_secret

# General Connector Settings
CONNECTOR_TIMEOUT=30000
CONNECTOR_RETRY_ATTEMPTS=3
CONNECTOR_RATE_LIMIT_WINDOW=60000
```

### Monitoring and Logging
- Monitor connector health and performance
- Log all API requests and responses
- Track error rates and response times
- Set up alerts for connector failures

### Scaling Considerations
- Design connectors to be stateless when possible
- Use horizontal scaling for high-volume integrations
- Implement connection pooling and resource management
- Consider using message queues for webhook processing

## Next Steps

- [Shopify Integration](./shopify.md) - E-commerce integration example
- [QuickBooks Integration](./quickbooks.md) - Accounting integration example
- [Slack Integration](./slack.md) - Communication integration example
- [Integration Roadmap](./roadmap.md) - Future connector plans

