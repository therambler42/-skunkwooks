import { defineConfig } from 'vitepress'

export default defineConfig({
  title: 'Integration Documentation',
  description: 'Comprehensive guides for Shopify, QuickBooks, and Slack integrations',
  base: '/integrations/',
  
  themeConfig: {
    nav: [
      { text: 'Home', link: '/' },
      { text: 'Integrations', link: '/integrations/' }
    ],

    sidebar: {
      '/integrations/': [
        {
          text: 'Getting Started',
          items: [
            { text: 'Overview', link: '/integrations/' },
            { text: 'Prerequisites', link: '/integrations/prerequisites' }
          ]
        },
        {
          text: 'E-commerce',
          items: [
            { text: 'Shopify Integration', link: '/integrations/shopify' },
            { text: 'Shopify OAuth Setup', link: '/integrations/shopify-oauth' }
          ]
        },
        {
          text: 'Accounting',
          items: [
            { text: 'QuickBooks Online', link: '/integrations/quickbooks' },
            { text: 'QuickBooks Webhooks', link: '/integrations/quickbooks-webhooks' }
          ]
        },
        {
          text: 'Communication',
          items: [
            { text: 'Slack Integration', link: '/integrations/slack' },
            { text: 'Slack Slash Commands', link: '/integrations/slack-commands' }
          ]
        },
        {
          text: 'Future Connectors',
          items: [
            { text: 'Roadmap', link: '/integrations/roadmap' },
            { text: 'Custom Connectors', link: '/integrations/custom' }
          ]
        }
      ]
    },

    socialLinks: [
      { icon: 'github', link: 'https://github.com/your-org/integrations-docs' }
    ],

    footer: {
      message: 'Released under the MIT License.',
      copyright: 'Copyright © 2025 Your Company'
    },

    search: {
      provider: 'local'
    }
  },

  head: [
    ['meta', { name: 'viewport', content: 'width=device-width, initial-scale=1.0' }],
    ['meta', { name: 'description', content: 'Integration documentation for Shopify, QuickBooks, and Slack' }],
    ['meta', { property: 'og:title', content: 'Integration Documentation' }],
    ['meta', { property: 'og:description', content: 'Comprehensive guides for Shopify, QuickBooks, and Slack integrations' }],
    ['meta', { property: 'og:type', content: 'website' }]
  ],

  markdown: {
    lineNumbers: true,
    theme: {
      light: 'github-light',
      dark: 'github-dark'
    }
  }
})

