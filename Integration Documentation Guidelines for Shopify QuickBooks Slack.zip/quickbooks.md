# QuickBooks Online Integration Guide

This comprehensive guide covers the complete setup and implementation of QuickBooks Online integration, including OAuth 2.0 authentication, API usage, and data synchronization.

## Overview

QuickBooks Online integration enables your application to access and manage accounting data including customers, items, invoices, payments, and financial reports. The integration uses Intuit's OAuth 2.0 implementation and the QuickBooks Online API v3.

## Prerequisites

Before starting, ensure you have:
- An Intuit Developer account
- QuickBooks Online company for testing
- Node.js and TypeScript development environment
- Understanding of OAuth 2.0 flows
- SSL certificate for production webhooks

## Step 1: Create QuickBooks App

### 1.1 Access Intuit Developer Console

1. Log in to [Intuit Developer Console](https://developer.intuit.com/)
2. Navigate to "My Apps" and click "Create an app"
3. Select "QuickBooks Online and Payments" as the platform
4. Choose your app type (Web app recommended)

### 1.2 Configure App Settings

Fill in the required information:

- **App name**: Descriptive name for your integration
- **Production Redirect URI**: Your OAuth callback URL (HTTPS required)
- **Development Redirect URI**: Local development callback URL
- **Webhooks URL**: Endpoint for receiving webhook notifications

Example configuration:
```
App name: Business Integration Suite
Production Redirect URI: https://myapp.example.com/auth/quickbooks/callback
Development Redirect URI: https://localhost:3000/auth/quickbooks/callback
Webhooks URL: https://myapp.example.com/webhooks/quickbooks
```

### 1.3 Note Your Credentials

After creating the app, save these credentials securely:
- **Client ID**: Used for OAuth flow initiation
- **Client Secret**: Used for token exchange and API calls
- **Webhook Verifier Token**: Used for webhook signature verification

## Step 2: Environment Configuration

### 2.1 Environment Variables

Add the following variables to your `.env` file:

```bash
# QuickBooks App Configuration
QB_CLIENT_ID=your_client_id_here
QB_CLIENT_SECRET=your_client_secret_here
QB_REDIRECT_URI=https://your-app-domain.com/auth/quickbooks/callback
QB_ENVIRONMENT=sandbox # or production
QB_WEBHOOK_VERIFIER=your_webhook_verifier_token

# OAuth Configuration
QB_SCOPE=com.intuit.quickbooks.accounting
QB_STATE_SECRET=your_state_secret_key

# API Configuration
QB_BASE_URL_SANDBOX=https://sandbox-quickbooks.api.intuit.com
QB_BASE_URL_PRODUCTION=https://quickbooks.api.intuit.com
QB_DISCOVERY_DOCUMENT_URL=https://appcenter.intuit.com/api/v1/OpenID_Connect/Discovery
```

### 2.2 Required Scopes

Common scopes for business integrations:

| Scope | Description |
|-------|-------------|
| `com.intuit.quickbooks.accounting` | Full access to accounting data |
| `com.intuit.quickbooks.payment` | Access to payment processing |
| `openid` | OpenID Connect authentication |
| `profile` | User profile information |
| `email` | User email address |
| `phone` | User phone number |
| `address` | User address information |

## Step 3: Implementation

### 3.1 Install Dependencies

```bash
npm install node-quickbooks oauth2-server crypto-js axios dotenv express
npm install -D @types/express @types/node @types/crypto-js typescript
```

### 3.2 OAuth Client Setup

```typescript
// src/quickbooks/oauth-client.ts
import axios from 'axios';
import crypto from 'crypto';

export interface QuickBooksTokens {
  access_token: string;
  refresh_token: string;
  token_type: string;
  expires_in: number;
  x_refresh_token_expires_in: number;
  scope: string;
  realmId: string;
}

export class QuickBooksOAuthClient {
  private clientId: string;
  private clientSecret: string;
  private redirectUri: string;
  private environment: 'sandbox' | 'production';
  private baseUrl: string;

  constructor() {
    this.clientId = process.env.QB_CLIENT_ID!;
    this.clientSecret = process.env.QB_CLIENT_SECRET!;
    this.redirectUri = process.env.QB_REDIRECT_URI!;
    this.environment = (process.env.QB_ENVIRONMENT as 'sandbox' | 'production') || 'sandbox';
    this.baseUrl = this.environment === 'sandbox' 
      ? process.env.QB_BASE_URL_SANDBOX!
      : process.env.QB_BASE_URL_PRODUCTION!;
  }

  // Generate authorization URL
  generateAuthUrl(state?: string): string {
    const scope = process.env.QB_SCOPE || 'com.intuit.quickbooks.accounting';
    const stateParam = state || this.generateState();

    const params = new URLSearchParams({
      client_id: this.clientId,
      scope,
      redirect_uri: this.redirectUri,
      response_type: 'code',
      access_type: 'offline',
      state: stateParam,
    });

    const baseAuthUrl = this.environment === 'sandbox'
      ? 'https://appcenter.intuit.com/connect/oauth2'
      : 'https://appcenter.intuit.com/connect/oauth2';

    return `${baseAuthUrl}?${params.toString()}`;
  }

  // Exchange authorization code for tokens
  async exchangeCodeForTokens(code: string, realmId: string): Promise<QuickBooksTokens> {
    const tokenUrl = 'https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer';
    
    const data = new URLSearchParams({
      grant_type: 'authorization_code',
      code,
      redirect_uri: this.redirectUri,
    });

    const auth = Buffer.from(`${this.clientId}:${this.clientSecret}`).toString('base64');

    try {
      const response = await axios.post(tokenUrl, data, {
        headers: {
          'Authorization': `Basic ${auth}`,
          'Content-Type': 'application/x-www-form-urlencoded',
          'Accept': 'application/json',
        },
      });

      return {
        ...response.data,
        realmId,
      };
    } catch (error) {
      console.error('Token exchange error:', error.response?.data || error.message);
      throw new Error('Failed to exchange authorization code for tokens');
    }
  }

  // Refresh access token
  async refreshAccessToken(refreshToken: string): Promise<QuickBooksTokens> {
    const tokenUrl = 'https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer';
    
    const data = new URLSearchParams({
      grant_type: 'refresh_token',
      refresh_token: refreshToken,
    });

    const auth = Buffer.from(`${this.clientId}:${this.clientSecret}`).toString('base64');

    try {
      const response = await axios.post(tokenUrl, data, {
        headers: {
          'Authorization': `Basic ${auth}`,
          'Content-Type': 'application/x-www-form-urlencoded',
          'Accept': 'application/json',
        },
      });

      return response.data;
    } catch (error) {
      console.error('Token refresh error:', error.response?.data || error.message);
      throw new Error('Failed to refresh access token');
    }
  }

  // Revoke tokens
  async revokeTokens(refreshToken: string): Promise<void> {
    const revokeUrl = 'https://developer.api.intuit.com/v2/oauth2/tokens/revoke';
    
    const data = new URLSearchParams({
      token: refreshToken,
    });

    const auth = Buffer.from(`${this.clientId}:${this.clientSecret}`).toString('base64');

    try {
      await axios.post(revokeUrl, data, {
        headers: {
          'Authorization': `Basic ${auth}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
      });
    } catch (error) {
      console.error('Token revocation error:', error.response?.data || error.message);
      throw new Error('Failed to revoke tokens');
    }
  }

  // Generate secure state parameter
  private generateState(): string {
    return crypto.randomBytes(32).toString('hex');
  }

  // Verify state parameter
  verifyState(receivedState: string, expectedState: string): boolean {
    return crypto.timingSafeEqual(
      Buffer.from(receivedState),
      Buffer.from(expectedState)
    );
  }
}
```

### 3.3 QuickBooks API Client

```typescript
// src/quickbooks/api-client.ts
import axios, { AxiosInstance } from 'axios';
import { QuickBooksTokens } from './oauth-client';

export interface CompanyInfo {
  QueryResponse: {
    CompanyInfo: Array<{
      Name: string;
      CompanyAddr: any;
      Country: string;
      FiscalYearStartMonth: string;
      SupportedLanguages: string;
    }>;
  };
}

export interface Customer {
  Id?: string;
  Name: string;
  CompanyName?: string;
  BillAddr?: any;
  ShipAddr?: any;
  Phone?: string;
  Email?: string;
  Active?: boolean;
}

export interface Item {
  Id?: string;
  Name: string;
  Description?: string;
  Type: 'Inventory' | 'NonInventory' | 'Service';
  UnitPrice?: number;
  IncomeAccountRef?: { value: string };
  ExpenseAccountRef?: { value: string };
  AssetAccountRef?: { value: string };
}

export interface Invoice {
  Id?: string;
  CustomerRef: { value: string };
  Line: Array<{
    Amount: number;
    DetailType: 'SalesItemLineDetail';
    SalesItemLineDetail: {
      ItemRef: { value: string };
      Qty?: number;
      UnitPrice?: number;
    };
  }>;
  DueDate?: string;
  TxnDate?: string;
  DocNumber?: string;
}

export class QuickBooksAPIClient {
  private client: AxiosInstance;
  private tokens: QuickBooksTokens;
  private realmId: string;
  private baseUrl: string;

  constructor(tokens: QuickBooksTokens) {
    this.tokens = tokens;
    this.realmId = tokens.realmId;
    this.baseUrl = process.env.QB_ENVIRONMENT === 'sandbox'
      ? process.env.QB_BASE_URL_SANDBOX!
      : process.env.QB_BASE_URL_PRODUCTION!;

    this.client = axios.create({
      baseURL: `${this.baseUrl}/v3/company/${this.realmId}`,
      headers: {
        'Authorization': `Bearer ${tokens.access_token}`,
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
    });

    // Add response interceptor for error handling
    this.client.interceptors.response.use(
      (response) => response,
      (error) => {
        console.error('QuickBooks API Error:', error.response?.data || error.message);
        return Promise.reject(error);
      }
    );
  }

  // Company Information
  async getCompanyInfo(): Promise<CompanyInfo> {
    const response = await this.client.get('/companyinfo/1');
    return response.data;
  }

  // Customer Operations
  async getCustomers(): Promise<Customer[]> {
    const response = await this.client.get("/query?query=SELECT * FROM Customer");
    return response.data.QueryResponse?.Customer || [];
  }

  async getCustomer(customerId: string): Promise<Customer> {
    const response = await this.client.get(`/customer/${customerId}`);
    return response.data.QueryResponse.Customer[0];
  }

  async createCustomer(customer: Customer): Promise<Customer> {
    const response = await this.client.post('/customer', customer);
    return response.data.QueryResponse.Customer[0];
  }

  async updateCustomer(customer: Customer): Promise<Customer> {
    if (!customer.Id) {
      throw new Error('Customer ID is required for updates');
    }

    // Get current customer to obtain SyncToken
    const currentCustomer = await this.getCustomer(customer.Id);
    const updatedCustomer = {
      ...customer,
      SyncToken: currentCustomer.SyncToken,
    };

    const response = await this.client.post('/customer', updatedCustomer);
    return response.data.QueryResponse.Customer[0];
  }

  // Item Operations
  async getItems(): Promise<Item[]> {
    const response = await this.client.get("/query?query=SELECT * FROM Item");
    return response.data.QueryResponse?.Item || [];
  }

  async getItem(itemId: string): Promise<Item> {
    const response = await this.client.get(`/item/${itemId}`);
    return response.data.QueryResponse.Item[0];
  }

  async createItem(item: Item): Promise<Item> {
    const response = await this.client.post('/item', item);
    return response.data.QueryResponse.Item[0];
  }

  // Invoice Operations
  async getInvoices(): Promise<Invoice[]> {
    const response = await this.client.get("/query?query=SELECT * FROM Invoice");
    return response.data.QueryResponse?.Invoice || [];
  }

  async getInvoice(invoiceId: string): Promise<Invoice> {
    const response = await this.client.get(`/invoice/${invoiceId}`);
    return response.data.QueryResponse.Invoice[0];
  }

  async createInvoice(invoice: Invoice): Promise<Invoice> {
    const response = await this.client.post('/invoice', invoice);
    return response.data.QueryResponse.Invoice[0];
  }

  async updateInvoice(invoice: Invoice): Promise<Invoice> {
    if (!invoice.Id) {
      throw new Error('Invoice ID is required for updates');
    }

    // Get current invoice to obtain SyncToken
    const currentInvoice = await this.getInvoice(invoice.Id);
    const updatedInvoice = {
      ...invoice,
      SyncToken: currentInvoice.SyncToken,
    };

    const response = await this.client.post('/invoice', updatedInvoice);
    return response.data.QueryResponse.Invoice[0];
  }

  // Account Operations
  async getAccounts(): Promise<any[]> {
    const response = await this.client.get("/query?query=SELECT * FROM Account");
    return response.data.QueryResponse?.Account || [];
  }

  // Payment Operations
  async getPayments(): Promise<any[]> {
    const response = await this.client.get("/query?query=SELECT * FROM Payment");
    return response.data.QueryResponse?.Payment || [];
  }

  async createPayment(payment: any): Promise<any> {
    const response = await this.client.post('/payment', payment);
    return response.data.QueryResponse.Payment[0];
  }

  // Reports
  async getProfitAndLoss(startDate: string, endDate: string): Promise<any> {
    const params = new URLSearchParams({
      start_date: startDate,
      end_date: endDate,
      summarize_column_by: 'Month',
    });

    const response = await this.client.get(`/reports/ProfitAndLoss?${params}`);
    return response.data;
  }

  async getBalanceSheet(date: string): Promise<any> {
    const params = new URLSearchParams({
      date,
    });

    const response = await this.client.get(`/reports/BalanceSheet?${params}`);
    return response.data;
  }

  // Batch Operations
  async batchRequest(operations: any[]): Promise<any> {
    const batchRequest = {
      BatchItemRequest: operations.map((op, index) => ({
        bId: `bid${index}`,
        ...op,
      })),
    };

    const response = await this.client.post('/batch', batchRequest);
    return response.data;
  }

  // Change Data Capture (CDC)
  async getChangedEntities(entities: string[], changedSince: string): Promise<any> {
    const entityList = entities.join(',');
    const response = await this.client.get(
      `/cdc?entities=${entityList}&changedSince=${changedSince}`
    );
    return response.data;
  }
}
```

### 3.4 Session Management

```typescript
// src/quickbooks/session-manager.ts
import { QuickBooksTokens, QuickBooksOAuthClient } from './oauth-client';
import { encrypt, decrypt } from '../utils/encryption';

export interface QuickBooksSession {
  id: string;
  realmId: string;
  accessToken: string;
  refreshToken: string;
  expiresAt: Date;
  refreshExpiresAt: Date;
  scope: string;
  createdAt: Date;
  updatedAt: Date;
}

export class QuickBooksSessionManager {
  private sessions: Map<string, QuickBooksSession> = new Map();
  private oauthClient: QuickBooksOAuthClient;

  constructor() {
    this.oauthClient = new QuickBooksOAuthClient();
  }

  // Store session with encryption
  async storeSession(tokens: QuickBooksTokens, userId?: string): Promise<string> {
    const sessionId = userId || `qb_${tokens.realmId}`;
    const now = new Date();

    const session: QuickBooksSession = {
      id: sessionId,
      realmId: tokens.realmId,
      accessToken: encrypt(tokens.access_token),
      refreshToken: encrypt(tokens.refresh_token),
      expiresAt: new Date(now.getTime() + tokens.expires_in * 1000),
      refreshExpiresAt: new Date(now.getTime() + tokens.x_refresh_token_expires_in * 1000),
      scope: tokens.scope,
      createdAt: now,
      updatedAt: now,
    };

    // In production, store in database
    this.sessions.set(sessionId, session);
    this.sessions.set(`realm:${tokens.realmId}`, session);

    console.log(`QuickBooks session stored for realm: ${tokens.realmId}`);
    return sessionId;
  }

  // Retrieve session with decryption
  async getSession(sessionId: string): Promise<QuickBooksSession | null> {
    const session = this.sessions.get(sessionId);
    if (!session) {
      return null;
    }

    // Check if refresh token is expired
    if (session.refreshExpiresAt < new Date()) {
      await this.deleteSession(sessionId);
      return null;
    }

    return {
      ...session,
      accessToken: decrypt(session.accessToken),
      refreshToken: decrypt(session.refreshToken),
    };
  }

  // Get session by realm ID
  async getSessionByRealm(realmId: string): Promise<QuickBooksSession | null> {
    return this.getSession(`realm:${realmId}`);
  }

  // Validate and refresh session if needed
  async validateSession(sessionId: string): Promise<QuickBooksSession | null> {
    const session = await this.getSession(sessionId);
    if (!session) {
      return null;
    }

    // Check if access token needs refresh (refresh 5 minutes before expiry)
    const fiveMinutesFromNow = new Date(Date.now() + 5 * 60 * 1000);
    if (session.expiresAt < fiveMinutesFromNow) {
      try {
        return await this.refreshSession(session);
      } catch (error) {
        console.error('Failed to refresh QuickBooks session:', error);
        await this.deleteSession(sessionId);
        return null;
      }
    }

    return session;
  }

  // Refresh session tokens
  private async refreshSession(session: QuickBooksSession): Promise<QuickBooksSession> {
    const tokens = await this.oauthClient.refreshAccessToken(session.refreshToken);
    
    const now = new Date();
    const updatedSession: QuickBooksSession = {
      ...session,
      accessToken: encrypt(tokens.access_token),
      refreshToken: encrypt(tokens.refresh_token),
      expiresAt: new Date(now.getTime() + tokens.expires_in * 1000),
      refreshExpiresAt: new Date(now.getTime() + tokens.x_refresh_token_expires_in * 1000),
      updatedAt: now,
    };

    // Update stored session
    this.sessions.set(session.id, updatedSession);
    this.sessions.set(`realm:${session.realmId}`, updatedSession);

    return {
      ...updatedSession,
      accessToken: decrypt(updatedSession.accessToken),
      refreshToken: decrypt(updatedSession.refreshToken),
    };
  }

  // Delete session
  async deleteSession(sessionId: string): Promise<void> {
    const session = this.sessions.get(sessionId);
    if (session) {
      // Revoke tokens before deletion
      try {
        await this.oauthClient.revokeTokens(decrypt(session.refreshToken));
      } catch (error) {
        console.error('Failed to revoke tokens:', error);
      }

      this.sessions.delete(sessionId);
      this.sessions.delete(`realm:${session.realmId}`);
    }
  }

  // Get all sessions (for admin purposes)
  async getAllSessions(): Promise<QuickBooksSession[]> {
    const sessions: QuickBooksSession[] = [];
    for (const [key, session] of this.sessions.entries()) {
      if (!key.startsWith('realm:')) {
        sessions.push({
          ...session,
          accessToken: '[ENCRYPTED]',
          refreshToken: '[ENCRYPTED]',
        });
      }
    }
    return sessions;
  }
}
```

### 3.5 Express Route Handlers

```typescript
// src/routes/quickbooks-auth.ts
import express from 'express';
import { QuickBooksOAuthClient } from '../quickbooks/oauth-client';
import { QuickBooksSessionManager } from '../quickbooks/session-manager';

const router = express.Router();
const oauthClient = new QuickBooksOAuthClient();
const sessionManager = new QuickBooksSessionManager();

// Store state for CSRF protection
const stateStore = new Map<string, { timestamp: number; userId?: string }>();

// Initiate OAuth flow
router.get('/connect', async (req, res) => {
  try {
    const { userId } = req.query;
    const state = generateSecureState();
    
    // Store state with optional user ID
    stateStore.set(state, {
      timestamp: Date.now(),
      userId: userId as string,
    });

    // Clean up old states
    cleanupExpiredStates();

    const authUrl = oauthClient.generateAuthUrl(state);
    res.redirect(authUrl);

  } catch (error) {
    console.error('OAuth initiation error:', error);
    res.status(500).json({
      error: 'Failed to initiate QuickBooks connection',
      message: 'Please try again or contact support'
    });
  }
});

// Handle OAuth callback
router.get('/callback', async (req, res) => {
  const { code, realmId, state, error } = req.query;

  try {
    // Handle OAuth errors
    if (error) {
      console.error('OAuth error:', error);
      return res.status(400).json({
        error: 'QuickBooks authorization failed',
        details: error
      });
    }

    // Validate required parameters
    if (!code || !realmId || !state) {
      return res.status(400).json({
        error: 'Missing required OAuth parameters'
      });
    }

    // Verify state parameter
    const stateData = stateStore.get(state as string);
    if (!stateData) {
      return res.status(400).json({
        error: 'Invalid or expired state parameter'
      });
    }

    // Clean up used state
    stateStore.delete(state as string);

    // Exchange code for tokens
    const tokens = await oauthClient.exchangeCodeForTokens(
      code as string,
      realmId as string
    );

    // Store session
    const sessionId = await sessionManager.storeSession(tokens, stateData.userId);

    // Redirect to success page
    res.redirect(`/quickbooks/success?session=${sessionId}&realm=${realmId}`);

  } catch (error) {
    console.error('OAuth callback error:', error);
    res.status(500).json({
      error: 'Failed to complete QuickBooks authorization',
      message: 'Please try again or contact support'
    });
  }
});

// Disconnect QuickBooks
router.post('/disconnect', async (req, res) => {
  try {
    const { sessionId } = req.body;

    if (!sessionId) {
      return res.status(400).json({
        error: 'Session ID is required'
      });
    }

    await sessionManager.deleteSession(sessionId);

    res.json({
      success: true,
      message: 'QuickBooks connection removed successfully'
    });

  } catch (error) {
    console.error('Disconnect error:', error);
    res.status(500).json({
      error: 'Failed to disconnect QuickBooks'
    });
  }
});

// Get connection status
router.get('/status/:sessionId', async (req, res) => {
  try {
    const { sessionId } = req.params;
    const session = await sessionManager.validateSession(sessionId);

    if (!session) {
      return res.json({
        connected: false,
        message: 'No active QuickBooks connection'
      });
    }

    res.json({
      connected: true,
      realmId: session.realmId,
      scope: session.scope,
      expiresAt: session.expiresAt,
      refreshExpiresAt: session.refreshExpiresAt
    });

  } catch (error) {
    console.error('Status check error:', error);
    res.status(500).json({
      error: 'Failed to check connection status'
    });
  }
});

// Helper functions
function generateSecureState(): string {
  return require('crypto').randomBytes(32).toString('hex');
}

function cleanupExpiredStates(): void {
  const tenMinutesAgo = Date.now() - (10 * 60 * 1000);
  for (const [state, data] of stateStore.entries()) {
    if (data.timestamp < tenMinutesAgo) {
      stateStore.delete(state);
    }
  }
}

export default router;
```

## Step 4: Data Synchronization

### 4.1 Sync Service Implementation

```typescript
// src/quickbooks/sync-service.ts
import { QuickBooksAPIClient, Customer, Item, Invoice } from './api-client';
import { QuickBooksSessionManager } from './session-manager';

export interface SyncResult {
  entity: string;
  action: 'created' | 'updated' | 'deleted' | 'error';
  id?: string;
  error?: string;
}

export class QuickBooksSyncService {
  private sessionManager: QuickBooksSessionManager;

  constructor() {
    this.sessionManager = new QuickBooksSessionManager();
  }

  // Sync customers from external system to QuickBooks
  async syncCustomersToQB(
    sessionId: string,
    customers: Customer[]
  ): Promise<SyncResult[]> {
    const session = await this.sessionManager.validateSession(sessionId);
    if (!session) {
      throw new Error('Invalid or expired QuickBooks session');
    }

    const client = new QuickBooksAPIClient({
      access_token: session.accessToken,
      refresh_token: session.refreshToken,
      realmId: session.realmId,
    } as any);

    const results: SyncResult[] = [];

    for (const customer of customers) {
      try {
        // Check if customer exists (by name or external ID)
        const existingCustomers = await client.getCustomers();
        const existingCustomer = existingCustomers.find(
          c => c.Name === customer.Name || c.Id === customer.Id
        );

        if (existingCustomer) {
          // Update existing customer
          const updatedCustomer = await client.updateCustomer({
            ...existingCustomer,
            ...customer,
            Id: existingCustomer.Id,
          });

          results.push({
            entity: 'customer',
            action: 'updated',
            id: updatedCustomer.Id,
          });
        } else {
          // Create new customer
          const newCustomer = await client.createCustomer(customer);
          results.push({
            entity: 'customer',
            action: 'created',
            id: newCustomer.Id,
          });
        }
      } catch (error) {
        results.push({
          entity: 'customer',
          action: 'error',
          error: error.message,
        });
      }
    }

    return results;
  }

  // Sync items from external system to QuickBooks
  async syncItemsToQB(
    sessionId: string,
    items: Item[]
  ): Promise<SyncResult[]> {
    const session = await this.sessionManager.validateSession(sessionId);
    if (!session) {
      throw new Error('Invalid or expired QuickBooks session');
    }

    const client = new QuickBooksAPIClient({
      access_token: session.accessToken,
      refresh_token: session.refreshToken,
      realmId: session.realmId,
    } as any);

    const results: SyncResult[] = [];

    for (const item of items) {
      try {
        // Check if item exists
        const existingItems = await client.getItems();
        const existingItem = existingItems.find(
          i => i.Name === item.Name || i.Id === item.Id
        );

        if (existingItem) {
          // Items cannot be updated in QuickBooks, only deactivated
          results.push({
            entity: 'item',
            action: 'error',
            error: 'Items cannot be updated, only created or deactivated',
          });
        } else {
          // Create new item
          const newItem = await client.createItem(item);
          results.push({
            entity: 'item',
            action: 'created',
            id: newItem.Id,
          });
        }
      } catch (error) {
        results.push({
          entity: 'item',
          action: 'error',
          error: error.message,
        });
      }
    }

    return results;
  }

  // Sync invoices from QuickBooks to external system
  async syncInvoicesFromQB(
    sessionId: string,
    lastSyncDate?: Date
  ): Promise<Invoice[]> {
    const session = await this.sessionManager.validateSession(sessionId);
    if (!session) {
      throw new Error('Invalid or expired QuickBooks session');
    }

    const client = new QuickBooksAPIClient({
      access_token: session.accessToken,
      refresh_token: session.refreshToken,
      realmId: session.realmId,
    } as any);

    if (lastSyncDate) {
      // Use Change Data Capture for incremental sync
      const changedData = await client.getChangedEntities(
        ['Invoice'],
        lastSyncDate.toISOString()
      );
      return changedData.QueryResponse?.Invoice || [];
    } else {
      // Full sync
      return await client.getInvoices();
    }
  }

  // Bidirectional sync
  async performBidirectionalSync(
    sessionId: string,
    externalData: {
      customers: Customer[];
      items: Item[];
    },
    lastSyncDate?: Date
  ): Promise<{
    toQuickBooks: SyncResult[];
    fromQuickBooks: {
      customers: Customer[];
      items: Item[];
      invoices: Invoice[];
    };
  }> {
    // Sync to QuickBooks
    const customerResults = await this.syncCustomersToQB(sessionId, externalData.customers);
    const itemResults = await this.syncItemsToQB(sessionId, externalData.items);

    // Sync from QuickBooks
    const session = await this.sessionManager.validateSession(sessionId);
    const client = new QuickBooksAPIClient({
      access_token: session!.accessToken,
      refresh_token: session!.refreshToken,
      realmId: session!.realmId,
    } as any);

    const [customers, items, invoices] = await Promise.all([
      client.getCustomers(),
      client.getItems(),
      this.syncInvoicesFromQB(sessionId, lastSyncDate),
    ]);

    return {
      toQuickBooks: [...customerResults, ...itemResults],
      fromQuickBooks: {
        customers,
        items,
        invoices,
      },
    };
  }
}
```

## Step 5: Error Handling and Rate Limiting

### 5.1 Error Handler

```typescript
// src/quickbooks/error-handler.ts
export enum QuickBooksErrorType {
  AUTHENTICATION_ERROR = 'authentication_error',
  AUTHORIZATION_ERROR = 'authorization_error',
  RATE_LIMIT_ERROR = 'rate_limit_error',
  VALIDATION_ERROR = 'validation_error',
  BUSINESS_RULE_ERROR = 'business_rule_error',
  NETWORK_ERROR = 'network_error',
  UNKNOWN_ERROR = 'unknown_error',
}

export class QuickBooksError extends Error {
  constructor(
    public type: QuickBooksErrorType,
    message: string,
    public code?: string,
    public detail?: any
  ) {
    super(message);
    this.name = 'QuickBooksError';
  }
}

export class QuickBooksErrorHandler {
  static handleError(error: any): QuickBooksError {
    if (error.response) {
      const { status, data } = error.response;

      switch (status) {
        case 401:
          return new QuickBooksError(
            QuickBooksErrorType.AUTHENTICATION_ERROR,
            'Authentication failed - token may be expired',
            data.code,
            data
          );

        case 403:
          return new QuickBooksError(
            QuickBooksErrorType.AUTHORIZATION_ERROR,
            'Insufficient permissions for this operation',
            data.code,
            data
          );

        case 429:
          return new QuickBooksError(
            QuickBooksErrorType.RATE_LIMIT_ERROR,
            'Rate limit exceeded',
            data.code,
            data
          );

        case 400:
          return new QuickBooksError(
            QuickBooksErrorType.VALIDATION_ERROR,
            data.Fault?.Error?.[0]?.Detail || 'Validation error',
            data.Fault?.Error?.[0]?.code,
            data
          );

        case 422:
          return new QuickBooksError(
            QuickBooksErrorType.BUSINESS_RULE_ERROR,
            data.Fault?.Error?.[0]?.Detail || 'Business rule violation',
            data.Fault?.Error?.[0]?.code,
            data
          );

        default:
          return new QuickBooksError(
            QuickBooksErrorType.UNKNOWN_ERROR,
            `HTTP ${status}: ${data.message || 'Unknown error'}`,
            data.code,
            data
          );
      }
    }

    if (error.code === 'ECONNREFUSED' || error.code === 'ETIMEDOUT') {
      return new QuickBooksError(
        QuickBooksErrorType.NETWORK_ERROR,
        'Network connection failed'
      );
    }

    return new QuickBooksError(
      QuickBooksErrorType.UNKNOWN_ERROR,
      error.message || 'Unknown error occurred'
    );
  }
}
```

## Testing and Validation

### Test Your Integration

1. **OAuth Flow**: Test complete authentication process
2. **API Operations**: Verify CRUD operations for all entities
3. **Token Refresh**: Test automatic token refresh
4. **Error Handling**: Test various error scenarios
5. **Data Sync**: Test bidirectional synchronization

### Example Test Script

```typescript
// tests/quickbooks-integration.test.ts
import { QuickBooksAPIClient } from '../src/quickbooks/api-client';
import { QuickBooksSessionManager } from '../src/quickbooks/session-manager';

describe('QuickBooks Integration', () => {
  let sessionManager: QuickBooksSessionManager;
  let apiClient: QuickBooksAPIClient;

  beforeEach(() => {
    sessionManager = new QuickBooksSessionManager();
    // Mock session setup
  });

  test('should create and retrieve customer', async () => {
    const customer = {
      Name: 'Test Customer',
      CompanyName: 'Test Company',
      Email: 'test@example.com',
    };

    const createdCustomer = await apiClient.createCustomer(customer);
    expect(createdCustomer.Id).toBeDefined();
    expect(createdCustomer.Name).toBe(customer.Name);

    const retrievedCustomer = await apiClient.getCustomer(createdCustomer.Id!);
    expect(retrievedCustomer.Name).toBe(customer.Name);
  });

  test('should handle token refresh', async () => {
    // Test token refresh logic
    const session = await sessionManager.validateSession('test-session');
    expect(session).toBeDefined();
  });
});
```

## Security Best Practices

1. **Token Storage**: Encrypt tokens at rest
2. **HTTPS Only**: Use HTTPS for all communications
3. **State Verification**: Always verify OAuth state parameter
4. **Token Refresh**: Implement automatic token refresh
5. **Error Logging**: Log errors without exposing sensitive data
6. **Rate Limiting**: Respect QuickBooks API rate limits

## Next Steps

- [QuickBooks Webhooks](./quickbooks-webhooks.md) - Real-time event handling
- [Slack Integration](./slack.md) - Communication integration
- [Shopify Integration](./shopify.md) - E-commerce integration

