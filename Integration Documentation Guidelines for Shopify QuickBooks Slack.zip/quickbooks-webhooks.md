# QuickBooks Webhooks Guide

This guide provides comprehensive instructions for implementing QuickBooks Online webhooks to receive real-time notifications when data changes in connected QuickBooks companies.

## Overview

QuickBooks webhooks enable your application to receive immediate notifications when specific events occur in a QuickBooks Online company. This eliminates the need for constant polling and ensures your application stays synchronized with the latest data changes.

## Supported Events

QuickBooks Online supports webhooks for the following entity types:

| Entity | Events | Description |
|--------|--------|-------------|
| `Customer` | Create, Update, Delete, Merge | Customer record changes |
| `Vendor` | Create, Update, Delete, Merge | Vendor record changes |
| `Item` | Create, Update, Delete, Merge | Product/service item changes |
| `Invoice` | Create, Update, Delete, Void | Invoice lifecycle events |
| `Payment` | Create, Update, Delete, Void | Payment transaction events |
| `Bill` | Create, Update, Delete | Bill/expense changes |
| `Estimate` | Create, Update, Delete | Quote/estimate changes |
| `SalesReceipt` | Create, Update, Delete | Sales receipt events |
| `PurchaseOrder` | Create, Update, Delete | Purchase order changes |
| `TimeActivity` | Create, Update, Delete | Time tracking events |

## Prerequisites

Before implementing webhooks, ensure you have:
- Active QuickBooks Online integration
- HTTPS endpoint for receiving webhooks
- Valid SSL certificate
- Webhook verifier token from Intuit Developer Console

## Step 1: Webhook Configuration

### 1.1 Environment Variables

Add webhook configuration to your `.env` file:

```bash
# QuickBooks Webhook Configuration
QB_WEBHOOK_VERIFIER=your_webhook_verifier_token
QB_WEBHOOK_URL=https://your-app-domain.com/webhooks/quickbooks
QB_WEBHOOK_SECRET=your_webhook_signing_secret

# Webhook Processing
WEBHOOK_RETRY_ATTEMPTS=3
WEBHOOK_RETRY_DELAY=5000
WEBHOOK_TIMEOUT=30000
```

### 1.2 Webhook Registration

```typescript
// src/quickbooks/webhook-manager.ts
import { QuickBooksAPIClient } from './api-client';
import { QuickBooksSessionManager } from './session-manager';

export interface WebhookSubscription {
  entityName: string;
  callbackUrl: string;
  verifierToken: string;
}

export class QuickBooksWebhookManager {
  private sessionManager: QuickBooksSessionManager;

  constructor() {
    this.sessionManager = new QuickBooksSessionManager();
  }

  // Register webhooks for a company
  async registerWebhooks(sessionId: string, entities: string[]): Promise<void> {
    const session = await this.sessionManager.validateSession(sessionId);
    if (!session) {
      throw new Error('Invalid or expired QuickBooks session');
    }

    const client = new QuickBooksAPIClient({
      access_token: session.accessToken,
      refresh_token: session.refreshToken,
      realmId: session.realmId,
    } as any);

    for (const entity of entities) {
      try {
        await this.registerWebhookForEntity(client, entity);
        console.log(`Webhook registered for entity: ${entity}`);
      } catch (error) {
        console.error(`Failed to register webhook for ${entity}:`, error);
      }
    }
  }

  // Register webhook for specific entity
  private async registerWebhookForEntity(
    client: QuickBooksAPIClient,
    entityName: string
  ): Promise<void> {
    const webhookData = {
      callbackUrl: process.env.QB_WEBHOOK_URL!,
      verifierToken: process.env.QB_WEBHOOK_VERIFIER!,
    };

    // QuickBooks webhook registration is done through the Developer Console
    // This method would be used if API-based registration becomes available
    console.log(`Would register webhook for ${entityName} with:`, webhookData);
  }

  // Get webhook subscriptions
  async getWebhookSubscriptions(sessionId: string): Promise<WebhookSubscription[]> {
    // In practice, webhook subscriptions are managed through the Developer Console
    // This method would query the current subscriptions if API support exists
    return [
      {
        entityName: 'Customer',
        callbackUrl: process.env.QB_WEBHOOK_URL!,
        verifierToken: process.env.QB_WEBHOOK_VERIFIER!,
      },
      // Add other subscribed entities
    ];
  }

  // Unregister webhooks
  async unregisterWebhooks(sessionId: string): Promise<void> {
    // Webhook unregistration is typically done through the Developer Console
    console.log('Webhooks would be unregistered for session:', sessionId);
  }
}
```

## Step 2: Webhook Handler Implementation

### 2.1 Webhook Verification

```typescript
// src/quickbooks/webhook-verifier.ts
import crypto from 'crypto';

export class QuickBooksWebhookVerifier {
  private verifierToken: string;

  constructor() {
    this.verifierToken = process.env.QB_WEBHOOK_VERIFIER!;
  }

  // Verify webhook signature
  verifySignature(payload: string, signature: string): boolean {
    try {
      // QuickBooks uses HMAC-SHA256 with the verifier token
      const expectedSignature = crypto
        .createHmac('sha256', this.verifierToken)
        .update(payload)
        .digest('base64');

      // Use timing-safe comparison
      return crypto.timingSafeEqual(
        Buffer.from(signature),
        Buffer.from(expectedSignature)
      );
    } catch (error) {
      console.error('Signature verification error:', error);
      return false;
    }
  }

  // Verify webhook payload structure
  verifyPayload(payload: any): boolean {
    // Check required fields
    if (!payload.eventNotifications || !Array.isArray(payload.eventNotifications)) {
      return false;
    }

    // Verify each notification has required fields
    for (const notification of payload.eventNotifications) {
      if (!notification.realmId || !notification.dataChangeEvent) {
        return false;
      }

      if (!notification.dataChangeEvent.entities || !Array.isArray(notification.dataChangeEvent.entities)) {
        return false;
      }
    }

    return true;
  }

  // Extract and validate realm ID
  extractRealmId(payload: any): string | null {
    if (payload.eventNotifications && payload.eventNotifications.length > 0) {
      return payload.eventNotifications[0].realmId;
    }
    return null;
  }
}
```

### 2.2 Webhook Event Processing

```typescript
// src/quickbooks/webhook-processor.ts
import { QuickBooksAPIClient } from './api-client';
import { QuickBooksSessionManager } from './session-manager';

export interface WebhookEvent {
  realmId: string;
  name: string;
  id: string;
  operation: 'Create' | 'Update' | 'Delete' | 'Merge' | 'Void';
  lastUpdated: string;
}

export interface WebhookNotification {
  realmId: string;
  dataChangeEvent: {
    entities: Array<{
      name: string;
      id: string;
      operation: string;
      lastUpdated: string;
    }>;
  };
}

export class QuickBooksWebhookProcessor {
  private sessionManager: QuickBooksSessionManager;
  private eventHandlers: Map<string, (event: WebhookEvent) => Promise<void>>;

  constructor() {
    this.sessionManager = new QuickBooksSessionManager();
    this.eventHandlers = new Map();
    this.setupDefaultHandlers();
  }

  // Process incoming webhook payload
  async processWebhook(payload: any): Promise<void> {
    const notifications: WebhookNotification[] = payload.eventNotifications;

    for (const notification of notifications) {
      await this.processNotification(notification);
    }
  }

  // Process individual notification
  private async processNotification(notification: WebhookNotification): Promise<void> {
    const { realmId, dataChangeEvent } = notification;

    // Get session for this realm
    const session = await this.sessionManager.getSessionByRealm(realmId);
    if (!session) {
      console.warn(`No session found for realm: ${realmId}`);
      return;
    }

    // Process each entity change
    for (const entity of dataChangeEvent.entities) {
      const event: WebhookEvent = {
        realmId,
        name: entity.name,
        id: entity.id,
        operation: entity.operation as any,
        lastUpdated: entity.lastUpdated,
      };

      await this.processEvent(event, session);
    }
  }

  // Process individual event
  private async processEvent(event: WebhookEvent, session: any): Promise<void> {
    try {
      console.log(`Processing ${event.operation} event for ${event.name} (ID: ${event.id})`);

      // Get handler for this entity type
      const handler = this.eventHandlers.get(event.name);
      if (handler) {
        await handler(event);
      } else {
        console.warn(`No handler registered for entity: ${event.name}`);
      }

      // Log successful processing
      await this.logWebhookEvent(event, 'processed');

    } catch (error) {
      console.error(`Error processing webhook event:`, error);
      await this.logWebhookEvent(event, 'error', error.message);
    }
  }

  // Register event handler
  registerHandler(entityName: string, handler: (event: WebhookEvent) => Promise<void>): void {
    this.eventHandlers.set(entityName, handler);
  }

  // Setup default event handlers
  private setupDefaultHandlers(): void {
    // Customer events
    this.registerHandler('Customer', async (event) => {
      await this.handleCustomerEvent(event);
    });

    // Invoice events
    this.registerHandler('Invoice', async (event) => {
      await this.handleInvoiceEvent(event);
    });

    // Payment events
    this.registerHandler('Payment', async (event) => {
      await this.handlePaymentEvent(event);
    });

    // Item events
    this.registerHandler('Item', async (event) => {
      await this.handleItemEvent(event);
    });
  }

  // Handle customer events
  private async handleCustomerEvent(event: WebhookEvent): Promise<void> {
    const session = await this.sessionManager.getSessionByRealm(event.realmId);
    if (!session) return;

    const client = new QuickBooksAPIClient({
      access_token: session.accessToken,
      refresh_token: session.refreshToken,
      realmId: session.realmId,
    } as any);

    switch (event.operation) {
      case 'Create':
      case 'Update':
        // Fetch updated customer data
        const customer = await client.getCustomer(event.id);
        await this.syncCustomerToExternalSystem(customer);
        break;

      case 'Delete':
        await this.handleCustomerDeletion(event.id);
        break;

      case 'Merge':
        await this.handleCustomerMerge(event);
        break;
    }
  }

  // Handle invoice events
  private async handleInvoiceEvent(event: WebhookEvent): Promise<void> {
    const session = await this.sessionManager.getSessionByRealm(event.realmId);
    if (!session) return;

    const client = new QuickBooksAPIClient({
      access_token: session.accessToken,
      refresh_token: session.refreshToken,
      realmId: session.realmId,
    } as any);

    switch (event.operation) {
      case 'Create':
        const invoice = await client.getInvoice(event.id);
        await this.handleNewInvoice(invoice);
        break;

      case 'Update':
        const updatedInvoice = await client.getInvoice(event.id);
        await this.handleInvoiceUpdate(updatedInvoice);
        break;

      case 'Delete':
      case 'Void':
        await this.handleInvoiceDeletion(event.id);
        break;
    }
  }

  // Handle payment events
  private async handlePaymentEvent(event: WebhookEvent): Promise<void> {
    const session = await this.sessionManager.getSessionByRealm(event.realmId);
    if (!session) return;

    const client = new QuickBooksAPIClient({
      access_token: session.accessToken,
      refresh_token: session.refreshToken,
      realmId: session.realmId,
    } as any);

    switch (event.operation) {
      case 'Create':
        const payments = await client.getPayments();
        const payment = payments.find(p => p.Id === event.id);
        if (payment) {
          await this.handleNewPayment(payment);
        }
        break;

      case 'Update':
        const updatedPayments = await client.getPayments();
        const updatedPayment = updatedPayments.find(p => p.Id === event.id);
        if (updatedPayment) {
          await this.handlePaymentUpdate(updatedPayment);
        }
        break;

      case 'Delete':
      case 'Void':
        await this.handlePaymentDeletion(event.id);
        break;
    }
  }

  // Handle item events
  private async handleItemEvent(event: WebhookEvent): Promise<void> {
    const session = await this.sessionManager.getSessionByRealm(event.realmId);
    if (!session) return;

    const client = new QuickBooksAPIClient({
      access_token: session.accessToken,
      refresh_token: session.refreshToken,
      realmId: session.realmId,
    } as any);

    switch (event.operation) {
      case 'Create':
      case 'Update':
        const item = await client.getItem(event.id);
        await this.syncItemToExternalSystem(item);
        break;

      case 'Delete':
        await this.handleItemDeletion(event.id);
        break;
    }
  }

  // Sync customer to external system
  private async syncCustomerToExternalSystem(customer: any): Promise<void> {
    // Implement your external system sync logic
    console.log('Syncing customer to external system:', customer.Id);
    
    // Example: Send to external CRM
    // await externalCRM.upsertCustomer(customer);
  }

  // Handle customer deletion
  private async handleCustomerDeletion(customerId: string): Promise<void> {
    console.log('Handling customer deletion:', customerId);
    
    // Example: Mark as deleted in external system
    // await externalCRM.markCustomerDeleted(customerId);
  }

  // Handle customer merge
  private async handleCustomerMerge(event: WebhookEvent): Promise<void> {
    console.log('Handling customer merge:', event);
    
    // Customer merge events require special handling
    // The merged customer ID is in the event, but you need to identify
    // which customer was merged into which
  }

  // Handle new invoice
  private async handleNewInvoice(invoice: any): Promise<void> {
    console.log('Handling new invoice:', invoice.Id);
    
    // Example: Send invoice to external accounting system
    // await externalAccounting.createInvoice(invoice);
    
    // Example: Send notification
    // await notificationService.sendInvoiceCreatedNotification(invoice);
  }

  // Handle invoice update
  private async handleInvoiceUpdate(invoice: any): Promise<void> {
    console.log('Handling invoice update:', invoice.Id);
    
    // Example: Update external system
    // await externalAccounting.updateInvoice(invoice);
  }

  // Handle invoice deletion
  private async handleInvoiceDeletion(invoiceId: string): Promise<void> {
    console.log('Handling invoice deletion:', invoiceId);
    
    // Example: Mark as deleted in external system
    // await externalAccounting.markInvoiceDeleted(invoiceId);
  }

  // Handle new payment
  private async handleNewPayment(payment: any): Promise<void> {
    console.log('Handling new payment:', payment.Id);
    
    // Example: Update payment status in external system
    // await externalAccounting.recordPayment(payment);
  }

  // Handle payment update
  private async handlePaymentUpdate(payment: any): Promise<void> {
    console.log('Handling payment update:', payment.Id);
    
    // Example: Update payment in external system
    // await externalAccounting.updatePayment(payment);
  }

  // Handle payment deletion
  private async handlePaymentDeletion(paymentId: string): Promise<void> {
    console.log('Handling payment deletion:', paymentId);
    
    // Example: Reverse payment in external system
    // await externalAccounting.reversePayment(paymentId);
  }

  // Sync item to external system
  private async syncItemToExternalSystem(item: any): Promise<void> {
    console.log('Syncing item to external system:', item.Id);
    
    // Example: Update inventory system
    // await inventorySystem.upsertItem(item);
  }

  // Handle item deletion
  private async handleItemDeletion(itemId: string): Promise<void> {
    console.log('Handling item deletion:', itemId);
    
    // Example: Mark as inactive in external system
    // await inventorySystem.deactivateItem(itemId);
  }

  // Log webhook event
  private async logWebhookEvent(
    event: WebhookEvent,
    status: 'processed' | 'error',
    errorMessage?: string
  ): Promise<void> {
    const logEntry = {
      timestamp: new Date().toISOString(),
      realmId: event.realmId,
      entityName: event.name,
      entityId: event.id,
      operation: event.operation,
      status,
      errorMessage,
    };

    // In production, store in database
    console.log('Webhook event log:', logEntry);
  }
}
```

## Step 3: Express Route Handler

### 3.1 Webhook Endpoint

```typescript
// src/routes/quickbooks-webhooks.ts
import express from 'express';
import { QuickBooksWebhookVerifier } from '../quickbooks/webhook-verifier';
import { QuickBooksWebhookProcessor } from '../quickbooks/webhook-processor';

const router = express.Router();
const verifier = new QuickBooksWebhookVerifier();
const processor = new QuickBooksWebhookProcessor();

// Middleware to capture raw body for signature verification
router.use('/quickbooks', express.raw({ type: 'application/json' }));

// QuickBooks webhook endpoint
router.post('/quickbooks', async (req, res) => {
  try {
    // Get signature from headers
    const signature = req.headers['intuit-signature'] as string;
    
    if (!signature) {
      console.warn('Missing Intuit signature header');
      return res.status(400).json({ error: 'Missing signature' });
    }

    // Convert raw body to string for verification
    const payload = req.body.toString('utf8');
    
    // Verify webhook signature
    if (!verifier.verifySignature(payload, signature)) {
      console.warn('Invalid webhook signature');
      return res.status(401).json({ error: 'Invalid signature' });
    }

    // Parse JSON payload
    let webhookData;
    try {
      webhookData = JSON.parse(payload);
    } catch (error) {
      console.error('Invalid JSON payload:', error);
      return res.status(400).json({ error: 'Invalid JSON' });
    }

    // Verify payload structure
    if (!verifier.verifyPayload(webhookData)) {
      console.warn('Invalid webhook payload structure');
      return res.status(400).json({ error: 'Invalid payload structure' });
    }

    // Extract realm ID for logging
    const realmId = verifier.extractRealmId(webhookData);
    console.log(`Received webhook for realm: ${realmId}`);

    // Process webhook asynchronously
    setImmediate(async () => {
      try {
        await processor.processWebhook(webhookData);
      } catch (error) {
        console.error('Webhook processing error:', error);
      }
    });

    // Respond immediately to QuickBooks
    res.status(200).json({ success: true });

  } catch (error) {
    console.error('Webhook handler error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Webhook health check endpoint
router.get('/quickbooks/health', (req, res) => {
  res.status(200).json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    service: 'quickbooks-webhooks'
  });
});

export default router;
```

### 3.2 Webhook Testing Endpoint

```typescript
// src/routes/quickbooks-webhook-test.ts
import express from 'express';
import { QuickBooksWebhookProcessor } from '../quickbooks/webhook-processor';

const router = express.Router();
const processor = new QuickBooksWebhookProcessor();

// Test webhook processing with sample data
router.post('/test', async (req, res) => {
  try {
    const { realmId, entityName, entityId, operation } = req.body;

    if (!realmId || !entityName || !entityId || !operation) {
      return res.status(400).json({
        error: 'Missing required fields: realmId, entityName, entityId, operation'
      });
    }

    // Create test webhook payload
    const testPayload = {
      eventNotifications: [
        {
          realmId,
          dataChangeEvent: {
            entities: [
              {
                name: entityName,
                id: entityId,
                operation,
                lastUpdated: new Date().toISOString()
              }
            ]
          }
        }
      ]
    };

    // Process test webhook
    await processor.processWebhook(testPayload);

    res.json({
      success: true,
      message: 'Test webhook processed successfully',
      payload: testPayload
    });

  } catch (error) {
    console.error('Test webhook error:', error);
    res.status(500).json({
      error: 'Failed to process test webhook',
      message: error.message
    });
  }
});

export default router;
```

## Step 4: Webhook Retry and Error Handling

### 4.1 Retry Mechanism

```typescript
// src/quickbooks/webhook-retry.ts
export interface RetryConfig {
  maxAttempts: number;
  baseDelay: number;
  maxDelay: number;
  backoffMultiplier: number;
}

export class WebhookRetryHandler {
  private config: RetryConfig;

  constructor(config?: Partial<RetryConfig>) {
    this.config = {
      maxAttempts: parseInt(process.env.WEBHOOK_RETRY_ATTEMPTS || '3'),
      baseDelay: parseInt(process.env.WEBHOOK_RETRY_DELAY || '5000'),
      maxDelay: 60000, // 1 minute
      backoffMultiplier: 2,
      ...config
    };
  }

  // Retry webhook processing with exponential backoff
  async retryWithBackoff<T>(
    operation: () => Promise<T>,
    context: string
  ): Promise<T> {
    let lastError: Error;

    for (let attempt = 1; attempt <= this.config.maxAttempts; attempt++) {
      try {
        return await operation();
      } catch (error) {
        lastError = error;
        
        console.warn(`${context} failed (attempt ${attempt}/${this.config.maxAttempts}):`, error.message);

        if (attempt === this.config.maxAttempts) {
          break;
        }

        // Calculate delay with exponential backoff
        const delay = Math.min(
          this.config.baseDelay * Math.pow(this.config.backoffMultiplier, attempt - 1),
          this.config.maxDelay
        );

        console.log(`Retrying ${context} in ${delay}ms...`);
        await this.sleep(delay);
      }
    }

    throw new Error(`${context} failed after ${this.config.maxAttempts} attempts: ${lastError.message}`);
  }

  private sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}
```

### 4.2 Dead Letter Queue

```typescript
// src/quickbooks/webhook-dlq.ts
export interface FailedWebhook {
  id: string;
  payload: any;
  error: string;
  attempts: number;
  firstAttempt: Date;
  lastAttempt: Date;
  realmId: string;
}

export class WebhookDeadLetterQueue {
  private failedWebhooks: Map<string, FailedWebhook> = new Map();

  // Add failed webhook to DLQ
  addFailedWebhook(payload: any, error: string, realmId: string): void {
    const id = this.generateWebhookId(payload);
    const existing = this.failedWebhooks.get(id);
    const now = new Date();

    if (existing) {
      // Update existing entry
      existing.attempts++;
      existing.lastAttempt = now;
      existing.error = error;
    } else {
      // Create new entry
      const failedWebhook: FailedWebhook = {
        id,
        payload,
        error,
        attempts: 1,
        firstAttempt: now,
        lastAttempt: now,
        realmId,
      };
      this.failedWebhooks.set(id, failedWebhook);
    }

    console.log(`Added webhook to DLQ: ${id} (attempts: ${existing?.attempts || 1})`);
  }

  // Get failed webhooks for manual processing
  getFailedWebhooks(): FailedWebhook[] {
    return Array.from(this.failedWebhooks.values());
  }

  // Get failed webhooks for specific realm
  getFailedWebhooksForRealm(realmId: string): FailedWebhook[] {
    return Array.from(this.failedWebhooks.values())
      .filter(webhook => webhook.realmId === realmId);
  }

  // Remove webhook from DLQ (after successful processing)
  removeWebhook(id: string): void {
    this.failedWebhooks.delete(id);
    console.log(`Removed webhook from DLQ: ${id}`);
  }

  // Retry failed webhooks
  async retryFailedWebhooks(processor: any): Promise<void> {
    const failedWebhooks = this.getFailedWebhooks();
    
    for (const failedWebhook of failedWebhooks) {
      try {
        console.log(`Retrying failed webhook: ${failedWebhook.id}`);
        await processor.processWebhook(failedWebhook.payload);
        
        // Remove from DLQ on success
        this.removeWebhook(failedWebhook.id);
        
      } catch (error) {
        console.error(`Retry failed for webhook ${failedWebhook.id}:`, error);
        
        // Update error information
        this.addFailedWebhook(
          failedWebhook.payload,
          error.message,
          failedWebhook.realmId
        );
      }
    }
  }

  private generateWebhookId(payload: any): string {
    // Generate unique ID based on payload content
    const crypto = require('crypto');
    const content = JSON.stringify(payload);
    return crypto.createHash('sha256').update(content).digest('hex').substring(0, 16);
  }
}
```

## Step 5: Monitoring and Logging

### 5.1 Webhook Metrics

```typescript
// src/quickbooks/webhook-metrics.ts
export interface WebhookMetrics {
  totalReceived: number;
  totalProcessed: number;
  totalFailed: number;
  averageProcessingTime: number;
  entityCounts: Record<string, number>;
  operationCounts: Record<string, number>;
  errorCounts: Record<string, number>;
}

export class WebhookMetricsCollector {
  private metrics: WebhookMetrics;
  private processingTimes: number[] = [];

  constructor() {
    this.metrics = {
      totalReceived: 0,
      totalProcessed: 0,
      totalFailed: 0,
      averageProcessingTime: 0,
      entityCounts: {},
      operationCounts: {},
      errorCounts: {},
    };
  }

  // Record webhook received
  recordWebhookReceived(): void {
    this.metrics.totalReceived++;
  }

  // Record webhook processed
  recordWebhookProcessed(entityName: string, operation: string, processingTime: number): void {
    this.metrics.totalProcessed++;
    
    // Update entity counts
    this.metrics.entityCounts[entityName] = (this.metrics.entityCounts[entityName] || 0) + 1;
    
    // Update operation counts
    this.metrics.operationCounts[operation] = (this.metrics.operationCounts[operation] || 0) + 1;
    
    // Update processing times
    this.processingTimes.push(processingTime);
    if (this.processingTimes.length > 1000) {
      this.processingTimes = this.processingTimes.slice(-1000); // Keep last 1000
    }
    
    // Calculate average processing time
    this.metrics.averageProcessingTime = 
      this.processingTimes.reduce((sum, time) => sum + time, 0) / this.processingTimes.length;
  }

  // Record webhook failed
  recordWebhookFailed(error: string): void {
    this.metrics.totalFailed++;
    this.metrics.errorCounts[error] = (this.metrics.errorCounts[error] || 0) + 1;
  }

  // Get current metrics
  getMetrics(): WebhookMetrics {
    return { ...this.metrics };
  }

  // Reset metrics
  resetMetrics(): void {
    this.metrics = {
      totalReceived: 0,
      totalProcessed: 0,
      totalFailed: 0,
      averageProcessingTime: 0,
      entityCounts: {},
      operationCounts: {},
      errorCounts: {},
    };
    this.processingTimes = [];
  }
}
```

### 5.2 Webhook Dashboard

```typescript
// src/routes/quickbooks-webhook-dashboard.ts
import express from 'express';
import { WebhookMetricsCollector } from '../quickbooks/webhook-metrics';
import { WebhookDeadLetterQueue } from '../quickbooks/webhook-dlq';

const router = express.Router();
const metricsCollector = new WebhookMetricsCollector();
const dlq = new WebhookDeadLetterQueue();

// Get webhook metrics
router.get('/metrics', (req, res) => {
  const metrics = metricsCollector.getMetrics();
  res.json(metrics);
});

// Get failed webhooks
router.get('/failed', (req, res) => {
  const { realmId } = req.query;
  
  const failedWebhooks = realmId 
    ? dlq.getFailedWebhooksForRealm(realmId as string)
    : dlq.getFailedWebhooks();
    
  res.json(failedWebhooks);
});

// Retry failed webhooks
router.post('/retry', async (req, res) => {
  try {
    const { processor } = req.app.locals; // Assuming processor is available
    await dlq.retryFailedWebhooks(processor);
    
    res.json({
      success: true,
      message: 'Failed webhooks retry initiated'
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to retry webhooks',
      message: error.message
    });
  }
});

// Reset metrics
router.post('/metrics/reset', (req, res) => {
  metricsCollector.resetMetrics();
  res.json({
    success: true,
    message: 'Metrics reset successfully'
  });
});

export default router;
```

## Testing Webhooks

### Local Testing with ngrok

1. Install ngrok: `npm install -g ngrok`
2. Start your application: `npm start`
3. Expose local server: `ngrok http 3000`
4. Update webhook URL in Intuit Developer Console
5. Test with QuickBooks Online changes

### Webhook Testing Script

```typescript
// scripts/test-webhooks.ts
import axios from 'axios';

async function testWebhookEndpoint() {
  const testPayload = {
    eventNotifications: [
      {
        realmId: 'test-realm-123',
        dataChangeEvent: {
          entities: [
            {
              name: 'Customer',
              id: 'test-customer-456',
              operation: 'Create',
              lastUpdated: new Date().toISOString()
            }
          ]
        }
      }
    ]
  };

  try {
    const response = await axios.post(
      'http://localhost:3000/webhooks/quickbooks/test',
      testPayload,
      {
        headers: {
          'Content-Type': 'application/json'
        }
      }
    );

    console.log('Test webhook response:', response.data);
  } catch (error) {
    console.error('Test webhook error:', error.response?.data || error.message);
  }
}

testWebhookEndpoint();
```

## Security Best Practices

1. **Signature Verification**: Always verify webhook signatures
2. **HTTPS Only**: Use HTTPS for all webhook endpoints
3. **Rate Limiting**: Implement rate limiting for webhook endpoints
4. **Timeout Handling**: Set appropriate timeouts for webhook processing
5. **Error Logging**: Log errors without exposing sensitive data
6. **Idempotency**: Handle duplicate webhook deliveries gracefully

## Troubleshooting

### Common Issues

1. **Missing Signatures**: Ensure webhook verifier token is correct
2. **Timeout Errors**: Optimize webhook processing for quick response
3. **Duplicate Events**: Implement idempotency checks
4. **Missing Events**: Check webhook subscription configuration

### Debug Mode

Enable webhook debugging:

```typescript
process.env.WEBHOOK_DEBUG = 'true';
```

## Next Steps

- [Slack Integration](./slack.md) - Communication integration
- [Shopify Integration](./shopify.md) - E-commerce integration
- [Custom Connectors](./custom.md) - Building custom integrations

