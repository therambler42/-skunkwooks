# Slack Slash Commands Guide

This guide provides comprehensive instructions for implementing custom slash commands in Slack, enabling users to interact with your application directly from the Slack interface.

## Overview

Slack slash commands allow users to trigger actions in your application by typing commands in Slack channels or direct messages. Commands start with a forward slash (/) followed by the command name and optional parameters.

## Prerequisites

Before implementing slash commands, ensure you have:
- Active Slack app with proper permissions
- HTTPS endpoint for handling command requests
- Understanding of Slack's request/response format
- Valid SSL certificate for production

## Step 1: Configure Slash Commands

### 1.1 Create Slash Commands in Slack App

1. Go to your [Slack App settings](https://api.slack.com/apps)
2. Navigate to "Slash Commands" in the sidebar
3. Click "Create New Command"
4. Fill in the command details:

```
Command: /myapp
Request URL: https://your-app-domain.com/slack/commands/myapp
Short Description: Interact with MyApp
Usage Hint: [action] [parameters]
```

### 1.2 Environment Configuration

Add command configuration to your `.env` file:

```bash
# Slack Slash Commands
SLACK_COMMAND_TIMEOUT=3000
SLACK_COMMAND_VERIFICATION=true
SLACK_COMMAND_ASYNC_PROCESSING=true

# Command-specific settings
SLACK_COMMAND_MYAPP_ENABLED=true
SLACK_COMMAND_HELP_ENABLED=true
SLACK_COMMAND_STATUS_ENABLED=true
```

## Step 2: Command Handler Implementation

### 2.1 Base Command Handler

```typescript
// src/slack/command-handler.ts
import { WebClient } from '@slack/web-api';
import crypto from 'crypto';

export interface SlackCommandRequest {
  token: string;
  team_id: string;
  team_domain: string;
  channel_id: string;
  channel_name: string;
  user_id: string;
  user_name: string;
  command: string;
  text: string;
  response_url: string;
  trigger_id: string;
}

export interface SlackCommandResponse {
  response_type?: 'in_channel' | 'ephemeral';
  text?: string;
  blocks?: any[];
  attachments?: any[];
  delete_original?: boolean;
  replace_original?: boolean;
}

export abstract class BaseCommandHandler {
  protected webClient: WebClient;

  constructor(token: string) {
    this.webClient = new WebClient(token);
  }

  // Abstract method to be implemented by specific command handlers
  abstract handle(request: SlackCommandRequest): Promise<SlackCommandResponse>;

  // Verify request signature
  verifySignature(body: string, timestamp: string, signature: string): boolean {
    const signingSecret = process.env.SLACK_SIGNING_SECRET!;
    
    // Check timestamp to prevent replay attacks
    const currentTime = Math.floor(Date.now() / 1000);
    if (Math.abs(currentTime - parseInt(timestamp)) > 300) {
      return false;
    }

    // Calculate expected signature
    const baseString = `v0:${timestamp}:${body}`;
    const expectedSignature = 'v0=' + crypto
      .createHmac('sha256', signingSecret)
      .update(baseString)
      .digest('hex');

    // Use timing-safe comparison
    return crypto.timingSafeEqual(
      Buffer.from(signature),
      Buffer.from(expectedSignature)
    );
  }

  // Send delayed response
  async sendDelayedResponse(responseUrl: string, response: SlackCommandResponse): Promise<void> {
    try {
      const fetch = (await import('node-fetch')).default;
      await fetch(responseUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(response),
      });
    } catch (error) {
      console.error('Error sending delayed response:', error);
    }
  }

  // Parse command text into arguments
  parseArguments(text: string): string[] {
    return text.trim().split(/\s+/).filter(arg => arg.length > 0);
  }

  // Create error response
  createErrorResponse(message: string): SlackCommandResponse {
    return {
      response_type: 'ephemeral',
      text: `:x: Error: ${message}`,
    };
  }

  // Create success response
  createSuccessResponse(message: string, inChannel: boolean = false): SlackCommandResponse {
    return {
      response_type: inChannel ? 'in_channel' : 'ephemeral',
      text: `:white_check_mark: ${message}`,
    };
  }

  // Create help response
  createHelpResponse(commands: Array<{ name: string; description: string; usage: string }>): SlackCommandResponse {
    const blocks = [
      {
        type: 'header',
        text: {
          type: 'plain_text',
          text: 'Available Commands',
        },
      },
      {
        type: 'divider',
      },
    ];

    commands.forEach(cmd => {
      blocks.push({
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: `*${cmd.name}*\n${cmd.description}\n\`Usage: ${cmd.usage}\``,
        },
      });
    });

    return {
      response_type: 'ephemeral',
      blocks,
    };
  }
}
```

### 2.2 Specific Command Handlers

```typescript
// src/slack/commands/myapp-command.ts
import { BaseCommandHandler, SlackCommandRequest, SlackCommandResponse } from '../command-handler';
import { SlackMessageBuilder } from '../message-builder';

export class MyAppCommandHandler extends BaseCommandHandler {
  async handle(request: SlackCommandRequest): Promise<SlackCommandResponse> {
    const args = this.parseArguments(request.text);
    const action = args[0]?.toLowerCase();

    switch (action) {
      case 'help':
        return this.handleHelp();
      
      case 'status':
        return this.handleStatus(request);
      
      case 'create':
        return this.handleCreate(args.slice(1), request);
      
      case 'list':
        return this.handleList(request);
      
      case 'delete':
        return this.handleDelete(args.slice(1), request);
      
      default:
        return this.handleDefault();
    }
  }

  private handleHelp(): SlackCommandResponse {
    const commands = [
      {
        name: '/myapp help',
        description: 'Show this help message',
        usage: '/myapp help',
      },
      {
        name: '/myapp status',
        description: 'Check application status',
        usage: '/myapp status',
      },
      {
        name: '/myapp create',
        description: 'Create a new item',
        usage: '/myapp create [name] [description]',
      },
      {
        name: '/myapp list',
        description: 'List all items',
        usage: '/myapp list',
      },
      {
        name: '/myapp delete',
        description: 'Delete an item',
        usage: '/myapp delete [id]',
      },
    ];

    return this.createHelpResponse(commands);
  }

  private async handleStatus(request: SlackCommandRequest): Promise<SlackCommandResponse> {
    try {
      // Check application status
      const status = await this.checkApplicationStatus();
      
      const message = new SlackMessageBuilder()
        .addHeader('Application Status')
        .addSection(`*Status:* ${status.healthy ? ':green_circle: Healthy' : ':red_circle: Unhealthy'}`)
        .addSection(`*Version:* ${status.version}`)
        .addSection(`*Uptime:* ${status.uptime}`)
        .addSection(`*Last Updated:* ${new Date().toISOString()}`)
        .build();

      return {
        response_type: 'ephemeral',
        blocks: message.blocks,
      };
    } catch (error) {
      return this.createErrorResponse('Failed to check application status');
    }
  }

  private async handleCreate(args: string[], request: SlackCommandRequest): Promise<SlackCommandResponse> {
    if (args.length < 2) {
      return this.createErrorResponse('Usage: /myapp create [name] [description]');
    }

    const [name, ...descriptionParts] = args;
    const description = descriptionParts.join(' ');

    try {
      // Create item in your application
      const item = await this.createItem(name, description, request.user_id);
      
      const message = new SlackMessageBuilder()
        .addHeader('Item Created Successfully')
        .addSection(`*Name:* ${item.name}`)
        .addSection(`*Description:* ${item.description}`)
        .addSection(`*ID:* ${item.id}`)
        .addButton('View Details', 'view_item', item.id, 'primary')
        .addButton('Edit Item', 'edit_item', item.id)
        .build();

      return {
        response_type: 'in_channel',
        blocks: message.blocks,
      };
    } catch (error) {
      return this.createErrorResponse(`Failed to create item: ${error.message}`);
    }
  }

  private async handleList(request: SlackCommandRequest): Promise<SlackCommandResponse> {
    try {
      const items = await this.getItems(request.user_id);
      
      if (items.length === 0) {
        return {
          response_type: 'ephemeral',
          text: 'No items found. Use `/myapp create` to create your first item.',
        };
      }

      const message = new SlackMessageBuilder()
        .addHeader(`Your Items (${items.length})`)
        .addDivider();

      items.forEach(item => {
        message.addSection(`*${item.name}*\n${item.description}\n_ID: ${item.id}_`);
      });

      message.addDivider()
        .addContext(['Use `/myapp create` to add more items']);

      return {
        response_type: 'ephemeral',
        blocks: message.build().blocks,
      };
    } catch (error) {
      return this.createErrorResponse('Failed to retrieve items');
    }
  }

  private async handleDelete(args: string[], request: SlackCommandRequest): Promise<SlackCommandResponse> {
    if (args.length === 0) {
      return this.createErrorResponse('Usage: /myapp delete [id]');
    }

    const itemId = args[0];

    try {
      await this.deleteItem(itemId, request.user_id);
      return this.createSuccessResponse(`Item ${itemId} deleted successfully`, true);
    } catch (error) {
      return this.createErrorResponse(`Failed to delete item: ${error.message}`);
    }
  }

  private handleDefault(): SlackCommandResponse {
    return {
      response_type: 'ephemeral',
      text: 'Welcome to MyApp! Use `/myapp help` to see available commands.',
    };
  }

  // Mock application methods (replace with actual implementation)
  private async checkApplicationStatus(): Promise<any> {
    return {
      healthy: true,
      version: '1.0.0',
      uptime: '2 days, 3 hours',
    };
  }

  private async createItem(name: string, description: string, userId: string): Promise<any> {
    // Implement your item creation logic
    return {
      id: `item_${Date.now()}`,
      name,
      description,
      userId,
      createdAt: new Date().toISOString(),
    };
  }

  private async getItems(userId: string): Promise<any[]> {
    // Implement your item retrieval logic
    return [
      {
        id: 'item_1',
        name: 'Sample Item 1',
        description: 'This is a sample item',
        userId,
      },
      {
        id: 'item_2',
        name: 'Sample Item 2',
        description: 'Another sample item',
        userId,
      },
    ];
  }

  private async deleteItem(itemId: string, userId: string): Promise<void> {
    // Implement your item deletion logic
    console.log(`Deleting item ${itemId} for user ${userId}`);
  }
}
```

### 2.3 Interactive Components Handler

```typescript
// src/slack/interactive-handler.ts
import { WebClient } from '@slack/web-api';
import { SlackMessageBuilder } from './message-builder';

export interface SlackInteractiveRequest {
  type: string;
  user: {
    id: string;
    name: string;
  };
  channel: {
    id: string;
    name: string;
  };
  team: {
    id: string;
    domain: string;
  };
  actions: Array<{
    action_id: string;
    value?: string;
    selected_option?: {
      value: string;
      text: {
        text: string;
      };
    };
  }>;
  response_url: string;
  trigger_id: string;
}

export class SlackInteractiveHandler {
  private webClient: WebClient;

  constructor(token: string) {
    this.webClient = new WebClient(token);
  }

  // Handle interactive component actions
  async handleInteraction(payload: SlackInteractiveRequest): Promise<any> {
    const action = payload.actions[0];
    
    switch (action.action_id) {
      case 'view_item':
        return this.handleViewItem(action.value!, payload);
      
      case 'edit_item':
        return this.handleEditItem(action.value!, payload);
      
      case 'delete_item':
        return this.handleDeleteItem(action.value!, payload);
      
      case 'confirm_delete':
        return this.handleConfirmDelete(action.value!, payload);
      
      case 'cancel_delete':
        return this.handleCancelDelete(payload);
      
      default:
        return this.handleUnknownAction(action.action_id, payload);
    }
  }

  private async handleViewItem(itemId: string, payload: SlackInteractiveRequest): Promise<any> {
    try {
      // Fetch item details
      const item = await this.getItemDetails(itemId);
      
      const message = new SlackMessageBuilder()
        .addHeader(`Item Details: ${item.name}`)
        .addSection(`*Description:* ${item.description}`)
        .addSection(`*Created:* ${new Date(item.createdAt).toLocaleDateString()}`)
        .addSection(`*Status:* ${item.status}`)
        .addDivider()
        .addButton('Edit Item', 'edit_item', itemId, 'primary')
        .addButton('Delete Item', 'delete_item', itemId, 'danger')
        .build();

      return {
        replace_original: true,
        blocks: message.blocks,
      };
    } catch (error) {
      return {
        replace_original: true,
        text: `:x: Error: Failed to load item details`,
      };
    }
  }

  private async handleEditItem(itemId: string, payload: SlackInteractiveRequest): Promise<any> {
    try {
      // Open modal for editing
      await this.webClient.views.open({
        trigger_id: payload.trigger_id,
        view: {
          type: 'modal',
          callback_id: 'edit_item_modal',
          title: {
            type: 'plain_text',
            text: 'Edit Item',
          },
          submit: {
            type: 'plain_text',
            text: 'Save Changes',
          },
          close: {
            type: 'plain_text',
            text: 'Cancel',
          },
          private_metadata: itemId,
          blocks: [
            {
              type: 'input',
              block_id: 'item_name',
              element: {
                type: 'plain_text_input',
                action_id: 'name_input',
                placeholder: {
                  type: 'plain_text',
                  text: 'Enter item name',
                },
              },
              label: {
                type: 'plain_text',
                text: 'Name',
              },
            },
            {
              type: 'input',
              block_id: 'item_description',
              element: {
                type: 'plain_text_input',
                action_id: 'description_input',
                multiline: true,
                placeholder: {
                  type: 'plain_text',
                  text: 'Enter item description',
                },
              },
              label: {
                type: 'plain_text',
                text: 'Description',
              },
            },
          ],
        },
      });

      return { response_type: 'ephemeral' };
    } catch (error) {
      return {
        replace_original: true,
        text: `:x: Error: Failed to open edit dialog`,
      };
    }
  }

  private async handleDeleteItem(itemId: string, payload: SlackInteractiveRequest): Promise<any> {
    const message = new SlackMessageBuilder()
      .addHeader('Confirm Deletion')
      .addSection(`Are you sure you want to delete this item?`)
      .addSection(`*Item ID:* ${itemId}`)
      .addDivider()
      .addButton('Yes, Delete', 'confirm_delete', itemId, 'danger')
      .addButton('Cancel', 'cancel_delete', itemId)
      .build();

    return {
      replace_original: true,
      blocks: message.blocks,
    };
  }

  private async handleConfirmDelete(itemId: string, payload: SlackInteractiveRequest): Promise<any> {
    try {
      // Delete the item
      await this.deleteItem(itemId, payload.user.id);
      
      return {
        replace_original: true,
        text: `:white_check_mark: Item ${itemId} has been deleted successfully.`,
      };
    } catch (error) {
      return {
        replace_original: true,
        text: `:x: Error: Failed to delete item`,
      };
    }
  }

  private handleCancelDelete(payload: SlackInteractiveRequest): any {
    return {
      replace_original: true,
      text: 'Deletion cancelled.',
    };
  }

  private handleUnknownAction(actionId: string, payload: SlackInteractiveRequest): any {
    return {
      replace_original: true,
      text: `:warning: Unknown action: ${actionId}`,
    };
  }

  // Mock methods (replace with actual implementation)
  private async getItemDetails(itemId: string): Promise<any> {
    return {
      id: itemId,
      name: 'Sample Item',
      description: 'This is a sample item description',
      status: 'Active',
      createdAt: new Date().toISOString(),
    };
  }

  private async deleteItem(itemId: string, userId: string): Promise<void> {
    console.log(`Deleting item ${itemId} for user ${userId}`);
  }
}
```

## Step 3: Express Route Handlers

### 3.1 Command Routes

```typescript
// src/routes/slack-commands.ts
import express from 'express';
import { MyAppCommandHandler } from '../slack/commands/myapp-command';
import { SlackInteractiveHandler } from '../slack/interactive-handler';
import { SlackSessionManager } from '../slack/session-manager';

const router = express.Router();
const sessionManager = new SlackSessionManager();

// Middleware to parse URL-encoded bodies (Slack sends form data)
router.use(express.urlencoded({ extended: true }));

// Handle slash commands
router.post('/myapp', async (req, res) => {
  try {
    // Verify request signature
    const timestamp = req.headers['x-slack-request-timestamp'] as string;
    const signature = req.headers['x-slack-signature'] as string;
    const body = JSON.stringify(req.body);

    // Get session for this team
    const session = await sessionManager.getSessionByTeam(req.body.team_id);
    if (!session) {
      return res.status(401).json({
        response_type: 'ephemeral',
        text: 'App not installed. Please install the app first.',
      });
    }

    // Create command handler
    const handler = new MyAppCommandHandler(session.botToken);

    // Verify signature
    if (!handler.verifySignature(body, timestamp, signature)) {
      return res.status(401).json({
        response_type: 'ephemeral',
        text: 'Invalid request signature.',
      });
    }

    // Handle command
    const response = await handler.handle(req.body);
    
    // Send immediate response
    res.json(response);

  } catch (error) {
    console.error('Command handler error:', error);
    res.status(500).json({
      response_type: 'ephemeral',
      text: 'An error occurred while processing your command.',
    });
  }
});

// Handle interactive components
router.post('/interactive', async (req, res) => {
  try {
    const payload = JSON.parse(req.body.payload);
    
    // Get session for this team
    const session = await sessionManager.getSessionByTeam(payload.team.id);
    if (!session) {
      return res.status(401).json({
        response_type: 'ephemeral',
        text: 'App not installed.',
      });
    }

    // Create interactive handler
    const handler = new SlackInteractiveHandler(session.botToken);

    // Handle interaction
    const response = await handler.handleInteraction(payload);
    
    // Send response
    res.json(response);

  } catch (error) {
    console.error('Interactive handler error:', error);
    res.status(500).json({
      response_type: 'ephemeral',
      text: 'An error occurred while processing your interaction.',
    });
  }
});

// Handle modal submissions
router.post('/modal', async (req, res) => {
  try {
    const payload = JSON.parse(req.body.payload);
    
    if (payload.type === 'view_submission') {
      await handleModalSubmission(payload);
    }

    res.status(200).send();

  } catch (error) {
    console.error('Modal handler error:', error);
    res.status(500).send();
  }
});

// Handle modal submission
async function handleModalSubmission(payload: any): Promise<void> {
  const callbackId = payload.view.callback_id;
  
  switch (callbackId) {
    case 'edit_item_modal':
      await handleEditItemModal(payload);
      break;
    
    default:
      console.warn(`Unknown modal callback: ${callbackId}`);
  }
}

// Handle edit item modal submission
async function handleEditItemModal(payload: any): Promise<void> {
  const itemId = payload.view.private_metadata;
  const values = payload.view.state.values;
  
  const name = values.item_name.name_input.value;
  const description = values.item_description.description_input.value;
  
  try {
    // Update item in your application
    await updateItem(itemId, { name, description });
    
    // Send success message to user
    const session = await sessionManager.getSessionByTeam(payload.team.id);
    if (session) {
      const { SlackClient } = await import('../slack/slack-client');
      const client = new SlackClient(session.botToken);
      
      await client.sendDirectMessage(
        payload.user.id,
        `Item ${itemId} updated successfully!`
      );
    }
  } catch (error) {
    console.error('Failed to update item:', error);
  }
}

// Mock update function
async function updateItem(itemId: string, updates: any): Promise<void> {
  console.log(`Updating item ${itemId}:`, updates);
}

export default router;
```

### 3.2 Command Testing Routes

```typescript
// src/routes/slack-command-test.ts
import express from 'express';
import { MyAppCommandHandler } from '../slack/commands/myapp-command';

const router = express.Router();

// Test command handler
router.post('/test', async (req, res) => {
  try {
    const { command, text, user_id, team_id } = req.body;

    if (!command || !user_id || !team_id) {
      return res.status(400).json({
        error: 'Missing required fields: command, user_id, team_id'
      });
    }

    // Create test request
    const testRequest = {
      token: 'test-token',
      team_id,
      team_domain: 'test-team',
      channel_id: 'C1234567890',
      channel_name: 'test-channel',
      user_id,
      user_name: 'test-user',
      command,
      text: text || '',
      response_url: 'https://hooks.slack.com/commands/test',
      trigger_id: 'test-trigger-id',
    };

    // Create handler with test token
    const handler = new MyAppCommandHandler('test-token');
    
    // Handle command
    const response = await handler.handle(testRequest);
    
    res.json({
      success: true,
      request: testRequest,
      response,
    });

  } catch (error) {
    console.error('Test command error:', error);
    res.status(500).json({
      error: 'Failed to test command',
      message: error.message
    });
  }
});

export default router;
```

## Step 4: Advanced Features

### 4.1 Command Middleware

```typescript
// src/slack/command-middleware.ts
import { SlackCommandRequest, SlackCommandResponse } from './command-handler';

export type CommandMiddleware = (
  request: SlackCommandRequest,
  next: () => Promise<SlackCommandResponse>
) => Promise<SlackCommandResponse>;

// Rate limiting middleware
export function rateLimitMiddleware(maxRequests: number = 10, windowMs: number = 60000): CommandMiddleware {
  const requests = new Map<string, number[]>();

  return async (request, next) => {
    const key = `${request.team_id}:${request.user_id}`;
    const now = Date.now();
    const userRequests = requests.get(key) || [];
    
    // Remove old requests
    const validRequests = userRequests.filter(time => now - time < windowMs);
    
    if (validRequests.length >= maxRequests) {
      return {
        response_type: 'ephemeral',
        text: ':warning: Rate limit exceeded. Please try again later.',
      };
    }

    validRequests.push(now);
    requests.set(key, validRequests);
    
    return next();
  };
}

// Authentication middleware
export function authMiddleware(): CommandMiddleware {
  return async (request, next) => {
    // Check if user is authenticated in your system
    const isAuthenticated = await checkUserAuthentication(request.user_id);
    
    if (!isAuthenticated) {
      return {
        response_type: 'ephemeral',
        text: ':lock: Please authenticate first using `/myapp login`',
      };
    }

    return next();
  };
}

// Logging middleware
export function loggingMiddleware(): CommandMiddleware {
  return async (request, next) => {
    const startTime = Date.now();
    
    console.log(`Command received: ${request.command} ${request.text} from ${request.user_name}`);
    
    try {
      const response = await next();
      const duration = Date.now() - startTime;
      
      console.log(`Command completed in ${duration}ms`);
      return response;
    } catch (error) {
      const duration = Date.now() - startTime;
      console.error(`Command failed after ${duration}ms:`, error);
      throw error;
    }
  };
}

// Mock authentication function
async function checkUserAuthentication(userId: string): Promise<boolean> {
  // Implement your authentication check
  return true;
}
```

### 4.2 Command Router

```typescript
// src/slack/command-router.ts
import { BaseCommandHandler, SlackCommandRequest, SlackCommandResponse } from './command-handler';
import { CommandMiddleware } from './command-middleware';

export class CommandRouter {
  private handlers = new Map<string, BaseCommandHandler>();
  private middleware: CommandMiddleware[] = [];

  // Register command handler
  register(command: string, handler: BaseCommandHandler): void {
    this.handlers.set(command, handler);
  }

  // Add middleware
  use(middleware: CommandMiddleware): void {
    this.middleware.push(middleware);
  }

  // Route command to appropriate handler
  async route(request: SlackCommandRequest): Promise<SlackCommandResponse> {
    const handler = this.handlers.get(request.command);
    
    if (!handler) {
      return {
        response_type: 'ephemeral',
        text: `:warning: Unknown command: ${request.command}`,
      };
    }

    // Execute middleware chain
    return this.executeMiddleware(request, handler);
  }

  // Execute middleware chain
  private async executeMiddleware(
    request: SlackCommandRequest,
    handler: BaseCommandHandler
  ): Promise<SlackCommandResponse> {
    let index = 0;

    const next = async (): Promise<SlackCommandResponse> => {
      if (index < this.middleware.length) {
        const middleware = this.middleware[index++];
        return middleware(request, next);
      } else {
        return handler.handle(request);
      }
    };

    return next();
  }
}
```

## Step 5: Testing and Deployment

### 5.1 Local Testing with ngrok

```bash
# Install ngrok
npm install -g ngrok

# Start your application
npm start

# Expose local server
ngrok http 3000

# Update Slack app request URLs with ngrok URL
```

### 5.2 Command Testing Script

```typescript
// scripts/test-commands.ts
import axios from 'axios';

async function testSlashCommand() {
  const testCases = [
    {
      command: '/myapp',
      text: 'help',
      description: 'Test help command',
    },
    {
      command: '/myapp',
      text: 'status',
      description: 'Test status command',
    },
    {
      command: '/myapp',
      text: 'create TestItem This is a test item',
      description: 'Test create command',
    },
    {
      command: '/myapp',
      text: 'list',
      description: 'Test list command',
    },
  ];

  for (const testCase of testCases) {
    console.log(`\nTesting: ${testCase.description}`);
    
    try {
      const response = await axios.post('http://localhost:3000/slack/commands/test', {
        command: testCase.command,
        text: testCase.text,
        user_id: 'U1234567890',
        team_id: 'T1234567890',
      });

      console.log('Response:', response.data.response);
    } catch (error) {
      console.error('Error:', error.response?.data || error.message);
    }
  }
}

testSlashCommand();
```

## Security Best Practices

1. **Signature Verification**: Always verify request signatures
2. **Rate Limiting**: Implement rate limiting per user/team
3. **Input Validation**: Validate and sanitize all user inputs
4. **Authentication**: Verify user permissions for sensitive operations
5. **Error Handling**: Don't expose sensitive information in error messages
6. **Logging**: Log commands for debugging and audit purposes

## Troubleshooting

### Common Issues

1. **Signature Verification Fails**: Check signing secret and timestamp
2. **Commands Not Responding**: Verify request URL and HTTPS
3. **Timeout Errors**: Respond within 3 seconds or use delayed responses
4. **Permission Errors**: Check app scopes and installation

### Debug Mode

Enable command debugging:

```typescript
process.env.SLACK_COMMAND_DEBUG = 'true';
```

## Next Steps

- [Slack Integration](./slack.md) - Main Slack integration guide
- [Shopify Integration](./shopify.md) - E-commerce integration
- [QuickBooks Integration](./quickbooks.md) - Accounting integration

