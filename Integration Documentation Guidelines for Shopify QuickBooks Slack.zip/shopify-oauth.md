# Shopify OAuth 2.0 Setup Guide

This guide provides detailed implementation instructions for Shopify's OAuth 2.0 authentication flow, including advanced configuration options and security best practices.

## OAuth 2.0 Flow Overview

Shopify uses OAuth 2.0 for secure app authentication. The flow involves several steps:

1. **Authorization Request**: Redirect user to Shopify's authorization server
2. **User Authorization**: User grants permissions to your app
3. **Authorization Code**: Shopify redirects back with authorization code
4. **Token Exchange**: Exchange code for access token
5. **API Access**: Use access token for API requests

## Implementation Details

### Step 1: Authorization URL Generation

```typescript
// src/auth/oauth-handler.ts
import { shopifyApi } from '@shopify/shopify-api';
import { randomBytes } from 'crypto';

export class ShopifyOAuthHandler {
  private shopify: any;
  private stateStore: Map<string, { shop: string; timestamp: number }> = new Map();

  constructor() {
    this.shopify = shopifyApi({
      apiKey: process.env.SHOPIFY_API_KEY!,
      apiSecretKey: process.env.SHOPIFY_API_SECRET!,
      scopes: process.env.SHOPIFY_SCOPES!.split(','),
      hostName: process.env.SHOPIFY_APP_URL!.replace(/https?:\/\//, ''),
      apiVersion: '2024-01',
      isEmbeddedApp: true,
    });
  }

  // Generate authorization URL with state parameter
  async generateAuthUrl(shop: string, isOnline: boolean = false): Promise<string> {
    // Validate shop domain
    if (!this.isValidShopDomain(shop)) {
      throw new Error('Invalid shop domain');
    }

    // Generate state parameter for CSRF protection
    const state = randomBytes(32).toString('hex');
    this.stateStore.set(state, {
      shop,
      timestamp: Date.now()
    });

    // Clean up old state entries (older than 10 minutes)
    this.cleanupExpiredStates();

    const authUrl = await this.shopify.auth.begin({
      shop,
      callbackPath: '/auth/shopify/callback',
      isOnline,
      state,
    });

    return authUrl;
  }

  // Validate shop domain format
  private isValidShopDomain(shop: string): boolean {
    const shopRegex = /^[a-zA-Z0-9][a-zA-Z0-9\-]*\.myshopify\.com$/;
    return shopRegex.test(shop);
  }

  // Clean up expired state entries
  private cleanupExpiredStates(): void {
    const tenMinutesAgo = Date.now() - (10 * 60 * 1000);
    for (const [state, data] of this.stateStore.entries()) {
      if (data.timestamp < tenMinutesAgo) {
        this.stateStore.delete(state);
      }
    }
  }

  // Verify state parameter
  verifyState(state: string, shop: string): boolean {
    const storedData = this.stateStore.get(state);
    if (!storedData) {
      return false;
    }

    // Check if state is expired (10 minutes)
    const tenMinutesAgo = Date.now() - (10 * 60 * 1000);
    if (storedData.timestamp < tenMinutesAgo) {
      this.stateStore.delete(state);
      return false;
    }

    // Verify shop matches
    if (storedData.shop !== shop) {
      return false;
    }

    // Clean up used state
    this.stateStore.delete(state);
    return true;
  }
}
```

### Step 2: OAuth Callback Handler

```typescript
// src/auth/callback-handler.ts
import express from 'express';
import { ShopifyOAuthHandler } from './oauth-handler';
import { SessionManager } from './session-manager';

const router = express.Router();
const oauthHandler = new ShopifyOAuthHandler();
const sessionManager = new SessionManager();

router.get('/callback', async (req, res) => {
  const { code, shop, state, hmac, timestamp } = req.query;

  try {
    // Validate required parameters
    if (!code || !shop || !state || !hmac || !timestamp) {
      return res.status(400).json({
        error: 'Missing required OAuth parameters'
      });
    }

    // Verify state parameter (CSRF protection)
    if (!oauthHandler.verifyState(state as string, shop as string)) {
      return res.status(400).json({
        error: 'Invalid or expired state parameter'
      });
    }

    // Verify HMAC signature
    if (!verifyHmacSignature(req.query)) {
      return res.status(400).json({
        error: 'Invalid HMAC signature'
      });
    }

    // Exchange authorization code for access token
    const callback = await oauthHandler.shopify.auth.callback({
      rawRequest: req,
      rawResponse: res,
    });

    const { session } = callback;

    // Store session securely
    await sessionManager.storeSession(session);

    // Register mandatory webhooks
    await registerMandatoryWebhooks(session);

    // Redirect to app or success page
    const redirectUrl = session.isOnline 
      ? `/app?shop=${session.shop}&host=${req.query.host}`
      : `/install/success?shop=${session.shop}`;

    res.redirect(redirectUrl);

  } catch (error) {
    console.error('OAuth callback error:', error);
    
    // Log error details for debugging
    console.error('Error details:', {
      shop,
      error: error.message,
      stack: error.stack
    });

    res.status(500).json({
      error: 'Authentication failed',
      message: 'Please try again or contact support'
    });
  }
});

// Verify HMAC signature for additional security
function verifyHmacSignature(query: any): boolean {
  const { hmac, ...params } = query;
  
  // Sort parameters and create query string
  const sortedParams = Object.keys(params)
    .sort()
    .map(key => `${key}=${params[key]}`)
    .join('&');

  // Calculate HMAC
  const crypto = require('crypto');
  const calculatedHmac = crypto
    .createHmac('sha256', process.env.SHOPIFY_API_SECRET!)
    .update(sortedParams)
    .digest('hex');

  return calculatedHmac === hmac;
}

// Register mandatory webhooks after installation
async function registerMandatoryWebhooks(session: any) {
  try {
    const webhooks = [
      'app/uninstalled',
      'customers/data_request',
      'customers/redact',
      'shop/redact'
    ];

    for (const topic of webhooks) {
      await registerWebhook(session, topic);
    }
  } catch (error) {
    console.error('Failed to register mandatory webhooks:', error);
  }
}

async function registerWebhook(session: any, topic: string) {
  const client = new oauthHandler.shopify.clients.Rest({ session });
  
  await client.post({
    path: 'webhooks',
    data: {
      webhook: {
        topic,
        address: `${process.env.SHOPIFY_APP_URL}/webhooks/${topic.replace('/', '-')}`,
        format: 'json'
      }
    }
  });
}

export default router;
```

### Step 3: Session Management

```typescript
// src/auth/session-manager.ts
import { Session } from '@shopify/shopify-api';
import { encrypt, decrypt } from '../utils/encryption';

export interface StoredSession {
  id: string;
  shop: string;
  accessToken: string;
  scope: string;
  expires?: Date;
  isOnline: boolean;
  state?: string;
  onlineAccessInfo?: any;
}

export class SessionManager {
  private sessions: Map<string, StoredSession> = new Map();

  // Store session with encryption
  async storeSession(session: Session): Promise<void> {
    const sessionData: StoredSession = {
      id: session.id,
      shop: session.shop,
      accessToken: encrypt(session.accessToken),
      scope: session.scope,
      expires: session.expires,
      isOnline: session.isOnline,
      state: session.state,
      onlineAccessInfo: session.onlineAccessInfo,
    };

    // In production, store in database
    this.sessions.set(session.id, sessionData);
    
    // Also store by shop for easy lookup
    this.sessions.set(`shop:${session.shop}`, sessionData);

    console.log(`Session stored for shop: ${session.shop}`);
  }

  // Retrieve session with decryption
  async getSession(sessionId: string): Promise<Session | null> {
    const storedSession = this.sessions.get(sessionId);
    if (!storedSession) {
      return null;
    }

    // Check if session is expired
    if (storedSession.expires && storedSession.expires < new Date()) {
      await this.deleteSession(sessionId);
      return null;
    }

    // Decrypt access token
    const session: Session = {
      id: storedSession.id,
      shop: storedSession.shop,
      accessToken: decrypt(storedSession.accessToken),
      scope: storedSession.scope,
      expires: storedSession.expires,
      isOnline: storedSession.isOnline,
      state: storedSession.state,
      onlineAccessInfo: storedSession.onlineAccessInfo,
    };

    return session;
  }

  // Get session by shop domain
  async getSessionByShop(shop: string): Promise<Session | null> {
    return this.getSession(`shop:${shop}`);
  }

  // Delete session
  async deleteSession(sessionId: string): Promise<void> {
    const session = this.sessions.get(sessionId);
    if (session) {
      this.sessions.delete(sessionId);
      this.sessions.delete(`shop:${session.shop}`);
    }
  }

  // Refresh online token
  async refreshOnlineToken(session: Session): Promise<Session> {
    if (!session.isOnline || !session.onlineAccessInfo?.refresh_token) {
      throw new Error('Cannot refresh offline token or missing refresh token');
    }

    const response = await fetch(`https://${session.shop}/admin/oauth/access_token`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        client_id: process.env.SHOPIFY_API_KEY,
        client_secret: process.env.SHOPIFY_API_SECRET,
        refresh_token: session.onlineAccessInfo.refresh_token,
        grant_type: 'refresh_token',
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to refresh token');
    }

    const tokenData = await response.json();
    
    // Update session with new token
    session.accessToken = tokenData.access_token;
    session.expires = new Date(Date.now() + tokenData.expires_in * 1000);
    
    // Store updated session
    await this.storeSession(session);
    
    return session;
  }

  // Validate session and refresh if needed
  async validateSession(sessionId: string): Promise<Session | null> {
    const session = await this.getSession(sessionId);
    if (!session) {
      return null;
    }

    // Check if online token needs refresh
    if (session.isOnline && session.expires) {
      const fiveMinutesFromNow = new Date(Date.now() + 5 * 60 * 1000);
      if (session.expires < fiveMinutesFromNow) {
        try {
          return await this.refreshOnlineToken(session);
        } catch (error) {
          console.error('Failed to refresh token:', error);
          await this.deleteSession(sessionId);
          return null;
        }
      }
    }

    return session;
  }
}
```

### Step 4: Middleware for Authentication

```typescript
// src/middleware/auth-middleware.ts
import { Request, Response, NextFunction } from 'express';
import { SessionManager } from '../auth/session-manager';

const sessionManager = new SessionManager();

export interface AuthenticatedRequest extends Request {
  session?: any;
  shop?: string;
}

// Middleware to verify Shopify session
export async function verifyShopifyAuth(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
) {
  try {
    const sessionId = getSessionId(req);
    
    if (!sessionId) {
      return res.status(401).json({
        error: 'No session found',
        redirectUrl: '/auth/shopify/install'
      });
    }

    const session = await sessionManager.validateSession(sessionId);
    
    if (!session) {
      return res.status(401).json({
        error: 'Invalid or expired session',
        redirectUrl: '/auth/shopify/install'
      });
    }

    // Attach session to request
    req.session = session;
    req.shop = session.shop;
    
    next();
  } catch (error) {
    console.error('Auth middleware error:', error);
    res.status(500).json({
      error: 'Authentication error'
    });
  }
}

// Extract session ID from request
function getSessionId(req: Request): string | null {
  // Try different sources for session ID
  
  // 1. Authorization header
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.substring(7);
  }

  // 2. Query parameter
  if (req.query.session) {
    return req.query.session as string;
  }

  // 3. Shop parameter (for offline sessions)
  if (req.query.shop) {
    return `shop:${req.query.shop}`;
  }

  // 4. Cookie (if using cookie-based sessions)
  if (req.cookies && req.cookies.shopify_session) {
    return req.cookies.shopify_session;
  }

  return null;
}

// Middleware for embedded app authentication
export async function verifyEmbeddedAuth(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
) {
  try {
    // Verify Shopify's embedded app token
    const token = req.headers['x-shopify-access-token'] as string;
    
    if (!token) {
      return res.status(401).json({
        error: 'Missing embedded app token'
      });
    }

    // Decode and verify JWT token
    const jwt = require('jsonwebtoken');
    const decoded = jwt.verify(token, process.env.SHOPIFY_API_SECRET!);
    
    req.shop = decoded.dest.replace('https://', '').replace('/admin', '');
    
    // Get session for this shop
    const session = await sessionManager.getSessionByShop(req.shop);
    
    if (!session) {
      return res.status(401).json({
        error: 'No session found for shop',
        redirectUrl: '/auth/shopify/install'
      });
    }

    req.session = session;
    next();
    
  } catch (error) {
    console.error('Embedded auth error:', error);
    res.status(401).json({
      error: 'Invalid embedded app token'
    });
  }
}
```

### Step 5: Advanced OAuth Configuration

```typescript
// src/config/oauth-config.ts
export interface OAuthConfig {
  scopes: string[];
  isEmbeddedApp: boolean;
  useOnlineTokens: boolean;
  customRedirectPath?: string;
  additionalAuthParams?: Record<string, string>;
}

export class AdvancedOAuthConfig {
  private config: OAuthConfig;

  constructor(config: OAuthConfig) {
    this.config = config;
  }

  // Generate scope-specific auth URL
  generateScopedAuthUrl(shop: string, requiredScopes: string[]): string {
    const missingScopes = this.getMissingScopes(shop, requiredScopes);
    
    if (missingScopes.length === 0) {
      throw new Error('All required scopes already granted');
    }

    return this.generateAuthUrlWithScopes(shop, missingScopes);
  }

  // Check if shop has required scopes
  async hasRequiredScopes(shop: string, requiredScopes: string[]): Promise<boolean> {
    const session = await sessionManager.getSessionByShop(shop);
    
    if (!session) {
      return false;
    }

    const grantedScopes = session.scope.split(',');
    return requiredScopes.every(scope => grantedScopes.includes(scope));
  }

  // Get missing scopes for a shop
  private getMissingScopes(shop: string, requiredScopes: string[]): string[] {
    // Implementation to check current scopes vs required
    // This would typically involve checking the stored session
    return requiredScopes; // Simplified for example
  }

  // Generate auth URL with specific scopes
  private generateAuthUrlWithScopes(shop: string, scopes: string[]): string {
    const params = new URLSearchParams({
      client_id: process.env.SHOPIFY_API_KEY!,
      scope: scopes.join(','),
      redirect_uri: `${process.env.SHOPIFY_APP_URL}/auth/shopify/callback`,
      state: this.generateState(),
      'grant_options[]': this.config.useOnlineTokens ? 'per-user' : '',
    });

    return `https://${shop}/admin/oauth/authorize?${params.toString()}`;
  }

  private generateState(): string {
    return require('crypto').randomBytes(32).toString('hex');
  }
}
```

### Step 6: Error Handling and Retry Logic

```typescript
// src/auth/oauth-error-handler.ts
export enum OAuthErrorType {
  INVALID_SHOP = 'invalid_shop',
  ACCESS_DENIED = 'access_denied',
  INVALID_SCOPE = 'invalid_scope',
  RATE_LIMITED = 'rate_limited',
  NETWORK_ERROR = 'network_error',
  UNKNOWN_ERROR = 'unknown_error'
}

export class OAuthError extends Error {
  constructor(
    public type: OAuthErrorType,
    message: string,
    public retryable: boolean = false,
    public retryAfter?: number
  ) {
    super(message);
    this.name = 'OAuthError';
  }
}

export class OAuthErrorHandler {
  // Handle OAuth errors with appropriate responses
  static handleError(error: any, req: any, res: any): void {
    const oauthError = this.parseError(error);
    
    console.error('OAuth Error:', {
      type: oauthError.type,
      message: oauthError.message,
      shop: req.query.shop,
      retryable: oauthError.retryable
    });

    switch (oauthError.type) {
      case OAuthErrorType.INVALID_SHOP:
        res.status(400).json({
          error: 'Invalid shop domain',
          message: 'Please provide a valid Shopify shop domain'
        });
        break;

      case OAuthErrorType.ACCESS_DENIED:
        res.status(403).json({
          error: 'Access denied',
          message: 'User denied access to the application'
        });
        break;

      case OAuthErrorType.INVALID_SCOPE:
        res.status(400).json({
          error: 'Invalid scope',
          message: 'Requested permissions are not valid'
        });
        break;

      case OAuthErrorType.RATE_LIMITED:
        res.status(429).json({
          error: 'Rate limited',
          message: 'Too many requests. Please try again later.',
          retryAfter: oauthError.retryAfter || 60
        });
        break;

      case OAuthErrorType.NETWORK_ERROR:
        if (oauthError.retryable) {
          res.status(503).json({
            error: 'Service temporarily unavailable',
            message: 'Please try again in a few moments',
            retryable: true
          });
        } else {
          res.status(500).json({
            error: 'Network error',
            message: 'Unable to connect to Shopify'
          });
        }
        break;

      default:
        res.status(500).json({
          error: 'Authentication failed',
          message: 'An unexpected error occurred during authentication'
        });
    }
  }

  // Parse different types of errors
  private static parseError(error: any): OAuthError {
    if (error.response) {
      const { status, data } = error.response;
      
      switch (status) {
        case 400:
          if (data.error === 'invalid_request') {
            return new OAuthError(OAuthErrorType.INVALID_SHOP, data.error_description);
          }
          return new OAuthError(OAuthErrorType.INVALID_SCOPE, data.error_description);
          
        case 403:
          return new OAuthError(OAuthErrorType.ACCESS_DENIED, 'User denied access');
          
        case 429:
          const retryAfter = parseInt(error.response.headers['retry-after']) || 60;
          return new OAuthError(OAuthErrorType.RATE_LIMITED, 'Rate limit exceeded', true, retryAfter);
          
        case 502:
        case 503:
        case 504:
          return new OAuthError(OAuthErrorType.NETWORK_ERROR, 'Service temporarily unavailable', true);
          
        default:
          return new OAuthError(OAuthErrorType.UNKNOWN_ERROR, data.error_description || 'Unknown error');
      }
    }

    if (error.code === 'ECONNREFUSED' || error.code === 'ETIMEDOUT') {
      return new OAuthError(OAuthErrorType.NETWORK_ERROR, 'Network connection failed', true);
    }

    return new OAuthError(OAuthErrorType.UNKNOWN_ERROR, error.message || 'Unknown error');
  }
}
```

## Testing OAuth Implementation

### Unit Tests

```typescript
// tests/oauth.test.ts
import { ShopifyOAuthHandler } from '../src/auth/oauth-handler';

describe('Shopify OAuth Handler', () => {
  let oauthHandler: ShopifyOAuthHandler;

  beforeEach(() => {
    oauthHandler = new ShopifyOAuthHandler();
  });

  test('should generate valid auth URL', async () => {
    const shop = 'test-shop.myshopify.com';
    const authUrl = await oauthHandler.generateAuthUrl(shop);
    
    expect(authUrl).toContain('https://test-shop.myshopify.com/admin/oauth/authorize');
    expect(authUrl).toContain('client_id=');
    expect(authUrl).toContain('scope=');
    expect(authUrl).toContain('state=');
  });

  test('should reject invalid shop domains', async () => {
    const invalidShops = [
      'invalid-shop',
      'shop.com',
      'https://shop.myshopify.com',
      'shop.myshopify.com.evil.com'
    ];

    for (const shop of invalidShops) {
      await expect(oauthHandler.generateAuthUrl(shop)).rejects.toThrow('Invalid shop domain');
    }
  });

  test('should verify state parameter correctly', () => {
    const shop = 'test-shop.myshopify.com';
    const state = 'test-state';
    
    // Manually add state to store
    oauthHandler['stateStore'].set(state, {
      shop,
      timestamp: Date.now()
    });

    expect(oauthHandler.verifyState(state, shop)).toBe(true);
    expect(oauthHandler.verifyState('invalid-state', shop)).toBe(false);
    expect(oauthHandler.verifyState(state, 'wrong-shop.myshopify.com')).toBe(false);
  });
});
```

### Integration Tests

```typescript
// tests/oauth-integration.test.ts
import request from 'supertest';
import app from '../src/app';

describe('OAuth Integration', () => {
  test('should initiate OAuth flow', async () => {
    const response = await request(app)
      .get('/auth/shopify/install')
      .query({ shop: 'test-shop.myshopify.com' });

    expect(response.status).toBe(302);
    expect(response.headers.location).toContain('test-shop.myshopify.com/admin/oauth/authorize');
  });

  test('should handle OAuth callback', async () => {
    const mockCallback = {
      code: 'test-code',
      shop: 'test-shop.myshopify.com',
      state: 'test-state',
      hmac: 'valid-hmac',
      timestamp: Date.now().toString()
    };

    const response = await request(app)
      .get('/auth/shopify/callback')
      .query(mockCallback);

    // This would require mocking Shopify's token exchange
    expect(response.status).toBe(302);
  });
});
```

## Security Considerations

### CSRF Protection
- Always use state parameter in OAuth flow
- Verify state parameter in callback
- Implement proper state cleanup

### Token Security
- Encrypt access tokens in storage
- Use HTTPS for all communications
- Implement token refresh for online tokens
- Set appropriate token expiration

### HMAC Verification
- Always verify HMAC signatures
- Use constant-time comparison
- Log failed verification attempts

### Rate Limiting
- Implement OAuth request rate limiting
- Handle rate limit responses gracefully
- Use exponential backoff for retries

## Best Practices

1. **State Management**: Use cryptographically secure random state values
2. **Error Handling**: Provide clear error messages without exposing sensitive data
3. **Logging**: Log OAuth events for debugging and security monitoring
4. **Testing**: Thoroughly test all OAuth flows and error scenarios
5. **Documentation**: Document all OAuth endpoints and parameters

## Troubleshooting

### Common Issues

1. **Redirect URI Mismatch**: Ensure exact match with app configuration
2. **Invalid HMAC**: Check secret key and parameter encoding
3. **Expired State**: Implement proper state cleanup and validation
4. **Scope Changes**: Handle scope upgrade flows properly

### Debug Tools

```typescript
// Enable OAuth debugging
process.env.SHOPIFY_LOG_LEVEL = 'debug';

// Log OAuth parameters
console.log('OAuth params:', {
  shop: req.query.shop,
  code: req.query.code ? 'present' : 'missing',
  state: req.query.state ? 'present' : 'missing',
  hmac: req.query.hmac ? 'present' : 'missing'
});
```

## Next Steps

- [Shopify Integration](./shopify.md) - Main integration guide
- [QuickBooks Integration](./quickbooks.md) - Accounting integration
- [Slack Integration](./slack.md) - Communication integration

