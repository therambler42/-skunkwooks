# Shopify Integration Guide

This comprehensive guide walks you through setting up a complete Shopify integration, including app creation, authentication, and data synchronization.

## Overview

Shopify integration enables your application to interact with Shopify stores, allowing you to manage products, orders, customers, and other store data. The integration uses Shopify's REST Admin API and GraphQL Admin API with OAuth 2.0 authentication.

## Prerequisites

Before starting, ensure you have:
- A Shopify Partner account
- A development store or access to a live Shopify store
- Node.js and TypeScript development environment
- Understanding of OAuth 2.0 flows

## Step 1: Create a Shopify App

### 1.1 Access Shopify Partner Dashboard

1. Log in to your [Shopify Partner Dashboard](https://partners.shopify.com/)
2. Navigate to "Apps" in the main menu
3. Click "Create app"
4. Choose "Public app" for distribution or "Custom app" for private use

### 1.2 Configure App Settings

Fill in the following required information:

- **App name**: Choose a descriptive name for your integration
- **App URL**: Your application's main URL (must be HTTPS)
- **Allowed redirection URL(s)**: OAuth callback endpoints

Example configuration:
```
App name: My Business Integration
App URL: https://myapp.example.com
Allowed redirection URLs: 
  - https://myapp.example.com/auth/shopify/callback
  - https://myapp.example.com/auth/shopify/install
```

### 1.3 Note Your Credentials

After creating the app, save these credentials securely:
- **API key**: Used for OAuth flow initiation
- **API secret key**: Used for token exchange and verification
- **Scopes**: Define what data your app can access

## Step 2: Environment Configuration

### 2.1 Environment Variables

Add the following variables to your `.env` file:

```bash
# Shopify App Configuration
SHOPIFY_API_KEY=your_api_key_here
SHOPIFY_API_SECRET=your_api_secret_here
SHOPIFY_SCOPES=read_products,write_products,read_orders,write_orders
SHOPIFY_APP_URL=https://your-app-domain.com

# OAuth Configuration
SHOPIFY_REDIRECT_URI=https://your-app-domain.com/auth/shopify/callback
SHOPIFY_WEBHOOK_SECRET=your_webhook_secret

# API Configuration
SHOPIFY_API_VERSION=2024-01
```

### 2.2 Required Scopes

Common scopes for business integrations:

| Scope | Description |
|-------|-------------|
| `read_products` | Read product information |
| `write_products` | Create and update products |
| `read_orders` | Read order information |
| `write_orders` | Create and update orders |
| `read_customers` | Read customer information |
| `write_customers` | Create and update customers |
| `read_inventory` | Read inventory levels |
| `write_inventory` | Update inventory levels |

## Step 3: Implementation

### 3.1 Install Dependencies

```bash
npm install @shopify/shopify-api @shopify/admin-api-client dotenv express
npm install -D @types/express @types/node typescript
```

### 3.2 Basic Setup

Create the main application file:

```typescript
// src/shopify-client.ts
import { shopifyApi, LATEST_API_VERSION } from '@shopify/shopify-api';
import { restResources } from '@shopify/shopify-api/rest/admin/2024-01';

const shopify = shopifyApi({
  apiKey: process.env.SHOPIFY_API_KEY!,
  apiSecretKey: process.env.SHOPIFY_API_SECRET!,
  scopes: process.env.SHOPIFY_SCOPES!.split(','),
  hostName: process.env.SHOPIFY_APP_URL!.replace(/https?:\/\//, ''),
  apiVersion: LATEST_API_VERSION,
  isEmbeddedApp: true,
  restResources,
});

export default shopify;
```

### 3.3 OAuth Flow Implementation

```typescript
// src/auth/shopify-auth.ts
import express from 'express';
import shopify from '../shopify-client';

const router = express.Router();

// Initiate OAuth flow
router.get('/install', async (req, res) => {
  const { shop } = req.query;
  
  if (!shop || typeof shop !== 'string') {
    return res.status(400).json({ error: 'Shop parameter is required' });
  }

  try {
    const authUrl = await shopify.auth.begin({
      shop: shop,
      callbackPath: '/auth/shopify/callback',
      isOnline: false, // Use offline tokens for background operations
    });

    res.redirect(authUrl);
  } catch (error) {
    console.error('OAuth initiation error:', error);
    res.status(500).json({ error: 'Failed to initiate OAuth flow' });
  }
});

// Handle OAuth callback
router.get('/callback', async (req, res) => {
  try {
    const callback = await shopify.auth.callback({
      rawRequest: req,
      rawResponse: res,
    });

    const { session } = callback;
    
    // Store session data securely
    await storeSession(session);
    
    // Redirect to success page or app
    res.redirect('/dashboard?shop=' + session.shop);
  } catch (error) {
    console.error('OAuth callback error:', error);
    res.status(500).json({ error: 'Authentication failed' });
  }
});

// Session storage (implement based on your database)
async function storeSession(session: any) {
  // Store session in your database
  // Include: shop, accessToken, scope, expires, isOnline
  console.log('Storing session for shop:', session.shop);
}

export default router;
```

### 3.4 API Client Implementation

```typescript
// src/services/shopify-service.ts
import { Session } from '@shopify/shopify-api';
import shopify from '../shopify-client';

export class ShopifyService {
  private session: Session;

  constructor(session: Session) {
    this.session = session;
  }

  // Get all products
  async getProducts(limit: number = 50) {
    const client = new shopify.clients.Rest({ session: this.session });
    
    try {
      const response = await client.get({
        path: 'products',
        query: { limit: limit.toString() }
      });
      
      return response.body;
    } catch (error) {
      console.error('Error fetching products:', error);
      throw error;
    }
  }

  // Create a new product
  async createProduct(productData: any) {
    const client = new shopify.clients.Rest({ session: this.session });
    
    try {
      const response = await client.post({
        path: 'products',
        data: { product: productData }
      });
      
      return response.body;
    } catch (error) {
      console.error('Error creating product:', error);
      throw error;
    }
  }

  // Get orders
  async getOrders(status: string = 'any', limit: number = 50) {
    const client = new shopify.clients.Rest({ session: this.session });
    
    try {
      const response = await client.get({
        path: 'orders',
        query: { 
          status,
          limit: limit.toString()
        }
      });
      
      return response.body;
    } catch (error) {
      console.error('Error fetching orders:', error);
      throw error;
    }
  }

  // Update inventory levels
  async updateInventory(inventoryItemId: string, locationId: string, quantity: number) {
    const client = new shopify.clients.Rest({ session: this.session });
    
    try {
      const response = await client.post({
        path: 'inventory_levels/set',
        data: {
          inventory_item_id: inventoryItemId,
          location_id: locationId,
          available: quantity
        }
      });
      
      return response.body;
    } catch (error) {
      console.error('Error updating inventory:', error);
      throw error;
    }
  }
}
```

### 3.5 GraphQL Implementation

For more complex queries, use GraphQL:

```typescript
// src/services/shopify-graphql.ts
import { Session } from '@shopify/shopify-api';
import shopify from '../shopify-client';

export class ShopifyGraphQLService {
  private session: Session;

  constructor(session: Session) {
    this.session = session;
  }

  async getProductsWithVariants() {
    const client = new shopify.clients.Graphql({ session: this.session });
    
    const query = `
      query getProducts($first: Int!) {
        products(first: $first) {
          edges {
            node {
              id
              title
              handle
              description
              variants(first: 10) {
                edges {
                  node {
                    id
                    title
                    price
                    inventoryQuantity
                    sku
                  }
                }
              }
              images(first: 5) {
                edges {
                  node {
                    id
                    url
                    altText
                  }
                }
              }
            }
          }
        }
      }
    `;

    try {
      const response = await client.query({
        data: {
          query,
          variables: { first: 50 }
        }
      });
      
      return response.body;
    } catch (error) {
      console.error('GraphQL query error:', error);
      throw error;
    }
  }
}
```

## Step 4: Webhook Configuration

Webhooks enable real-time notifications when data changes in Shopify stores.

### 4.1 Webhook Setup

```typescript
// src/webhooks/shopify-webhooks.ts
import express from 'express';
import crypto from 'crypto';
import shopify from '../shopify-client';

const router = express.Router();

// Webhook verification middleware
function verifyWebhook(req: express.Request, res: express.Response, next: express.NextFunction) {
  const hmac = req.get('X-Shopify-Hmac-Sha256');
  const body = JSON.stringify(req.body);
  const hash = crypto
    .createHmac('sha256', process.env.SHOPIFY_WEBHOOK_SECRET!)
    .update(body, 'utf8')
    .digest('base64');

  if (hash !== hmac) {
    return res.status(401).send('Unauthorized');
  }

  next();
}

// Order creation webhook
router.post('/orders/create', verifyWebhook, async (req, res) => {
  const order = req.body;
  
  try {
    // Process new order
    await processNewOrder(order);
    res.status(200).send('OK');
  } catch (error) {
    console.error('Error processing order webhook:', error);
    res.status(500).send('Error');
  }
});

// Product update webhook
router.post('/products/update', verifyWebhook, async (req, res) => {
  const product = req.body;
  
  try {
    // Process product update
    await processProductUpdate(product);
    res.status(200).send('OK');
  } catch (error) {
    console.error('Error processing product webhook:', error);
    res.status(500).send('Error');
  }
});

async function processNewOrder(order: any) {
  // Implement your order processing logic
  console.log('New order received:', order.id);
}

async function processProductUpdate(product: any) {
  // Implement your product update logic
  console.log('Product updated:', product.id);
}

export default router;
```

### 4.2 Register Webhooks

```typescript
// src/setup/register-webhooks.ts
import { Session } from '@shopify/shopify-api';
import shopify from '../shopify-client';

export async function registerWebhooks(session: Session) {
  const client = new shopify.clients.Rest({ session });

  const webhooks = [
    {
      topic: 'orders/create',
      address: `${process.env.SHOPIFY_APP_URL}/webhooks/orders/create`,
      format: 'json'
    },
    {
      topic: 'orders/updated',
      address: `${process.env.SHOPIFY_APP_URL}/webhooks/orders/update`,
      format: 'json'
    },
    {
      topic: 'products/update',
      address: `${process.env.SHOPIFY_APP_URL}/webhooks/products/update`,
      format: 'json'
    }
  ];

  for (const webhook of webhooks) {
    try {
      await client.post({
        path: 'webhooks',
        data: { webhook }
      });
      console.log(`Registered webhook: ${webhook.topic}`);
    } catch (error) {
      console.error(`Failed to register webhook ${webhook.topic}:`, error);
    }
  }
}
```

## Step 5: Error Handling and Rate Limiting

### 5.1 Rate Limiting

```typescript
// src/utils/rate-limiter.ts
export class RateLimiter {
  private requests: Map<string, number[]> = new Map();
  private readonly maxRequests: number;
  private readonly windowMs: number;

  constructor(maxRequests: number = 40, windowMs: number = 1000) {
    this.maxRequests = maxRequests;
    this.windowMs = windowMs;
  }

  canMakeRequest(shop: string): boolean {
    const now = Date.now();
    const requests = this.requests.get(shop) || [];
    
    // Remove old requests outside the window
    const validRequests = requests.filter(time => now - time < this.windowMs);
    
    if (validRequests.length >= this.maxRequests) {
      return false;
    }

    validRequests.push(now);
    this.requests.set(shop, validRequests);
    return true;
  }

  getWaitTime(shop: string): number {
    const requests = this.requests.get(shop) || [];
    if (requests.length === 0) return 0;
    
    const oldestRequest = Math.min(...requests);
    const waitTime = this.windowMs - (Date.now() - oldestRequest);
    return Math.max(0, waitTime);
  }
}
```

### 5.2 Error Handling

```typescript
// src/utils/error-handler.ts
export class ShopifyError extends Error {
  constructor(
    message: string,
    public statusCode: number,
    public shopifyErrorCode?: string
  ) {
    super(message);
    this.name = 'ShopifyError';
  }
}

export function handleShopifyError(error: any): ShopifyError {
  if (error.response) {
    const { status, data } = error.response;
    const message = data?.errors || data?.error || 'Unknown Shopify API error';
    return new ShopifyError(message, status, data?.error_code);
  }
  
  return new ShopifyError('Network error', 500);
}
```

## Testing and Validation

### Test Your Integration

1. **OAuth Flow**: Test the complete authentication process
2. **API Calls**: Verify all CRUD operations work correctly
3. **Webhooks**: Test webhook reception and processing
4. **Error Handling**: Test rate limiting and error scenarios

### Example Test Script

```typescript
// tests/shopify-integration.test.ts
import { ShopifyService } from '../src/services/shopify-service';

async function testIntegration() {
  // Mock session for testing
  const session = {
    shop: 'test-shop.myshopify.com',
    accessToken: 'test-token'
  };

  const service = new ShopifyService(session as any);

  try {
    // Test product retrieval
    const products = await service.getProducts(5);
    console.log('Products retrieved:', products.products.length);

    // Test order retrieval
    const orders = await service.getOrders('any', 5);
    console.log('Orders retrieved:', orders.orders.length);

  } catch (error) {
    console.error('Integration test failed:', error);
  }
}
```

## Security Best Practices

1. **Token Storage**: Store access tokens securely and encrypt sensitive data
2. **HTTPS Only**: Always use HTTPS for all communications
3. **Webhook Verification**: Always verify webhook signatures
4. **Scope Limitation**: Request only the minimum required scopes
5. **Rate Limiting**: Implement proper rate limiting to avoid API limits
6. **Error Logging**: Log errors securely without exposing sensitive data

## Troubleshooting

### Common Issues

1. **OAuth Redirect Mismatch**: Ensure redirect URLs match exactly
2. **Scope Errors**: Verify your app has the required permissions
3. **Rate Limiting**: Implement proper rate limiting and retry logic
4. **Webhook Verification**: Check webhook secret configuration

### Debug Mode

Enable debug logging:

```typescript
process.env.SHOPIFY_LOG_LEVEL = 'debug';
```

## Next Steps

- [Shopify OAuth Setup](./shopify-oauth.md) - Detailed OAuth implementation
- [QuickBooks Integration](./quickbooks.md) - Accounting integration
- [Slack Integration](./slack.md) - Communication integration

