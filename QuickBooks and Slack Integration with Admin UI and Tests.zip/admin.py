from flask import Blueprint, request, jsonify
from src.models.user import db, QuickBooksToken, SlackToken, Recipe
from src.utils import create_error_response, create_success_response

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/tokens/quickbooks', methods=['GET'])
def get_quickbooks_tokens():
    """Get all QuickBooks tokens"""
    tokens = QuickBooksToken.query.all()
    token_list = []
    
    for token in tokens:
        token_list.append({
            'id': token.id,
            'company_id': token.company_id,
            'expires_at': token.token_expires_at.isoformat(),
            'created_at': token.created_at.isoformat(),
            'updated_at': token.updated_at.isoformat()
        })
    
    return create_success_response(token_list)

@admin_bp.route('/tokens/slack', methods=['GET'])
def get_slack_tokens():
    """Get all Slack tokens"""
    tokens = SlackToken.query.all()
    token_list = []
    
    for token in tokens:
        token_list.append({
            'id': token.id,
            'team_id': token.team_id,
            'has_webhook': bool(token.webhook_url),
            'channel_id': token.channel_id,
            'created_at': token.created_at.isoformat(),
            'updated_at': token.updated_at.isoformat()
        })
    
    return create_success_response(token_list)

@admin_bp.route('/tokens/quickbooks/<int:token_id>', methods=['DELETE'])
def delete_quickbooks_token(token_id):
    """Delete QuickBooks token"""
    token = QuickBooksToken.query.get(token_id)
    if not token:
        return create_error_response('Token not found', 404)
    
    db.session.delete(token)
    db.session.commit()
    
    return create_success_response(message='QuickBooks token deleted successfully')

@admin_bp.route('/tokens/slack/<int:token_id>', methods=['DELETE'])
def delete_slack_token(token_id):
    """Delete Slack token"""
    token = SlackToken.query.get(token_id)
    if not token:
        return create_error_response('Token not found', 404)
    
    db.session.delete(token)
    db.session.commit()
    
    return create_success_response(message='Slack token deleted successfully')

@admin_bp.route('/recipes', methods=['GET'])
def get_recipes():
    """Get all recipes"""
    recipes = Recipe.query.all()
    recipe_list = []
    
    for recipe in recipes:
        recipe_list.append({
            'id': recipe.id,
            'name': recipe.name,
            'cost': float(recipe.cost),
            'ingredients': recipe.ingredients,
            'created_at': recipe.created_at.isoformat(),
            'updated_at': recipe.updated_at.isoformat()
        })
    
    return create_success_response(recipe_list)

@admin_bp.route('/recipes', methods=['POST'])
def create_recipe():
    """Create new recipe"""
    data = request.json
    name = data.get('name')
    cost = data.get('cost')
    ingredients = data.get('ingredients', '')
    
    if not name or cost is None:
        return create_error_response('Name and cost are required')
    
    # Check if recipe already exists
    existing_recipe = Recipe.query.filter_by(name=name).first()
    if existing_recipe:
        return create_error_response('Recipe with this name already exists')
    
    new_recipe = Recipe(
        name=name,
        cost=cost,
        ingredients=ingredients
    )
    
    db.session.add(new_recipe)
    db.session.commit()
    
    return create_success_response({
        'id': new_recipe.id,
        'name': new_recipe.name,
        'cost': float(new_recipe.cost),
        'ingredients': new_recipe.ingredients
    }, 'Recipe created successfully')

@admin_bp.route('/recipes/<int:recipe_id>', methods=['PUT'])
def update_recipe(recipe_id):
    """Update recipe"""
    recipe = Recipe.query.get(recipe_id)
    if not recipe:
        return create_error_response('Recipe not found', 404)
    
    data = request.json
    
    if 'name' in data:
        # Check if new name conflicts with existing recipe
        existing_recipe = Recipe.query.filter(
            Recipe.name == data['name'],
            Recipe.id != recipe_id
        ).first()
        if existing_recipe:
            return create_error_response('Recipe with this name already exists')
        recipe.name = data['name']
    
    if 'cost' in data:
        recipe.cost = data['cost']
    
    if 'ingredients' in data:
        recipe.ingredients = data['ingredients']
    
    db.session.commit()
    
    return create_success_response({
        'id': recipe.id,
        'name': recipe.name,
        'cost': float(recipe.cost),
        'ingredients': recipe.ingredients
    }, 'Recipe updated successfully')

@admin_bp.route('/recipes/<int:recipe_id>', methods=['DELETE'])
def delete_recipe(recipe_id):
    """Delete recipe"""
    recipe = Recipe.query.get(recipe_id)
    if not recipe:
        return create_error_response('Recipe not found', 404)
    
    db.session.delete(recipe)
    db.session.commit()
    
    return create_success_response(message='Recipe deleted successfully')

@admin_bp.route('/config/slack/<team_id>', methods=['PUT'])
def update_slack_config(team_id):
    """Update Slack configuration"""
    data = request.json
    
    slack_token = SlackToken.query.filter_by(team_id=team_id).first()
    if not slack_token:
        return create_error_response('Slack team not found', 404)
    
    if 'webhook_url' in data:
        slack_token.webhook_url = data['webhook_url']
    
    if 'channel_id' in data:
        slack_token.channel_id = data['channel_id']
    
    db.session.commit()
    
    return create_success_response({
        'team_id': slack_token.team_id,
        'webhook_url': slack_token.webhook_url,
        'channel_id': slack_token.channel_id
    }, 'Slack configuration updated successfully')

@admin_bp.route('/dashboard', methods=['GET'])
def get_dashboard_data():
    """Get dashboard overview data"""
    # Count connections
    qb_connections = QuickBooksToken.query.count()
    slack_connections = SlackToken.query.count()
    
    # Count recipes
    recipe_count = Recipe.query.count()
    
    # Get recent activity (simplified)
    recent_qb_tokens = QuickBooksToken.query.order_by(QuickBooksToken.updated_at.desc()).limit(5).all()
    recent_slack_tokens = SlackToken.query.order_by(SlackToken.updated_at.desc()).limit(5).all()
    
    dashboard_data = {
        'connections': {
            'quickbooks': qb_connections,
            'slack': slack_connections
        },
        'recipes': recipe_count,
        'recent_activity': {
            'quickbooks': [
                {
                    'company_id': token.company_id,
                    'updated_at': token.updated_at.isoformat()
                } for token in recent_qb_tokens
            ],
            'slack': [
                {
                    'team_id': token.team_id,
                    'updated_at': token.updated_at.isoformat()
                } for token in recent_slack_tokens
            ]
        }
    }
    
    return create_success_response(dashboard_data)

