from flask import Blueprint, request, jsonify
import requests
import os
import hmac
import hashlib
import time
from datetime import datetime
from src.models.user import db, SlackToken, Recipe
from src.utils import create_error_response, create_success_response, format_currency

slack_bp = Blueprint('slack', __name__)

# Slack OAuth configuration
SLACK_CLIENT_ID = os.getenv('SLACK_CLIENT_ID', 'your_slack_client_id')
SLACK_CLIENT_SECRET = os.getenv('SLACK_CLIENT_SECRET', 'your_slack_client_secret')
SLACK_SIGNING_SECRET = os.getenv('SLACK_SIGNING_SECRET', 'your_slack_signing_secret')
SLACK_REDIRECT_URI = os.getenv('SLACK_REDIRECT_URI', 'http://localhost:5000/api/slack/callback')

@slack_bp.route('/auth', methods=['GET'])
def initiate_oauth():
    """Initiate Slack OAuth flow"""
    scopes = 'commands,chat:write,incoming-webhook,channels:read'
    auth_url = f"https://slack.com/oauth/v2/authorize?client_id={SLACK_CLIENT_ID}&scope={scopes}&redirect_uri={SLACK_REDIRECT_URI}"
    return jsonify({'auth_url': auth_url})

@slack_bp.route('/callback', methods=['GET'])
def oauth_callback():
    """Handle OAuth callback from Slack"""
    code = request.args.get('code')
    
    if not code:
        return create_error_response('Missing authorization code')
    
    # Exchange code for tokens
    token_url = 'https://slack.com/api/oauth.v2.access'
    data = {
        'client_id': SLACK_CLIENT_ID,
        'client_secret': SLACK_CLIENT_SECRET,
        'code': code,
        'redirect_uri': SLACK_REDIRECT_URI
    }
    
    try:
        response = requests.post(token_url, data=data)
        response.raise_for_status()
        token_data = response.json()
        
        if not token_data.get('ok'):
            return create_error_response(f"Slack OAuth error: {token_data.get('error', 'Unknown error')}")
        
        # Extract token information
        team_id = token_data.get('team', {}).get('id')
        access_token = token_data.get('access_token')
        bot_token = token_data.get('bot_user_id')
        webhook_url = token_data.get('incoming_webhook', {}).get('url')
        channel_id = token_data.get('incoming_webhook', {}).get('channel_id')
        
        # Save tokens to database
        existing_token = SlackToken.query.filter_by(team_id=team_id).first()
        if existing_token:
            existing_token.access_token = access_token
            existing_token.bot_token = bot_token
            existing_token.webhook_url = webhook_url
            existing_token.channel_id = channel_id
            existing_token.updated_at = datetime.utcnow()
        else:
            new_token = SlackToken(
                team_id=team_id,
                access_token=access_token,
                bot_token=bot_token,
                webhook_url=webhook_url,
                channel_id=channel_id
            )
            db.session.add(new_token)
        
        db.session.commit()
        
        return create_success_response({
            'team_id': team_id,
            'channel_id': channel_id
        }, 'Slack connected successfully')
    
    except requests.RequestException as e:
        return create_error_response(f'Failed to exchange code for tokens: {str(e)}', 500)

@slack_bp.route('/commands/skunk', methods=['POST'])
def handle_skunk_command():
    """Handle /skunk slash command"""
    # Verify request signature
    if not verify_slack_signature(request):
        return create_error_response('Invalid request signature', 401)
    
    # Extract command data
    team_id = request.form.get('team_id')
    user_id = request.form.get('user_id')
    command = request.form.get('command')
    text = request.form.get('text', '').strip()
    
    if not text:
        return jsonify({
            'response_type': 'ephemeral',
            'text': 'Please provide a recipe name. Usage: `/skunk recipe_name`'
        })
    
    # Look up recipe cost
    recipe = Recipe.query.filter_by(name=text).first()
    
    if not recipe:
        # Try partial match
        recipe = Recipe.query.filter(Recipe.name.ilike(f'%{text}%')).first()
    
    if recipe:
        cost_formatted = format_currency(recipe.cost)
        response_text = f"🍽️ Recipe: *{recipe.name}*\n💰 Cost: *{cost_formatted}*"
        
        if recipe.ingredients:
            response_text += f"\n📝 Ingredients: {recipe.ingredients}"
    else:
        response_text = f"❌ Recipe '{text}' not found. Please check the recipe name and try again."
    
    return jsonify({
        'response_type': 'in_channel',
        'text': response_text
    })

@slack_bp.route('/webhook/notify', methods=['POST'])
def send_webhook_notification():
    """Send notification via Slack webhook"""
    data = request.json
    team_id = data.get('team_id')
    message = data.get('message')
    
    if not team_id or not message:
        return create_error_response('team_id and message are required')
    
    # Get Slack token for team
    slack_token = SlackToken.query.filter_by(team_id=team_id).first()
    if not slack_token or not slack_token.webhook_url:
        return create_error_response('Slack webhook not configured for this team', 404)
    
    # Send webhook notification
    webhook_payload = {
        'text': message,
        'username': 'QuickBooks Connector',
        'icon_emoji': ':moneybag:'
    }
    
    try:
        response = requests.post(slack_token.webhook_url, json=webhook_payload)
        response.raise_for_status()
        
        return create_success_response(message='Notification sent successfully')
    
    except requests.RequestException as e:
        return create_error_response(f'Failed to send webhook notification: {str(e)}', 500)

@slack_bp.route('/notify/invoice', methods=['POST'])
def notify_invoice_update():
    """Send invoice update notification to Slack"""
    data = request.json
    team_id = data.get('team_id')
    invoice_data = data.get('invoice')
    
    if not team_id or not invoice_data:
        return create_error_response('team_id and invoice data are required')
    
    # Format invoice notification message
    doc_number = invoice_data.get('doc_number', 'N/A')
    customer_name = invoice_data.get('customer_name', 'Unknown')
    total_amount = format_currency(invoice_data.get('total_amount'))
    balance = format_currency(invoice_data.get('balance'))
    po_status = invoice_data.get('po_status', 'unknown')
    
    # Create status emoji
    status_emoji = {
        'paid': '✅',
        'partially_paid': '🟡',
        'pending': '🔴'
    }.get(po_status, '❓')
    
    message = f"""
📄 *Invoice Update*
{status_emoji} Status: *{po_status.replace('_', ' ').title()}*
🧾 Invoice: #{doc_number}
👤 Customer: {customer_name}
💰 Total: {total_amount}
💳 Balance: {balance}
    """.strip()
    
    # Send notification
    return send_webhook_notification_internal(team_id, message)

@slack_bp.route('/notify/payment', methods=['POST'])
def notify_payment_received():
    """Send payment notification to Slack"""
    data = request.json
    team_id = data.get('team_id')
    payment_data = data.get('payment')
    invoice_data = data.get('invoice')
    
    if not team_id or not payment_data:
        return create_error_response('team_id and payment data are required')
    
    # Format payment notification message
    amount = format_currency(payment_data.get('amount'))
    payment_date = payment_data.get('payment_date', 'Unknown')
    payment_method = payment_data.get('payment_method', 'Unknown')
    
    message = f"""
💰 *Payment Received*
✅ Amount: {amount}
📅 Date: {payment_date}
💳 Method: {payment_method}
    """.strip()
    
    if invoice_data:
        doc_number = invoice_data.get('doc_number', 'N/A')
        customer_name = invoice_data.get('customer_name', 'Unknown')
        message += f"\n🧾 Invoice: #{doc_number}\n👤 Customer: {customer_name}"
    
    # Send notification
    return send_webhook_notification_internal(team_id, message)

@slack_bp.route('/status', methods=['GET'])
def get_connection_status():
    """Get Slack connection status"""
    tokens = SlackToken.query.all()
    status_list = []
    
    for token in tokens:
        status_list.append({
            'team_id': token.team_id,
            'connected': True,
            'has_webhook': bool(token.webhook_url),
            'channel_id': token.channel_id,
            'last_updated': token.updated_at.isoformat()
        })
    
    return jsonify({'connections': status_list})

def verify_slack_signature(request):
    """Verify Slack request signature"""
    timestamp = request.headers.get('X-Slack-Request-Timestamp')
    signature = request.headers.get('X-Slack-Signature')
    
    if not timestamp or not signature:
        return False
    
    # Check timestamp (prevent replay attacks)
    if abs(time.time() - int(timestamp)) > 60 * 5:  # 5 minutes
        return False
    
    # Verify signature
    sig_basestring = f"v0:{timestamp}:{request.get_data(as_text=True)}"
    expected_signature = 'v0=' + hmac.new(
        SLACK_SIGNING_SECRET.encode(),
        sig_basestring.encode(),
        hashlib.sha256
    ).hexdigest()
    
    return hmac.compare_digest(signature, expected_signature)

def send_webhook_notification_internal(team_id, message):
    """Internal function to send webhook notification"""
    slack_token = SlackToken.query.filter_by(team_id=team_id).first()
    if not slack_token or not slack_token.webhook_url:
        return create_error_response('Slack webhook not configured for this team', 404)
    
    webhook_payload = {
        'text': message,
        'username': 'QuickBooks Connector',
        'icon_emoji': ':moneybag:'
    }
    
    try:
        response = requests.post(slack_token.webhook_url, json=webhook_payload)
        response.raise_for_status()
        
        return create_success_response(message='Notification sent successfully')
    
    except requests.RequestException as e:
        return create_error_response(f'Failed to send webhook notification: {str(e)}', 500)

