from flask import Blueprint, request, jsonify
import requests
import os
from datetime import datetime, timedelta
from src.models.user import db, QuickBooksToken, Invoice, Payment
from src.utils import retry_with_backoff, handle_api_response, RateLimitError, QuickBooksAPIError, parse_quickbooks_date, create_error_response, create_success_response

quickbooks_bp = Blueprint('quickbooks', __name__)

# QuickBooks OAuth configuration
QB_CLIENT_ID = os.getenv('QB_CLIENT_ID', 'your_client_id')
QB_CLIENT_SECRET = os.getenv('QB_CLIENT_SECRET', 'your_client_secret')
QB_REDIRECT_URI = os.getenv('QB_REDIRECT_URI', 'http://localhost:5000/api/quickbooks/callback')
QB_SCOPE = 'com.intuit.quickbooks.accounting'
QB_DISCOVERY_DOCUMENT_URL = 'https://appcenter.intuit.com/api/v1/connection/oauth2'
QB_BASE_URL = 'https://sandbox-quickbooks.api.intuit.com'

@quickbooks_bp.route('/auth', methods=['GET'])
def initiate_oauth():
    """Initiate QuickBooks OAuth flow"""
    auth_url = f"https://appcenter.intuit.com/connect/oauth2?client_id={QB_CLIENT_ID}&scope={QB_SCOPE}&redirect_uri={QB_REDIRECT_URI}&response_type=code&access_type=offline"
    return jsonify({'auth_url': auth_url})

@quickbooks_bp.route('/callback', methods=['GET'])
def oauth_callback():
    """Handle OAuth callback from QuickBooks"""
    code = request.args.get('code')
    company_id = request.args.get('realmId')
    
    if not code or not company_id:
        return jsonify({'error': 'Missing authorization code or company ID'}), 400
    
    # Exchange code for tokens
    token_url = 'https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer'
    headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': f'Basic {get_basic_auth_header()}'
    }
    
    data = {
        'grant_type': 'authorization_code',
        'code': code,
        'redirect_uri': QB_REDIRECT_URI
    }
    
    try:
        response = requests.post(token_url, headers=headers, data=data)
        response.raise_for_status()
        token_data = response.json()
        
        # Save tokens to database
        expires_at = datetime.utcnow() + timedelta(seconds=token_data.get('expires_in', 3600))
        
        # Check if token already exists for this company
        existing_token = QuickBooksToken.query.filter_by(company_id=company_id).first()
        if existing_token:
            existing_token.access_token = token_data['access_token']
            existing_token.refresh_token = token_data['refresh_token']
            existing_token.token_expires_at = expires_at
            existing_token.updated_at = datetime.utcnow()
        else:
            new_token = QuickBooksToken(
                company_id=company_id,
                access_token=token_data['access_token'],
                refresh_token=token_data['refresh_token'],
                token_expires_at=expires_at
            )
            db.session.add(new_token)
        
        db.session.commit()
        
        return jsonify({'message': 'QuickBooks connected successfully', 'company_id': company_id})
    
    except requests.RequestException as e:
        return jsonify({'error': f'Failed to exchange code for tokens: {str(e)}'}), 500

@quickbooks_bp.route('/sync/invoices', methods=['POST'])
@retry_with_backoff(max_retries=3)
def sync_invoices():
    """Sync invoices from QuickBooks"""
    company_id = request.json.get('company_id')
    
    if not company_id:
        return create_error_response('Company ID is required')
    
    token = QuickBooksToken.query.filter_by(company_id=company_id).first()
    if not token:
        return create_error_response('QuickBooks not connected for this company', 404)
    
    # Check if token needs refresh
    if datetime.utcnow() >= token.token_expires_at:
        if not refresh_access_token(token):
            return create_error_response('Failed to refresh access token', 401)
    
    try:
        # Fetch invoices from QuickBooks API
        headers = {
            'Authorization': f'Bearer {token.access_token}',
            'Accept': 'application/json'
        }
        
        url = f"{QB_BASE_URL}/v3/company/{company_id}/query"
        query = "SELECT * FROM Invoice MAXRESULTS 100"
        
        response = requests.get(url, headers=headers, params={'query': query})
        handle_api_response(response)
        
        data = response.json()
        invoices_data = data.get('QueryResponse', {}).get('Invoice', [])
        
        synced_count = 0
        for invoice_data in invoices_data:
            # Process and save invoice
            invoice_id = invoice_data.get('Id')
            existing_invoice = Invoice.query.filter_by(quickbooks_id=invoice_id).first()
            
            if existing_invoice:
                # Update existing invoice
                existing_invoice.doc_number = invoice_data.get('DocNumber')
                existing_invoice.total_amount = invoice_data.get('TotalAmt', 0)
                existing_invoice.balance = invoice_data.get('Balance', 0)
                existing_invoice.due_date = parse_quickbooks_date(invoice_data.get('DueDate'))
                existing_invoice.last_synced = datetime.utcnow()
                
                # Update PO status based on balance
                if existing_invoice.balance == 0:
                    existing_invoice.po_status = 'paid'
                elif existing_invoice.balance < existing_invoice.total_amount:
                    existing_invoice.po_status = 'partially_paid'
                else:
                    existing_invoice.po_status = 'pending'
            else:
                # Create new invoice
                customer_ref = invoice_data.get('CustomerRef', {})
                new_invoice = Invoice(
                    quickbooks_id=invoice_id,
                    doc_number=invoice_data.get('DocNumber'),
                    customer_name=customer_ref.get('name'),
                    total_amount=invoice_data.get('TotalAmt', 0),
                    balance=invoice_data.get('Balance', 0),
                    due_date=parse_quickbooks_date(invoice_data.get('DueDate')),
                    po_number=invoice_data.get('CustomField', [{}])[0].get('StringValue') if invoice_data.get('CustomField') else None,
                    po_status='pending' if invoice_data.get('Balance', 0) > 0 else 'paid'
                )
                db.session.add(new_invoice)
            
            synced_count += 1
        
        db.session.commit()
        
        return create_success_response({
            'synced_count': synced_count
        }, f'Successfully synced {synced_count} invoices')
    
    except (RateLimitError, QuickBooksAPIError) as e:
        return create_error_response(str(e), 500)

@quickbooks_bp.route('/sync/payments', methods=['POST'])
def sync_payments():
    """Sync payments from QuickBooks"""
    company_id = request.json.get('company_id')
    
    if not company_id:
        return jsonify({'error': 'Company ID is required'}), 400
    
    token = QuickBooksToken.query.filter_by(company_id=company_id).first()
    if not token:
        return jsonify({'error': 'QuickBooks not connected for this company'}), 404
    
    # Check if token needs refresh
    if datetime.utcnow() >= token.token_expires_at:
        if not refresh_access_token(token):
            return jsonify({'error': 'Failed to refresh access token'}), 401
    
    try:
        # Fetch payments from QuickBooks API
        headers = {
            'Authorization': f'Bearer {token.access_token}',
            'Accept': 'application/json'
        }
        
        url = f"{QB_BASE_URL}/v3/company/{company_id}/query"
        query = "SELECT * FROM Payment MAXRESULTS 100"
        
        response = requests.get(url, headers=headers, params={'query': query})
        response.raise_for_status()
        
        data = response.json()
        payments_data = data.get('QueryResponse', {}).get('Payment', [])
        
        synced_count = 0
        for payment_data in payments_data:
            payment_id = payment_data.get('Id')
            existing_payment = Payment.query.filter_by(quickbooks_id=payment_id).first()
            
            if not existing_payment:
                # Find associated invoice
                lines = payment_data.get('Line', [])
                for line in lines:
                    linked_txn = line.get('LinkedTxn', [])
                    for txn in linked_txn:
                        if txn.get('TxnType') == 'Invoice':
                            invoice = Invoice.query.filter_by(quickbooks_id=txn.get('TxnId')).first()
                            if invoice:
                                new_payment = Payment(
                                    quickbooks_id=payment_id,
                                    invoice_id=invoice.id,
                                    amount=line.get('Amount', 0),
                                    payment_date=parse_date(payment_data.get('TxnDate')),
                                    payment_method=payment_data.get('PaymentMethodRef', {}).get('name')
                                )
                                db.session.add(new_payment)
                                synced_count += 1
        
        db.session.commit()
        
        return jsonify({
            'message': f'Successfully synced {synced_count} payments',
            'synced_count': synced_count
        })
    
    except requests.RequestException as e:
        return jsonify({'error': f'Failed to sync payments: {str(e)}'}), 500

@quickbooks_bp.route('/status', methods=['GET'])
def get_connection_status():
    """Get QuickBooks connection status"""
    tokens = QuickBooksToken.query.all()
    status_list = []
    
    for token in tokens:
        is_expired = datetime.utcnow() >= token.token_expires_at
        status_list.append({
            'company_id': token.company_id,
            'connected': True,
            'expires_at': token.token_expires_at.isoformat(),
            'is_expired': is_expired,
            'last_updated': token.updated_at.isoformat()
        })
    
    return jsonify({'connections': status_list})

def get_basic_auth_header():
    """Generate basic auth header for QuickBooks OAuth"""
    import base64
    credentials = f"{QB_CLIENT_ID}:{QB_CLIENT_SECRET}"
    encoded_credentials = base64.b64encode(credentials.encode()).decode()
    return encoded_credentials

def refresh_access_token(token):
    """Refresh QuickBooks access token"""
    token_url = 'https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer'
    headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': f'Basic {get_basic_auth_header()}'
    }
    
    data = {
        'grant_type': 'refresh_token',
        'refresh_token': token.refresh_token
    }
    
    try:
        response = requests.post(token_url, headers=headers, data=data)
        response.raise_for_status()
        token_data = response.json()
        
        # Update token in database
        token.access_token = token_data['access_token']
        if 'refresh_token' in token_data:
            token.refresh_token = token_data['refresh_token']
        token.token_expires_at = datetime.utcnow() + timedelta(seconds=token_data.get('expires_in', 3600))
        token.updated_at = datetime.utcnow()
        
        db.session.commit()
        return True
    
    except requests.RequestException:
        return False

def parse_date(date_string):
    """Parse date string from QuickBooks API"""
    if not date_string:
        return None
    try:
        return datetime.strptime(date_string, '%Y-%m-%d').date()
    except ValueError:
        return None

