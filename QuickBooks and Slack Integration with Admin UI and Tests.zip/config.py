import os
from dataclasses import dataclass
from typing import Optional

@dataclass
class QuickBooksConfig:
    client_id: str
    client_secret: str
    redirect_uri: str
    base_url: str = 'https://sandbox-quickbooks.api.intuit.com'
    scope: str = 'com.intuit.quickbooks.accounting'

@dataclass
class SlackConfig:
    client_id: str
    client_secret: str
    signing_secret: str
    redirect_uri: str
    bot_scope: str = 'commands,chat:write,incoming-webhook'

@dataclass
class DatabaseConfig:
    username: str = 'root'
    password: str = 'password'
    host: str = 'localhost'
    port: str = '3306'
    name: str = 'mydb'

class Config:
    """Application configuration management"""
    
    def __init__(self):
        self.quickbooks = QuickBooksConfig(
            client_id=os.getenv('QB_CLIENT_ID', 'your_quickbooks_client_id'),
            client_secret=os.getenv('QB_CLIENT_SECRET', 'your_quickbooks_client_secret'),
            redirect_uri=os.getenv('QB_REDIRECT_URI', 'http://localhost:5000/api/quickbooks/callback')
        )
        
        self.slack = SlackConfig(
            client_id=os.getenv('SLACK_CLIENT_ID', 'your_slack_client_id'),
            client_secret=os.getenv('SLACK_CLIENT_SECRET', 'your_slack_client_secret'),
            signing_secret=os.getenv('SLACK_SIGNING_SECRET', 'your_slack_signing_secret'),
            redirect_uri=os.getenv('SLACK_REDIRECT_URI', 'http://localhost:5000/api/slack/callback')
        )
        
        self.database = DatabaseConfig(
            username=os.getenv('DB_USERNAME', 'root'),
            password=os.getenv('DB_PASSWORD', 'password'),
            host=os.getenv('DB_HOST', 'localhost'),
            port=os.getenv('DB_PORT', '3306'),
            name=os.getenv('DB_NAME', 'mydb')
        )
        
        self.secret_key = os.getenv('SECRET_KEY', 'asdf#FGSgvasgf$5$WGT')
        self.debug = os.getenv('DEBUG', 'True').lower() == 'true'
        self.port = int(os.getenv('PORT', '5000'))

# Global configuration instance
config = Config()

