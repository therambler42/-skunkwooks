import unittest
from unittest.mock import patch, MagicMock
from datetime import datetime, timedelta
import sys
import os

# Add the src directory to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from utils import (
    retry_with_backoff, 
    handle_api_response, 
    RateLimitError, 
    QuickBooksAPIError,
    format_currency,
    parse_quickbooks_date,
    validate_webhook_signature
)

class UtilsTestCase(unittest.TestCase):
    """Test cases for utility functions"""
    
    def test_format_currency_valid_amount(self):
        """Test currency formatting with valid amounts"""
        self.assertEqual(format_currency(123.45), '$123.45')
        self.assertEqual(format_currency(1000), '$1,000.00')
        self.assertEqual(format_currency(0), '$0.00')
        self.assertEqual(format_currency(0.99), '$0.99')
    
    def test_format_currency_none(self):
        """Test currency formatting with None"""
        self.assertEqual(format_currency(None), '$0.00')
    
    def test_parse_quickbooks_date_valid(self):
        """Test parsing valid QuickBooks date formats"""
        # Test simple date format
        result = parse_quickbooks_date('2024-01-15')
        self.assertEqual(result.year, 2024)
        self.assertEqual(result.month, 1)
        self.assertEqual(result.day, 15)
        
        # Test ISO format with timezone
        result = parse_quickbooks_date('2024-01-15T10:30:00-05:00')
        self.assertEqual(result.year, 2024)
        self.assertEqual(result.month, 1)
        self.assertEqual(result.day, 15)
    
    def test_parse_quickbooks_date_invalid(self):
        """Test parsing invalid date formats"""
        self.assertIsNone(parse_quickbooks_date('invalid-date'))
        self.assertIsNone(parse_quickbooks_date(''))
        self.assertIsNone(parse_quickbooks_date(None))
    
    def test_validate_webhook_signature_valid(self):
        """Test webhook signature validation with valid signature"""
        request_data = b'test_payload'
        signing_secret = 'test_secret'
        
        import hmac
        import hashlib
        expected_signature = hmac.new(
            signing_secret.encode(),
            request_data,
            hashlib.sha256
        ).hexdigest()
        
        result = validate_webhook_signature(request_data, expected_signature, signing_secret)
        self.assertTrue(result)
    
    def test_validate_webhook_signature_invalid(self):
        """Test webhook signature validation with invalid signature"""
        request_data = b'test_payload'
        signing_secret = 'test_secret'
        invalid_signature = 'invalid_signature'
        
        result = validate_webhook_signature(request_data, invalid_signature, signing_secret)
        self.assertFalse(result)
    
    def test_handle_api_response_success(self):
        """Test handling successful API response"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.ok = True
        
        # Should not raise any exception
        result = handle_api_response(mock_response)
        self.assertEqual(result, mock_response)
    
    def test_handle_api_response_rate_limit(self):
        """Test handling rate limit response"""
        mock_response = MagicMock()
        mock_response.status_code = 429
        
        with self.assertRaises(RateLimitError):
            handle_api_response(mock_response)
    
    def test_handle_api_response_unauthorized(self):
        """Test handling unauthorized response"""
        mock_response = MagicMock()
        mock_response.status_code = 401
        
        with self.assertRaises(QuickBooksAPIError) as context:
            handle_api_response(mock_response)
        
        self.assertIn('Unauthorized', str(context.exception))
    
    def test_handle_api_response_bad_request(self):
        """Test handling bad request response"""
        mock_response = MagicMock()
        mock_response.status_code = 400
        mock_response.json.return_value = {
            'Fault': {
                'Error': [{'Detail': 'Invalid request'}]
            }
        }
        mock_response.content = True
        
        with self.assertRaises(QuickBooksAPIError) as context:
            handle_api_response(mock_response)
        
        self.assertIn('Invalid request', str(context.exception))
    
    def test_handle_api_response_server_error(self):
        """Test handling server error response"""
        mock_response = MagicMock()
        mock_response.status_code = 500
        
        with self.assertRaises(QuickBooksAPIError) as context:
            handle_api_response(mock_response)
        
        self.assertIn('Server error', str(context.exception))
    
    def test_retry_with_backoff_success(self):
        """Test retry decorator with successful function"""
        @retry_with_backoff(max_retries=3)
        def successful_function():
            return 'success'
        
        result = successful_function()
        self.assertEqual(result, 'success')
    
    def test_retry_with_backoff_rate_limit(self):
        """Test retry decorator with rate limit errors"""
        call_count = 0
        
        @retry_with_backoff(max_retries=3, base_delay=0.01)  # Short delay for testing
        def rate_limited_function():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise RateLimitError("Rate limit exceeded")
            return 'success'
        
        result = rate_limited_function()
        self.assertEqual(result, 'success')
        self.assertEqual(call_count, 3)
    
    def test_retry_with_backoff_max_retries_exceeded(self):
        """Test retry decorator when max retries exceeded"""
        @retry_with_backoff(max_retries=2, base_delay=0.01)
        def always_failing_function():
            raise RateLimitError("Always fails")
        
        with self.assertRaises(RateLimitError):
            always_failing_function()

class BusinessLogicTestCase(unittest.TestCase):
    """Test cases for business logic functions"""
    
    def test_po_status_calculation_paid(self):
        """Test PO status calculation for paid invoice"""
        # This would test the logic in the integration layer
        # For now, we'll test the logic directly
        total_amount = 100.00
        balance = 0.00
        
        if balance == 0:
            status = 'paid'
        elif balance < total_amount:
            status = 'partially_paid'
        else:
            status = 'pending'
        
        self.assertEqual(status, 'paid')
    
    def test_po_status_calculation_partially_paid(self):
        """Test PO status calculation for partially paid invoice"""
        total_amount = 100.00
        balance = 50.00
        
        if balance == 0:
            status = 'paid'
        elif balance < total_amount:
            status = 'partially_paid'
        else:
            status = 'pending'
        
        self.assertEqual(status, 'partially_paid')
    
    def test_po_status_calculation_pending(self):
        """Test PO status calculation for pending invoice"""
        total_amount = 100.00
        balance = 100.00
        
        if balance == 0:
            status = 'paid'
        elif balance < total_amount:
            status = 'partially_paid'
        else:
            status = 'pending'
        
        self.assertEqual(status, 'pending')

if __name__ == '__main__':
    unittest.main()

