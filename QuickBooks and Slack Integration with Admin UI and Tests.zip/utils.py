import time
import logging
from functools import wraps
from flask import jsonify

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class RateLimitError(Exception):
    """Custom exception for rate limit errors"""
    pass

class QuickBooksAPIError(Exception):
    """Custom exception for QuickBooks API errors"""
    pass

def retry_with_backoff(max_retries=3, base_delay=1):
    """Decorator to implement exponential backoff for API calls"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except RateLimitError:
                    if attempt == max_retries - 1:
                        raise
                    delay = base_delay * (2 ** attempt)
                    logger.warning(f"Rate limit hit, retrying in {delay} seconds (attempt {attempt + 1}/{max_retries})")
                    time.sleep(delay)
                except QuickBooksAPIError as e:
                    logger.error(f"QuickBooks API error: {str(e)}")
                    raise
                except Exception as e:
                    logger.error(f"Unexpected error in {func.__name__}: {str(e)}")
                    if attempt == max_retries - 1:
                        raise
                    delay = base_delay * (2 ** attempt)
                    time.sleep(delay)
            return None
        return wrapper
    return decorator

def handle_api_response(response):
    """Handle QuickBooks API response and raise appropriate exceptions"""
    if response.status_code == 429:
        raise RateLimitError("Rate limit exceeded")
    elif response.status_code == 401:
        raise QuickBooksAPIError("Unauthorized - token may be expired")
    elif response.status_code == 400:
        error_data = response.json() if response.content else {}
        error_msg = error_data.get('Fault', {}).get('Error', [{}])[0].get('Detail', 'Bad request')
        raise QuickBooksAPIError(f"Bad request: {error_msg}")
    elif response.status_code >= 500:
        raise QuickBooksAPIError(f"Server error: {response.status_code}")
    elif not response.ok:
        raise QuickBooksAPIError(f"API error: {response.status_code} - {response.text}")
    
    return response

def validate_webhook_signature(request_data, signature, signing_secret):
    """Validate webhook signature for security"""
    import hmac
    import hashlib
    
    expected_signature = hmac.new(
        signing_secret.encode(),
        request_data,
        hashlib.sha256
    ).hexdigest()
    
    return hmac.compare_digest(signature, expected_signature)

def format_currency(amount):
    """Format currency amount for display"""
    if amount is None:
        return "$0.00"
    return f"${float(amount):,.2f}"

def parse_quickbooks_date(date_string):
    """Parse date from QuickBooks API format"""
    from datetime import datetime
    if not date_string:
        return None
    try:
        return datetime.strptime(date_string, '%Y-%m-%d').date()
    except ValueError:
        try:
            return datetime.strptime(date_string, '%Y-%m-%dT%H:%M:%S%z').date()
        except ValueError:
            logger.warning(f"Could not parse date: {date_string}")
            return None

def create_error_response(message, status_code=400):
    """Create standardized error response"""
    return jsonify({
        'error': True,
        'message': message,
        'status_code': status_code
    }), status_code

def create_success_response(data=None, message="Success"):
    """Create standardized success response"""
    response = {
        'error': False,
        'message': message
    }
    if data is not None:
        response['data'] = data
    return jsonify(response)

