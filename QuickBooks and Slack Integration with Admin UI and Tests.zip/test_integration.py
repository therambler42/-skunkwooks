import unittest
import json
from unittest.mock import patch, MagicMock
from datetime import datetime, timedelta
import sys
import os

# Add the src directory to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from main import app
from models.user import db, QuickBooksToken, SlackToken, Recipe, Invoice, Payment

class QuickBooksIntegrationTestCase(unittest.TestCase):
    """Test cases for QuickBooks integration"""
    
    def setUp(self):
        """Set up test environment"""
        app.config['TESTING'] = True
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        self.app = app.test_client()
        self.app_context = app.app_context()
        self.app_context.push()
        db.create_all()
    
    def tearDown(self):
        """Clean up test environment"""
        db.session.remove()
        db.drop_all()
        self.app_context.pop()
    
    def test_oauth_initiation(self):
        """Test QuickBooks OAuth initiation"""
        response = self.app.get('/api/quickbooks/auth')
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertIn('auth_url', data)
        self.assertIn('client_id', data['auth_url'])
        self.assertIn('scope', data['auth_url'])
    
    @patch('src.routes.quickbooks.requests.post')
    def test_oauth_callback_success(self, mock_post):
        """Test successful OAuth callback"""
        # Mock successful token exchange
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            'access_token': 'test_access_token',
            'refresh_token': 'test_refresh_token',
            'expires_in': 3600
        }
        mock_post.return_value = mock_response
        
        response = self.app.get('/api/quickbooks/callback?code=test_code&realmId=test_company')
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertIn('company_id', data)
        self.assertEqual(data['company_id'], 'test_company')
        
        # Verify token was saved to database
        token = QuickBooksToken.query.filter_by(company_id='test_company').first()
        self.assertIsNotNone(token)
        self.assertEqual(token.access_token, 'test_access_token')
    
    def test_oauth_callback_missing_code(self):
        """Test OAuth callback with missing code"""
        response = self.app.get('/api/quickbooks/callback?realmId=test_company')
        self.assertEqual(response.status_code, 400)
        
        data = json.loads(response.data)
        self.assertIn('error', data)
    
    @patch('src.routes.quickbooks.requests.get')
    def test_sync_invoices_success(self, mock_get):
        """Test successful invoice sync"""
        # Create test token
        token = QuickBooksToken(
            company_id='test_company',
            access_token='test_token',
            refresh_token='test_refresh',
            token_expires_at=datetime.utcnow() + timedelta(hours=1)
        )
        db.session.add(token)
        db.session.commit()
        
        # Mock API response
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            'QueryResponse': {
                'Invoice': [
                    {
                        'Id': '1',
                        'DocNumber': 'INV-001',
                        'TotalAmt': 100.00,
                        'Balance': 50.00,
                        'DueDate': '2024-01-15',
                        'CustomerRef': {'name': 'Test Customer'}
                    }
                ]
            }
        }
        mock_get.return_value = mock_response
        
        response = self.app.post('/api/quickbooks/sync/invoices', 
                               json={'company_id': 'test_company'})
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertFalse(data['error'])
        self.assertIn('synced_count', data['data'])
    
    def test_sync_invoices_no_token(self):
        """Test invoice sync with no token"""
        response = self.app.post('/api/quickbooks/sync/invoices', 
                               json={'company_id': 'nonexistent_company'})
        self.assertEqual(response.status_code, 404)
        
        data = json.loads(response.data)
        self.assertTrue(data['error'])
    
    def test_connection_status(self):
        """Test connection status endpoint"""
        # Create test token
        token = QuickBooksToken(
            company_id='test_company',
            access_token='test_token',
            refresh_token='test_refresh',
            token_expires_at=datetime.utcnow() + timedelta(hours=1)
        )
        db.session.add(token)
        db.session.commit()
        
        response = self.app.get('/api/quickbooks/status')
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertIn('connections', data)
        self.assertEqual(len(data['connections']), 1)
        self.assertEqual(data['connections'][0]['company_id'], 'test_company')

class SlackIntegrationTestCase(unittest.TestCase):
    """Test cases for Slack integration"""
    
    def setUp(self):
        """Set up test environment"""
        app.config['TESTING'] = True
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        self.app = app.test_client()
        self.app_context = app.app_context()
        self.app_context.push()
        db.create_all()
    
    def tearDown(self):
        """Clean up test environment"""
        db.session.remove()
        db.drop_all()
        self.app_context.pop()
    
    def test_oauth_initiation(self):
        """Test Slack OAuth initiation"""
        response = self.app.get('/api/slack/auth')
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertIn('auth_url', data)
        self.assertIn('client_id', data['auth_url'])
        self.assertIn('scope', data['auth_url'])
    
    @patch('src.routes.slack.requests.post')
    def test_oauth_callback_success(self, mock_post):
        """Test successful Slack OAuth callback"""
        # Mock successful token exchange
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            'ok': True,
            'access_token': 'test_access_token',
            'bot_user_id': 'test_bot_id',
            'team': {'id': 'test_team'},
            'incoming_webhook': {
                'url': 'https://hooks.slack.com/test',
                'channel_id': 'C1234567890'
            }
        }
        mock_post.return_value = mock_response
        
        response = self.app.get('/api/slack/callback?code=test_code')
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertFalse(data['error'])
        self.assertIn('team_id', data['data'])
    
    @patch('src.routes.slack.verify_slack_signature')
    def test_skunk_command_with_recipe(self, mock_verify):
        """Test /skunk command with existing recipe"""
        mock_verify.return_value = True
        
        # Create test recipe
        recipe = Recipe(name='Test Recipe', cost=15.50, ingredients='Test ingredients')
        db.session.add(recipe)
        db.session.commit()
        
        response = self.app.post('/api/slack/commands/skunk', data={
            'team_id': 'test_team',
            'user_id': 'test_user',
            'command': '/skunk',
            'text': 'Test Recipe'
        })
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertIn('text', data)
        self.assertIn('$15.50', data['text'])
    
    @patch('src.routes.slack.verify_slack_signature')
    def test_skunk_command_recipe_not_found(self, mock_verify):
        """Test /skunk command with non-existent recipe"""
        mock_verify.return_value = True
        
        response = self.app.post('/api/slack/commands/skunk', data={
            'team_id': 'test_team',
            'user_id': 'test_user',
            'command': '/skunk',
            'text': 'Nonexistent Recipe'
        })
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertIn('not found', data['text'])
    
    @patch('src.routes.slack.verify_slack_signature')
    def test_skunk_command_no_text(self, mock_verify):
        """Test /skunk command with no recipe name"""
        mock_verify.return_value = True
        
        response = self.app.post('/api/slack/commands/skunk', data={
            'team_id': 'test_team',
            'user_id': 'test_user',
            'command': '/skunk',
            'text': ''
        })
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertIn('Usage:', data['text'])
    
    def test_skunk_command_invalid_signature(self):
        """Test /skunk command with invalid signature"""
        response = self.app.post('/api/slack/commands/skunk', data={
            'team_id': 'test_team',
            'user_id': 'test_user',
            'command': '/skunk',
            'text': 'Test Recipe'
        })
        self.assertEqual(response.status_code, 401)

class AdminAPITestCase(unittest.TestCase):
    """Test cases for Admin API"""
    
    def setUp(self):
        """Set up test environment"""
        app.config['TESTING'] = True
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        self.app = app.test_client()
        self.app_context = app.app_context()
        self.app_context.push()
        db.create_all()
    
    def tearDown(self):
        """Clean up test environment"""
        db.session.remove()
        db.drop_all()
        self.app_context.pop()
    
    def test_get_recipes(self):
        """Test getting all recipes"""
        # Create test recipes
        recipe1 = Recipe(name='Recipe 1', cost=10.00)
        recipe2 = Recipe(name='Recipe 2', cost=15.00)
        db.session.add_all([recipe1, recipe2])
        db.session.commit()
        
        response = self.app.get('/api/admin/recipes')
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertFalse(data['error'])
        self.assertEqual(len(data['data']), 2)
    
    def test_create_recipe(self):
        """Test creating a new recipe"""
        recipe_data = {
            'name': 'New Recipe',
            'cost': 12.50,
            'ingredients': 'Test ingredients'
        }
        
        response = self.app.post('/api/admin/recipes', json=recipe_data)
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertFalse(data['error'])
        self.assertEqual(data['data']['name'], 'New Recipe')
        
        # Verify recipe was created in database
        recipe = Recipe.query.filter_by(name='New Recipe').first()
        self.assertIsNotNone(recipe)
        self.assertEqual(float(recipe.cost), 12.50)
    
    def test_create_recipe_duplicate_name(self):
        """Test creating recipe with duplicate name"""
        # Create existing recipe
        recipe = Recipe(name='Existing Recipe', cost=10.00)
        db.session.add(recipe)
        db.session.commit()
        
        recipe_data = {
            'name': 'Existing Recipe',
            'cost': 15.00
        }
        
        response = self.app.post('/api/admin/recipes', json=recipe_data)
        self.assertEqual(response.status_code, 400)
        
        data = json.loads(response.data)
        self.assertTrue(data['error'])
        self.assertIn('already exists', data['message'])
    
    def test_update_recipe(self):
        """Test updating an existing recipe"""
        # Create test recipe
        recipe = Recipe(name='Test Recipe', cost=10.00)
        db.session.add(recipe)
        db.session.commit()
        
        update_data = {
            'name': 'Updated Recipe',
            'cost': 15.00,
            'ingredients': 'Updated ingredients'
        }
        
        response = self.app.put(f'/api/admin/recipes/{recipe.id}', json=update_data)
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertFalse(data['error'])
        self.assertEqual(data['data']['name'], 'Updated Recipe')
        
        # Verify recipe was updated in database
        updated_recipe = Recipe.query.get(recipe.id)
        self.assertEqual(updated_recipe.name, 'Updated Recipe')
        self.assertEqual(float(updated_recipe.cost), 15.00)
    
    def test_delete_recipe(self):
        """Test deleting a recipe"""
        # Create test recipe
        recipe = Recipe(name='Test Recipe', cost=10.00)
        db.session.add(recipe)
        db.session.commit()
        recipe_id = recipe.id
        
        response = self.app.delete(f'/api/admin/recipes/{recipe_id}')
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertFalse(data['error'])
        
        # Verify recipe was deleted from database
        deleted_recipe = Recipe.query.get(recipe_id)
        self.assertIsNone(deleted_recipe)
    
    def test_dashboard_data(self):
        """Test dashboard data endpoint"""
        # Create test data
        qb_token = QuickBooksToken(
            company_id='test_company',
            access_token='test_token',
            refresh_token='test_refresh',
            token_expires_at=datetime.utcnow() + timedelta(hours=1)
        )
        slack_token = SlackToken(
            team_id='test_team',
            access_token='test_token'
        )
        recipe = Recipe(name='Test Recipe', cost=10.00)
        
        db.session.add_all([qb_token, slack_token, recipe])
        db.session.commit()
        
        response = self.app.get('/api/admin/dashboard')
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertFalse(data['error'])
        self.assertEqual(data['data']['connections']['quickbooks'], 1)
        self.assertEqual(data['data']['connections']['slack'], 1)
        self.assertEqual(data['data']['recipes'], 1)

if __name__ == '__main__':
    unittest.main()

