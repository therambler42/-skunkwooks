from flask import Blueprint, request, jsonify
from datetime import datetime
from src.models.user import db, Invoice, Payment, QuickBooksToken, SlackToken
from src.routes.slack import send_webhook_notification_internal
from src.utils import create_error_response, create_success_response, format_currency
import logging

integration_bp = Blueprint('integration', __name__)
logger = logging.getLogger(__name__)

@integration_bp.route('/sync/trigger', methods=['POST'])
def trigger_sync():
    """Trigger sync for all connected QuickBooks companies"""
    data = request.json
    company_ids = data.get('company_ids', [])
    
    if not company_ids:
        # Get all connected companies
        tokens = QuickBooksToken.query.all()
        company_ids = [token.company_id for token in tokens]
    
    results = []
    
    for company_id in company_ids:
        try:
            # Trigger invoice sync
            invoice_result = sync_company_invoices(company_id)
            
            # Trigger payment sync
            payment_result = sync_company_payments(company_id)
            
            results.append({
                'company_id': company_id,
                'invoices_synced': invoice_result.get('synced_count', 0),
                'payments_synced': payment_result.get('synced_count', 0),
                'status': 'success'
            })
            
        except Exception as e:
            logger.error(f"Sync failed for company {company_id}: {str(e)}")
            results.append({
                'company_id': company_id,
                'status': 'error',
                'error': str(e)
            })
    
    return create_success_response(results, 'Sync completed')

@integration_bp.route('/webhook/invoice-updated', methods=['POST'])
def handle_invoice_webhook():
    """Handle invoice update webhook from QuickBooks"""
    data = request.json
    invoice_id = data.get('invoice_id')
    company_id = data.get('company_id')
    
    if not invoice_id or not company_id:
        return create_error_response('invoice_id and company_id are required')
    
    try:
        # Find the invoice in our database
        invoice = Invoice.query.filter_by(quickbooks_id=invoice_id).first()
        
        if invoice:
            # Check for status changes
            old_status = invoice.po_status
            
            # Update PO status based on balance
            if invoice.balance == 0:
                invoice.po_status = 'paid'
            elif invoice.balance < invoice.total_amount:
                invoice.po_status = 'partially_paid'
            else:
                invoice.po_status = 'pending'
            
            db.session.commit()
            
            # Send Slack notification if status changed
            if old_status != invoice.po_status:
                notify_invoice_status_change(invoice, old_status)
        
        return create_success_response(message='Invoice webhook processed')
    
    except Exception as e:
        logger.error(f"Invoice webhook processing failed: {str(e)}")
        return create_error_response(f'Webhook processing failed: {str(e)}', 500)

@integration_bp.route('/webhook/payment-received', methods=['POST'])
def handle_payment_webhook():
    """Handle payment received webhook from QuickBooks"""
    data = request.json
    payment_id = data.get('payment_id')
    company_id = data.get('company_id')
    
    if not payment_id or not company_id:
        return create_error_response('payment_id and company_id are required')
    
    try:
        # Find the payment in our database
        payment = Payment.query.filter_by(quickbooks_id=payment_id).first()
        
        if payment:
            # Get associated invoice
            invoice = Invoice.query.get(payment.invoice_id)
            
            if invoice:
                # Send Slack notification
                notify_payment_received(payment, invoice)
        
        return create_success_response(message='Payment webhook processed')
    
    except Exception as e:
        logger.error(f"Payment webhook processing failed: {str(e)}")
        return create_error_response(f'Webhook processing failed: {str(e)}', 500)

@integration_bp.route('/po-status/update', methods=['POST'])
def update_po_status():
    """Manually update PO status for invoices"""
    data = request.json
    invoice_ids = data.get('invoice_ids', [])
    
    if not invoice_ids:
        return create_error_response('invoice_ids are required')
    
    updated_count = 0
    
    for invoice_id in invoice_ids:
        invoice = Invoice.query.get(invoice_id)
        if invoice:
            old_status = invoice.po_status
            
            # Update PO status based on balance
            if invoice.balance == 0:
                invoice.po_status = 'paid'
            elif invoice.balance < invoice.total_amount:
                invoice.po_status = 'partially_paid'
            else:
                invoice.po_status = 'pending'
            
            if old_status != invoice.po_status:
                updated_count += 1
    
    db.session.commit()
    
    return create_success_response({
        'updated_count': updated_count
    }, f'Updated {updated_count} PO statuses')

@integration_bp.route('/notifications/test', methods=['POST'])
def test_notification():
    """Test Slack notification system"""
    data = request.json
    team_id = data.get('team_id')
    notification_type = data.get('type', 'test')
    
    if not team_id:
        return create_error_response('team_id is required')
    
    # Create test message based on type
    if notification_type == 'invoice':
        message = """
📄 *Test Invoice Update*
✅ Status: *Paid*
🧾 Invoice: #TEST-001
👤 Customer: Test Customer
💰 Total: $1,234.56
💳 Balance: $0.00
        """.strip()
    elif notification_type == 'payment':
        message = """
💰 *Test Payment Received*
✅ Amount: $1,234.56
📅 Date: 2024-01-15
💳 Method: Credit Card
🧾 Invoice: #TEST-001
👤 Customer: Test Customer
        """.strip()
    else:
        message = "🧪 This is a test notification from the QuickBooks & Slack Connector!"
    
    try:
        result = send_webhook_notification_internal(team_id, message)
        return result
    except Exception as e:
        return create_error_response(f'Test notification failed: {str(e)}', 500)

@integration_bp.route('/reports/sync-status', methods=['GET'])
def get_sync_status():
    """Get sync status report"""
    # Get all invoices with their sync status
    invoices = Invoice.query.order_by(Invoice.last_synced.desc()).limit(50).all()
    
    # Get all payments with their sync status
    payments = Payment.query.order_by(Payment.last_synced.desc()).limit(50).all()
    
    # Calculate statistics
    total_invoices = Invoice.query.count()
    paid_invoices = Invoice.query.filter_by(po_status='paid').count()
    pending_invoices = Invoice.query.filter_by(po_status='pending').count()
    partially_paid_invoices = Invoice.query.filter_by(po_status='partially_paid').count()
    
    total_payments = Payment.query.count()
    
    # Get recent sync activity
    recent_invoices = [
        {
            'id': inv.id,
            'doc_number': inv.doc_number,
            'customer_name': inv.customer_name,
            'total_amount': float(inv.total_amount) if inv.total_amount else 0,
            'balance': float(inv.balance) if inv.balance else 0,
            'po_status': inv.po_status,
            'last_synced': inv.last_synced.isoformat() if inv.last_synced else None
        } for inv in invoices
    ]
    
    recent_payments = [
        {
            'id': pay.id,
            'amount': float(pay.amount) if pay.amount else 0,
            'payment_date': pay.payment_date.isoformat() if pay.payment_date else None,
            'payment_method': pay.payment_method,
            'last_synced': pay.last_synced.isoformat() if pay.last_synced else None
        } for pay in payments
    ]
    
    report = {
        'statistics': {
            'total_invoices': total_invoices,
            'paid_invoices': paid_invoices,
            'pending_invoices': pending_invoices,
            'partially_paid_invoices': partially_paid_invoices,
            'total_payments': total_payments
        },
        'recent_invoices': recent_invoices,
        'recent_payments': recent_payments,
        'generated_at': datetime.utcnow().isoformat()
    }
    
    return create_success_response(report)

def sync_company_invoices(company_id):
    """Internal function to sync invoices for a specific company"""
    from src.routes.quickbooks import sync_invoices
    
    # This would normally call the sync_invoices function
    # For now, return a mock result
    return {'synced_count': 0}

def sync_company_payments(company_id):
    """Internal function to sync payments for a specific company"""
    from src.routes.quickbooks import sync_payments
    
    # This would normally call the sync_payments function
    # For now, return a mock result
    return {'synced_count': 0}

def notify_invoice_status_change(invoice, old_status):
    """Send Slack notification for invoice status change"""
    # Get all Slack teams to notify
    slack_tokens = SlackToken.query.filter(SlackToken.webhook_url.isnot(None)).all()
    
    for token in slack_tokens:
        try:
            # Create status emoji
            status_emoji = {
                'paid': '✅',
                'partially_paid': '🟡',
                'pending': '🔴'
            }.get(invoice.po_status, '❓')
            
            old_emoji = {
                'paid': '✅',
                'partially_paid': '🟡',
                'pending': '🔴'
            }.get(old_status, '❓')
            
            message = f"""
📄 *Invoice Status Changed*
{old_emoji} {old_status.replace('_', ' ').title()} → {status_emoji} {invoice.po_status.replace('_', ' ').title()}
🧾 Invoice: #{invoice.doc_number or 'N/A'}
👤 Customer: {invoice.customer_name or 'Unknown'}
💰 Total: {format_currency(invoice.total_amount)}
💳 Balance: {format_currency(invoice.balance)}
            """.strip()
            
            send_webhook_notification_internal(token.team_id, message)
            
        except Exception as e:
            logger.error(f"Failed to send invoice notification to team {token.team_id}: {str(e)}")

def notify_payment_received(payment, invoice):
    """Send Slack notification for payment received"""
    # Get all Slack teams to notify
    slack_tokens = SlackToken.query.filter(SlackToken.webhook_url.isnot(None)).all()
    
    for token in slack_tokens:
        try:
            message = f"""
💰 *Payment Received*
✅ Amount: {format_currency(payment.amount)}
📅 Date: {payment.payment_date.strftime('%Y-%m-%d') if payment.payment_date else 'Unknown'}
💳 Method: {payment.payment_method or 'Unknown'}
🧾 Invoice: #{invoice.doc_number or 'N/A'}
👤 Customer: {invoice.customer_name or 'Unknown'}
            """.strip()
            
            send_webhook_notification_internal(token.team_id, message)
            
        except Exception as e:
            logger.error(f"Failed to send payment notification to team {token.team_id}: {str(e)}")

