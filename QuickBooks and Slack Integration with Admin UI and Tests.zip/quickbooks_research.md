# QuickBooks Online API Research Notes

## OAuth 2.0 Implementation

### Key Requirements:
- Client ID and Client Secret from Intuit Developer Portal
- Redirect URI must match exactly (including casing, scheme, trailing slash)
- Required scopes: `com.intuit.quickbooks.accounting`
- Authorization endpoint: Uses Intuit OAuth 2.0 Server
- Token endpoint: `https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer`

### Authorization Flow:
1. Create authorization request with client_id, scope, redirect_uri, response_type=code, state
2. User authorizes app and grants permission
3. Intuit OAuth 2.0 Server sends authorization code to redirect_uri
4. Exchange authorization code for access and refresh tokens
5. Use access tokens for API calls (tied to realmID/company)

### Token Management:
- Access tokens expire (typically 1 hour)
- Refresh tokens used to get new access tokens
- If refresh token expires, user must re-authorize
- Tokens are tied to specific QuickBooks company (realmID)

## API Endpoints

### Base URLs:
- Sandbox: `https://sandbox-quickbooks.api.intuit.com`
- Production: `https://quickbooks.api.intuit.com`

### Invoice API:
- Query invoices: `GET /v3/company/{realmID}/query?query=SELECT * FROM Invoice`
- Get specific invoice: `GET /v3/company/{realmID}/invoice/{id}`
- Create invoice: `POST /v3/company/{realmID}/invoice`
- Update invoice: `POST /v3/company/{realmID}/invoice`

### Payment API:
- Query payments: `GET /v3/company/{realmID}/query?query=SELECT * FROM Payment`
- Get specific payment: `GET /v3/company/{realmID}/payment/{id}`
- Create payment: `POST /v3/company/{realmID}/payment`

### Key Invoice Fields:
- Id: Unique identifier
- DocNumber: Invoice number
- CustomerRef: Customer reference
- TotalAmt: Total amount
- Balance: Outstanding balance
- DueDate: Payment due date
- Line: Line items array
- CustomField: Custom fields (can store PO number)

### Key Payment Fields:
- Id: Unique identifier
- TotalAmt: Payment amount
- TxnDate: Transaction date
- CustomerRef: Customer reference
- Line: Array of linked transactions (invoices)
- PaymentMethodRef: Payment method reference

## Rate Limiting:
- 500 requests per minute per app per realm
- 100 concurrent requests per app per realm
- Implement exponential backoff for rate limit errors

## Error Handling:
- HTTP 401: Unauthorized (token expired/invalid)
- HTTP 400: Bad request (validation errors)
- HTTP 429: Rate limit exceeded
- HTTP 500: Server errors

## Best Practices:
- Store realmID with tokens for company identification
- Implement token refresh logic
- Handle rate limiting gracefully
- Use query operations for bulk data retrieval
- Validate webhook signatures for security

