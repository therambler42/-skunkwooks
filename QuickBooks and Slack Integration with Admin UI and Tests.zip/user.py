from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Numeric

db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)

    def __repr__(self):
        return '<User %r>' % self.username

class QuickBooksToken(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.String(255), nullable=False)
    access_token = db.Column(db.Text, nullable=False)
    refresh_token = db.Column(db.Text, nullable=False)
    token_expires_at = db.Column(db.DateTime, nullable=False)
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())
    updated_at = db.Column(db.DateTime, default=db.func.current_timestamp(), onupdate=db.func.current_timestamp())

class SlackToken(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    team_id = db.Column(db.String(255), nullable=False)
    access_token = db.Column(db.Text, nullable=False)
    bot_token = db.Column(db.Text, nullable=True)
    webhook_url = db.Column(db.Text, nullable=True)
    channel_id = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())
    updated_at = db.Column(db.DateTime, default=db.func.current_timestamp(), onupdate=db.func.current_timestamp())

class Invoice(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    quickbooks_id = db.Column(db.String(255), unique=True, nullable=False)
    doc_number = db.Column(db.String(255), nullable=True)
    customer_name = db.Column(db.String(255), nullable=True)
    total_amount = db.Column(Numeric(10, 2), nullable=True)
    balance = db.Column(Numeric(10, 2), nullable=True)
    due_date = db.Column(db.Date, nullable=True)
    status = db.Column(db.String(50), nullable=True)
    po_number = db.Column(db.String(255), nullable=True)
    po_status = db.Column(db.String(50), default='pending')
    last_synced = db.Column(db.DateTime, default=db.func.current_timestamp())
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())

class Payment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    quickbooks_id = db.Column(db.String(255), unique=True, nullable=False)
    invoice_id = db.Column(db.Integer, db.ForeignKey('invoice.id'), nullable=False)
    amount = db.Column(Numeric(10, 2), nullable=False)
    payment_date = db.Column(db.Date, nullable=False)
    payment_method = db.Column(db.String(100), nullable=True)
    last_synced = db.Column(db.DateTime, default=db.func.current_timestamp())
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())

class Recipe(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    cost = db.Column(Numeric(10, 2), nullable=False)
    ingredients = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())
    updated_at = db.Column(db.DateTime, default=db.func.current_timestamp(), onupdate=db.func.current_timestamp())

