from celery import Celery
from datetime import datetime, timedelta
import os
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize Celery
celery = Celery('quickbooks_slack_connector')
celery.conf.update(
    broker_url=os.getenv('CELERY_BROKER_URL', 'redis://localhost:6379/0'),
    result_backend=os.getenv('CELERY_RESULT_BACKEND', 'redis://localhost:6379/0'),
    task_serializer='json',
    accept_content=['json'],
    result_serializer='json',
    timezone='UTC',
    enable_utc=True,
)

# Periodic task configuration
celery.conf.beat_schedule = {
    'sync-all-companies': {
        'task': 'src.tasks.sync_all_companies',
        'schedule': 300.0,  # Run every 5 minutes
    },
    'cleanup-expired-tokens': {
        'task': 'src.tasks.cleanup_expired_tokens',
        'schedule': 3600.0,  # Run every hour
    },
}

@celery.task
def sync_all_companies():
    """Periodic task to sync all connected QuickBooks companies"""
    try:
        from src.models.user import QuickBooksToken
        from src.routes.integration import sync_company_invoices, sync_company_payments
        
        # Get all active tokens
        tokens = QuickBooksToken.query.filter(
            QuickBooksToken.token_expires_at > datetime.utcnow()
        ).all()
        
        results = []
        
        for token in tokens:
            try:
                # Sync invoices
                invoice_result = sync_company_invoices(token.company_id)
                
                # Sync payments
                payment_result = sync_company_payments(token.company_id)
                
                results.append({
                    'company_id': token.company_id,
                    'invoices_synced': invoice_result.get('synced_count', 0),
                    'payments_synced': payment_result.get('synced_count', 0),
                    'status': 'success'
                })
                
                logger.info(f"Synced company {token.company_id}: {invoice_result.get('synced_count', 0)} invoices, {payment_result.get('synced_count', 0)} payments")
                
            except Exception as e:
                logger.error(f"Sync failed for company {token.company_id}: {str(e)}")
                results.append({
                    'company_id': token.company_id,
                    'status': 'error',
                    'error': str(e)
                })
        
        logger.info(f"Completed sync for {len(results)} companies")
        return results
        
    except Exception as e:
        logger.error(f"Sync all companies task failed: {str(e)}")
        raise

@celery.task
def cleanup_expired_tokens():
    """Periodic task to clean up expired tokens"""
    try:
        from src.models.user import db, QuickBooksToken
        
        # Find expired tokens (older than 7 days past expiration)
        cutoff_date = datetime.utcnow() - timedelta(days=7)
        expired_tokens = QuickBooksToken.query.filter(
            QuickBooksToken.token_expires_at < cutoff_date
        ).all()
        
        count = len(expired_tokens)
        
        for token in expired_tokens:
            db.session.delete(token)
        
        db.session.commit()
        
        logger.info(f"Cleaned up {count} expired tokens")
        return {'cleaned_up': count}
        
    except Exception as e:
        logger.error(f"Token cleanup task failed: {str(e)}")
        raise

@celery.task
def send_invoice_notification(invoice_id, old_status):
    """Task to send invoice status change notification"""
    try:
        from src.models.user import Invoice
        from src.routes.integration import notify_invoice_status_change
        
        invoice = Invoice.query.get(invoice_id)
        if invoice:
            notify_invoice_status_change(invoice, old_status)
            logger.info(f"Sent invoice notification for invoice {invoice_id}")
        
    except Exception as e:
        logger.error(f"Invoice notification task failed: {str(e)}")
        raise

@celery.task
def send_payment_notification(payment_id):
    """Task to send payment received notification"""
    try:
        from src.models.user import Payment, Invoice
        from src.routes.integration import notify_payment_received
        
        payment = Payment.query.get(payment_id)
        if payment:
            invoice = Invoice.query.get(payment.invoice_id)
            if invoice:
                notify_payment_received(payment, invoice)
                logger.info(f"Sent payment notification for payment {payment_id}")
        
    except Exception as e:
        logger.error(f"Payment notification task failed: {str(e)}")
        raise

@celery.task
def sync_single_company(company_id):
    """Task to sync a single company's data"""
    try:
        from src.routes.integration import sync_company_invoices, sync_company_payments
        
        # Sync invoices
        invoice_result = sync_company_invoices(company_id)
        
        # Sync payments
        payment_result = sync_company_payments(company_id)
        
        result = {
            'company_id': company_id,
            'invoices_synced': invoice_result.get('synced_count', 0),
            'payments_synced': payment_result.get('synced_count', 0),
            'status': 'success'
        }
        
        logger.info(f"Synced company {company_id}: {result}")
        return result
        
    except Exception as e:
        logger.error(f"Single company sync failed for {company_id}: {str(e)}")
        raise

if __name__ == '__main__':
    # Start Celery worker
    celery.start()

