# Sample recipe data for testing
sample_recipes = [
    {
        'name': 'Chocolate Chip Cookies',
        'cost': 12.50,
        'ingredients': 'Flour, butter, sugar, chocolate chips, eggs, vanilla'
    },
    {
        'name': 'Caesar Salad',
        'cost': 8.75,
        'ingredients': 'Romaine lettuce, parmesan cheese, croutons, caesar dressing'
    },
    {
        'name': 'Beef Tacos',
        'cost': 15.25,
        'ingredients': 'Ground beef, taco shells, lettuce, tomatoes, cheese, sour cream'
    },
    {
        'name': 'Chicken Soup',
        'cost': 9.50,
        'ingredients': 'Chicken broth, chicken breast, carrots, celery, onions, noodles'
    },
    {
        'name': 'Margherita Pizza',
        'cost': 18.00,
        'ingredients': 'Pizza dough, tomato sauce, mozzarella cheese, fresh basil'
    }
]

def seed_database():
    """Seed the database with sample data"""
    from src.models.user import db, Recipe
    
    # Clear existing recipes
    Recipe.query.delete()
    
    # Add sample recipes
    for recipe_data in sample_recipes:
        recipe = Recipe(
            name=recipe_data['name'],
            cost=recipe_data['cost'],
            ingredients=recipe_data['ingredients']
        )
        db.session.add(recipe)
    
    db.session.commit()
    print(f"Seeded database with {len(sample_recipes)} recipes")

if __name__ == '__main__':
    from src.main import app
    
    with app.app_context():
        seed_database()

