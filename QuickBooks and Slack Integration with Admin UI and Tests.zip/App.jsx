import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Textarea } from '@/components/ui/textarea.jsx';
import { 
  Settings, 
  Database, 
  Slack, 
  DollarSign, 
  ChefHat, 
  Plus, 
  Trash2, 
  Edit,
  ExternalLink,
  CheckCircle,
  XCircle,
  Clock,
  BarChart3
} from 'lucide-react';
import './App.css';

// API base URL
const API_BASE = 'https://4nghki1c63p8.manus.space/api';

// Dashboard Overview Component
function Dashboard() {
  const [dashboardData, setDashboardData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const response = await fetch(`${API_BASE}/admin/dashboard`);
      const data = await response.json();
      if (!data.error) {
        setDashboardData(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
        <p className="text-muted-foreground">
          Overview of your QuickBooks and Slack integrations
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">QuickBooks Connections</CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dashboardData?.connections?.quickbooks || 0}</div>
            <p className="text-xs text-muted-foreground">
              Active company connections
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Slack Teams</CardTitle>
            <Slack className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dashboardData?.connections?.slack || 0}</div>
            <p className="text-xs text-muted-foreground">
              Connected Slack workspaces
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Recipes</CardTitle>
            <ChefHat className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dashboardData?.recipes || 0}</div>
            <p className="text-xs text-muted-foreground">
              Available for /skunk command
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Recent QuickBooks Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {dashboardData?.recent_activity?.quickbooks?.length > 0 ? (
                dashboardData.recent_activity.quickbooks.map((activity, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <span className="text-sm">{activity.company_id}</span>
                    <span className="text-xs text-muted-foreground">
                      {new Date(activity.updated_at).toLocaleDateString()}
                    </span>
                  </div>
                ))
              ) : (
                <p className="text-sm text-muted-foreground">No recent activity</p>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Slack Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {dashboardData?.recent_activity?.slack?.length > 0 ? (
                dashboardData.recent_activity.slack.map((activity, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <span className="text-sm">{activity.team_id}</span>
                    <span className="text-xs text-muted-foreground">
                      {new Date(activity.updated_at).toLocaleDateString()}
                    </span>
                  </div>
                ))
              ) : (
                <p className="text-sm text-muted-foreground">No recent activity</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

// Connections Management Component
function Connections() {
  const [qbTokens, setQbTokens] = useState([]);
  const [slackTokens, setSlackTokens] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchConnections();
  }, []);

  const fetchConnections = async () => {
    try {
      const [qbResponse, slackResponse] = await Promise.all([
        fetch(`${API_BASE}/admin/tokens/quickbooks`),
        fetch(`${API_BASE}/admin/tokens/slack`)
      ]);

      const qbData = await qbResponse.json();
      const slackData = await slackResponse.json();

      if (!qbData.error) setQbTokens(qbData.data);
      if (!slackData.error) setSlackTokens(slackData.data);
    } catch (error) {
      console.error('Failed to fetch connections:', error);
    } finally {
      setLoading(false);
    }
  };

  const deleteConnection = async (type, id) => {
    try {
      const response = await fetch(`${API_BASE}/admin/tokens/${type}/${id}`, {
        method: 'DELETE'
      });
      
      if (response.ok) {
        fetchConnections(); // Refresh the list
      }
    } catch (error) {
      console.error('Failed to delete connection:', error);
    }
  };

  const initiateOAuth = async (type) => {
    try {
      const response = await fetch(`${API_BASE}/${type}/auth`);
      const data = await response.json();
      
      if (data.auth_url) {
        window.open(data.auth_url, '_blank');
      }
    } catch (error) {
      console.error('Failed to initiate OAuth:', error);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Connections</h2>
        <p className="text-muted-foreground">
          Manage your QuickBooks and Slack integrations
        </p>
      </div>

      <Tabs defaultValue="quickbooks" className="space-y-4">
        <TabsList>
          <TabsTrigger value="quickbooks">QuickBooks</TabsTrigger>
          <TabsTrigger value="slack">Slack</TabsTrigger>
        </TabsList>

        <TabsContent value="quickbooks" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-medium">QuickBooks Connections</h3>
            <Button onClick={() => initiateOAuth('quickbooks')}>
              <Plus className="mr-2 h-4 w-4" />
              Connect QuickBooks
            </Button>
          </div>

          <div className="grid gap-4">
            {qbTokens.map((token) => (
              <Card key={token.id}>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">{token.company_id}</p>
                      <p className="text-sm text-muted-foreground">
                        Expires: {new Date(token.expires_at).toLocaleDateString()}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Connected: {new Date(token.created_at).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant={new Date(token.expires_at) > new Date() ? "default" : "destructive"}>
                        {new Date(token.expires_at) > new Date() ? "Active" : "Expired"}
                      </Badge>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => deleteConnection('quickbooks', token.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
            {qbTokens.length === 0 && (
              <Card>
                <CardContent className="pt-6">
                  <p className="text-center text-muted-foreground">
                    No QuickBooks connections found. Click "Connect QuickBooks" to get started.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="slack" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-medium">Slack Connections</h3>
            <Button onClick={() => initiateOAuth('slack')}>
              <Plus className="mr-2 h-4 w-4" />
              Connect Slack
            </Button>
          </div>

          <div className="grid gap-4">
            {slackTokens.map((token) => (
              <Card key={token.id}>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">{token.team_id}</p>
                      <p className="text-sm text-muted-foreground">
                        Channel: {token.channel_id || 'Not configured'}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Connected: {new Date(token.created_at).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant={token.has_webhook ? "default" : "secondary"}>
                        {token.has_webhook ? "Webhook Active" : "No Webhook"}
                      </Badge>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => deleteConnection('slack', token.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
            {slackTokens.length === 0 && (
              <Card>
                <CardContent className="pt-6">
                  <p className="text-center text-muted-foreground">
                    No Slack connections found. Click "Connect Slack" to get started.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

// Recipes Management Component
function Recipes() {
  const [recipes, setRecipes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingRecipe, setEditingRecipe] = useState(null);
  const [newRecipe, setNewRecipe] = useState({ name: '', cost: '', ingredients: '' });
  const [showAddForm, setShowAddForm] = useState(false);

  useEffect(() => {
    fetchRecipes();
  }, []);

  const fetchRecipes = async () => {
    try {
      const response = await fetch(`${API_BASE}/admin/recipes`);
      const data = await response.json();
      if (!data.error) {
        setRecipes(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch recipes:', error);
    } finally {
      setLoading(false);
    }
  };

  const createRecipe = async () => {
    try {
      const response = await fetch(`${API_BASE}/admin/recipes`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newRecipe)
      });

      if (response.ok) {
        setNewRecipe({ name: '', cost: '', ingredients: '' });
        setShowAddForm(false);
        fetchRecipes();
      }
    } catch (error) {
      console.error('Failed to create recipe:', error);
    }
  };

  const updateRecipe = async (id, updatedRecipe) => {
    try {
      const response = await fetch(`${API_BASE}/admin/recipes/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedRecipe)
      });

      if (response.ok) {
        setEditingRecipe(null);
        fetchRecipes();
      }
    } catch (error) {
      console.error('Failed to update recipe:', error);
    }
  };

  const deleteRecipe = async (id) => {
    try {
      const response = await fetch(`${API_BASE}/admin/recipes/${id}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        fetchRecipes();
      }
    } catch (error) {
      console.error('Failed to delete recipe:', error);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Recipes</h2>
          <p className="text-muted-foreground">
            Manage recipes for the /skunk Slack command
          </p>
        </div>
        <Button onClick={() => setShowAddForm(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Add Recipe
        </Button>
      </div>

      {showAddForm && (
        <Card>
          <CardHeader>
            <CardTitle>Add New Recipe</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="name">Recipe Name</Label>
              <Input
                id="name"
                value={newRecipe.name}
                onChange={(e) => setNewRecipe({ ...newRecipe, name: e.target.value })}
                placeholder="Enter recipe name"
              />
            </div>
            <div>
              <Label htmlFor="cost">Cost ($)</Label>
              <Input
                id="cost"
                type="number"
                step="0.01"
                value={newRecipe.cost}
                onChange={(e) => setNewRecipe({ ...newRecipe, cost: e.target.value })}
                placeholder="0.00"
              />
            </div>
            <div>
              <Label htmlFor="ingredients">Ingredients (Optional)</Label>
              <Textarea
                id="ingredients"
                value={newRecipe.ingredients}
                onChange={(e) => setNewRecipe({ ...newRecipe, ingredients: e.target.value })}
                placeholder="List ingredients..."
              />
            </div>
            <div className="flex space-x-2">
              <Button onClick={createRecipe}>Create Recipe</Button>
              <Button variant="outline" onClick={() => setShowAddForm(false)}>
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4">
        {recipes.map((recipe) => (
          <Card key={recipe.id}>
            <CardContent className="pt-6">
              {editingRecipe === recipe.id ? (
                <EditRecipeForm
                  recipe={recipe}
                  onSave={(updatedRecipe) => updateRecipe(recipe.id, updatedRecipe)}
                  onCancel={() => setEditingRecipe(null)}
                />
              ) : (
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <h3 className="font-medium">{recipe.name}</h3>
                    <p className="text-lg font-bold text-green-600">${recipe.cost.toFixed(2)}</p>
                    {recipe.ingredients && (
                      <p className="text-sm text-muted-foreground">{recipe.ingredients}</p>
                    )}
                    <p className="text-xs text-muted-foreground">
                      Created: {new Date(recipe.created_at).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="flex space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setEditingRecipe(recipe.id)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => deleteRecipe(recipe.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
        {recipes.length === 0 && (
          <Card>
            <CardContent className="pt-6">
              <p className="text-center text-muted-foreground">
                No recipes found. Click "Add Recipe" to get started.
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

// Edit Recipe Form Component
function EditRecipeForm({ recipe, onSave, onCancel }) {
  const [formData, setFormData] = useState({
    name: recipe.name,
    cost: recipe.cost.toString(),
    ingredients: recipe.ingredients || ''
  });

  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="edit-name">Recipe Name</Label>
        <Input
          id="edit-name"
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
        />
      </div>
      <div>
        <Label htmlFor="edit-cost">Cost ($)</Label>
        <Input
          id="edit-cost"
          type="number"
          step="0.01"
          value={formData.cost}
          onChange={(e) => setFormData({ ...formData, cost: e.target.value })}
        />
      </div>
      <div>
        <Label htmlFor="edit-ingredients">Ingredients</Label>
        <Textarea
          id="edit-ingredients"
          value={formData.ingredients}
          onChange={(e) => setFormData({ ...formData, ingredients: e.target.value })}
        />
      </div>
      <div className="flex space-x-2">
        <Button onClick={() => onSave(formData)}>Save Changes</Button>
        <Button variant="outline" onClick={onCancel}>Cancel</Button>
      </div>
    </div>
  );
}

// Navigation Component
function Navigation() {
  const location = useLocation();

  const navItems = [
    { path: '/', label: 'Dashboard', icon: BarChart3 },
    { path: '/connections', label: 'Connections', icon: Database },
    { path: '/recipes', label: 'Recipes', icon: ChefHat },
  ];

  return (
    <nav className="w-64 bg-card border-r border-border p-6">
      <div className="mb-8">
        <h1 className="text-xl font-bold">QB & Slack Connector</h1>
        <p className="text-sm text-muted-foreground">Admin Dashboard</p>
      </div>
      
      <div className="space-y-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center space-x-3 px-3 py-2 rounded-md transition-colors ${
                isActive 
                  ? 'bg-primary text-primary-foreground' 
                  : 'hover:bg-accent hover:text-accent-foreground'
              }`}
            >
              <Icon className="h-4 w-4" />
              <span>{item.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}

// Main App Component
function App() {
  return (
    <Router>
      <div className="flex h-screen bg-background">
        <Navigation />
        <main className="flex-1 overflow-auto p-6">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/connections" element={<Connections />} />
            <Route path="/recipes" element={<Recipes />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;

