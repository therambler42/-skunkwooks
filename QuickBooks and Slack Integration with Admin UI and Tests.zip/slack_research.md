# Slack API Research Notes

## Slack App Development Overview

### OAuth 2.0 Implementation:
- OAuth endpoint: `https://slack.com/oauth/v2/authorize`
- Token endpoint: `https://slack.com/api/oauth.v2.access`
- Required parameters: client_id, scope, redirect_uri
- Returns bot token and user token (if user scopes requested)

### Required Scopes:
- `commands` - Enable slash commands
- `chat:write` - Send messages to channels
- `incoming-webhook` - Post messages via webhooks
- `channels:read` - Read channel information
- `users:read` - Read user information (optional)

### Slash Commands:
- Must be registered in Slack app configuration
- Each command has its own Request URL endpoint
- Commands triggered by typing `/command` in Slack
- Slack sends POST request to your endpoint with command data
- Must respond within 3 seconds or use delayed response

### Slash Command Request Format:
```
token=verification_token
team_id=T1234567890
team_domain=example
channel_id=C1234567890
channel_name=general
user_id=U1234567890
user_name=username
command=/skunk
text=recipe_name
response_url=https://hooks.slack.com/commands/...
trigger_id=trigger_id_value
```

### Response Formats:
1. Immediate response (within 3 seconds):
   - JSON with text, response_type (ephemeral/in_channel)
2. Delayed response:
   - Use response_url to send message later

### Webhooks:
- Incoming webhooks for posting messages
- Each webhook has unique URL
- POST JSON payload to webhook URL
- Support rich formatting, attachments, blocks

### Bot Token vs User Token:
- Bot tokens: Perform actions as bot user
- User tokens: Perform actions on behalf of user
- Bot tokens preferred for most use cases

### Security:
- Verify requests using signing secret
- Check timestamp to prevent replay attacks
- Validate token parameter (legacy verification)

### Rate Limits:
- Web API: Tier-based rate limiting
- Webhooks: 1 message per second per webhook
- Slash commands: No specific rate limit

## Implementation Requirements:

### For /skunk Command:
1. Register slash command in Slack app
2. Create endpoint to handle command requests
3. Parse recipe name from command text
4. Look up recipe cost in database
5. Return formatted response with cost

### For Webhook Notifications:
1. Store webhook URL during OAuth flow
2. Create notification system for invoice updates
3. Format messages with invoice/payment details
4. Send to configured channels

### OAuth Flow:
1. Redirect user to Slack authorization URL
2. Handle callback with authorization code
3. Exchange code for access tokens
4. Store bot token and webhook URL
5. Associate with team/workspace ID

