#!/bin/bash

# PDF generation script for SLA Documentation
# Converts Markdown files to PDF format for download

set -e

echo "📄 Generating PDF versions of documentation..."

# Configuration
OUTPUT_DIR="dist/docs/sla/assets/pdf"
TEMPLATE_DIR="templates"

# Create PDF output directory
mkdir -p "$OUTPUT_DIR"

# Function to generate PDF from Markdown
generate_pdf() {
    local input_file="$1"
    local output_file="$2"
    local title="$3"
    
    echo "📄 Converting $input_file to $output_file"
    
    # Use pandoc to convert Markdown to PDF
    pandoc "$input_file" \
        --from markdown+smart \
        --to pdf \
        --pdf-engine=wkhtmltopdf \
        --css="$TEMPLATE_DIR/pdf.css" \
        --metadata title="$title" \
        --metadata author="Your Organization" \
        --metadata date="$(date '+%B %d, %Y')" \
        --metadata version="1.0" \
        --toc \
        --toc-depth=3 \
        --number-sections \
        --variable geometry:margin=1in \
        --variable fontsize:11pt \
        --variable documentclass:article \
        --variable papersize:letter \
        --output="$output_file"
}

# Function to combine all documents into one PDF
generate_complete_package() {
    echo "📦 Creating complete documentation package..."
    
    # Create temporary combined markdown file
    TEMP_COMBINED="/tmp/sla-complete-package.md"
    
    cat > "$TEMP_COMBINED" << 'EOF'
---
title: "SLA & Support Documentation - Complete Package"
author: "Your Organization"
date: "$(date '+%B %d, %Y')"
version: "1.0"
---

# SLA & Support Documentation
## Complete Package

This document contains the complete SLA and Support documentation package including:

- Service Level Agreement
- Support Workflow and Escalation Procedures  
- Incident Response Runbook
- Status Page Configuration Guide

---

EOF

    # Append each document with page breaks
    if [ -f "sla-document.md" ]; then
        echo -e "\n\\newpage\n" >> "$TEMP_COMBINED"
        cat "sla-document.md" >> "$TEMP_COMBINED"
    fi
    
    if [ -f "support-workflow.md" ]; then
        echo -e "\n\\newpage\n" >> "$TEMP_COMBINED"
        cat "support-workflow.md" >> "$TEMP_COMBINED"
    fi
    
    if [ -f "incident-response-runbook.md" ]; then
        echo -e "\n\\newpage\n" >> "$TEMP_COMBINED"
        cat "incident-response-runbook.md" >> "$TEMP_COMBINED"
    fi
    
    if [ -f "status-page-config.md" ]; then
        echo -e "\n\\newpage\n" >> "$TEMP_COMBINED"
        cat "status-page-config.md" >> "$TEMP_COMBINED"
    fi
    
    # Generate combined PDF
    generate_pdf "$TEMP_COMBINED" "$OUTPUT_DIR/sla-complete-package.pdf" "SLA & Support Documentation - Complete Package"
    
    # Cleanup
    rm -f "$TEMP_COMBINED"
}

# Generate individual PDFs
if [ -f "sla-document.md" ]; then
    generate_pdf "sla-document.md" "$OUTPUT_DIR/sla-document.pdf" "Service Level Agreement"
fi

if [ -f "support-workflow.md" ]; then
    generate_pdf "support-workflow.md" "$OUTPUT_DIR/support-workflow.pdf" "Support Workflow and Escalation Procedures"
fi

if [ -f "incident-response-runbook.md" ]; then
    generate_pdf "incident-response-runbook.md" "$OUTPUT_DIR/incident-response-runbook.pdf" "Incident Response Runbook"
fi

if [ -f "status-page-config.md" ]; then
    generate_pdf "status-page-config.md" "$OUTPUT_DIR/status-page-config.pdf" "Status Page Configuration Guide"
fi

# Generate complete package
generate_complete_package

# Create templates directory for downloadable templates
TEMPLATES_DIR="dist/docs/sla/assets/templates"
mkdir -p "$TEMPLATES_DIR"

# Generate incident response checklist template
cat > "/tmp/incident-checklist.md" << 'EOF'
# Incident Response Checklist

## Initial Response (First 15 minutes)
- [ ] Incident detected and confirmed
- [ ] Severity level assessed
- [ ] Incident Commander assigned
- [ ] Initial customer notification sent
- [ ] Technical team notified
- [ ] Status page updated

## Investigation Phase
- [ ] Root cause analysis initiated
- [ ] Affected systems identified
- [ ] Customer impact assessed
- [ ] Workarounds identified
- [ ] Progress updates sent (hourly for critical)

## Resolution Phase
- [ ] Fix implemented
- [ ] Solution tested
- [ ] Customer notification sent
- [ ] Status page updated
- [ ] Monitoring confirmed

## Post-Incident
- [ ] Post-mortem scheduled
- [ ] Documentation updated
- [ ] Lessons learned captured
- [ ] Prevention measures implemented
EOF

generate_pdf "/tmp/incident-checklist.md" "$TEMPLATES_DIR/incident-checklist.pdf" "Incident Response Checklist"

# Generate escalation contacts template
cat > "/tmp/escalation-contacts.md" << 'EOF'
# Emergency Escalation Contacts

## On-Call Rotation
| Role | Primary | Backup | Phone | Email |
|------|---------|--------|-------|-------|
| Incident Commander | [Name] | [Name] | [Phone] | [Email] |
| Technical Lead | [Name] | [Name] | [Phone] | [Email] |
| Communications Lead | [Name] | [Name] | [Phone] | [Email] |

## Management Escalation
| Level | Role | Name | Phone | Email |
|-------|------|------|-------|-------|
| L5 | Support Manager | [Name] | [Phone] | [Email] |
| L6 | Director/VP | [Name] | [Phone] | [Email] |

## External Contacts
| Service | Contact | Phone | Email | Account ID |
|---------|---------|-------|-------|------------|
| Cloud Provider | [Name] | [Phone] | [Email] | [ID] |
| CDN Provider | [Name] | [Phone] | [Email] | [ID] |
| Payment Processor | [Name] | [Phone] | [Email] | [ID] |

## Emergency Procedures
1. For P1 incidents: Call Incident Commander immediately
2. If no response in 15 minutes: Call backup
3. If still no response: Escalate to management
4. Document all escalation attempts
EOF

generate_pdf "/tmp/escalation-contacts.md" "$TEMPLATES_DIR/escalation-contacts.pdf" "Emergency Escalation Contacts"

# Cleanup temporary files
rm -f /tmp/incident-checklist.md /tmp/escalation-contacts.md

echo "✅ PDF generation completed!"
echo "📁 PDFs available in: $OUTPUT_DIR"
echo "📋 Templates available in: $TEMPLATES_DIR"

# Display PDF summary
echo ""
echo "📊 PDF Generation Summary:"
echo "=========================="
find "$OUTPUT_DIR" -name "*.pdf" | wc -l | xargs echo "PDF documents:"
find "$TEMPLATES_DIR" -name "*.pdf" | wc -l | xargs echo "Template documents:"
du -sh "$OUTPUT_DIR" "$TEMPLATES_DIR" 2>/dev/null | awk '{print $2 ": " $1}' || true

