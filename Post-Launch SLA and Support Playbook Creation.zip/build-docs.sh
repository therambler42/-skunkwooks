#!/bin/bash

# Build script for SLA Documentation
# Converts Markdown files to HTML and prepares for deployment

set -e

echo "🔨 Building SLA Documentation..."

# Configuration
SOURCE_DIR="docs/sla"
OUTPUT_DIR="dist/docs/sla"
TEMPLATE_DIR="templates"
ASSETS_DIR="assets"

# Create output directories
mkdir -p "$OUTPUT_DIR"
mkdir -p "$OUTPUT_DIR/assets/css"
mkdir -p "$OUTPUT_DIR/assets/js"
mkdir -p "$OUTPUT_DIR/assets/images"

# Copy base template files
echo "📋 Copying templates and assets..."
cp -r "$TEMPLATE_DIR"/* "$OUTPUT_DIR/" 2>/dev/null || true
cp -r "$ASSETS_DIR"/* "$OUTPUT_DIR/assets/" 2>/dev/null || true

# Function to convert Markdown to HTML
convert_markdown() {
    local input_file="$1"
    local output_file="$2"
    local title="$3"
    
    echo "📄 Converting $input_file to $output_file"
    
    # Use pandoc to convert Markdown to HTML with custom template
    pandoc "$input_file" \
        --from markdown+smart \
        --to html5 \
        --template="$TEMPLATE_DIR/document.html" \
        --css="/assets/css/docs.css" \
        --css="/assets/css/print.css" \
        --toc \
        --toc-depth=3 \
        --number-sections \
        --highlight-style=github \
        --metadata title="$title" \
        --metadata date="$(date '+%B %d, %Y')" \
        --metadata version="1.0" \
        --metadata organization="Your Organization" \
        --standalone \
        --output="$output_file"
}

# Function to generate navigation
generate_navigation() {
    cat > "$OUTPUT_DIR/navigation.html" << 'EOF'
<nav class="docs-navigation">
    <div class="nav-header">
        <h3>SLA & Support Documentation</h3>
    </div>
    <ul class="nav-menu">
        <li><a href="index.html" class="nav-link">Overview</a></li>
        <li><a href="sla-document.html" class="nav-link">Service Level Agreement</a></li>
        <li><a href="support-workflow.html" class="nav-link">Support Workflow</a></li>
        <li><a href="incident-response-runbook.html" class="nav-link">Incident Response</a></li>
        <li><a href="status-page-config.html" class="nav-link">Status Page Configuration</a></li>
        <li class="nav-divider"></li>
        <li><a href="downloads.html" class="nav-link">Downloads</a></li>
        <li><a href="changelog.html" class="nav-link">Changelog</a></li>
    </ul>
</nav>
EOF
}

# Function to create index page
create_index_page() {
    cat > "$OUTPUT_DIR/index.html" << 'EOF'
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SLA & Support Documentation</title>
    <link rel="stylesheet" href="/assets/css/docs.css">
    <link rel="stylesheet" href="/assets/css/print.css" media="print">
    <meta name="description" content="Comprehensive SLA and Support documentation including service level agreements, support workflows, and incident response procedures.">
</head>
<body>
    <div class="docs-container">
        <aside class="docs-sidebar">
            <!-- Navigation will be inserted here -->
        </aside>
        <main class="docs-content">
            <header class="docs-header">
                <h1>SLA & Support Documentation</h1>
                <p class="docs-subtitle">Comprehensive service level agreements and support procedures</p>
            </header>
            
            <section class="docs-overview">
                <div class="overview-grid">
                    <div class="overview-card">
                        <h3>Service Level Agreement</h3>
                        <p>Uptime commitments, response times, and resolution targets for all services.</p>
                        <a href="sla-document.html" class="btn btn-primary">View SLA</a>
                    </div>
                    
                    <div class="overview-card">
                        <h3>Support Workflow</h3>
                        <p>Ticket triage, escalation procedures, and on-call rotation management.</p>
                        <a href="support-workflow.html" class="btn btn-primary">View Workflow</a>
                    </div>
                    
                    <div class="overview-card">
                        <h3>Incident Response</h3>
                        <p>Comprehensive runbook for managing service incidents and outages.</p>
                        <a href="incident-response-runbook.html" class="btn btn-primary">View Runbook</a>
                    </div>
                    
                    <div class="overview-card">
                        <h3>Status Page Setup</h3>
                        <p>Configuration guide for customer-facing status page implementation.</p>
                        <a href="status-page-config.html" class="btn btn-primary">View Guide</a>
                    </div>
                </div>
            </section>
            
            <section class="docs-quick-links">
                <h2>Quick Links</h2>
                <ul>
                    <li><a href="#emergency-contacts">Emergency Contacts</a></li>
                    <li><a href="#escalation-matrix">Escalation Matrix</a></li>
                    <li><a href="#sla-targets">SLA Targets</a></li>
                    <li><a href="downloads.html">Download PDF Versions</a></li>
                </ul>
            </section>
            
            <section class="docs-updates">
                <h2>Recent Updates</h2>
                <div class="update-item">
                    <span class="update-date">$(date '+%B %d, %Y')</span>
                    <span class="update-description">Initial documentation release</span>
                </div>
            </section>
        </main>
    </div>
    
    <script src="/assets/js/docs.js"></script>
</body>
</html>
EOF
}

# Function to create downloads page
create_downloads_page() {
    cat > "$OUTPUT_DIR/downloads.html" << 'EOF'
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Downloads - SLA & Support Documentation</title>
    <link rel="stylesheet" href="/assets/css/docs.css">
</head>
<body>
    <div class="docs-container">
        <aside class="docs-sidebar">
            <!-- Navigation will be inserted here -->
        </aside>
        <main class="docs-content">
            <header class="docs-header">
                <h1>Downloads</h1>
                <p class="docs-subtitle">PDF versions and additional resources</p>
            </header>
            
            <section class="downloads-section">
                <h2>PDF Documents</h2>
                <div class="download-grid">
                    <div class="download-item">
                        <h3>Complete SLA Package</h3>
                        <p>All documentation in a single PDF file</p>
                        <a href="/assets/pdf/sla-complete-package.pdf" class="btn btn-download" download>Download PDF</a>
                    </div>
                    
                    <div class="download-item">
                        <h3>Service Level Agreement</h3>
                        <p>SLA document with uptime and response commitments</p>
                        <a href="/assets/pdf/sla-document.pdf" class="btn btn-download" download>Download PDF</a>
                    </div>
                    
                    <div class="download-item">
                        <h3>Support Workflow</h3>
                        <p>Support procedures and escalation matrix</p>
                        <a href="/assets/pdf/support-workflow.pdf" class="btn btn-download" download>Download PDF</a>
                    </div>
                    
                    <div class="download-item">
                        <h3>Incident Response Runbook</h3>
                        <p>Comprehensive incident management procedures</p>
                        <a href="/assets/pdf/incident-response-runbook.pdf" class="btn btn-download" download>Download PDF</a>
                    </div>
                </div>
            </section>
            
            <section class="downloads-section">
                <h2>Templates and Tools</h2>
                <div class="download-grid">
                    <div class="download-item">
                        <h3>Incident Response Checklist</h3>
                        <p>Quick reference checklist for incident response</p>
                        <a href="/assets/templates/incident-checklist.pdf" class="btn btn-download" download>Download Template</a>
                    </div>
                    
                    <div class="download-item">
                        <h3>Escalation Contact Sheet</h3>
                        <p>Emergency contact information template</p>
                        <a href="/assets/templates/escalation-contacts.pdf" class="btn btn-download" download>Download Template</a>
                    </div>
                </div>
            </section>
        </main>
    </div>
    
    <script src="/assets/js/docs.js"></script>
</body>
</html>
EOF
}

# Main build process
echo "🏗️  Starting documentation build process..."

# Generate navigation
generate_navigation

# Create index and downloads pages
create_index_page
create_downloads_page

# Convert main documentation files
if [ -f "sla-document.md" ]; then
    convert_markdown "sla-document.md" "$OUTPUT_DIR/sla-document.html" "Service Level Agreement"
fi

if [ -f "support-workflow.md" ]; then
    convert_markdown "support-workflow.md" "$OUTPUT_DIR/support-workflow.html" "Support Workflow and Escalation Procedures"
fi

if [ -f "incident-response-runbook.md" ]; then
    convert_markdown "incident-response-runbook.md" "$OUTPUT_DIR/incident-response-runbook.html" "Incident Response Runbook"
fi

if [ -f "status-page-config.md" ]; then
    convert_markdown "status-page-config.md" "$OUTPUT_DIR/status-page-config.html" "Status Page Configuration"
fi

# Insert navigation into all HTML files
echo "🧭 Inserting navigation into HTML files..."
for html_file in "$OUTPUT_DIR"/*.html; do
    if [ -f "$html_file" ]; then
        # Insert navigation after the sidebar div
        sed -i '/<aside class="docs-sidebar">/r '"$OUTPUT_DIR/navigation.html" "$html_file"
    fi
done

# Generate sitemap
echo "🗺️  Generating sitemap..."
cat > "$OUTPUT_DIR/sitemap.xml" << EOF
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <url>
        <loc>https://your-domain.com/docs/sla/</loc>
        <lastmod>$(date -u +%Y-%m-%d)</lastmod>
        <changefreq>monthly</changefreq>
        <priority>1.0</priority>
    </url>
    <url>
        <loc>https://your-domain.com/docs/sla/sla-document.html</loc>
        <lastmod>$(date -u +%Y-%m-%d)</lastmod>
        <changefreq>monthly</changefreq>
        <priority>0.9</priority>
    </url>
    <url>
        <loc>https://your-domain.com/docs/sla/support-workflow.html</loc>
        <lastmod>$(date -u +%Y-%m-%d)</lastmod>
        <changefreq>monthly</changefreq>
        <priority>0.9</priority>
    </url>
    <url>
        <loc>https://your-domain.com/docs/sla/incident-response-runbook.html</loc>
        <lastmod>$(date -u +%Y-%m-%d)</lastmod>
        <changefreq>monthly</changefreq>
        <priority>0.9</priority>
    </url>
    <url>
        <loc>https://your-domain.com/docs/sla/status-page-config.html</loc>
        <lastmod>$(date -u +%Y-%m-%d)</lastmod>
        <changefreq>monthly</changefreq>
        <priority>0.8</priority>
    </url>
</urlset>
EOF

# Generate robots.txt
cat > "$OUTPUT_DIR/robots.txt" << EOF
User-agent: *
Allow: /

Sitemap: https://your-domain.com/docs/sla/sitemap.xml
EOF

# Create .htaccess for Apache servers
cat > "$OUTPUT_DIR/.htaccess" << EOF
# SLA Documentation .htaccess

# Enable compression
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/plain
    AddOutputFilterByType DEFLATE text/html
    AddOutputFilterByType DEFLATE text/xml
    AddOutputFilterByType DEFLATE text/css
    AddOutputFilterByType DEFLATE application/xml
    AddOutputFilterByType DEFLATE application/xhtml+xml
    AddOutputFilterByType DEFLATE application/rss+xml
    AddOutputFilterByType DEFLATE application/javascript
    AddOutputFilterByType DEFLATE application/x-javascript
</IfModule>

# Set cache headers
<IfModule mod_expires.c>
    ExpiresActive on
    ExpiresByType text/css "access plus 1 month"
    ExpiresByType application/javascript "access plus 1 month"
    ExpiresByType image/png "access plus 1 month"
    ExpiresByType image/jpg "access plus 1 month"
    ExpiresByType image/jpeg "access plus 1 month"
    ExpiresByType image/gif "access plus 1 month"
    ExpiresByType application/pdf "access plus 1 week"
</IfModule>

# Security headers
<IfModule mod_headers.c>
    Header always set X-Content-Type-Options nosniff
    Header always set X-Frame-Options DENY
    Header always set X-XSS-Protection "1; mode=block"
    Header always set Referrer-Policy "strict-origin-when-cross-origin"
</IfModule>

# Custom error pages
ErrorDocument 404 /docs/sla/404.html
EOF

# Cleanup temporary files
rm -f "$OUTPUT_DIR/navigation.html"

echo "✅ Documentation build completed successfully!"
echo "📁 Output directory: $OUTPUT_DIR"
echo "🌐 Ready for deployment to /docs/sla/"

# Display build summary
echo ""
echo "📊 Build Summary:"
echo "=================="
find "$OUTPUT_DIR" -name "*.html" | wc -l | xargs echo "HTML files:"
find "$OUTPUT_DIR" -name "*.css" | wc -l | xargs echo "CSS files:"
find "$OUTPUT_DIR" -name "*.js" | wc -l | xargs echo "JavaScript files:"
find "$OUTPUT_DIR" -name "*.pdf" | wc -l | xargs echo "PDF files:"
du -sh "$OUTPUT_DIR" | cut -f1 | xargs echo "Total size:"

