#!/bin/bash

# Notification script for deployment completion
# Sends notifications to various channels about successful deployment

set -e

echo "📢 Sending deployment notifications..."

# Configuration
DEPLOYMENT_URL="${DEPLOYMENT_URL:-https://your-domain.com/docs/sla/}"
DEPLOYMENT_TIME=$(date '+%Y-%m-%d %H:%M:%S UTC')
GIT_COMMIT=$(git rev-parse --short HEAD 2>/dev/null || echo "unknown")
GIT_BRANCH=$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo "unknown")

# Function to send Slack notification
send_slack_notification() {
    if [ -n "$SLACK_WEBHOOK" ]; then
        echo "📱 Sending Slack notification..."
        
        SLACK_MESSAGE='{
            "text": "📚 SLA Documentation Deployed",
            "attachments": [
                {
                    "color": "good",
                    "fields": [
                        {
                            "title": "Environment",
                            "value": "Production",
                            "short": true
                        },
                        {
                            "title": "URL",
                            "value": "'$DEPLOYMENT_URL'",
                            "short": true
                        },
                        {
                            "title": "Commit",
                            "value": "'$GIT_COMMIT'",
                            "short": true
                        },
                        {
                            "title": "Branch",
                            "value": "'$GIT_BRANCH'",
                            "short": true
                        },
                        {
                            "title": "Deployed At",
                            "value": "'$DEPLOYMENT_TIME'",
                            "short": false
                        }
                    ]
                }
            ]
        }'
        
        curl -X POST -H 'Content-type: application/json' \
            --data "$SLACK_MESSAGE" \
            "$SLACK_WEBHOOK" || echo "Failed to send Slack notification"
    else
        echo "⚠️  SLACK_WEBHOOK not configured, skipping Slack notification"
    fi
}

# Function to send Microsoft Teams notification
send_teams_notification() {
    if [ -n "$TEAMS_WEBHOOK" ]; then
        echo "📱 Sending Teams notification..."
        
        TEAMS_MESSAGE='{
            "@type": "MessageCard",
            "@context": "http://schema.org/extensions",
            "themeColor": "0076D7",
            "summary": "SLA Documentation Deployed",
            "sections": [{
                "activityTitle": "📚 SLA Documentation Deployed",
                "activitySubtitle": "Production deployment completed successfully",
                "facts": [{
                    "name": "Environment",
                    "value": "Production"
                }, {
                    "name": "URL",
                    "value": "'$DEPLOYMENT_URL'"
                }, {
                    "name": "Commit",
                    "value": "'$GIT_COMMIT'"
                }, {
                    "name": "Branch",
                    "value": "'$GIT_BRANCH'"
                }, {
                    "name": "Deployed At",
                    "value": "'$DEPLOYMENT_TIME'"
                }],
                "markdown": true
            }],
            "potentialAction": [{
                "@type": "OpenUri",
                "name": "View Documentation",
                "targets": [{
                    "os": "default",
                    "uri": "'$DEPLOYMENT_URL'"
                }]
            }]
        }'
        
        curl -X POST -H 'Content-Type: application/json' \
            --data "$TEAMS_MESSAGE" \
            "$TEAMS_WEBHOOK" || echo "Failed to send Teams notification"
    else
        echo "⚠️  TEAMS_WEBHOOK not configured, skipping Teams notification"
    fi
}

# Function to send email notification
send_email_notification() {
    if [ -n "$EMAIL_RECIPIENTS" ] && [ -n "$SMTP_SERVER" ]; then
        echo "📧 Sending email notification..."
        
        EMAIL_SUBJECT="SLA Documentation Deployed - $DEPLOYMENT_TIME"
        EMAIL_BODY="
SLA Documentation has been successfully deployed to production.

Details:
- Environment: Production
- URL: $DEPLOYMENT_URL
- Commit: $GIT_COMMIT
- Branch: $GIT_BRANCH
- Deployed At: $DEPLOYMENT_TIME

The following documents are now available:
- Service Level Agreement
- Support Workflow and Escalation Procedures
- Incident Response Runbook
- Status Page Configuration Guide

You can access the documentation at: $DEPLOYMENT_URL

This is an automated notification from the CI/CD pipeline.
"
        
        # Use sendmail or mail command if available
        if command -v mail >/dev/null 2>&1; then
            echo "$EMAIL_BODY" | mail -s "$EMAIL_SUBJECT" "$EMAIL_RECIPIENTS"
        elif command -v sendmail >/dev/null 2>&1; then
            {
                echo "To: $EMAIL_RECIPIENTS"
                echo "Subject: $EMAIL_SUBJECT"
                echo ""
                echo "$EMAIL_BODY"
            } | sendmail "$EMAIL_RECIPIENTS"
        else
            echo "⚠️  No mail command available, skipping email notification"
        fi
    else
        echo "⚠️  Email configuration not complete, skipping email notification"
    fi
}

# Function to update status dashboard
update_status_dashboard() {
    if [ -n "$STATUS_DASHBOARD_API" ] && [ -n "$STATUS_API_KEY" ]; then
        echo "📊 Updating status dashboard..."
        
        STATUS_UPDATE='{
            "component": "documentation",
            "status": "operational",
            "message": "SLA Documentation updated and deployed",
            "timestamp": "'$(date -u +%Y-%m-%dT%H:%M:%SZ)'"
        }'
        
        curl -X POST \
            -H "Authorization: Bearer $STATUS_API_KEY" \
            -H "Content-Type: application/json" \
            --data "$STATUS_UPDATE" \
            "$STATUS_DASHBOARD_API" || echo "Failed to update status dashboard"
    else
        echo "⚠️  Status dashboard not configured, skipping update"
    fi
}

# Function to create deployment record
create_deployment_record() {
    echo "📝 Creating deployment record..."
    
    DEPLOYMENT_RECORD='{
        "environment": "production",
        "service": "sla-documentation",
        "version": "'$GIT_COMMIT'",
        "url": "'$DEPLOYMENT_URL'",
        "deployed_at": "'$DEPLOYMENT_TIME'",
        "deployed_by": "ci-cd-pipeline",
        "status": "success"
    }'
    
    # Save to local file for audit trail
    echo "$DEPLOYMENT_RECORD" > "/tmp/deployment-record-$(date +%s).json"
    
    # Send to deployment tracking service if configured
    if [ -n "$DEPLOYMENT_TRACKER_API" ] && [ -n "$DEPLOYMENT_API_KEY" ]; then
        curl -X POST \
            -H "Authorization: Bearer $DEPLOYMENT_API_KEY" \
            -H "Content-Type: application/json" \
            --data "$DEPLOYMENT_RECORD" \
            "$DEPLOYMENT_TRACKER_API" || echo "Failed to record deployment"
    fi
}

# Main notification process
echo "🚀 Starting notification process..."

# Send notifications
send_slack_notification
send_teams_notification
send_email_notification
update_status_dashboard
create_deployment_record

echo "✅ Deployment notifications completed!"
echo ""
echo "📊 Notification Summary:"
echo "======================="
echo "Deployment URL: $DEPLOYMENT_URL"
echo "Deployment Time: $DEPLOYMENT_TIME"
echo "Git Commit: $GIT_COMMIT"
echo "Git Branch: $GIT_BRANCH"
echo ""

# Verify deployment is accessible
echo "🔍 Verifying deployment accessibility..."
if curl -f -s -o /dev/null "$DEPLOYMENT_URL"; then
    echo "✅ Deployment is accessible"
else
    echo "❌ Warning: Deployment may not be accessible"
fi

echo "📢 All notifications sent successfully!"

