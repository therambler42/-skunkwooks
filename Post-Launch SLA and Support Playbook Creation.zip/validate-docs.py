#!/usr/bin/env python3

"""
Document validation script for SLA Documentation
Validates document structure, links, and content quality
"""

import os
import re
import sys
import json
from pathlib import Path

def validate_markdown_structure(file_path):
    """Validate markdown document structure"""
    errors = []
    
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Check for required sections
    required_sections = [
        r'# .+',  # Main title
        r'## .+', # At least one section
    ]
    
    for pattern in required_sections:
        if not re.search(pattern, content, re.MULTILINE):
            errors.append(f"Missing required section pattern: {pattern}")
    
    # Check for proper heading hierarchy
    headings = re.findall(r'^(#{1,6})\s+(.+)$', content, re.MULTILINE)
    prev_level = 0
    
    for heading_match in headings:
        level = len(heading_match[0])
        title = heading_match[1]
        
        # Check for proper heading progression
        if level > prev_level + 1:
            errors.append(f"Heading level jump: '{title}' (level {level} after level {prev_level})")
        
        prev_level = level
    
    # Check for table of contents if document is long
    if len(content.split('\n')) > 100:
        if 'table of contents' not in content.lower():
            errors.append("Long document missing table of contents")
    
    return errors

def validate_links(file_path):
    """Validate internal links in markdown"""
    errors = []
    
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Find all markdown links
    links = re.findall(r'\[([^\]]+)\]\(([^)]+)\)', content)
    
    for link_text, link_url in links:
        # Skip external links
        if link_url.startswith(('http://', 'https://', 'mailto:')):
            continue
        
        # Check internal file links
        if link_url.startswith('#'):
            # Anchor link - check if anchor exists
            anchor = link_url[1:].lower().replace(' ', '-')
            anchor_pattern = f'#{anchor}'
            if anchor_pattern not in content.lower():
                errors.append(f"Broken anchor link: {link_url}")
        else:
            # File link - check if file exists
            link_path = Path(file_path).parent / link_url
            if not link_path.exists():
                errors.append(f"Broken file link: {link_url}")
    
    return errors

def validate_content_quality(file_path):
    """Validate content quality and completeness"""
    errors = []
    warnings = []
    
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Check for placeholder content
    placeholders = [
        r'\[Insert .+\]',
        r'\[Your .+\]',
        r'\[Name\]',
        r'\[Email\]',
        r'\[Phone\]',
        r'\[Date\]',
        r'TODO:',
        r'FIXME:',
    ]
    
    for pattern in placeholders:
        matches = re.findall(pattern, content, re.IGNORECASE)
        if matches:
            warnings.append(f"Placeholder content found: {matches}")
    
    # Check for minimum content length
    word_count = len(content.split())
    if word_count < 500:
        warnings.append(f"Document may be too short: {word_count} words")
    
    # Check for proper document metadata
    if not content.startswith('# '):
        errors.append("Document should start with main heading")
    
    return errors, warnings

def main():
    """Main validation function"""
    docs_dir = Path('.')
    markdown_files = list(docs_dir.glob('*.md'))
    
    if not markdown_files:
        print("No markdown files found to validate")
        return 0
    
    total_errors = 0
    total_warnings = 0
    
    print("🔍 Validating SLA Documentation...")
    print("=" * 50)
    
    for md_file in markdown_files:
        print(f"\n📄 Validating {md_file.name}...")
        
        # Structure validation
        structure_errors = validate_markdown_structure(md_file)
        if structure_errors:
            print(f"  ❌ Structure errors:")
            for error in structure_errors:
                print(f"    - {error}")
            total_errors += len(structure_errors)
        
        # Link validation
        link_errors = validate_links(md_file)
        if link_errors:
            print(f"  ❌ Link errors:")
            for error in link_errors:
                print(f"    - {error}")
            total_errors += len(link_errors)
        
        # Content quality validation
        content_errors, content_warnings = validate_content_quality(md_file)
        if content_errors:
            print(f"  ❌ Content errors:")
            for error in content_errors:
                print(f"    - {error}")
            total_errors += len(content_errors)
        
        if content_warnings:
            print(f"  ⚠️  Content warnings:")
            for warning in content_warnings:
                print(f"    - {warning}")
            total_warnings += len(content_warnings)
        
        if not (structure_errors or link_errors or content_errors or content_warnings):
            print(f"  ✅ {md_file.name} validation passed")
    
    print("\n" + "=" * 50)
    print(f"📊 Validation Summary:")
    print(f"  Files validated: {len(markdown_files)}")
    print(f"  Total errors: {total_errors}")
    print(f"  Total warnings: {total_warnings}")
    
    if total_errors > 0:
        print(f"\n❌ Validation failed with {total_errors} errors")
        return 1
    elif total_warnings > 0:
        print(f"\n⚠️  Validation passed with {total_warnings} warnings")
        return 0
    else:
        print(f"\n✅ All validations passed!")
        return 0

if __name__ == "__main__":
    sys.exit(main())

