import { gql } from '@apollo/client';

export const GET_SUPPLIERS = gql`
  query GetSuppliers {
    suppliers {
      id
      name
      contactName
      contactEmail
      contactPhone
      address
      defaultTerms
      notes
      isActive
      createdAt
      updatedAt
    }
  }
`;

export const GET_SUPPLIER = gql`
  query GetSupplier($id: Int!) {
    supplier(id: $id) {
      id
      name
      contactName
      contactEmail
      contactPhone
      address
      defaultTerms
      notes
      isActive
      createdAt
      updatedAt
    }
  }
`;

export const CREATE_SUPPLIER = gql`
  mutation CreateSupplier($supplierData: SupplierInput!) {
    createSupplier(supplierData: $supplierData) {
      supplier {
        id
        name
        contactName
        contactEmail
        contactPhone
        address
        defaultTerms
        notes
        isActive
      }
      success
      message
    }
  }
`;

export const UPDATE_SUPPLIER = gql`
  mutation UpdateSupplier($id: Int!, $supplierData: SupplierInput!) {
    updateSupplier(id: $id, supplierData: $supplierData) {
      supplier {
        id
        name
        contactName
        contactEmail
        contactPhone
        address
        defaultTerms
        notes
        isActive
      }
      success
      message
    }
  }
`;

export const DELETE_SUPPLIER = gql`
  mutation DeleteSupplier($id: Int!) {
    deleteSupplier(id: $id) {
      success
      message
    }
  }
`;

export const GET_INGREDIENTS = gql`
  query GetIngredients {
    ingredients {
      id
      name
      description
      supplierId
      unitCost
      packSize
      unitOfMeasure
      sku
      category
      isActive
    }
  }
`;

export const GET_INGREDIENTS_BY_SUPPLIER = gql`
  query GetIngredientsBySupplier($supplierId: Int!) {
    ingredientsBySupplier(supplierId: $supplierId) {
      id
      name
      description
      unitCost
      packSize
      unitOfMeasure
      sku
      category
      isActive
    }
  }
`;

