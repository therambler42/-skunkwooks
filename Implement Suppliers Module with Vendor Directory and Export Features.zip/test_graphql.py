import pytest
import json
from src.models.supplier import db, Supplier, Ingredient

class TestGraphQLQueries:
    def test_get_suppliers_query(self, client):
        """Test GraphQL suppliers query"""
        # Create test data
        with client.application.app_context():
            supplier1 = Supplier(name='Supplier 1', is_active=True)
            supplier2 = Supplier(name='Supplier 2', is_active=True)
            supplier3 = Supplier(name='Supplier 3', is_active=False)
            
            db.session.add_all([supplier1, supplier2, supplier3])
            db.session.commit()
        
        # Test GraphQL query
        query = '''
        query {
            suppliers {
                id
                name
                isActive
            }
        }
        '''
        
        response = client.post('/graphql', 
                             data=json.dumps({'query': query}),
                             content_type='application/json')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        
        # Should only return active suppliers
        suppliers = data['data']['suppliers']
        assert len(suppliers) == 2
        assert all(supplier['isActive'] for supplier in suppliers)

    def test_get_supplier_by_id_query(self, client):
        """Test GraphQL supplier by ID query"""
        with client.application.app_context():
            supplier = Supplier(
                name='Test Supplier',
                contact_name='John Doe',
                contact_email='john@test.com',
                is_active=True
            )
            db.session.add(supplier)
            db.session.commit()
            supplier_id = supplier.id
        
        query = f'''
        query {{
            supplier(id: {supplier_id}) {{
                id
                name
                contactName
                contactEmail
                isActive
            }}
        }}
        '''
        
        response = client.post('/graphql',
                             data=json.dumps({'query': query}),
                             content_type='application/json')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        
        supplier = data['data']['supplier']
        assert supplier['name'] == 'Test Supplier'
        assert supplier['contactName'] == 'John Doe'
        assert supplier['contactEmail'] == 'john@test.com'

    def test_get_ingredients_by_supplier_query(self, client):
        """Test GraphQL ingredients by supplier query"""
        with client.application.app_context():
            supplier = Supplier(name='Test Supplier')
            db.session.add(supplier)
            db.session.flush()
            
            ingredient1 = Ingredient(name='Ingredient 1', supplier_id=supplier.id, is_active=True)
            ingredient2 = Ingredient(name='Ingredient 2', supplier_id=supplier.id, is_active=True)
            ingredient3 = Ingredient(name='Ingredient 3', supplier_id=supplier.id, is_active=False)
            
            db.session.add_all([ingredient1, ingredient2, ingredient3])
            db.session.commit()
            supplier_id = supplier.id
        
        query = f'''
        query {{
            ingredientsBySupplier(supplierId: {supplier_id}) {{
                id
                name
                isActive
            }}
        }}
        '''
        
        response = client.post('/graphql',
                             data=json.dumps({'query': query}),
                             content_type='application/json')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        
        # Should only return active ingredients
        ingredients = data['data']['ingredientsBySupplier']
        assert len(ingredients) == 2
        assert all(ingredient['isActive'] for ingredient in ingredients)

class TestGraphQLMutations:
    def test_create_supplier_mutation(self, client):
        """Test GraphQL create supplier mutation"""
        mutation = '''
        mutation {
            createSupplier(supplierData: {
                name: "New Supplier"
                contactName: "Jane Doe"
                contactEmail: "jane@test.com"
                contactPhone: "555-5678"
                defaultTerms: "Net 15"
                isActive: true
            }) {
                success
                message
                supplier {
                    id
                    name
                    contactName
                    contactEmail
                }
            }
        }
        '''
        
        response = client.post('/graphql',
                             data=json.dumps({'query': mutation}),
                             content_type='application/json')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        
        result = data['data']['createSupplier']
        assert result['success'] == True
        assert result['supplier']['name'] == 'New Supplier'
        assert result['supplier']['contactName'] == 'Jane Doe'

    def test_update_supplier_mutation(self, client):
        """Test GraphQL update supplier mutation"""
        # Create a supplier first
        with client.application.app_context():
            supplier = Supplier(name='Original Name', contact_name='Original Contact')
            db.session.add(supplier)
            db.session.commit()
            supplier_id = supplier.id
        
        mutation = f'''
        mutation {{
            updateSupplier(id: {supplier_id}, supplierData: {{
                name: "Updated Name"
                contactName: "Updated Contact"
                contactEmail: "updated@test.com"
            }}) {{
                success
                message
                supplier {{
                    id
                    name
                    contactName
                    contactEmail
                }}
            }}
        }}
        '''
        
        response = client.post('/graphql',
                             data=json.dumps({'query': mutation}),
                             content_type='application/json')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        
        result = data['data']['updateSupplier']
        assert result['success'] == True
        assert result['supplier']['name'] == 'Updated Name'
        assert result['supplier']['contactName'] == 'Updated Contact'
        assert result['supplier']['contactEmail'] == 'updated@test.com'

    def test_delete_supplier_mutation(self, client):
        """Test GraphQL delete supplier mutation"""
        # Create a supplier first
        with client.application.app_context():
            supplier = Supplier(name='To Be Deleted')
            db.session.add(supplier)
            db.session.commit()
            supplier_id = supplier.id
        
        mutation = f'''
        mutation {{
            deleteSupplier(id: {supplier_id}) {{
                success
                message
            }}
        }}
        '''
        
        response = client.post('/graphql',
                             data=json.dumps({'query': mutation}),
                             content_type='application/json')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        
        result = data['data']['deleteSupplier']
        assert result['success'] == True
        
        # Verify supplier was deleted
        with client.application.app_context():
            deleted_supplier = Supplier.query.get(supplier_id)
            assert deleted_supplier is None

    def test_create_supplier_validation(self, client):
        """Test create supplier with invalid data"""
        mutation = '''
        mutation {
            createSupplier(supplierData: {
                name: ""
            }) {
                success
                message
                supplier {
                    id
                }
            }
        }
        '''
        
        response = client.post('/graphql',
                             data=json.dumps({'query': mutation}),
                             content_type='application/json')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        
        # Should handle validation errors gracefully
        result = data['data']['createSupplier']
        assert result['success'] == False
        assert result['supplier'] is None

