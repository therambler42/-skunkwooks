import graphene
from graphene import ObjectType, String, Int, Float, Boolean, DateTime, List, Field, Mutation, Argument
from graphene_sqlalchemy import SQLAlchemyObjectType
from src.models.supplier import Supplier as SupplierModel, Ingredient as IngredientModel

# GraphQL Types
class Supplier(SQLAlchemyObjectType):
    class Meta:
        model = SupplierModel
        load_instance = True

class Ingredient(SQLAlchemyObjectType):
    class Meta:
        model = IngredientModel
        load_instance = True

# Input Types for Mutations
class SupplierInput(graphene.InputObjectType):
    name = String(required=True)
    contact_name = String()
    contact_email = String()
    contact_phone = String()
    address = String()
    default_terms = String()
    notes = String()
    is_active = Boolean()

class IngredientInput(graphene.InputObjectType):
    name = String(required=True)
    description = String()
    supplier_id = Int(required=True)
    unit_cost = Float()
    pack_size = String()
    unit_of_measure = String()
    sku = String()
    category = String()
    is_active = Boolean()

# Mutations
class CreateSupplier(Mutation):
    class Arguments:
        supplier_data = SupplierInput(required=True)
    
    supplier = Field(lambda: Supplier)
    success = Boolean()
    message = String()
    
    def mutate(self, info, supplier_data):
        from src.models.supplier import db
        try:
            supplier = SupplierModel(**supplier_data)
            db.session.add(supplier)
            db.session.commit()
            return CreateSupplier(supplier=supplier, success=True, message="Supplier created successfully")
        except Exception as e:
            db.session.rollback()
            return CreateSupplier(supplier=None, success=False, message=str(e))

class UpdateSupplier(Mutation):
    class Arguments:
        id = Int(required=True)
        supplier_data = SupplierInput(required=True)
    
    supplier = Field(lambda: Supplier)
    success = Boolean()
    message = String()
    
    def mutate(self, info, id, supplier_data):
        from src.models.supplier import db
        try:
            supplier = SupplierModel.query.get(id)
            if not supplier:
                return UpdateSupplier(supplier=None, success=False, message="Supplier not found")
            
            for key, value in supplier_data.items():
                if hasattr(supplier, key):
                    setattr(supplier, key, value)
            
            db.session.commit()
            return UpdateSupplier(supplier=supplier, success=True, message="Supplier updated successfully")
        except Exception as e:
            db.session.rollback()
            return UpdateSupplier(supplier=None, success=False, message=str(e))

class DeleteSupplier(Mutation):
    class Arguments:
        id = Int(required=True)
    
    success = Boolean()
    message = String()
    
    def mutate(self, info, id):
        from src.models.supplier import db
        try:
            supplier = SupplierModel.query.get(id)
            if not supplier:
                return DeleteSupplier(success=False, message="Supplier not found")
            
            db.session.delete(supplier)
            db.session.commit()
            return DeleteSupplier(success=True, message="Supplier deleted successfully")
        except Exception as e:
            db.session.rollback()
            return DeleteSupplier(success=False, message=str(e))

class CreateIngredient(Mutation):
    class Arguments:
        ingredient_data = IngredientInput(required=True)
    
    ingredient = Field(lambda: Ingredient)
    success = Boolean()
    message = String()
    
    def mutate(self, info, ingredient_data):
        from src.models.supplier import db
        try:
            ingredient = IngredientModel(**ingredient_data)
            db.session.add(ingredient)
            db.session.commit()
            return CreateIngredient(ingredient=ingredient, success=True, message="Ingredient created successfully")
        except Exception as e:
            db.session.rollback()
            return CreateIngredient(ingredient=None, success=False, message=str(e))

# Query
class Query(ObjectType):
    suppliers = List(Supplier)
    supplier = Field(Supplier, id=Int(required=True))
    ingredients = List(Ingredient)
    ingredient = Field(Ingredient, id=Int(required=True))
    ingredients_by_supplier = List(Ingredient, supplier_id=Int(required=True))
    
    def resolve_suppliers(self, info):
        return SupplierModel.query.filter_by(is_active=True).all()
    
    def resolve_supplier(self, info, id):
        return SupplierModel.query.get(id)
    
    def resolve_ingredients(self, info):
        return IngredientModel.query.filter_by(is_active=True).all()
    
    def resolve_ingredient(self, info, id):
        return IngredientModel.query.get(id)
    
    def resolve_ingredients_by_supplier(self, info, supplier_id):
        return IngredientModel.query.filter_by(supplier_id=supplier_id, is_active=True).all()

# Mutation
class Mutation(ObjectType):
    create_supplier = CreateSupplier.Field()
    update_supplier = UpdateSupplier.Field()
    delete_supplier = DeleteSupplier.Field()
    create_ingredient = CreateIngredient.Field()

# Schema
schema = graphene.Schema(query=Query, mutation=Mutation)

