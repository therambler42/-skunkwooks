import pytest
import os
import tempfile
from src.main import app
from src.models.supplier import db

@pytest.fixture
def client():
    # Create a temporary database file
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    with app.test_client() as client:
        with app.app_context():
            db.drop_all()
            db.create_all()
        yield client

@pytest.fixture
def sample_supplier_data():
    return {
        'name': 'Test Supplier',
        'contactName': 'John Doe',
        'contactEmail': 'john@test.com',
        'contactPhone': '555-1234',
        'address': '123 Test St',
        'defaultTerms': 'Net 30',
        'notes': 'Test notes',
        'isActive': True
    }

