// cypress/support/commands.js

// Custom command to visit suppliers page
Cypress.Commands.add('visitSuppliersPage', () => {
  cy.visit('/suppliers')
  cy.get('[data-testid="suppliers-page"]', { timeout: 10000 }).should('be.visible')
})

// Custom command to create a supplier via UI
Cypress.Commands.add('createSupplierViaUI', (supplierData) => {
  cy.get('[data-testid="new-supplier-btn"]').click()
  cy.get('[data-testid="supplier-form"]').should('be.visible')
  
  cy.get('[data-testid="supplier-name-input"]').type(supplierData.name)
  
  if (supplierData.contactName) {
    cy.get('[data-testid="contact-name-input"]').type(supplierData.contactName)
  }
  
  if (supplierData.contactEmail) {
    cy.get('[data-testid="contact-email-input"]').type(supplierData.contactEmail)
  }
  
  if (supplierData.contactPhone) {
    cy.get('[data-testid="contact-phone-input"]').type(supplierData.contactPhone)
  }
  
  if (supplierData.defaultTerms) {
    cy.get('[data-testid="default-terms-input"]').type(supplierData.defaultTerms)
  }
  
  cy.get('[data-testid="submit-supplier-btn"]').click()
  cy.get('[data-testid="supplier-form"]').should('not.exist')
})

// Custom command to delete a supplier via UI
Cypress.Commands.add('deleteSupplierViaUI', (supplierName) => {
  cy.contains('[data-testid="supplier-card"]', supplierName)
    .find('[data-testid="delete-supplier-btn"]')
    .click()
  
  cy.get('[data-testid="delete-confirm-dialog"]').should('be.visible')
  cy.get('[data-testid="confirm-delete-btn"]').click()
  cy.get('[data-testid="delete-confirm-dialog"]').should('not.exist')
})

// Custom command to search for suppliers
Cypress.Commands.add('searchSuppliers', (searchTerm) => {
  cy.get('[data-testid="search-input"]').clear().type(searchTerm)
  cy.wait(500) // Wait for debounced search
})

