import os
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.models.supplier import db, Supplier as SupplierModel, Ingredient as IngredientModel

def seed_sample_data():
    """Create sample suppliers and ingredients for testing"""
    
    # Check if data already exists
    if SupplierModel.query.count() > 0:
        print("Sample data already exists. Skipping seed.")
        return
    
    # Sample suppliers
    suppliers_data = [
        {
            'name': 'ABC Food Distributors',
            'contact_name': 'John Smith',
            'contact_email': 'john@abcfood.com',
            'contact_phone': '(555) 123-4567',
            'address': '123 Main St, City, State 12345',
            'default_terms': 'Net 30',
            'notes': 'Primary produce supplier',
            'is_active': True
        },
        {
            'name': 'Fresh Ingredients Co',
            'contact_name': 'Sarah Johnson',
            'contact_email': 'sarah@freshingredients.com',
            'contact_phone': '(555) 987-6543',
            'address': '456 Oak Ave, City, State 67890',
            'default_terms': 'Net 15',
            'notes': 'Organic specialty items',
            'is_active': True
        },
        {
            'name': 'Quality Meats Inc',
            'contact_name': 'Mike Wilson',
            'contact_email': 'mike@qualitymeats.com',
            'contact_phone': '(555) 456-7890',
            'address': '789 Pine St, City, State 54321',
            'default_terms': 'COD',
            'notes': 'Premium meat supplier',
            'is_active': True
        },
        {
            'name': 'Dairy Fresh Suppliers',
            'contact_name': 'Lisa Brown',
            'contact_email': 'lisa@dairyfresh.com',
            'contact_phone': '(555) 321-0987',
            'address': '321 Elm St, City, State 98765',
            'default_terms': 'Net 21',
            'notes': 'Local dairy products',
            'is_active': True
        }
    ]
    
    # Create suppliers
    suppliers = []
    for supplier_data in suppliers_data:
        supplier = SupplierModel(**supplier_data)
        db.session.add(supplier)
        suppliers.append(supplier)
    
    db.session.flush()  # Flush to get IDs
    
    # Sample ingredients
    ingredients_data = [
        # ABC Food Distributors ingredients
        {'name': 'Organic Tomatoes', 'supplier_id': suppliers[0].id, 'unit_cost': 3.50, 'pack_size': '25 lbs', 'unit_of_measure': 'lbs', 'sku': 'ABC-TOM-001', 'category': 'Produce'},
        {'name': 'Fresh Lettuce', 'supplier_id': suppliers[0].id, 'unit_cost': 2.25, 'pack_size': '24 heads', 'unit_of_measure': 'heads', 'sku': 'ABC-LET-001', 'category': 'Produce'},
        {'name': 'Yellow Onions', 'supplier_id': suppliers[0].id, 'unit_cost': 1.80, 'pack_size': '50 lbs', 'unit_of_measure': 'lbs', 'sku': 'ABC-ONI-001', 'category': 'Produce'},
        
        # Fresh Ingredients Co ingredients
        {'name': 'Organic Olive Oil', 'supplier_id': suppliers[1].id, 'unit_cost': 12.50, 'pack_size': '1 gallon', 'unit_of_measure': 'gallon', 'sku': 'FIC-OIL-001', 'category': 'Oils'},
        {'name': 'Sea Salt', 'supplier_id': suppliers[1].id, 'unit_cost': 4.75, 'pack_size': '5 lbs', 'unit_of_measure': 'lbs', 'sku': 'FIC-SAL-001', 'category': 'Seasonings'},
        {'name': 'Black Pepper', 'supplier_id': suppliers[1].id, 'unit_cost': 8.90, 'pack_size': '2 lbs', 'unit_of_measure': 'lbs', 'sku': 'FIC-PEP-001', 'category': 'Seasonings'},
        
        # Quality Meats Inc ingredients
        {'name': 'Ground Beef 80/20', 'supplier_id': suppliers[2].id, 'unit_cost': 6.50, 'pack_size': '10 lbs', 'unit_of_measure': 'lbs', 'sku': 'QMI-BEF-001', 'category': 'Meat'},
        {'name': 'Chicken Breast', 'supplier_id': suppliers[2].id, 'unit_cost': 4.25, 'pack_size': '5 lbs', 'unit_of_measure': 'lbs', 'sku': 'QMI-CHI-001', 'category': 'Meat'},
        {'name': 'Pork Tenderloin', 'supplier_id': suppliers[2].id, 'unit_cost': 8.75, 'pack_size': '3 lbs', 'unit_of_measure': 'lbs', 'sku': 'QMI-POR-001', 'category': 'Meat'},
        
        # Dairy Fresh Suppliers ingredients
        {'name': 'Whole Milk', 'supplier_id': suppliers[3].id, 'unit_cost': 3.25, 'pack_size': '1 gallon', 'unit_of_measure': 'gallon', 'sku': 'DFS-MIL-001', 'category': 'Dairy'},
        {'name': 'Cheddar Cheese', 'supplier_id': suppliers[3].id, 'unit_cost': 5.50, 'pack_size': '2 lbs', 'unit_of_measure': 'lbs', 'sku': 'DFS-CHE-001', 'category': 'Dairy'},
        {'name': 'Greek Yogurt', 'supplier_id': suppliers[3].id, 'unit_cost': 4.80, 'pack_size': '32 oz', 'unit_of_measure': 'oz', 'sku': 'DFS-YOG-001', 'category': 'Dairy'},
    ]
    
    # Create ingredients
    for ingredient_data in ingredients_data:
        ingredient = IngredientModel(**ingredient_data)
        db.session.add(ingredient)
    
    db.session.commit()
    print(f"Created {len(suppliers)} suppliers and {len(ingredients_data)} ingredients")

if __name__ == '__main__':
    from src.main import app
    with app.app_context():
        seed_sample_data()

