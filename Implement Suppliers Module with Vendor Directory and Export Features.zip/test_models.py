import pytest
import json
from src.models.supplier import db, Supplier, Ingredient

class TestSupplierModel:
    def test_create_supplier(self, client):
        """Test creating a new supplier"""
        supplier = Supplier(
            name='Test Supplier',
            contact_name='John Doe',
            contact_email='john@test.com',
            contact_phone='555-1234',
            address='123 Test St',
            default_terms='Net 30',
            notes='Test notes',
            is_active=True
        )
        
        with client.application.app_context():
            db.session.add(supplier)
            db.session.commit()
            
            # Verify supplier was created
            saved_supplier = Supplier.query.filter_by(name='Test Supplier').first()
            assert saved_supplier is not None
            assert saved_supplier.name == 'Test Supplier'
            assert saved_supplier.contact_name == 'John Doe'
            assert saved_supplier.contact_email == 'john@test.com'
            assert saved_supplier.is_active == True

    def test_supplier_to_dict(self, client):
        """Test supplier to_dict method"""
        supplier = Supplier(
            name='Test Supplier',
            contact_name='John Doe',
            contact_email='john@test.com',
            is_active=True
        )
        
        with client.application.app_context():
            db.session.add(supplier)
            db.session.commit()
            
            supplier_dict = supplier.to_dict()
            assert supplier_dict['name'] == 'Test Supplier'
            assert supplier_dict['contact_name'] == 'John Doe'
            assert supplier_dict['contact_email'] == 'john@test.com'
            assert supplier_dict['is_active'] == True
            assert 'id' in supplier_dict
            assert 'created_at' in supplier_dict

    def test_supplier_unique_name_constraint(self, client):
        """Test that supplier names must be unique"""
        with client.application.app_context():
            supplier1 = Supplier(name='Duplicate Name')
            supplier2 = Supplier(name='Duplicate Name')
            
            db.session.add(supplier1)
            db.session.commit()
            
            db.session.add(supplier2)
            with pytest.raises(Exception):  # Should raise integrity error
                db.session.commit()

class TestIngredientModel:
    def test_create_ingredient(self, client):
        """Test creating a new ingredient"""
        with client.application.app_context():
            # First create a supplier
            supplier = Supplier(name='Test Supplier')
            db.session.add(supplier)
            db.session.flush()
            
            # Create ingredient
            ingredient = Ingredient(
                name='Test Ingredient',
                description='Test description',
                supplier_id=supplier.id,
                unit_cost=5.50,
                pack_size='10 lbs',
                unit_of_measure='lbs',
                sku='TEST-001',
                category='Test Category',
                is_active=True
            )
            
            db.session.add(ingredient)
            db.session.commit()
            
            # Verify ingredient was created
            saved_ingredient = Ingredient.query.filter_by(name='Test Ingredient').first()
            assert saved_ingredient is not None
            assert saved_ingredient.name == 'Test Ingredient'
            assert saved_ingredient.supplier_id == supplier.id
            assert float(saved_ingredient.unit_cost) == 5.50
            assert saved_ingredient.pack_size == '10 lbs'

    def test_ingredient_to_dict(self, client):
        """Test ingredient to_dict method"""
        with client.application.app_context():
            supplier = Supplier(name='Test Supplier')
            db.session.add(supplier)
            db.session.flush()
            
            ingredient = Ingredient(
                name='Test Ingredient',
                supplier_id=supplier.id,
                unit_cost=5.50,
                pack_size='10 lbs'
            )
            
            db.session.add(ingredient)
            db.session.commit()
            
            ingredient_dict = ingredient.to_dict()
            assert ingredient_dict['name'] == 'Test Ingredient'
            assert ingredient_dict['supplier_id'] == supplier.id
            assert ingredient_dict['unit_cost'] == 5.50
            assert ingredient_dict['pack_size'] == '10 lbs'
            assert 'id' in ingredient_dict

    def test_supplier_ingredient_relationship(self, client):
        """Test the relationship between supplier and ingredients"""
        with client.application.app_context():
            supplier = Supplier(name='Test Supplier')
            db.session.add(supplier)
            db.session.flush()
            
            ingredient1 = Ingredient(name='Ingredient 1', supplier_id=supplier.id)
            ingredient2 = Ingredient(name='Ingredient 2', supplier_id=supplier.id)
            
            db.session.add_all([ingredient1, ingredient2])
            db.session.commit()
            
            # Test relationship
            assert len(supplier.ingredients) == 2
            assert ingredient1.supplier == supplier
            assert ingredient2.supplier == supplier

