import React, { useState } from 'react';
import { Upload, X, FileText, AlertCircle, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';

function BulkImportModal({ onClose, onSuccess }) {
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [result, setResult] = useState(null);
  const [dragOver, setDragOver] = useState(false);

  const handleFileSelect = (selectedFile) => {
    if (selectedFile && selectedFile.type === 'text/csv') {
      setFile(selectedFile);
      setResult(null);
    } else {
      alert('Please select a CSV file');
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    const droppedFile = e.dataTransfer.files[0];
    handleFileSelect(droppedFile);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    setDragOver(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    setDragOver(false);
  };

  const handleUpload = async () => {
    if (!file) return;

    setUploading(true);
    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await fetch('http://localhost:5000/api/suppliers/bulk-import', {
        method: 'POST',
        body: formData,
      });

      const data = await response.json();
      setResult(data);

      if (data.success && data.imported_count > 0) {
        setTimeout(() => {
          onSuccess();
        }, 2000);
      }
    } catch (error) {
      setResult({
        success: false,
        error: 'Failed to upload file: ' + error.message
      });
    } finally {
      setUploading(false);
    }
  };

  const downloadSampleCSV = () => {
    const sampleData = [
      ['name', 'contact_name', 'contact_email', 'contact_phone', 'address', 'default_terms', 'notes', 'is_active'],
      ['ABC Food Distributors', 'John Smith', 'john@abcfood.com', '(555) 123-4567', '123 Main St, City, State 12345', 'Net 30', 'Primary produce supplier', 'true'],
      ['Fresh Ingredients Co', 'Sarah Johnson', 'sarah@freshingredients.com', '(555) 987-6543', '456 Oak Ave, City, State 67890', 'Net 15', 'Organic specialty items', 'true'],
      ['Quality Meats Inc', 'Mike Wilson', 'mike@qualitymeats.com', '(555) 456-7890', '789 Pine St, City, State 54321', 'COD', 'Premium meat supplier', 'true']
    ];

    const csvContent = sampleData.map(row => row.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'suppliers_sample.csv';
    a.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-2xl">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <CardTitle className="text-xl">Bulk Import Suppliers</CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="h-8 w-8 p-0"
          >
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>
        <CardContent className="space-y-4">
          {!result && (
            <>
              <div className="text-sm text-gray-600 mb-4">
                Upload a CSV file with supplier information. The file should include columns: 
                name, contact_name, contact_email, contact_phone, address, default_terms, notes, is_active.
              </div>

              <div className="flex justify-center mb-4">
                <Button
                  variant="outline"
                  onClick={downloadSampleCSV}
                  className="flex items-center"
                >
                  <FileText className="h-4 w-4 mr-2" />
                  Download Sample CSV
                </Button>
              </div>

              <div
                className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                  dragOver
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-300 hover:border-gray-400'
                }`}
                onDrop={handleDrop}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
              >
                <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <div className="text-lg font-medium text-gray-900 mb-2">
                  Drop your CSV file here
                </div>
                <div className="text-sm text-gray-600 mb-4">
                  or click to browse
                </div>
                <input
                  type="file"
                  accept=".csv"
                  onChange={(e) => handleFileSelect(e.target.files[0])}
                  className="hidden"
                  id="file-upload"
                />
                <label htmlFor="file-upload">
                  <Button variant="outline" className="cursor-pointer">
                    Choose File
                  </Button>
                </label>
              </div>

              {file && (
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center">
                    <FileText className="h-5 w-5 text-gray-500 mr-2" />
                    <span className="text-sm font-medium">{file.name}</span>
                    <span className="text-sm text-gray-500 ml-2">
                      ({(file.size / 1024).toFixed(1)} KB)
                    </span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setFile(null)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              )}

              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={onClose}>
                  Cancel
                </Button>
                <Button
                  onClick={handleUpload}
                  disabled={!file || uploading}
                >
                  {uploading ? 'Uploading...' : 'Upload'}
                </Button>
              </div>

              {uploading && (
                <div className="space-y-2">
                  <Progress value={50} className="w-full" />
                  <div className="text-sm text-center text-gray-600">
                    Processing file...
                  </div>
                </div>
              )}
            </>
          )}

          {result && (
            <div className="space-y-4">
              <div className={`flex items-center p-4 rounded-lg ${
                result.success ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'
              }`}>
                {result.success ? (
                  <CheckCircle className="h-5 w-5 mr-2" />
                ) : (
                  <AlertCircle className="h-5 w-5 mr-2" />
                )}
                <div>
                  {result.success ? (
                    <div>
                      <div className="font-medium">Import Successful!</div>
                      <div className="text-sm">
                        {result.imported_count} suppliers imported successfully.
                      </div>
                    </div>
                  ) : (
                    <div>
                      <div className="font-medium">Import Failed</div>
                      <div className="text-sm">
                        {result.error || 'An error occurred during import.'}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {result.errors && result.errors.length > 0 && (
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <div className="font-medium text-yellow-800 mb-2">
                    Warnings ({result.errors.length}):
                  </div>
                  <div className="text-sm text-yellow-700 space-y-1 max-h-32 overflow-y-auto">
                    {result.errors.map((error, index) => (
                      <div key={index}>• {error}</div>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex justify-end">
                <Button onClick={onClose}>
                  Close
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

export default BulkImportModal;

