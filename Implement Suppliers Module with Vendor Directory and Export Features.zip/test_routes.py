import pytest
import io
import csv
from src.models.supplier import db, Supplier, Ingredient

class TestExportOrderGuide:
    def test_export_order_guide_empty(self, client):
        """Test export with no data"""
        response = client.get('/api/suppliers/export-order-guide')
        
        assert response.status_code == 200
        assert response.headers['Content-Type'] == 'text/csv'
        assert 'attachment; filename=order_guide.csv' in response.headers['Content-Disposition']
        
        # Should have header row only
        csv_content = response.data.decode('utf-8')
        lines = csv_content.strip().split('\n')
        assert len(lines) == 1  # Header only
        assert 'Supplier Name' in lines[0]

    def test_export_order_guide_with_data(self, client):
        """Test export with sample data"""
        with client.application.app_context():
            # Create test data
            supplier1 = Supplier(name='Supplier A', is_active=True)
            supplier2 = Supplier(name='Supplier B', is_active=True)
            supplier3 = Supplier(name='Inactive Supplier', is_active=False)
            
            db.session.add_all([supplier1, supplier2, supplier3])
            db.session.flush()
            
            # Add ingredients
            ingredients = [
                Ingredient(name='Tomatoes', supplier_id=supplier1.id, unit_cost=3.50, 
                          pack_size='25 lbs', sku='TOM-001', category='Produce', is_active=True),
                Ingredient(name='Lettuce', supplier_id=supplier1.id, unit_cost=2.25,
                          pack_size='24 heads', sku='LET-001', category='Produce', is_active=True),
                Ingredient(name='Olive Oil', supplier_id=supplier2.id, unit_cost=12.50,
                          pack_size='1 gallon', sku='OIL-001', category='Oils', is_active=True),
                Ingredient(name='Inactive Item', supplier_id=supplier1.id, is_active=False),
                Ingredient(name='From Inactive Supplier', supplier_id=supplier3.id, is_active=True)
            ]
            
            db.session.add_all(ingredients)
            db.session.commit()
        
        response = client.get('/api/suppliers/export-order-guide')
        
        assert response.status_code == 200
        
        # Parse CSV content
        csv_content = response.data.decode('utf-8')
        reader = csv.DictReader(io.StringIO(csv_content))
        rows = list(reader)
        
        # Should only include active suppliers and active ingredients
        assert len(rows) == 3  # 2 from Supplier A, 1 from Supplier B
        
        # Check data content
        supplier_a_items = [row for row in rows if row['Supplier Name'] == 'Supplier A']
        supplier_b_items = [row for row in rows if row['Supplier Name'] == 'Supplier B']
        
        assert len(supplier_a_items) == 2
        assert len(supplier_b_items) == 1
        
        # Verify specific data
        tomato_row = next(row for row in rows if row['Ingredient Name'] == 'Tomatoes')
        assert tomato_row['Unit Cost'] == '3.50'
        assert tomato_row['Pack Size'] == '25 lbs'
        assert tomato_row['SKU'] == 'TOM-001'
        assert tomato_row['Category'] == 'Produce'

class TestBulkImport:
    def test_bulk_import_no_file(self, client):
        """Test bulk import without file"""
        response = client.post('/api/suppliers/bulk-import')
        
        assert response.status_code == 400
        data = response.get_json()
        assert 'No file provided' in data['error']

    def test_bulk_import_invalid_file_type(self, client):
        """Test bulk import with non-CSV file"""
        data = {'file': (io.BytesIO(b'not a csv'), 'test.txt')}
        response = client.post('/api/suppliers/bulk-import', data=data)
        
        assert response.status_code == 400
        data = response.get_json()
        assert 'File must be CSV format' in data['error']

    def test_bulk_import_valid_csv(self, client):
        """Test bulk import with valid CSV data"""
        csv_data = '''name,contact_name,contact_email,contact_phone,default_terms,is_active
Test Supplier 1,John Doe,john@test.com,555-1234,Net 30,true
Test Supplier 2,Jane Smith,jane@test.com,555-5678,Net 15,true
Test Supplier 3,Bob Johnson,bob@test.com,555-9012,COD,false'''
        
        data = {'file': (io.BytesIO(csv_data.encode()), 'suppliers.csv')}
        response = client.post('/api/suppliers/bulk-import', 
                             data=data, 
                             content_type='multipart/form-data')
        
        assert response.status_code == 200
        result = response.get_json()
        
        assert result['success'] == True
        assert result['imported_count'] == 3
        assert len(result['errors']) == 0
        
        # Verify suppliers were created
        with client.application.app_context():
            suppliers = Supplier.query.all()
            assert len(suppliers) == 3
            
            supplier1 = Supplier.query.filter_by(name='Test Supplier 1').first()
            assert supplier1.contact_name == 'John Doe'
            assert supplier1.contact_email == 'john@test.com'
            assert supplier1.default_terms == 'Net 30'
            assert supplier1.is_active == True
            
            supplier3 = Supplier.query.filter_by(name='Test Supplier 3').first()
            assert supplier3.is_active == False

    def test_bulk_import_duplicate_names(self, client):
        """Test bulk import with duplicate supplier names"""
        # Create existing supplier
        with client.application.app_context():
            existing_supplier = Supplier(name='Existing Supplier')
            db.session.add(existing_supplier)
            db.session.commit()
        
        csv_data = '''name,contact_name
Existing Supplier,John Doe
New Supplier,Jane Smith'''
        
        data = {'file': (io.BytesIO(csv_data.encode()), 'suppliers.csv')}
        response = client.post('/api/suppliers/bulk-import',
                             data=data,
                             content_type='multipart/form-data')
        
        assert response.status_code == 200
        result = response.get_json()
        
        assert result['success'] == True
        assert result['imported_count'] == 1  # Only new supplier
        assert len(result['errors']) == 1
        assert 'already exists' in result['errors'][0]

    def test_bulk_import_missing_required_fields(self, client):
        """Test bulk import with missing required fields"""
        csv_data = '''name,contact_name
,John Doe
Valid Supplier,Jane Smith'''
        
        data = {'file': (io.BytesIO(csv_data.encode()), 'suppliers.csv')}
        response = client.post('/api/suppliers/bulk-import',
                             data=data,
                             content_type='multipart/form-data')
        
        assert response.status_code == 200
        result = response.get_json()
        
        assert result['success'] == True
        assert result['imported_count'] == 1  # Only valid supplier
        assert len(result['errors']) == 1
        assert 'Name is required' in result['errors'][0]

    def test_bulk_import_empty_csv(self, client):
        """Test bulk import with empty CSV"""
        csv_data = '''name,contact_name'''
        
        data = {'file': (io.BytesIO(csv_data.encode()), 'suppliers.csv')}
        response = client.post('/api/suppliers/bulk-import',
                             data=data,
                             content_type='multipart/form-data')
        
        assert response.status_code == 200
        result = response.get_json()
        
        assert result['success'] == True
        assert result['imported_count'] == 0
        assert len(result['errors']) == 0

