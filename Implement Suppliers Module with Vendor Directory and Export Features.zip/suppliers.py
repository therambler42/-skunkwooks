import csv
import io
from flask import jsonify, request, make_response
from src.models.supplier import db, Supplier as SupplierModel, Ingredient as IngredientModel

def export_order_guide():
    """Export order guide as CSV with ingredients grouped by supplier"""
    try:
        # Query all active suppliers with their ingredients
        suppliers = SupplierModel.query.filter_by(is_active=True).all()
        
        # Create CSV data
        output = io.StringIO()
        writer = csv.writer(output)
        
        # Write header
        writer.writerow(['Supplier Name', 'Ingredient Name', 'SKU', 'Unit Cost', 'Pack Size', 'Unit of Measure', 'Category'])
        
        # Write data grouped by supplier
        for supplier in suppliers:
            ingredients = IngredientModel.query.filter_by(supplier_id=supplier.id, is_active=True).all()
            for ingredient in ingredients:
                writer.writerow([
                    supplier.name,
                    ingredient.name,
                    ingredient.sku or '',
                    ingredient.unit_cost or '',
                    ingredient.pack_size or '',
                    ingredient.unit_of_measure or '',
                    ingredient.category or ''
                ])
        
        # Create response
        output.seek(0)
        response = make_response(output.getvalue())
        response.headers['Content-Type'] = 'text/csv'
        response.headers['Content-Disposition'] = 'attachment; filename=order_guide.csv'
        
        return response
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def bulk_import_suppliers():
    """Bulk import suppliers from CSV file"""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if not file.filename.endswith('.csv'):
            return jsonify({'error': 'File must be CSV format'}), 400
        
        # Read CSV data
        stream = io.StringIO(file.stream.read().decode("UTF8"), newline=None)
        csv_input = csv.DictReader(stream)
        
        imported_count = 0
        errors = []
        
        for row_num, row in enumerate(csv_input, start=2):  # Start at 2 to account for header
            try:
                # Validate required fields
                if not row.get('name'):
                    errors.append(f"Row {row_num}: Name is required")
                    continue
                
                # Check if supplier already exists
                existing_supplier = SupplierModel.query.filter_by(name=row['name']).first()
                if existing_supplier:
                    errors.append(f"Row {row_num}: Supplier '{row['name']}' already exists")
                    continue
                
                # Create new supplier
                supplier = SupplierModel(
                    name=row['name'],
                    contact_name=row.get('contact_name', ''),
                    contact_email=row.get('contact_email', ''),
                    contact_phone=row.get('contact_phone', ''),
                    address=row.get('address', ''),
                    default_terms=row.get('default_terms', ''),
                    notes=row.get('notes', ''),
                    is_active=row.get('is_active', 'true').lower() == 'true'
                )
                
                db.session.add(supplier)
                imported_count += 1
                
            except Exception as e:
                errors.append(f"Row {row_num}: {str(e)}")
        
        # Commit all changes
        if imported_count > 0:
            db.session.commit()
        
        return jsonify({
            'success': True,
            'imported_count': imported_count,
            'errors': errors
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

