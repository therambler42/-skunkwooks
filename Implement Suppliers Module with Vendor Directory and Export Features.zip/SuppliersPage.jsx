import React, { useState } from 'react';
import { useQuery, useMutation } from '@apollo/client';
import { Plus, Edit, Trash2, Download, Upload, Search, Building2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { GET_SUPPLIERS, DELETE_SUPPLIER } from '../lib/queries';
import SupplierForm from './SupplierForm';
import DeleteConfirmDialog from './DeleteConfirmDialog';
import BulkImportModal from './BulkImportModal';

function SuppliersPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState(null);
  const [deletingSupplier, setDeletingSupplier] = useState(null);
  const [showBulkImport, setShowBulkImport] = useState(false);

  const { loading, error, data, refetch } = useQuery(GET_SUPPLIERS);
  const [deleteSupplier] = useMutation(DELETE_SUPPLIER);

  const suppliers = data?.suppliers || [];
  const filteredSuppliers = suppliers.filter(supplier =>
    supplier.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    supplier.contactName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    supplier.contactEmail?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleEdit = (supplier) => {
    setEditingSupplier(supplier);
    setShowForm(true);
  };

  const handleDelete = async (supplier) => {
    try {
      const result = await deleteSupplier({
        variables: { id: supplier.id }
      });
      
      if (result.data.deleteSupplier.success) {
        refetch();
        setDeletingSupplier(null);
      } else {
        alert('Error deleting supplier: ' + result.data.deleteSupplier.message);
      }
    } catch (err) {
      alert('Error deleting supplier: ' + err.message);
    }
  };

  const handleFormClose = () => {
    setShowForm(false);
    setEditingSupplier(null);
    refetch();
  };

  const handleExportOrderGuide = () => {
    window.open('http://localhost:5000/api/suppliers/export-order-guide', '_blank');
  };

  const handleBulkImport = () => {
    setShowBulkImport(true);
  };

  const handleBulkImportSuccess = () => {
    setShowBulkImport(false);
    refetch();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-lg">Loading suppliers...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-lg text-red-600">Error loading suppliers: {error.message}</div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8" data-testid="suppliers-page">
      <div className="px-4 py-6 sm:px-0">
        {/* Header */}
        <div className="mb-6">
          <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-4 gap-4">
            <h1 className="text-3xl font-bold text-gray-900">Suppliers</h1>
            <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2">
              <Button
                onClick={handleBulkImport}
                variant="outline"
                className="flex items-center justify-center"
                data-testid="bulk-import-btn"
              >
                <Upload className="h-4 w-4 mr-2" />
                Bulk Import
              </Button>
              <Button
                onClick={handleExportOrderGuide}
                variant="outline"
                className="flex items-center justify-center"
                data-testid="export-order-guide-btn"
              >
                <Download className="h-4 w-4 mr-2" />
                Export Order Guide
              </Button>
              <Button
                onClick={() => setShowForm(true)}
                className="flex items-center justify-center"
                data-testid="new-supplier-btn"
              >
                <Plus className="h-4 w-4 mr-2" />
                New Supplier
              </Button>
            </div>
          </div>

          {/* Search */}
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              type="text"
              placeholder="Search suppliers..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
              data-testid="search-input"
            />
          </div>
        </div>

        {/* Suppliers List */}
        <div className="grid gap-4 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filteredSuppliers.map((supplier) => (
            <Card key={supplier.id} className="hover:shadow-lg transition-all duration-200 hover:scale-105" data-testid="supplier-card">
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <CardTitle className="text-lg truncate pr-2">{supplier.name}</CardTitle>
                  <div className="flex space-x-1 flex-shrink-0">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleEdit(supplier)}
                      className="h-8 w-8 p-0 hover:bg-blue-100"
                      data-testid="edit-supplier-btn"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setDeletingSupplier(supplier)}
                      className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-100"
                      data-testid="delete-supplier-btn"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {supplier.contactName && (
                    <p className="text-sm text-gray-600 truncate">
                      <span className="font-medium">Contact:</span> {supplier.contactName}
                    </p>
                  )}
                  {supplier.contactEmail && (
                    <p className="text-sm text-gray-600 truncate">
                      <span className="font-medium">Email:</span> {supplier.contactEmail}
                    </p>
                  )}
                  {supplier.contactPhone && (
                    <p className="text-sm text-gray-600">
                      <span className="font-medium">Phone:</span> {supplier.contactPhone}
                    </p>
                  )}
                  {supplier.defaultTerms && (
                    <div className="flex items-center space-x-2">
                      <span className="text-sm font-medium text-gray-600">Terms:</span>
                      <Badge variant="secondary" className="text-xs">{supplier.defaultTerms}</Badge>
                    </div>
                  )}
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium text-gray-600">Status:</span>
                    <Badge variant={supplier.isActive ? "default" : "secondary"} className="text-xs">
                      {supplier.isActive ? "Active" : "Inactive"}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredSuppliers.length === 0 && (
          <div className="text-center py-12">
            <Building2 className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <div className="text-gray-500 text-lg mb-2">
              {searchTerm ? 'No suppliers found matching your search.' : 'No suppliers found.'}
            </div>
            {!searchTerm && (
              <p className="text-gray-400 mb-4">Create your first supplier to get started!</p>
            )}
            {!searchTerm && (
              <Button
                onClick={() => setShowForm(true)}
                className="flex items-center mx-auto"
              >
                <Plus className="h-4 w-4 mr-2" />
                Create First Supplier
              </Button>
            )}
          </div>
        )}

        {/* Supplier Form Modal */}
        {showForm && (
          <SupplierForm
            supplier={editingSupplier}
            onClose={handleFormClose}
          />
        )}

        {/* Delete Confirmation Dialog */}
        {deletingSupplier && (
          <DeleteConfirmDialog
            supplier={deletingSupplier}
            onConfirm={() => handleDelete(deletingSupplier)}
            onCancel={() => setDeletingSupplier(null)}
          />
        )}

        {/* Bulk Import Modal */}
        {showBulkImport && (
          <BulkImportModal
            onClose={() => setShowBulkImport(false)}
            onSuccess={handleBulkImportSuccess}
          />
        )}
      </div>
    </div>
  );
}

export default SuppliersPage;

