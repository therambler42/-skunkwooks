describe('Export and Import Functionality', () => {
  beforeEach(() => {
    cy.visit('/suppliers')
    cy.get('[data-testid="suppliers-page"]', { timeout: 10000 }).should('be.visible')
  })

  it('should export order guide', () => {
    // Create some test suppliers and ingredients first
    const suppliers = [
      { name: 'Export Test Supplier 1', contactName: 'Contact 1' },
      { name: 'Export Test Supplier 2', contactName: 'Contact 2' }
    ]

    suppliers.forEach(supplier => {
      cy.createSupplierViaUI(supplier)
    })

    // Click export button
    cy.get('[data-testid="export-order-guide-btn"]').click()

    // Verify download starts (we can't easily test file download in Cypress)
    // But we can verify the button click doesn't cause errors
    cy.get('[data-testid="export-order-guide-btn"]').should('be.visible')
  })

  it('should open bulk import modal', () => {
    cy.get('[data-testid="bulk-import-btn"]').click()
    cy.get('[data-testid="bulk-import-modal"]').should('be.visible')
    
    // Check modal content
    cy.contains('Bulk Import Suppliers').should('be.visible')
    cy.get('[data-testid="download-sample-btn"]').should('be.visible')
    cy.get('[data-testid="file-upload-area"]').should('be.visible')
    
    // Close modal
    cy.get('[data-testid="close-modal-btn"]').click()
    cy.get('[data-testid="bulk-import-modal"]').should('not.exist')
  })

  it('should download sample CSV', () => {
    cy.get('[data-testid="bulk-import-btn"]').click()
    cy.get('[data-testid="bulk-import-modal"]').should('be.visible')
    
    // Click download sample button
    cy.get('[data-testid="download-sample-btn"]').click()
    
    // Verify button is still clickable (download doesn't break UI)
    cy.get('[data-testid="download-sample-btn"]').should('be.visible')
  })

  it('should handle file upload UI', () => {
    cy.get('[data-testid="bulk-import-btn"]').click()
    cy.get('[data-testid="bulk-import-modal"]').should('be.visible')
    
    // Create a test CSV file
    const csvContent = 'name,contact_name,contact_email\nTest Import Supplier,John Doe,john@test.com'
    const fileName = 'test-suppliers.csv'
    
    // Upload file
    cy.get('[data-testid="file-input"]').selectFile({
      contents: csvContent,
      fileName: fileName,
      mimeType: 'text/csv'
    }, { force: true })
    
    // Verify file is selected
    cy.contains(fileName).should('be.visible')
    
    // Upload button should be enabled
    cy.get('[data-testid="upload-btn"]').should('not.be.disabled')
  })

  it('should reject non-CSV files', () => {
    cy.get('[data-testid="bulk-import-btn"]').click()
    cy.get('[data-testid="bulk-import-modal"]').should('be.visible')
    
    // Try to upload a non-CSV file
    const textContent = 'This is not a CSV file'
    const fileName = 'test.txt'
    
    cy.get('[data-testid="file-input"]').selectFile({
      contents: textContent,
      fileName: fileName,
      mimeType: 'text/plain'
    }, { force: true })
    
    // Should show error message
    cy.contains('Please select a CSV file').should('be.visible')
  })

  it('should show drag and drop area', () => {
    cy.get('[data-testid="bulk-import-btn"]').click()
    cy.get('[data-testid="bulk-import-modal"]').should('be.visible')
    
    // Check drag and drop area
    cy.get('[data-testid="file-upload-area"]').should('be.visible')
    cy.contains('Drop your CSV file here').should('be.visible')
    cy.contains('or click to browse').should('be.visible')
  })

  it('should cancel bulk import', () => {
    cy.get('[data-testid="bulk-import-btn"]').click()
    cy.get('[data-testid="bulk-import-modal"]').should('be.visible')
    
    // Click cancel button
    cy.get('[data-testid="cancel-import-btn"]').click()
    
    // Modal should close
    cy.get('[data-testid="bulk-import-modal"]').should('not.exist')
  })
})

