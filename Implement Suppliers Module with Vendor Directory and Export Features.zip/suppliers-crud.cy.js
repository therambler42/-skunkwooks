describe('Suppliers CRUD Operations', () => {
  beforeEach(() => {
    // Visit the suppliers page before each test
    cy.visit('/suppliers')
    cy.get('[data-testid="suppliers-page"]', { timeout: 10000 }).should('be.visible')
  })

  it('should display the suppliers page correctly', () => {
    cy.get('h1').should('contain', 'Suppliers')
    cy.get('[data-testid="new-supplier-btn"]').should('be.visible')
    cy.get('[data-testid="export-order-guide-btn"]').should('be.visible')
    cy.get('[data-testid="bulk-import-btn"]').should('be.visible')
    cy.get('[data-testid="search-input"]').should('be.visible')
  })

  it('should create a new supplier', () => {
    const supplierData = {
      name: 'Test Supplier E2E',
      contactName: 'John Doe',
      contactEmail: 'john@test.com',
      contactPhone: '555-1234',
      defaultTerms: 'Net 30'
    }

    // Click new supplier button
    cy.get('[data-testid="new-supplier-btn"]').click()
    cy.get('[data-testid="supplier-form"]').should('be.visible')

    // Fill out the form
    cy.get('[data-testid="supplier-name-input"]').type(supplierData.name)
    cy.get('[data-testid="contact-name-input"]').type(supplierData.contactName)
    cy.get('[data-testid="contact-email-input"]').type(supplierData.contactEmail)
    cy.get('[data-testid="contact-phone-input"]').type(supplierData.contactPhone)
    cy.get('[data-testid="default-terms-input"]').type(supplierData.defaultTerms)

    // Submit the form
    cy.get('[data-testid="submit-supplier-btn"]').click()

    // Verify the form closes and supplier appears in list
    cy.get('[data-testid="supplier-form"]').should('not.exist')
    cy.contains('[data-testid="supplier-card"]', supplierData.name).should('be.visible')
  })

  it('should edit an existing supplier', () => {
    // First create a supplier to edit
    const originalData = {
      name: 'Original Supplier',
      contactName: 'Original Contact'
    }

    cy.createSupplierViaUI(originalData)

    // Edit the supplier
    cy.contains('[data-testid="supplier-card"]', originalData.name)
      .find('[data-testid="edit-supplier-btn"]')
      .click()

    cy.get('[data-testid="supplier-form"]').should('be.visible')
    
    // Update the name
    cy.get('[data-testid="supplier-name-input"]')
      .clear()
      .type('Updated Supplier Name')

    cy.get('[data-testid="submit-supplier-btn"]').click()

    // Verify the update
    cy.get('[data-testid="supplier-form"]').should('not.exist')
    cy.contains('[data-testid="supplier-card"]', 'Updated Supplier Name').should('be.visible')
    cy.contains('[data-testid="supplier-card"]', originalData.name).should('not.exist')
  })

  it('should delete a supplier', () => {
    const supplierData = {
      name: 'Supplier to Delete',
      contactName: 'Delete Me'
    }

    // Create a supplier to delete
    cy.createSupplierViaUI(supplierData)

    // Delete the supplier
    cy.deleteSupplierViaUI(supplierData.name)

    // Verify the supplier is removed
    cy.contains('[data-testid="supplier-card"]', supplierData.name).should('not.exist')
  })

  it('should search suppliers', () => {
    // Create multiple suppliers
    const suppliers = [
      { name: 'ABC Food Distributors', contactName: 'John Smith' },
      { name: 'XYZ Ingredients Co', contactName: 'Jane Doe' },
      { name: 'Fresh Produce LLC', contactName: 'Bob Johnson' }
    ]

    suppliers.forEach(supplier => {
      cy.createSupplierViaUI(supplier)
    })

    // Search for specific supplier
    cy.searchSuppliers('ABC')
    cy.get('[data-testid="supplier-card"]').should('have.length', 1)
    cy.contains('[data-testid="supplier-card"]', 'ABC Food Distributors').should('be.visible')

    // Clear search and verify all suppliers are shown
    cy.get('[data-testid="search-input"]').clear()
    cy.get('[data-testid="supplier-card"]').should('have.length.at.least', 3)
  })

  it('should validate required fields', () => {
    cy.get('[data-testid="new-supplier-btn"]').click()
    cy.get('[data-testid="supplier-form"]').should('be.visible')

    // Try to submit without required fields
    cy.get('[data-testid="submit-supplier-btn"]').click()

    // Form should still be visible (validation failed)
    cy.get('[data-testid="supplier-form"]').should('be.visible')
    
    // Check for validation error
    cy.get('[data-testid="supplier-name-input"]').should('have.class', 'border-red-500')
  })

  it('should cancel form creation', () => {
    cy.get('[data-testid="new-supplier-btn"]').click()
    cy.get('[data-testid="supplier-form"]').should('be.visible')

    // Fill some data
    cy.get('[data-testid="supplier-name-input"]').type('Test Supplier')

    // Cancel the form
    cy.get('[data-testid="cancel-supplier-btn"]').click()

    // Form should close
    cy.get('[data-testid="supplier-form"]').should('not.exist')
    
    // Supplier should not be created
    cy.contains('[data-testid="supplier-card"]', 'Test Supplier').should('not.exist')
  })
})

