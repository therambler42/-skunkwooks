import os
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory, jsonify
from flask_cors import CORS
from src.models.supplier import db, Supplier, Ingredient
from src.routes.suppliers_blueprint import suppliers_bp

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))
app.config['SECRET_KEY'] = 'asdf#FGSgvasgf$5$WGT'

# Enable CORS for all routes
CORS(app)

app.register_blueprint(suppliers_bp, url_prefix='/api/suppliers')

# Database configuration - use SQLite for deployment
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///suppliers.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

with app.app_context():
    db.create_all()
    
    # Seed some data if empty
    if Supplier.query.count() == 0:
        suppliers = [
            Supplier(name='ABC Food Distributors', contact_name='John Smith', 
                    contact_email='john@abcfood.com', contact_phone='(555) 123-4567',
                    default_terms='Net 30', is_active=True),
            Supplier(name='Fresh Ingredients Co', contact_name='Sarah Johnson',
                    contact_email='sarah@freshingredients.com', contact_phone='(555) 987-6543',
                    default_terms='Net 15', is_active=True),
            Supplier(name='Quality Meats Inc', contact_name='Mike Wilson',
                    contact_email='mike@qualitymeats.com', contact_phone='(555) 456-7890',
                    default_terms='COD', is_active=True),
            Supplier(name='Dairy Fresh Suppliers', contact_name='Lisa Brown',
                    contact_email='lisa@dairyfresh.com', contact_phone='(555) 321-0987',
                    default_terms='Net 21', is_active=True)
        ]
        
        for supplier in suppliers:
            db.session.add(supplier)
        
        db.session.commit()
        
        # Add some ingredients
        ingredients = [
            Ingredient(name='Tomatoes', supplier_id=1, unit_cost=3.50, pack_size='25 lbs', sku='TOM-001', category='Produce'),
            Ingredient(name='Lettuce', supplier_id=1, unit_cost=2.25, pack_size='24 heads', sku='LET-001', category='Produce'),
            Ingredient(name='Onions', supplier_id=1, unit_cost=1.75, pack_size='50 lbs', sku='ONI-001', category='Produce'),
            Ingredient(name='Organic Spinach', supplier_id=2, unit_cost=4.50, pack_size='10 lbs', sku='SPI-001', category='Organic'),
            Ingredient(name='Organic Carrots', supplier_id=2, unit_cost=3.25, pack_size='25 lbs', sku='CAR-001', category='Organic'),
            Ingredient(name='Herbs Mix', supplier_id=2, unit_cost=8.75, pack_size='5 lbs', sku='HER-001', category='Organic'),
            Ingredient(name='Ground Beef', supplier_id=3, unit_cost=6.50, pack_size='10 lbs', sku='BEF-001', category='Meat'),
            Ingredient(name='Chicken Breast', supplier_id=3, unit_cost=5.25, pack_size='10 lbs', sku='CHI-001', category='Meat'),
            Ingredient(name='Pork Tenderloin', supplier_id=3, unit_cost=8.75, pack_size='5 lbs', sku='POR-001', category='Meat'),
            Ingredient(name='Whole Milk', supplier_id=4, unit_cost=3.25, pack_size='1 gallon', sku='MIL-001', category='Dairy'),
            Ingredient(name='Cheddar Cheese', supplier_id=4, unit_cost=4.50, pack_size='5 lbs', sku='CHE-001', category='Dairy'),
            Ingredient(name='Greek Yogurt', supplier_id=4, unit_cost=2.75, pack_size='32 oz', sku='YOG-001', category='Dairy')
        ]
        
        for ingredient in ingredients:
            db.session.add(ingredient)
        
        db.session.commit()

@app.route('/api/suppliers')
def get_suppliers():
    suppliers = Supplier.query.filter_by(is_active=True).all()
    return jsonify([supplier.to_dict() for supplier in suppliers])

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    static_folder_path = app.static_folder
    if static_folder_path is None:
        return jsonify({'message': 'Suppliers API is running', 'status': 'ok'})

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            return jsonify({'message': 'Suppliers API is running', 'status': 'ok'})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

