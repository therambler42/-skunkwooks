import React from 'react';
import { AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

function DeleteConfirmDialog({ supplier, onConfirm, onCancel }) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-md" data-testid="delete-confirm-dialog">
        <CardHeader className="pb-4">
          <div className="flex items-center space-x-2">
            <AlertTriangle className="h-6 w-6 text-red-600" />
            <CardTitle className="text-lg">Confirm Deletion</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600 mb-6">
            Are you sure you want to delete the supplier "{supplier.name}"? 
            This action cannot be undone.
          </p>
          <div className="flex flex-col sm:flex-row justify-end space-y-2 sm:space-y-0 sm:space-x-2">
            <Button
              variant="outline"
              onClick={onCancel}
              className="w-full sm:w-auto"
              data-testid="cancel-delete-btn"
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={onConfirm}
              className="w-full sm:w-auto"
              data-testid="confirm-delete-btn"
            >
              Delete
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default DeleteConfirmDialog;

