from flask import Blueprint
from src.routes.suppliers import export_order_guide, bulk_import_suppliers

suppliers_bp = Blueprint('suppliers', __name__)

# Export order guide endpoint
suppliers_bp.add_url_rule('/export-order-guide', 'export_order_guide', export_order_guide, methods=['GET'])

# Bulk import suppliers endpoint
suppliers_bp.add_url_rule('/bulk-import', 'bulk_import_suppliers', bulk_import_suppliers, methods=['POST'])

