describe('Navigation and Responsive Design', () => {
  it('should navigate between pages', () => {
    cy.visit('/')
    
    // Check dashboard
    cy.contains('Welcome to Suppliers Management').should('be.visible')
    
    // Navigate to suppliers
    cy.get('[data-testid="nav-suppliers"]').click()
    cy.url().should('include', '/suppliers')
    cy.get('[data-testid="suppliers-page"]').should('be.visible')
    
    // Navigate back to dashboard
    cy.get('[data-testid="nav-dashboard"]').click()
    cy.url().should('eq', Cypress.config().baseUrl + '/')
    cy.contains('Welcome to Suppliers Management').should('be.visible')
  })

  it('should highlight active navigation item', () => {
    cy.visit('/suppliers')
    
    // Suppliers nav should be active
    cy.get('[data-testid="nav-suppliers"]')
      .should('have.class', 'border-blue-500')
      .should('have.class', 'text-gray-900')
    
    // Dashboard nav should not be active
    cy.get('[data-testid="nav-dashboard"]')
      .should('have.class', 'border-transparent')
      .should('have.class', 'text-gray-500')
  })

  it('should be responsive on mobile', () => {
    cy.viewport('iphone-6')
    cy.visit('/suppliers')
    
    // Page should still be functional on mobile
    cy.get('[data-testid="suppliers-page"]').should('be.visible')
    cy.get('[data-testid="new-supplier-btn"]').should('be.visible')
    
    // Cards should stack properly
    cy.get('[data-testid="supplier-card"]').should('be.visible')
  })

  it('should be responsive on tablet', () => {
    cy.viewport('ipad-2')
    cy.visit('/suppliers')
    
    // Page should be functional on tablet
    cy.get('[data-testid="suppliers-page"]').should('be.visible')
    cy.get('[data-testid="new-supplier-btn"]').should('be.visible')
  })

  it('should handle large screens', () => {
    cy.viewport(1920, 1080)
    cy.visit('/suppliers')
    
    // Page should utilize space efficiently
    cy.get('[data-testid="suppliers-page"]').should('be.visible')
    cy.get('[data-testid="new-supplier-btn"]').should('be.visible')
  })

  it('should show loading states', () => {
    cy.visit('/suppliers')
    
    // Initially might show loading
    cy.get('body').should('be.visible')
    
    // Eventually should show content
    cy.get('[data-testid="suppliers-page"]', { timeout: 10000 }).should('be.visible')
  })

  it('should handle empty states', () => {
    cy.visit('/suppliers')
    cy.get('[data-testid="suppliers-page"]', { timeout: 10000 }).should('be.visible')
    
    // If no suppliers, should show empty state message
    cy.get('body').then(($body) => {
      if ($body.find('[data-testid="supplier-card"]').length === 0) {
        cy.contains('No suppliers found').should('be.visible')
      }
    })
  })
})

