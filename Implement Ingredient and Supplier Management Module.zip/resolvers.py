from ariadne import QueryType, MutationType
from src.models.ingredient import (
    db, Ingredient, Supplier, Category, 
    NutritionFacts, IngredientSupplier, CostHistory,
    RFQ, RFQItem, RFQResponse
)
from datetime import datetime, timedelta

query = QueryType()
mutation = MutationType()

# Query resolvers
@query.field("ingredients")
def resolve_ingredients(_, info):
    ingredients = db.session.query(Ingredient).all()
    return [ingredient.to_dict() for ingredient in ingredients]

@query.field("ingredient")
def resolve_ingredient(_, info, id):
    ingredient = db.session.query(Ingredient).filter(Ingredient.id == id).first()
    return ingredient.to_dict() if ingredient else None

@query.field("ingredientsByCategory")
def resolve_ingredients_by_category(_, info, categoryId):
    ingredients = db.session.query(Ingredient).filter(Ingredient.category_id == categoryId).all()
    return [ingredient.to_dict() for ingredient in ingredients]

@query.field("suppliers")
def resolve_suppliers(_, info):
    suppliers = db.session.query(Supplier).all()
    return [supplier.to_dict() for supplier in suppliers]

@query.field("supplier")
def resolve_supplier(_, info, id):
    supplier = db.session.query(Supplier).filter(Supplier.id == id).first()
    return supplier.to_dict() if supplier else None

@query.field("categories")
def resolve_categories(_, info):
    categories = db.session.query(Category).all()
    return [category.to_dict() for category in categories]

@query.field("category")
def resolve_category(_, info, id):
    category = db.session.query(Category).filter(Category.id == id).first()
    return category.to_dict() if category else None

@query.field("rootCategories")
def resolve_root_categories(_, info):
    categories = db.session.query(Category).filter(Category.parent_id.is_(None)).all()
    return [category.to_dict() for category in categories]

@query.field("costHistory")
def resolve_cost_history(_, info, ingredientId=None):
    query_obj = db.session.query(CostHistory)
    if ingredientId:
        query_obj = query_obj.filter(CostHistory.ingredient_id == ingredientId)
    cost_history = query_obj.order_by(CostHistory.effective_date.desc()).all()
    return [ch.to_dict() for ch in cost_history]

@query.field("costTrends")
def resolve_cost_trends(_, info, ingredientId=None, months=12):
    end_date = datetime.now()
    start_date = end_date - timedelta(days=months * 30)
    
    query_obj = db.session.query(CostHistory).filter(
        CostHistory.effective_date >= start_date,
        CostHistory.effective_date <= end_date
    )
    
    if ingredientId:
        query_obj = query_obj.filter(CostHistory.ingredient_id == ingredientId)
    
    cost_history = query_obj.order_by(CostHistory.effective_date.asc()).all()
    return [ch.to_dict() for ch in cost_history]

@query.field("rfqs")
def resolve_rfqs(_, info):
    rfqs = db.session.query(RFQ).all()
    return [rfq.to_dict() for rfq in rfqs]

@query.field("rfq")
def resolve_rfq(_, info, id):
    rfq = db.session.query(RFQ).filter(RFQ.id == id).first()
    return rfq.to_dict() if rfq else None

# Mutation resolvers
@mutation.field("createIngredient")
def resolve_create_ingredient(_, info, input):
    try:
        ingredient = Ingredient(
            name=input['name'],
            description=input.get('description'),
            category_id=input.get('categoryId'),
            unit_of_measure=input['unitOfMeasure'],
            cost_per_unit=input.get('costPerUnit'),
            yield_percentage=input.get('yieldPercentage', 100.0),
            usda_food_id=input.get('usdaFoodId')
        )
        
        db.session.add(ingredient)
        db.session.commit()
        
        return ingredient.to_dict()
    except Exception as e:
        db.session.rollback()
        raise Exception(f"Failed to create ingredient: {str(e)}")

@mutation.field("updateIngredient")
def resolve_update_ingredient(_, info, id, input):
    try:
        ingredient = db.session.query(Ingredient).filter(Ingredient.id == id).first()
        if not ingredient:
            raise Exception("Ingredient not found")
        
        for key, value in input.items():
            if hasattr(ingredient, key):
                setattr(ingredient, key, value)
        
        ingredient.updated_at = datetime.utcnow()
        db.session.commit()
        
        return ingredient.to_dict()
    except Exception as e:
        db.session.rollback()
        raise Exception(f"Failed to update ingredient: {str(e)}")

@mutation.field("deleteIngredient")
def resolve_delete_ingredient(_, info, id):
    try:
        ingredient = db.session.query(Ingredient).filter(Ingredient.id == id).first()
        if not ingredient:
            return False
        
        db.session.delete(ingredient)
        db.session.commit()
        
        return True
    except Exception as e:
        db.session.rollback()
        raise Exception(f"Failed to delete ingredient: {str(e)}")

@mutation.field("createSupplier")
def resolve_create_supplier(_, info, input):
    try:
        supplier = Supplier(
            name=input['name'],
            contact_name=input.get('contactName'),
            email=input.get('email'),
            phone=input.get('phone'),
            address=input.get('address'),
            sku_prefix=input.get('skuPrefix')
        )
        
        db.session.add(supplier)
        db.session.commit()
        
        return supplier.to_dict()
    except Exception as e:
        db.session.rollback()
        raise Exception(f"Failed to create supplier: {str(e)}")

@mutation.field("updateSupplier")
def resolve_update_supplier(_, info, id, input):
    try:
        supplier = db.session.query(Supplier).filter(Supplier.id == id).first()
        if not supplier:
            raise Exception("Supplier not found")
        
        for key, value in input.items():
            if hasattr(supplier, key):
                setattr(supplier, key, value)
        
        supplier.updated_at = datetime.utcnow()
        db.session.commit()
        
        return supplier.to_dict()
    except Exception as e:
        db.session.rollback()
        raise Exception(f"Failed to update supplier: {str(e)}")

@mutation.field("deleteSupplier")
def resolve_delete_supplier(_, info, id):
    try:
        supplier = db.session.query(Supplier).filter(Supplier.id == id).first()
        if not supplier:
            return False
        
        db.session.delete(supplier)
        db.session.commit()
        
        return True
    except Exception as e:
        db.session.rollback()
        raise Exception(f"Failed to delete supplier: {str(e)}")

@mutation.field("createCategory")
def resolve_create_category(_, info, input):
    try:
        category = Category(
            name=input['name'],
            parent_id=input.get('parentId'),
            description=input.get('description')
        )
        
        db.session.add(category)
        db.session.commit()
        
        return category.to_dict()
    except Exception as e:
        db.session.rollback()
        raise Exception(f"Failed to create category: {str(e)}")

@mutation.field("createNutritionFacts")
def resolve_create_nutrition_facts(_, info, input):
    try:
        nutrition_facts = NutritionFacts(
            ingredient_id=input['ingredientId'],
            calories=input.get('calories'),
            protein_g=input.get('proteinG'),
            carbs_g=input.get('carbsG'),
            fat_g=input.get('fatG'),
            fiber_g=input.get('fiberG'),
            sugar_g=input.get('sugarG'),
            sodium_mg=input.get('sodiumMg'),
            serving_size=input.get('servingSize'),
            usda_source=input.get('usdaSource', False)
        )
        
        db.session.add(nutrition_facts)
        db.session.commit()
        
        return nutrition_facts.to_dict()
    except Exception as e:
        db.session.rollback()
        raise Exception(f"Failed to create nutrition facts: {str(e)}")

