import React, { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Separator } from '@/components/ui/separator'
import { Settings, Database, Zap, Mail, Download, Shield, Bell } from 'lucide-react'
import { toast } from 'sonner'

const SettingsPage = () => {
  const [usdaApiKey, setUsdaApiKey] = useState('')
  const [emailNotifications, setEmailNotifications] = useState(true)
  const [autoBackup, setAutoBackup] = useState(false)
  const [costAlerts, setCostAlerts] = useState(true)

  const handleSaveSettings = () => {
    toast.success('Settings saved successfully')
  }

  const handleTestUSDAConnection = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/usda/test-connection')
      if (response.ok) {
        const data = await response.json()
        if (data.success) {
          toast.success(`USDA API connection working (${data.api_key_type})`)
        } else {
          toast.error(data.error || 'Failed to connect to USDA API')
        }
      }
    } catch (error) {
      toast.error('Failed to test USDA API connection')
    }
  }

  const handleSeedCategories = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/seed-categories', {
        method: 'POST'
      })
      if (response.ok) {
        const data = await response.json()
        toast.success(data.message)
      }
    } catch (error) {
      toast.error('Failed to seed categories')
    }
  }

  const handleExportData = () => {
    toast.success('Data export will be available for download shortly')
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Settings</h2>
          <p className="text-muted-foreground">
            Configure your platform settings and integrations
          </p>
        </div>
      </div>

      {/* API Configuration */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Zap className="h-5 w-5" />
            <span>USDA API Integration</span>
          </CardTitle>
          <CardDescription>
            Configure USDA FoodData Central API for nutrition data auto-fill
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="usda-api-key" className="text-right">
              API Key
            </Label>
            <Input
              id="usda-api-key"
              type="password"
              value={usdaApiKey}
              onChange={(e) => setUsdaApiKey(e.target.value)}
              className="col-span-2"
              placeholder="Enter your USDA API key"
            />
            <Button variant="outline" onClick={handleTestUSDAConnection}>
              Test Connection
            </Button>
          </div>
          <div className="text-sm text-muted-foreground">
            <p>
              Get your free API key from{' '}
              <a 
                href="https://fdc.nal.usda.gov/api-key-signup" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-blue-600 hover:underline"
              >
                USDA FoodData Central
              </a>
            </p>
            <p className="mt-1">
              Current status: <Badge variant="secondary">Using DEMO_KEY (limited rate)</Badge>
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Database Management */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Database className="h-5 w-5" />
            <span>Database Management</span>
          </CardTitle>
          <CardDescription>
            Manage your database and initial data setup
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium">Seed Categories</h4>
              <p className="text-sm text-muted-foreground">
                Initialize the database with default ingredient categories
              </p>
            </div>
            <Button variant="outline" onClick={handleSeedCategories}>
              Seed Categories
            </Button>
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium">Export Data</h4>
              <p className="text-sm text-muted-foreground">
                Export all ingredients and suppliers to CSV format
              </p>
            </div>
            <Button variant="outline" onClick={handleExportData}>
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium">Auto Backup</h4>
              <p className="text-sm text-muted-foreground">
                Automatically backup data daily
              </p>
            </div>
            <Switch
              checked={autoBackup}
              onCheckedChange={setAutoBackup}
            />
          </div>
        </CardContent>
      </Card>

      {/* Notifications */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Bell className="h-5 w-5" />
            <span>Notifications</span>
          </CardTitle>
          <CardDescription>
            Configure email notifications and alerts
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium">Email Notifications</h4>
              <p className="text-sm text-muted-foreground">
                Receive email updates for important events
              </p>
            </div>
            <Switch
              checked={emailNotifications}
              onCheckedChange={setEmailNotifications}
            />
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium">Cost Alerts</h4>
              <p className="text-sm text-muted-foreground">
                Get notified when ingredient costs change significantly
              </p>
            </div>
            <Switch
              checked={costAlerts}
              onCheckedChange={setCostAlerts}
            />
          </div>
        </CardContent>
      </Card>

      {/* System Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Shield className="h-5 w-5" />
            <span>System Information</span>
          </CardTitle>
          <CardDescription>
            Platform version and system status
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="font-medium">Platform Version</h4>
              <p className="text-sm text-muted-foreground">v1.0.0</p>
            </div>
            <div>
              <h4 className="font-medium">Database Status</h4>
              <Badge variant="secondary">Connected</Badge>
            </div>
            <div>
              <h4 className="font-medium">USDA API Status</h4>
              <Badge variant="outline">Demo Mode</Badge>
            </div>
            <div>
              <h4 className="font-medium">Last Backup</h4>
              <p className="text-sm text-muted-foreground">Never</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button onClick={handleSaveSettings}>
          Save Settings
        </Button>
      </div>
    </div>
  )
}

export default SettingsPage

