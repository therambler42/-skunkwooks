from flask import Blueprint, request, jsonify
from ariadne import graphql_sync, make_executable_schema, load_schema_from_path
from ariadne.explorer import ExplorerPlayground
from src.models.ingredient import db, Category
import os

# Load GraphQL schema from file
type_defs = """
    type Query {
        ingredients: [Ingredient!]!
        ingredient(id: Int!): Ingredient
        ingredientsByCategory(categoryId: Int!): [Ingredient!]!
        suppliers: [Supplier!]!
        supplier(id: Int!): Supplier
        categories: [Category!]!
        category(id: Int!): Category
        rootCategories: [Category!]!
        costHistory(ingredientId: Int): [CostHistory!]!
        costTrends(ingredientId: Int, months: Int): [CostHistory!]!
        rfqs: [RFQ!]!
        rfq(id: Int!): RFQ
    }

    type Mutation {
        createIngredient(input: IngredientInput!): Ingredient!
        updateIngredient(id: Int!, input: IngredientInput!): Ingredient!
        deleteIngredient(id: Int!): Boolean!
        createSupplier(input: SupplierInput!): Supplier!
        updateSupplier(id: Int!, input: SupplierInput!): Supplier!
        deleteSupplier(id: Int!): Boolean!
        createCategory(input: CategoryInput!): Category!
        createNutritionFacts(input: NutritionFactsInput!): NutritionFacts!
    }

    type Ingredient {
        id: Int!
        name: String!
        description: String
        categoryId: Int
        category: Category
        unitOfMeasure: String!
        costPerUnit: Float
        yieldPercentage: Float
        usdaFoodId: String
        nutritionFacts: NutritionFacts
        suppliers: [IngredientSupplier!]!
        costHistory: [CostHistory!]!
        createdAt: String!
        updatedAt: String!
    }

    type Supplier {
        id: Int!
        name: String!
        contactName: String
        email: String
        phone: String
        address: String
        skuPrefix: String
        ingredients: [IngredientSupplier!]!
        createdAt: String!
        updatedAt: String!
    }

    type Category {
        id: Int!
        name: String!
        parentId: Int
        parent: Category
        children: [Category!]!
        description: String
        ingredients: [Ingredient!]!
        createdAt: String!
    }

    type NutritionFacts {
        id: Int!
        ingredientId: Int!
        calories: Float
        proteinG: Float
        carbsG: Float
        fatG: Float
        fiberG: Float
        sugarG: Float
        sodiumMg: Float
        servingSize: String
        usdaSource: Boolean!
        createdAt: String!
    }

    type IngredientSupplier {
        id: Int!
        ingredientId: Int!
        supplierId: Int!
        ingredient: Ingredient!
        supplier: Supplier!
        supplierSku: String
        costPerUnit: Float
        minimumOrderQuantity: Int
        leadTimeDays: Int
        isPreferred: Boolean!
        createdAt: String!
    }

    type CostHistory {
        id: Int!
        ingredientId: Int!
        supplierId: Int
        ingredient: Ingredient!
        supplier: Supplier
        costPerUnit: Float!
        effectiveDate: String!
        source: String
        notes: String
        createdAt: String!
    }

    type RFQ {
        id: Int!
        title: String!
        description: String
        status: String!
        createdBy: String
        dueDate: String
        rfqItems: [RFQItem!]!
        createdAt: String!
        updatedAt: String!
    }

    type RFQItem {
        id: Int!
        rfqId: Int!
        ingredientId: Int!
        rfq: RFQ!
        ingredient: Ingredient!
        quantity: Float
        currentCost: Float
        notes: String
        rfqResponses: [RFQResponse!]!
        createdAt: String!
    }

    type RFQResponse {
        id: Int!
        rfqId: Int!
        supplierId: Int!
        rfqItemId: Int!
        supplier: Supplier!
        rfqItem: RFQItem!
        quotedPrice: Float
        leadTimeDays: Int
        minimumQuantity: Int
        notes: String
        submittedAt: String!
    }

    input IngredientInput {
        name: String!
        description: String
        categoryId: Int
        unitOfMeasure: String!
        costPerUnit: Float
        yieldPercentage: Float
        usdaFoodId: String
    }

    input SupplierInput {
        name: String!
        contactName: String
        email: String
        phone: String
        address: String
        skuPrefix: String
    }

    input CategoryInput {
        name: String!
        parentId: Int
        description: String
    }

    input NutritionFactsInput {
        ingredientId: Int!
        calories: Float
        proteinG: Float
        carbsG: Float
        fatG: Float
        fiberG: Float
        sugarG: Float
        sodiumMg: Float
        servingSize: String
        usdaSource: Boolean
    }
"""

# Import resolvers
from src.resolvers import query, mutation

# Create executable schema
schema = make_executable_schema(type_defs, query, mutation)

graphql_bp = Blueprint('graphql', __name__)

# GraphQL endpoint
@graphql_bp.route('/graphql', methods=['GET', 'POST'])
def graphql_server():
    if request.method == 'GET':
        # Return GraphQL Explorer for development
        return ExplorerPlayground().html(None), 200
    
    data = request.get_json()
    success, result = graphql_sync(schema, data, context_value=request, debug=True)
    status_code = 200 if success else 400
    return jsonify(result), status_code

@graphql_bp.route('/seed-categories', methods=['POST'])
def seed_categories():
    """Seed the database with default categories"""
    try:
        # Check if categories already exist
        if db.session.query(Category).count() > 0:
            return jsonify({'message': 'Categories already exist'}), 200
        
        # Default categories structure
        categories_data = [
            {'name': 'API', 'description': 'Active Pharmaceutical Ingredients'},
            {'name': 'Beverages', 'description': 'All beverage ingredients'},
            {'name': 'Dairy', 'description': 'Dairy products and ingredients'},
            {'name': 'Grains & Cereals', 'description': 'Grain-based ingredients'},
            {'name': 'Proteins', 'description': 'Protein sources'},
            {'name': 'Produce', 'description': 'Fresh produce ingredients'},
            {'name': 'Spices & Seasonings', 'description': 'Spices and seasoning ingredients'},
            {'name': 'Oils & Fats', 'description': 'Oil and fat ingredients'},
            {'name': 'Sweeteners', 'description': 'Natural and artificial sweeteners'},
            {'name': 'Additives & Preservatives', 'description': 'Food additives and preservatives'}
        ]
        
        # Create parent categories
        parent_categories = {}
        for cat_data in categories_data:
            category = Category(
                name=cat_data['name'],
                description=cat_data['description']
            )
            db.session.add(category)
            db.session.flush()  # Get the ID
            parent_categories[cat_data['name']] = category.id
        
        # Create subcategories
        subcategories_data = [
            {'name': 'Alcoholic', 'parent': 'Beverages'},
            {'name': 'Non-Alcoholic', 'parent': 'Beverages'},
            {'name': 'Milk Products', 'parent': 'Dairy'},
            {'name': 'Cheese', 'parent': 'Dairy'},
            {'name': 'Yogurt', 'parent': 'Dairy'},
            {'name': 'Meat', 'parent': 'Proteins'},
            {'name': 'Seafood', 'parent': 'Proteins'},
            {'name': 'Plant-Based', 'parent': 'Proteins'},
            {'name': 'Fruits', 'parent': 'Produce'},
            {'name': 'Vegetables', 'parent': 'Produce'}
        ]
        
        for subcat_data in subcategories_data:
            subcategory = Category(
                name=subcat_data['name'],
                parent_id=parent_categories[subcat_data['parent']]
            )
            db.session.add(subcategory)
        
        db.session.commit()
        return jsonify({'message': 'Categories seeded successfully'}), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

