import requests
import json
from typing import Dict, List, Optional, Any
from dataclasses import dataclass

@dataclass
class USDANutrient:
    """Represents a nutrient from USDA data"""
    nutrient_id: int
    nutrient_name: str
    unit_name: str
    value: float

@dataclass
class USDAFoodItem:
    """Represents a food item from USDA FoodData Central"""
    fdc_id: int
    description: str
    data_type: str
    nutrients: List[USDANutrient]
    brand_owner: Optional[str] = None
    brand_name: Optional[str] = None
    ingredients: Optional[str] = None

class USDAClient:
    """Client for interacting with USDA FoodData Central API"""
    
    BASE_URL = "https://api.nal.usda.gov/fdc/v1"
    
    def __init__(self, api_key: str = "DEMO_KEY"):
        """
        Initialize USDA client
        
        Args:
            api_key: USDA API key. Defaults to DEMO_KEY for testing.
        """
        self.api_key = api_key
        self.session = requests.Session()
    
    def search_foods(self, query: str, data_type: Optional[List[str]] = None, 
                    page_size: int = 25, page_number: int = 1) -> List[USDAFoodItem]:
        """
        Search for foods by query string
        
        Args:
            query: Search query (e.g., "cheddar cheese")
            data_type: List of data types to include (e.g., ["Branded", "Foundation"])
            page_size: Number of results per page (max 200)
            page_number: Page number to retrieve
            
        Returns:
            List of USDAFoodItem objects
        """
        url = f"{self.BASE_URL}/foods/search"
        
        payload = {
            "query": query,
            "pageSize": page_size,
            "pageNumber": page_number
        }
        
        if data_type:
            payload["dataType"] = data_type
        
        params = {"api_key": self.api_key}
        
        try:
            response = self.session.post(url, json=payload, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            foods = []
            
            for food_data in data.get("foods", []):
                nutrients = []
                for nutrient_data in food_data.get("foodNutrients", []):
                    if "value" in nutrient_data and nutrient_data["value"] is not None:
                        nutrient = USDANutrient(
                            nutrient_id=nutrient_data.get("nutrientId"),
                            nutrient_name=nutrient_data.get("nutrientName", ""),
                            unit_name=nutrient_data.get("unitName", ""),
                            value=float(nutrient_data["value"])
                        )
                        nutrients.append(nutrient)
                
                food_item = USDAFoodItem(
                    fdc_id=food_data.get("fdcId"),
                    description=food_data.get("description", ""),
                    data_type=food_data.get("dataType", ""),
                    nutrients=nutrients,
                    brand_owner=food_data.get("brandOwner"),
                    brand_name=food_data.get("brandName"),
                    ingredients=food_data.get("ingredients")
                )
                foods.append(food_item)
            
            return foods
            
        except requests.exceptions.RequestException as e:
            raise Exception(f"USDA API request failed: {str(e)}")
        except (KeyError, ValueError) as e:
            raise Exception(f"Failed to parse USDA API response: {str(e)}")
    
    def get_food_details(self, fdc_id: int, nutrients: Optional[List[int]] = None) -> Optional[USDAFoodItem]:
        """
        Get detailed information for a specific food by FDC ID
        
        Args:
            fdc_id: FoodData Central ID
            nutrients: List of specific nutrient IDs to include
            
        Returns:
            USDAFoodItem object or None if not found
        """
        url = f"{self.BASE_URL}/food/{fdc_id}"
        params = {"api_key": self.api_key}
        
        if nutrients:
            params["nutrients"] = ",".join(map(str, nutrients))
        
        try:
            response = self.session.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            food_data = response.json()
            nutrients_list = []
            
            for nutrient_data in food_data.get("foodNutrients", []):
                if "value" in nutrient_data and nutrient_data["value"] is not None:
                    nutrient = USDANutrient(
                        nutrient_id=nutrient_data.get("nutrientId"),
                        nutrient_name=nutrient_data.get("nutrientName", ""),
                        unit_name=nutrient_data.get("unitName", ""),
                        value=float(nutrient_data["value"])
                    )
                    nutrients_list.append(nutrient)
            
            return USDAFoodItem(
                fdc_id=food_data.get("fdcId"),
                description=food_data.get("description", ""),
                data_type=food_data.get("dataType", ""),
                nutrients=nutrients_list,
                brand_owner=food_data.get("brandOwner"),
                brand_name=food_data.get("brandName"),
                ingredients=food_data.get("ingredients")
            )
            
        except requests.exceptions.RequestException as e:
            if hasattr(e, 'response') and e.response.status_code == 404:
                return None
            raise Exception(f"USDA API request failed: {str(e)}")
        except (KeyError, ValueError) as e:
            raise Exception(f"Failed to parse USDA API response: {str(e)}")

class NutritionParser:
    """Parser for converting USDA nutrition data to our database format"""
    
    # Mapping of USDA nutrient IDs to our database fields
    NUTRIENT_MAPPING = {
        1008: 'calories',      # Energy (kcal)
        1003: 'protein_g',     # Protein
        1005: 'carbs_g',       # Carbohydrate, by difference
        1004: 'fat_g',         # Total lipid (fat)
        1079: 'fiber_g',       # Fiber, total dietary
        2000: 'sugar_g',       # Sugars, total including NLEA
        1093: 'sodium_mg',     # Sodium, Na
    }
    
    @classmethod
    def parse_nutrition_facts(cls, usda_food: USDAFoodItem) -> Dict[str, Any]:
        """
        Parse USDA food item into nutrition facts for our database
        
        Args:
            usda_food: USDAFoodItem object
            
        Returns:
            Dictionary with nutrition facts data
        """
        nutrition_data = {
            'calories': None,
            'protein_g': None,
            'carbs_g': None,
            'fat_g': None,
            'fiber_g': None,
            'sugar_g': None,
            'sodium_mg': None,
            'serving_size': '100g',  # USDA data is typically per 100g
            'usda_source': True
        }
        
        for nutrient in usda_food.nutrients:
            if nutrient.nutrient_id in cls.NUTRIENT_MAPPING:
                field_name = cls.NUTRIENT_MAPPING[nutrient.nutrient_id]
                nutrition_data[field_name] = nutrient.value
        
        return nutrition_data
    
    @classmethod
    def calculate_match_score(cls, ingredient_name: str, usda_food: USDAFoodItem) -> float:
        """
        Calculate how well a USDA food item matches an ingredient name
        
        Args:
            ingredient_name: Name of the ingredient to match
            usda_food: USDA food item to compare against
            
        Returns:
            Match score between 0.0 and 1.0
        """
        ingredient_words = set(ingredient_name.lower().split())
        description_words = set(usda_food.description.lower().split())
        
        # Calculate Jaccard similarity
        intersection = ingredient_words.intersection(description_words)
        union = ingredient_words.union(description_words)
        
        if not union:
            return 0.0
        
        base_score = len(intersection) / len(union)
        
        # Boost score for exact matches
        if ingredient_name.lower() in usda_food.description.lower():
            base_score += 0.3
        
        # Boost score for Foundation Foods (more reliable)
        if usda_food.data_type == "Foundation":
            base_score += 0.1
        
        return min(base_score, 1.0)

def find_best_nutrition_match(ingredient_name: str, api_key: str = "DEMO_KEY") -> Optional[Dict[str, Any]]:
    """
    Find the best USDA nutrition match for an ingredient
    
    Args:
        ingredient_name: Name of the ingredient to search for
        api_key: USDA API key
        
    Returns:
        Dictionary with nutrition facts or None if no good match found
    """
    client = USDAClient(api_key)
    parser = NutritionParser()
    
    try:
        # Search for foods matching the ingredient name
        foods = client.search_foods(
            query=ingredient_name,
            data_type=["Foundation", "SR Legacy"],  # Prefer more reliable data sources
            page_size=10
        )
        
        if not foods:
            return None
        
        # Find the best match
        best_match = None
        best_score = 0.0
        
        for food in foods:
            score = parser.calculate_match_score(ingredient_name, food)
            if score > best_score and score >= 0.5:  # Minimum 50% match required
                best_match = food
                best_score = score
        
        if best_match:
            nutrition_data = parser.parse_nutrition_facts(best_match)
            nutrition_data['usda_food_id'] = str(best_match.fdc_id)
            nutrition_data['match_score'] = best_score
            return nutrition_data
        
        return None
        
    except Exception as e:
        print(f"Error finding nutrition match for '{ingredient_name}': {str(e)}")
        return None

