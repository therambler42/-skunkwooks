# Ingredient & Supplier Management Platform

## Data Model Design

### Core Entities

#### Ingredient
```sql
CREATE TABLE ingredients (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    category_id INTEGER REFERENCES categories(id),
    unit_of_measure VARCHAR(50) NOT NULL,
    cost_per_unit DECIMAL(10,4),
    yield_percentage DECIMAL(5,2) DEFAULT 100.00,
    usda_food_id VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### Supplier
```sql
CREATE TABLE suppliers (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    contact_name VARCHAR(255),
    email VARCHAR(255),
    phone VARCHAR(50),
    address TEXT,
    sku_prefix VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### Category
```sql
CREATE TABLE categories (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    parent_id INTEGER REFERENCES categories(id),
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### Nutrition Facts
```sql
CREATE TABLE nutrition_facts (
    id SERIAL PRIMARY KEY,
    ingredient_id INTEGER REFERENCES ingredients(id),
    calories DECIMAL(8,2),
    protein_g DECIMAL(8,2),
    carbs_g DECIMAL(8,2),
    fat_g DECIMAL(8,2),
    fiber_g DECIMAL(8,2),
    sugar_g DECIMAL(8,2),
    sodium_mg DECIMAL(8,2),
    serving_size VARCHAR(100),
    usda_source BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### Ingredient Supplier
```sql
CREATE TABLE ingredient_suppliers (
    id SERIAL PRIMARY KEY,
    ingredient_id INTEGER REFERENCES ingredients(id),
    supplier_id INTEGER REFERENCES suppliers(id),
    supplier_sku VARCHAR(100),
    cost_per_unit DECIMAL(10,4),
    minimum_order_quantity INTEGER,
    lead_time_days INTEGER,
    is_preferred BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(ingredient_id, supplier_id)
);
```

#### Cost History
```sql
CREATE TABLE cost_history (
    id SERIAL PRIMARY KEY,
    ingredient_id INTEGER REFERENCES ingredients(id),
    supplier_id INTEGER REFERENCES suppliers(id),
    cost_per_unit DECIMAL(10,4) NOT NULL,
    effective_date DATE NOT NULL,
    source VARCHAR(50), -- 'manual', 'rfq', 'import'
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### RFQ (Request for Quote)
```sql
CREATE TABLE rfqs (
    id SERIAL PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    status VARCHAR(50) DEFAULT 'draft', -- 'draft', 'sent', 'responded', 'closed'
    created_by VARCHAR(255),
    due_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### RFQ Items
```sql
CREATE TABLE rfq_items (
    id SERIAL PRIMARY KEY,
    rfq_id INTEGER REFERENCES rfqs(id),
    ingredient_id INTEGER REFERENCES ingredients(id),
    quantity DECIMAL(10,2),
    current_cost DECIMAL(10,4),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### RFQ Responses
```sql
CREATE TABLE rfq_responses (
    id SERIAL PRIMARY KEY,
    rfq_id INTEGER REFERENCES rfqs(id),
    supplier_id INTEGER REFERENCES suppliers(id),
    rfq_item_id INTEGER REFERENCES rfq_items(id),
    quoted_price DECIMAL(10,4),
    lead_time_days INTEGER,
    minimum_quantity INTEGER,
    notes TEXT,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Relationships

1. **Ingredient ↔ Category**: Many-to-One (ingredients belong to categories)
2. **Ingredient ↔ Supplier**: Many-to-Many (through ingredient_suppliers)
3. **Ingredient ↔ Nutrition**: One-to-One (each ingredient has nutrition facts)
4. **Ingredient ↔ Cost History**: One-to-Many (track cost changes over time)
5. **Category ↔ Category**: Self-referencing (hierarchical categories)
6. **RFQ ↔ RFQ Items**: One-to-Many (RFQ contains multiple items)
7. **RFQ Items ↔ RFQ Responses**: One-to-Many (multiple supplier responses per item)

### Default Categories

```
- API (Active Pharmaceutical Ingredients)
- Beverages
  - Alcoholic
  - Non-Alcoholic
- Dairy
  - Milk Products
  - Cheese
  - Yogurt
- Grains & Cereals
- Proteins
  - Meat
  - Seafood
  - Plant-Based
- Produce
  - Fruits
  - Vegetables
- Spices & Seasonings
- Oils & Fats
- Sweeteners
- Additives & Preservatives
```

### API Integration Points

#### USDA FoodData Central API
- **Endpoint**: `https://api.nal.usda.gov/fdc/v1/foods/search`
- **Purpose**: Auto-populate nutrition facts for ingredients
- **Data Mapping**:
  - `description` → `ingredient.name`
  - `foodNutrients` → `nutrition_facts` table
  - `fdcId` → `ingredient.usda_food_id`

#### GraphQL Schema Structure

```graphql
type Ingredient {
  id: ID!
  name: String!
  description: String
  category: Category
  unitOfMeasure: String!
  costPerUnit: Float
  yieldPercentage: Float
  usdaFoodId: String
  nutritionFacts: NutritionFacts
  suppliers: [IngredientSupplier!]!
  costHistory: [CostHistory!]!
  createdAt: DateTime!
  updatedAt: DateTime!
}

type Supplier {
  id: ID!
  name: String!
  contactName: String
  email: String
  phone: String
  address: String
  skuPrefix: String
  ingredients: [IngredientSupplier!]!
  createdAt: DateTime!
  updatedAt: DateTime!
}

type Category {
  id: ID!
  name: String!
  parent: Category
  children: [Category!]!
  description: String
  ingredients: [Ingredient!]!
}
```

This data model provides a solid foundation for the ingredient and supplier management system with proper relationships, cost tracking, and integration capabilities.

