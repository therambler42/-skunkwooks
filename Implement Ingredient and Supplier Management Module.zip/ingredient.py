from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from decimal import Decimal

db = SQLAlchemy()

class Category(db.Model):
    __tablename__ = 'categories'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    parent_id = db.Column(db.Integer, db.ForeignKey('categories.id'), nullable=True)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    parent = db.relationship('Category', remote_side=[id], backref='children')
    ingredients = db.relationship('Ingredient', backref='category', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'parent_id': self.parent_id,
            'description': self.description,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class Supplier(db.Model):
    __tablename__ = 'suppliers'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    contact_name = db.Column(db.String(255))
    email = db.Column(db.String(255))
    phone = db.Column(db.String(50))
    address = db.Column(db.Text)
    sku_prefix = db.Column(db.String(20))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    ingredient_suppliers = db.relationship('IngredientSupplier', backref='supplier', lazy=True)
    rfq_responses = db.relationship('RFQResponse', backref='supplier', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'contact_name': self.contact_name,
            'email': self.email,
            'phone': self.phone,
            'address': self.address,
            'sku_prefix': self.sku_prefix,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class Ingredient(db.Model):
    __tablename__ = 'ingredients'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text)
    category_id = db.Column(db.Integer, db.ForeignKey('categories.id'), nullable=True)
    unit_of_measure = db.Column(db.String(50), nullable=False)
    cost_per_unit = db.Column(db.Numeric(10, 4))
    yield_percentage = db.Column(db.Numeric(5, 2), default=100.00)
    usda_food_id = db.Column(db.String(50))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    nutrition_facts = db.relationship('NutritionFacts', backref='ingredient', uselist=False)
    ingredient_suppliers = db.relationship('IngredientSupplier', backref='ingredient', lazy=True)
    cost_history = db.relationship('CostHistory', backref='ingredient', lazy=True)
    rfq_items = db.relationship('RFQItem', backref='ingredient', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'category_id': self.category_id,
            'unit_of_measure': self.unit_of_measure,
            'cost_per_unit': float(self.cost_per_unit) if self.cost_per_unit else None,
            'yield_percentage': float(self.yield_percentage) if self.yield_percentage else None,
            'usda_food_id': self.usda_food_id,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class NutritionFacts(db.Model):
    __tablename__ = 'nutrition_facts'
    
    id = db.Column(db.Integer, primary_key=True)
    ingredient_id = db.Column(db.Integer, db.ForeignKey('ingredients.id'), nullable=False)
    calories = db.Column(db.Numeric(8, 2))
    protein_g = db.Column(db.Numeric(8, 2))
    carbs_g = db.Column(db.Numeric(8, 2))
    fat_g = db.Column(db.Numeric(8, 2))
    fiber_g = db.Column(db.Numeric(8, 2))
    sugar_g = db.Column(db.Numeric(8, 2))
    sodium_mg = db.Column(db.Numeric(8, 2))
    serving_size = db.Column(db.String(100))
    usda_source = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'ingredient_id': self.ingredient_id,
            'calories': float(self.calories) if self.calories else None,
            'protein_g': float(self.protein_g) if self.protein_g else None,
            'carbs_g': float(self.carbs_g) if self.carbs_g else None,
            'fat_g': float(self.fat_g) if self.fat_g else None,
            'fiber_g': float(self.fiber_g) if self.fiber_g else None,
            'sugar_g': float(self.sugar_g) if self.sugar_g else None,
            'sodium_mg': float(self.sodium_mg) if self.sodium_mg else None,
            'serving_size': self.serving_size,
            'usda_source': self.usda_source,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class IngredientSupplier(db.Model):
    __tablename__ = 'ingredient_suppliers'
    
    id = db.Column(db.Integer, primary_key=True)
    ingredient_id = db.Column(db.Integer, db.ForeignKey('ingredients.id'), nullable=False)
    supplier_id = db.Column(db.Integer, db.ForeignKey('suppliers.id'), nullable=False)
    supplier_sku = db.Column(db.String(100))
    cost_per_unit = db.Column(db.Numeric(10, 4))
    minimum_order_quantity = db.Column(db.Integer)
    lead_time_days = db.Column(db.Integer)
    is_preferred = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    __table_args__ = (db.UniqueConstraint('ingredient_id', 'supplier_id'),)
    
    def to_dict(self):
        return {
            'id': self.id,
            'ingredient_id': self.ingredient_id,
            'supplier_id': self.supplier_id,
            'supplier_sku': self.supplier_sku,
            'cost_per_unit': float(self.cost_per_unit) if self.cost_per_unit else None,
            'minimum_order_quantity': self.minimum_order_quantity,
            'lead_time_days': self.lead_time_days,
            'is_preferred': self.is_preferred,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class CostHistory(db.Model):
    __tablename__ = 'cost_history'
    
    id = db.Column(db.Integer, primary_key=True)
    ingredient_id = db.Column(db.Integer, db.ForeignKey('ingredients.id'), nullable=False)
    supplier_id = db.Column(db.Integer, db.ForeignKey('suppliers.id'), nullable=True)
    cost_per_unit = db.Column(db.Numeric(10, 4), nullable=False)
    effective_date = db.Column(db.Date, nullable=False)
    source = db.Column(db.String(50))  # 'manual', 'rfq', 'import'
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'ingredient_id': self.ingredient_id,
            'supplier_id': self.supplier_id,
            'cost_per_unit': float(self.cost_per_unit),
            'effective_date': self.effective_date.isoformat() if self.effective_date else None,
            'source': self.source,
            'notes': self.notes,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class RFQ(db.Model):
    __tablename__ = 'rfqs'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text)
    status = db.Column(db.String(50), default='draft')  # 'draft', 'sent', 'responded', 'closed'
    created_by = db.Column(db.String(255))
    due_date = db.Column(db.Date)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    rfq_items = db.relationship('RFQItem', backref='rfq', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'status': self.status,
            'created_by': self.created_by,
            'due_date': self.due_date.isoformat() if self.due_date else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class RFQItem(db.Model):
    __tablename__ = 'rfq_items'
    
    id = db.Column(db.Integer, primary_key=True)
    rfq_id = db.Column(db.Integer, db.ForeignKey('rfqs.id'), nullable=False)
    ingredient_id = db.Column(db.Integer, db.ForeignKey('ingredients.id'), nullable=False)
    quantity = db.Column(db.Numeric(10, 2))
    current_cost = db.Column(db.Numeric(10, 4))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    rfq_responses = db.relationship('RFQResponse', backref='rfq_item', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'rfq_id': self.rfq_id,
            'ingredient_id': self.ingredient_id,
            'quantity': float(self.quantity) if self.quantity else None,
            'current_cost': float(self.current_cost) if self.current_cost else None,
            'notes': self.notes,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class RFQResponse(db.Model):
    __tablename__ = 'rfq_responses'
    
    id = db.Column(db.Integer, primary_key=True)
    rfq_id = db.Column(db.Integer, db.ForeignKey('rfqs.id'), nullable=False)
    supplier_id = db.Column(db.Integer, db.ForeignKey('suppliers.id'), nullable=False)
    rfq_item_id = db.Column(db.Integer, db.ForeignKey('rfq_items.id'), nullable=False)
    quoted_price = db.Column(db.Numeric(10, 4))
    lead_time_days = db.Column(db.Integer)
    minimum_quantity = db.Column(db.Integer)
    notes = db.Column(db.Text)
    submitted_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'rfq_id': self.rfq_id,
            'supplier_id': self.supplier_id,
            'rfq_item_id': self.rfq_item_id,
            'quoted_price': float(self.quoted_price) if self.quoted_price else None,
            'lead_time_days': self.lead_time_days,
            'minimum_quantity': self.minimum_quantity,
            'notes': self.notes,
            'submitted_at': self.submitted_at.isoformat() if self.submitted_at else None
        }

