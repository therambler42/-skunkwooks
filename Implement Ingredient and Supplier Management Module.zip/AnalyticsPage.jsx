import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { TrendingUp, TrendingDown, DollarSign, Package, Users, BarChart3 } from 'lucide-react'

const AnalyticsPage = () => {
  const [timeRange, setTimeRange] = useState('12')
  const [selectedCategory, setSelectedCategory] = useState('')
  const [selectedSupplier, setSelectedSupplier] = useState('')

  // Mock data for demonstration
  const mockStats = {
    totalIngredients: 156,
    totalSuppliers: 23,
    avgCostTrend: 2.3,
    topCategory: 'Produce'
  }

  const mockCostTrends = [
    { month: 'Jan', cost: 2.45 },
    { month: 'Feb', cost: 2.52 },
    { month: 'Mar', cost: 2.48 },
    { month: 'Apr', cost: 2.61 },
    { month: 'May', cost: 2.58 },
    { month: 'Jun', cost: 2.67 },
    { month: 'Jul', cost: 2.71 },
    { month: 'Aug', cost: 2.69 },
    { month: 'Sep', cost: 2.74 },
    { month: 'Oct', cost: 2.78 },
    { month: 'Nov', cost: 2.82 },
    { month: 'Dec', cost: 2.85 }
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Analytics</h2>
          <p className="text-muted-foreground">
            Cost trends and insights for your ingredient portfolio
          </p>
        </div>
        <div className="flex space-x-2">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-[120px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="3">3 Months</SelectItem>
              <SelectItem value="6">6 Months</SelectItem>
              <SelectItem value="12">12 Months</SelectItem>
              <SelectItem value="24">24 Months</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Ingredients</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockStats.totalIngredients}</div>
            <p className="text-xs text-muted-foreground">
              +12% from last month
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Suppliers</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockStats.totalSuppliers}</div>
            <p className="text-xs text-muted-foreground">
              +2 new this month
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Cost Trend</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">+{mockStats.avgCostTrend}%</div>
            <p className="text-xs text-muted-foreground">
              Over last 12 months
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Top Category</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockStats.topCategory}</div>
            <p className="text-xs text-muted-foreground">
              42% of total ingredients
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex space-x-4">
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="All categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All categories</SelectItem>
                <SelectItem value="produce">Produce</SelectItem>
                <SelectItem value="dairy">Dairy</SelectItem>
                <SelectItem value="proteins">Proteins</SelectItem>
                <SelectItem value="grains">Grains & Cereals</SelectItem>
              </SelectContent>
            </Select>
            <Select value={selectedSupplier} onValueChange={setSelectedSupplier}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="All suppliers" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All suppliers</SelectItem>
                <SelectItem value="supplier1">ABC Food Distributors</SelectItem>
                <SelectItem value="supplier2">Fresh Farm Supply</SelectItem>
                <SelectItem value="supplier3">Global Ingredients Co</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Cost Trend Chart Placeholder */}
      <Card>
        <CardHeader>
          <CardTitle>Cost Trends Over Time</CardTitle>
          <CardDescription>
            Average ingredient costs over the selected time period
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[400px] flex items-center justify-center border-2 border-dashed border-gray-300 rounded-lg">
            <div className="text-center">
              <BarChart3 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-600 mb-2">Chart.js Integration</h3>
              <p className="text-gray-500">
                Interactive cost trend chart will be implemented in Phase 7
              </p>
              <div className="mt-4 text-sm text-gray-400">
                <p>Features coming soon:</p>
                <ul className="list-disc list-inside mt-2 space-y-1">
                  <li>Interactive line charts with Chart.js</li>
                  <li>Filter by category and supplier</li>
                  <li>12-month rolling cost trends</li>
                  <li>Cost variance analysis</li>
                </ul>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Top Ingredients by Cost Variance */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Highest Cost Increases</CardTitle>
            <CardDescription>Ingredients with significant price increases</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { name: 'Organic Tomatoes', increase: '+15.2%', cost: '$3.45/kg' },
                { name: 'Premium Olive Oil', increase: '+12.8%', cost: '$8.90/L' },
                { name: 'Grass-Fed Beef', increase: '+9.4%', cost: '$12.50/kg' },
                { name: 'Organic Quinoa', increase: '+7.1%', cost: '$6.20/kg' }
              ].map((item, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">{item.name}</p>
                    <p className="text-sm text-muted-foreground">{item.cost}</p>
                  </div>
                  <Badge variant="destructive" className="flex items-center">
                    <TrendingUp className="h-3 w-3 mr-1" />
                    {item.increase}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Cost Savings Opportunities</CardTitle>
            <CardDescription>Ingredients with price decreases</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { name: 'Conventional Wheat', decrease: '-8.3%', cost: '$0.85/kg' },
                { name: 'Frozen Vegetables', decrease: '-5.7%', cost: '$2.10/kg' },
                { name: 'Canola Oil', decrease: '-4.2%', cost: '$3.20/L' },
                { name: 'White Rice', decrease: '-3.1%', cost: '$1.45/kg' }
              ].map((item, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">{item.name}</p>
                    <p className="text-sm text-muted-foreground">{item.cost}</p>
                  </div>
                  <Badge variant="secondary" className="flex items-center">
                    <TrendingDown className="h-3 w-3 mr-1" />
                    {item.decrease}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default AnalyticsPage

