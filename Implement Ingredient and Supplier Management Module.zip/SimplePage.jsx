import React from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Package, Users, BarChart3, Settings, Plus, Search } from 'lucide-react'

const SimplePage = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Package className="h-8 w-8 text-blue-600" />
                <h1 className="text-xl font-bold text-gray-900">
                  Ingredient & Supplier Platform
                </h1>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="text-sm">
                v1.0.0
              </Badge>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Navigation Tabs */}
        <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg mb-8">
          <button className="flex items-center space-x-2 px-4 py-2 bg-white rounded-md shadow-sm text-blue-600 font-medium">
            <Package className="h-4 w-4" />
            <span>Ingredients</span>
            <Badge variant="secondary" className="ml-2">0</Badge>
          </button>
          <button className="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:text-gray-900">
            <Users className="h-4 w-4" />
            <span>Suppliers</span>
            <Badge variant="secondary" className="ml-2">0</Badge>
          </button>
          <button className="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:text-gray-900">
            <BarChart3 className="h-4 w-4" />
            <span>Analytics</span>
          </button>
          <button className="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:text-gray-900">
            <Settings className="h-4 w-4" />
            <span>Settings</span>
          </button>
        </div>

        {/* Content */}
        <div className="space-y-6">
          {/* Header */}
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-3xl font-bold tracking-tight">Ingredients</h2>
              <p className="text-gray-600">
                Manage your ingredient inventory with nutrition data and supplier links
              </p>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" size="sm">
                Import CSV
              </Button>
              <Button variant="outline" size="sm">
                Export
              </Button>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Add Ingredient
              </Button>
            </div>
          </div>

          {/* Search */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex space-x-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
                    <input
                      type="text"
                      placeholder="Search ingredients..."
                      className="w-full pl-8 pr-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>
                <select className="px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                  <option>All categories</option>
                  <option>Produce</option>
                  <option>Dairy</option>
                  <option>Proteins</option>
                </select>
              </div>
            </CardContent>
          </Card>

          {/* Ingredients Table */}
          <Card>
            <CardHeader>
              <CardTitle>Ingredients (0)</CardTitle>
              <CardDescription>
                Manage your ingredient database with nutrition information and supplier relationships
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-600 mb-2">No ingredients yet</h3>
                <p className="text-gray-500 mb-4">
                  Start by adding your first ingredient to the database
                </p>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Add First Ingredient
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Features Preview */}
          <div className="grid gap-4 md:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">USDA Integration</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">
                  Auto-fill nutrition data from USDA FoodData Central with 90%+ accuracy
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Supplier Management</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">
                  Generate RFQs and manage supplier relationships with cost tracking
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Cost Analytics</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">
                  Track cost trends over time with interactive charts and insights
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}

export default SimplePage

