import graphene
from graphene import ObjectType, String, Int, Float, Boolean, DateTime, List, Field
from graphene_sqlalchemy import SQLAlchemyObjectType
from src.models.ingredient import (
    Ingredient as IngredientModel,
    Supplier as SupplierModel,
    Category as CategoryModel,
    NutritionFacts as NutritionFactsModel,
    IngredientSupplier as IngredientSupplierModel,
    CostHistory as CostHistoryModel,
    RFQ as RFQModel,
    RFQItem as RFQItemModel,
    RFQResponse as RFQResponseModel,
    db
)

# GraphQL Types
class Category(SQLAlchemyObjectType):
    class Meta:
        model = CategoryModel
        interfaces = (graphene.relay.Node,)

class Supplier(SQLAlchemyObjectType):
    class Meta:
        model = SupplierModel
        interfaces = (graphene.relay.Node,)

class Ingredient(SQLAlchemyObjectType):
    class Meta:
        model = IngredientModel
        interfaces = (graphene.relay.Node,)

class NutritionFacts(SQLAlchemyObjectType):
    class Meta:
        model = NutritionFactsModel
        interfaces = (graphene.relay.Node,)

class IngredientSupplier(SQLAlchemyObjectType):
    class Meta:
        model = IngredientSupplierModel
        interfaces = (graphene.relay.Node,)

class CostHistory(SQLAlchemyObjectType):
    class Meta:
        model = CostHistoryModel
        interfaces = (graphene.relay.Node,)

class RFQ(SQLAlchemyObjectType):
    class Meta:
        model = RFQModel
        interfaces = (graphene.relay.Node,)

class RFQItem(SQLAlchemyObjectType):
    class Meta:
        model = RFQItemModel
        interfaces = (graphene.relay.Node,)

class RFQResponse(SQLAlchemyObjectType):
    class Meta:
        model = RFQResponseModel
        interfaces = (graphene.relay.Node,)

# Input Types
class IngredientInput(graphene.InputObjectType):
    name = String(required=True)
    description = String()
    category_id = Int()
    unit_of_measure = String(required=True)
    cost_per_unit = Float()
    yield_percentage = Float()
    usda_food_id = String()

class SupplierInput(graphene.InputObjectType):
    name = String(required=True)
    contact_name = String()
    email = String()
    phone = String()
    address = String()
    sku_prefix = String()

class CategoryInput(graphene.InputObjectType):
    name = String(required=True)
    parent_id = Int()
    description = String()

class NutritionFactsInput(graphene.InputObjectType):
    ingredient_id = Int(required=True)
    calories = Float()
    protein_g = Float()
    carbs_g = Float()
    fat_g = Float()
    fiber_g = Float()
    sugar_g = Float()
    sodium_mg = Float()
    serving_size = String()
    usda_source = Boolean()

# Queries
class Query(ObjectType):
    # Ingredient queries
    ingredients = List(Ingredient)
    ingredient = Field(Ingredient, id=Int(required=True))
    ingredients_by_category = List(Ingredient, category_id=Int(required=True))
    
    # Supplier queries
    suppliers = List(Supplier)
    supplier = Field(Supplier, id=Int(required=True))
    
    # Category queries
    categories = List(Category)
    category = Field(Category, id=Int(required=True))
    root_categories = List(Category)
    
    # Cost history queries
    cost_history = List(CostHistory, ingredient_id=Int())
    cost_trends = List(CostHistory, ingredient_id=Int(), months=Int())
    
    # RFQ queries
    rfqs = List(RFQ)
    rfq = Field(RFQ, id=Int(required=True))

    def resolve_ingredients(self, info):
        return db.session.query(IngredientModel).all()

    def resolve_ingredient(self, info, id):
        return db.session.query(IngredientModel).filter(IngredientModel.id == id).first()

    def resolve_ingredients_by_category(self, info, category_id):
        return db.session.query(IngredientModel).filter(IngredientModel.category_id == category_id).all()

    def resolve_suppliers(self, info):
        return db.session.query(SupplierModel).all()

    def resolve_supplier(self, info, id):
        return db.session.query(SupplierModel).filter(SupplierModel.id == id).first()

    def resolve_categories(self, info):
        return db.session.query(CategoryModel).all()

    def resolve_category(self, info, id):
        return db.session.query(CategoryModel).filter(CategoryModel.id == id).first()

    def resolve_root_categories(self, info):
        return db.session.query(CategoryModel).filter(CategoryModel.parent_id.is_(None)).all()

    def resolve_cost_history(self, info, ingredient_id=None):
        query = db.session.query(CostHistoryModel)
        if ingredient_id:
            query = query.filter(CostHistoryModel.ingredient_id == ingredient_id)
        return query.order_by(CostHistoryModel.effective_date.desc()).all()

    def resolve_cost_trends(self, info, ingredient_id=None, months=12):
        from datetime import datetime, timedelta
        start_date = datetime.now() - timedelta(days=months * 30)
        
        query = db.session.query(CostHistoryModel).filter(
            CostHistoryModel.effective_date >= start_date
        )
        if ingredient_id:
            query = query.filter(CostHistoryModel.ingredient_id == ingredient_id)
        
        return query.order_by(CostHistoryModel.effective_date.asc()).all()

    def resolve_rfqs(self, info):
        return db.session.query(RFQModel).all()

    def resolve_rfq(self, info, id):
        return db.session.query(RFQModel).filter(RFQModel.id == id).first()

# Mutations
class CreateIngredient(graphene.Mutation):
    class Arguments:
        ingredient_data = IngredientInput(required=True)

    ingredient = Field(Ingredient)

    def mutate(self, info, ingredient_data):
        ingredient = IngredientModel(**ingredient_data)
        db.session.add(ingredient)
        db.session.commit()
        return CreateIngredient(ingredient=ingredient)

class UpdateIngredient(graphene.Mutation):
    class Arguments:
        id = Int(required=True)
        ingredient_data = IngredientInput(required=True)

    ingredient = Field(Ingredient)

    def mutate(self, info, id, ingredient_data):
        ingredient = db.session.query(IngredientModel).filter(IngredientModel.id == id).first()
        if not ingredient:
            raise Exception("Ingredient not found")
        
        for key, value in ingredient_data.items():
            setattr(ingredient, key, value)
        
        db.session.commit()
        return UpdateIngredient(ingredient=ingredient)

class DeleteIngredient(graphene.Mutation):
    class Arguments:
        id = Int(required=True)

    success = Boolean()

    def mutate(self, info, id):
        ingredient = db.session.query(IngredientModel).filter(IngredientModel.id == id).first()
        if not ingredient:
            raise Exception("Ingredient not found")
        
        db.session.delete(ingredient)
        db.session.commit()
        return DeleteIngredient(success=True)

class CreateSupplier(graphene.Mutation):
    class Arguments:
        supplier_data = SupplierInput(required=True)

    supplier = Field(Supplier)

    def mutate(self, info, supplier_data):
        supplier = SupplierModel(**supplier_data)
        db.session.add(supplier)
        db.session.commit()
        return CreateSupplier(supplier=supplier)

class UpdateSupplier(graphene.Mutation):
    class Arguments:
        id = Int(required=True)
        supplier_data = SupplierInput(required=True)

    supplier = Field(Supplier)

    def mutate(self, info, id, supplier_data):
        supplier = db.session.query(SupplierModel).filter(SupplierModel.id == id).first()
        if not supplier:
            raise Exception("Supplier not found")
        
        for key, value in supplier_data.items():
            setattr(supplier, key, value)
        
        db.session.commit()
        return UpdateSupplier(supplier=supplier)

class DeleteSupplier(graphene.Mutation):
    class Arguments:
        id = Int(required=True)

    success = Boolean()

    def mutate(self, info, id):
        supplier = db.session.query(SupplierModel).filter(SupplierModel.id == id).first()
        if not supplier:
            raise Exception("Supplier not found")
        
        db.session.delete(supplier)
        db.session.commit()
        return DeleteSupplier(success=True)

class CreateCategory(graphene.Mutation):
    class Arguments:
        category_data = CategoryInput(required=True)

    category = Field(Category)

    def mutate(self, info, category_data):
        category = CategoryModel(**category_data)
        db.session.add(category)
        db.session.commit()
        return CreateCategory(category=category)

class CreateNutritionFacts(graphene.Mutation):
    class Arguments:
        nutrition_data = NutritionFactsInput(required=True)

    nutrition_facts = Field(NutritionFacts)

    def mutate(self, info, nutrition_data):
        nutrition_facts = NutritionFactsModel(**nutrition_data)
        db.session.add(nutrition_facts)
        db.session.commit()
        return CreateNutritionFacts(nutrition_facts=nutrition_facts)

class Mutation(ObjectType):
    create_ingredient = CreateIngredient.Field()
    update_ingredient = UpdateIngredient.Field()
    delete_ingredient = DeleteIngredient.Field()
    create_supplier = CreateSupplier.Field()
    update_supplier = UpdateSupplier.Field()
    delete_supplier = DeleteSupplier.Field()
    create_category = CreateCategory.Field()
    create_nutrition_facts = CreateNutritionFacts.Field()

# Schema
schema = graphene.Schema(query=Query, mutation=Mutation)

