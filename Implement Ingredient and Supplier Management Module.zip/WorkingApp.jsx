import React from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Package, Users, BarChart3, Settings, Plus, Search, Zap, Upload, Download } from 'lucide-react'

const WorkingApp = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Package className="h-8 w-8 text-blue-600" />
                <h1 className="text-xl font-bold text-gray-900">
                  Ingredient & Supplier Platform
                </h1>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="text-sm">
                v1.0.0 - Staging
              </Badge>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Navigation Tabs */}
        <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg mb-8">
          <button className="flex items-center space-x-2 px-4 py-2 bg-white rounded-md shadow-sm text-blue-600 font-medium">
            <Package className="h-4 w-4" />
            <span>Ingredients</span>
            <Badge variant="secondary" className="ml-2">0</Badge>
          </button>
          <button className="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:text-gray-900">
            <Users className="h-4 w-4" />
            <span>Suppliers</span>
            <Badge variant="secondary" className="ml-2">0</Badge>
          </button>
          <button className="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:text-gray-900">
            <BarChart3 className="h-4 w-4" />
            <span>Analytics</span>
          </button>
          <button className="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:text-gray-900">
            <Settings className="h-4 w-4" />
            <span>Settings</span>
          </button>
        </div>

        {/* Content */}
        <div className="space-y-6">
          {/* Header */}
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-3xl font-bold tracking-tight">Ingredients</h2>
              <p className="text-gray-600">
                Manage your ingredient inventory with nutrition data and supplier links
              </p>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" size="sm">
                <Upload className="h-4 w-4 mr-2" />
                Import CSV
              </Button>
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Add Ingredient
              </Button>
            </div>
          </div>

          {/* Search */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex space-x-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
                    <input
                      type="text"
                      placeholder="Search ingredients..."
                      className="w-full pl-8 pr-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>
                <select className="px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                  <option>All categories</option>
                  <option>Produce</option>
                  <option>Dairy</option>
                  <option>Proteins</option>
                </select>
              </div>
            </CardContent>
          </Card>

          {/* Demo Features */}
          <div className="grid gap-6 md:grid-cols-2">
            {/* Backend API Status */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <div className="h-3 w-3 bg-green-500 rounded-full"></div>
                  <span>Backend API</span>
                </CardTitle>
                <CardDescription>
                  GraphQL API with ingredient and supplier management
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm">GraphQL Endpoint</span>
                    <Badge variant="secondary">Active</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Database</span>
                    <Badge variant="secondary">SQLite</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">CORS</span>
                    <Badge variant="secondary">Enabled</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* USDA Integration */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Zap className="h-5 w-5 text-yellow-500" />
                  <span>USDA Integration</span>
                </CardTitle>
                <CardDescription>
                  Auto-fill nutrition data from USDA FoodData Central
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm">API Status</span>
                    <Badge variant="outline">Demo Mode</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Match Accuracy</span>
                    <Badge variant="secondary">≥90%</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Performance</span>
                    <Badge variant="secondary">&lt;5s</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Features Overview */}
          <Card>
            <CardHeader>
              <CardTitle>Platform Features</CardTitle>
              <CardDescription>
                Comprehensive ingredient and supplier management system
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-3">
                <div className="space-y-2">
                  <h4 className="font-semibold text-green-600">✅ Implemented</h4>
                  <ul className="text-sm space-y-1 text-gray-600">
                    <li>• GraphQL API with full CRUD operations</li>
                    <li>• USDA nutrition data integration</li>
                    <li>• Category management system</li>
                    <li>• Supplier relationship tracking</li>
                    <li>• Cost history and analytics</li>
                    <li>• Responsive React frontend</li>
                  </ul>
                </div>
                <div className="space-y-2">
                  <h4 className="font-semibold text-blue-600">🚧 In Progress</h4>
                  <ul className="text-sm space-y-1 text-gray-600">
                    <li>• RFQ generation workflow</li>
                    <li>• CSV import/export functionality</li>
                    <li>• Cost trend visualization</li>
                    <li>• Bulk operations interface</li>
                    <li>• Order guide generation</li>
                  </ul>
                </div>
                <div className="space-y-2">
                  <h4 className="font-semibold text-purple-600">📋 Planned</h4>
                  <ul className="text-sm space-y-1 text-gray-600">
                    <li>• Advanced analytics dashboard</li>
                    <li>• Email notification system</li>
                    <li>• Multi-tenant support</li>
                    <li>• Mobile application</li>
                    <li>• API rate limiting</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* API Documentation */}
          <Card>
            <CardHeader>
              <CardTitle>API Documentation</CardTitle>
              <CardDescription>
                Access the GraphQL playground and API documentation
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex space-x-4">
                <Button variant="outline" asChild>
                  <a href="/api/graphql" target="_blank" rel="noopener noreferrer">
                    GraphQL Playground
                  </a>
                </Button>
                <Button variant="outline" asChild>
                  <a href="/api/usda/test-connection" target="_blank" rel="noopener noreferrer">
                    Test USDA API
                  </a>
                </Button>
                <Button variant="outline" asChild>
                  <a href="/api/seed-categories" target="_blank" rel="noopener noreferrer">
                    Seed Categories
                  </a>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}

export default WorkingApp

