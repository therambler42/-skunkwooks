import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Plus, Search, Edit, Trash2, Zap, Upload, Download } from 'lucide-react'
import { toast } from 'sonner'

const IngredientsPage = ({ onCountChange }) => {
  const [ingredients, setIngredients] = useState([])
  const [categories, setCategories] = useState([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('')
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [editingIngredient, setEditingIngredient] = useState(null)

  const [newIngredient, setNewIngredient] = useState({
    name: '',
    description: '',
    categoryId: '',
    unitOfMeasure: '',
    costPerUnit: '',
    yieldPercentage: '100'
  })

  useEffect(() => {
    fetchIngredients()
    fetchCategories()
  }, [])

  useEffect(() => {
    onCountChange(ingredients.length)
  }, [ingredients, onCountChange])

  const fetchIngredients = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/graphql', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          query: `
            query {
              ingredients {
                id
                name
                description
                categoryId
                unitOfMeasure
                costPerUnit
                yieldPercentage
                usdaFoodId
                createdAt
                updatedAt
              }
            }
          `
        })
      })

      if (response.ok) {
        const data = await response.json()
        setIngredients(data.data?.ingredients || [])
      }
    } catch (error) {
      console.error('Error fetching ingredients:', error)
      toast.error('Failed to fetch ingredients')
    } finally {
      setLoading(false)
    }
  }

  const fetchCategories = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/graphql', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          query: `
            query {
              categories {
                id
                name
                description
                parentId
              }
            }
          `
        })
      })

      if (response.ok) {
        const data = await response.json()
        setCategories(data.data?.categories || [])
      }
    } catch (error) {
      console.error('Error fetching categories:', error)
    }
  }

  const handleCreateIngredient = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/graphql', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          query: `
            mutation CreateIngredient($input: IngredientInput!) {
              createIngredient(input: $input) {
                id
                name
                description
                categoryId
                unitOfMeasure
                costPerUnit
                yieldPercentage
                createdAt
                updatedAt
              }
            }
          `,
          variables: {
            input: {
              name: newIngredient.name,
              description: newIngredient.description,
              categoryId: newIngredient.categoryId ? parseInt(newIngredient.categoryId) : null,
              unitOfMeasure: newIngredient.unitOfMeasure,
              costPerUnit: newIngredient.costPerUnit ? parseFloat(newIngredient.costPerUnit) : null,
              yieldPercentage: newIngredient.yieldPercentage ? parseFloat(newIngredient.yieldPercentage) : 100
            }
          }
        })
      })

      if (response.ok) {
        const data = await response.json()
        if (data.data?.createIngredient) {
          setIngredients([...ingredients, data.data.createIngredient])
          setIsAddDialogOpen(false)
          setNewIngredient({
            name: '',
            description: '',
            categoryId: '',
            unitOfMeasure: '',
            costPerUnit: '',
            yieldPercentage: '100'
          })
          toast.success('Ingredient created successfully')
        }
      }
    } catch (error) {
      console.error('Error creating ingredient:', error)
      toast.error('Failed to create ingredient')
    }
  }

  const handleAutoFillNutrition = async (ingredientId, ingredientName) => {
    try {
      const response = await fetch('http://localhost:5000/api/usda/auto-fill-nutrition', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ingredient_id: ingredientId
        })
      })

      if (response.ok) {
        const data = await response.json()
        if (data.success) {
          toast.success(`Nutrition data auto-filled for ${ingredientName} (${Math.round(data.match_score * 100)}% match)`)
        } else {
          toast.error(data.message || 'No suitable nutrition match found')
        }
      }
    } catch (error) {
      console.error('Error auto-filling nutrition:', error)
      toast.error('Failed to auto-fill nutrition data')
    }
  }

  const filteredIngredients = ingredients.filter(ingredient => {
    const matchesSearch = ingredient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         ingredient.description?.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = !selectedCategory || ingredient.categoryId?.toString() === selectedCategory
    return matchesSearch && matchesCategory
  })

  const getCategoryName = (categoryId) => {
    const category = categories.find(cat => cat.id === categoryId)
    return category?.name || 'Uncategorized'
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Ingredients</h2>
          <p className="text-muted-foreground">
            Manage your ingredient inventory with nutrition data and supplier links
          </p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" size="sm">
            <Upload className="h-4 w-4 mr-2" />
            Import CSV
          </Button>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Add Ingredient
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Add New Ingredient</DialogTitle>
                <DialogDescription>
                  Create a new ingredient with basic information. You can add nutrition data later.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="name" className="text-right">
                    Name
                  </Label>
                  <Input
                    id="name"
                    value={newIngredient.name}
                    onChange={(e) => setNewIngredient({...newIngredient, name: e.target.value})}
                    className="col-span-3"
                    placeholder="e.g., Organic Tomatoes"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="description" className="text-right">
                    Description
                  </Label>
                  <Textarea
                    id="description"
                    value={newIngredient.description}
                    onChange={(e) => setNewIngredient({...newIngredient, description: e.target.value})}
                    className="col-span-3"
                    placeholder="Optional description"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="category" className="text-right">
                    Category
                  </Label>
                  <Select value={newIngredient.categoryId} onValueChange={(value) => setNewIngredient({...newIngredient, categoryId: value})}>
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category.id} value={category.id.toString()}>
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="unit" className="text-right">
                    Unit
                  </Label>
                  <Input
                    id="unit"
                    value={newIngredient.unitOfMeasure}
                    onChange={(e) => setNewIngredient({...newIngredient, unitOfMeasure: e.target.value})}
                    className="col-span-3"
                    placeholder="e.g., kg, lbs, pieces"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="cost" className="text-right">
                    Cost/Unit
                  </Label>
                  <Input
                    id="cost"
                    type="number"
                    step="0.01"
                    value={newIngredient.costPerUnit}
                    onChange={(e) => setNewIngredient({...newIngredient, costPerUnit: e.target.value})}
                    className="col-span-3"
                    placeholder="0.00"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="yield" className="text-right">
                    Yield %
                  </Label>
                  <Input
                    id="yield"
                    type="number"
                    step="0.1"
                    value={newIngredient.yieldPercentage}
                    onChange={(e) => setNewIngredient({...newIngredient, yieldPercentage: e.target.value})}
                    className="col-span-3"
                    placeholder="100"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="submit" onClick={handleCreateIngredient}>
                  Create Ingredient
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex space-x-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search ingredients..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-8"
                />
              </div>
            </div>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="All categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All categories</SelectItem>
                {categories.map((category) => (
                  <SelectItem key={category.id} value={category.id.toString()}>
                    {category.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Ingredients Table */}
      <Card>
        <CardHeader>
          <CardTitle>Ingredients ({filteredIngredients.length})</CardTitle>
          <CardDescription>
            Manage your ingredient database with nutrition information and supplier relationships
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Unit</TableHead>
                <TableHead>Cost/Unit</TableHead>
                <TableHead>Yield %</TableHead>
                <TableHead>USDA Data</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredIngredients.map((ingredient) => (
                <TableRow key={ingredient.id}>
                  <TableCell className="font-medium">
                    <div>
                      <div className="font-semibold">{ingredient.name}</div>
                      {ingredient.description && (
                        <div className="text-sm text-muted-foreground">{ingredient.description}</div>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">
                      {getCategoryName(ingredient.categoryId)}
                    </Badge>
                  </TableCell>
                  <TableCell>{ingredient.unitOfMeasure}</TableCell>
                  <TableCell>
                    {ingredient.costPerUnit ? `$${ingredient.costPerUnit}` : '-'}
                  </TableCell>
                  <TableCell>{ingredient.yieldPercentage}%</TableCell>
                  <TableCell>
                    {ingredient.usdaFoodId ? (
                      <Badge variant="secondary">Linked</Badge>
                    ) : (
                      <Badge variant="outline">None</Badge>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleAutoFillNutrition(ingredient.id, ingredient.name)}
                      >
                        <Zap className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="sm">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="sm">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {filteredIngredients.length === 0 && (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No ingredients found</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

export default IngredientsPage

