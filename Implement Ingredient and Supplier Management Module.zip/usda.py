from flask import Blueprint, request, jsonify
from src.usda_client import find_best_nutrition_match, USDAClient
from src.models.ingredient import db, Ingredient, NutritionFacts
import os

usda_bp = Blueprint('usda', __name__)

@usda_bp.route('/search-nutrition', methods=['POST'])
def search_nutrition():
    """Search for nutrition data using USDA API"""
    try:
        data = request.get_json()
        ingredient_name = data.get('ingredient_name')
        
        if not ingredient_name:
            return jsonify({'error': 'ingredient_name is required'}), 400
        
        # Get API key from environment or use demo key
        api_key = os.getenv('USDA_API_KEY', 'DEMO_KEY')
        
        # Find nutrition match
        nutrition_data = find_best_nutrition_match(ingredient_name, api_key)
        
        if nutrition_data:
            return jsonify({
                'success': True,
                'nutrition_data': nutrition_data,
                'match_score': nutrition_data.get('match_score', 0.0)
            }), 200
        else:
            return jsonify({
                'success': False,
                'message': 'No suitable nutrition match found'
            }), 404
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@usda_bp.route('/auto-fill-nutrition', methods=['POST'])
def auto_fill_nutrition():
    """Auto-fill nutrition data for an ingredient"""
    try:
        data = request.get_json()
        ingredient_id = data.get('ingredient_id')
        
        if not ingredient_id:
            return jsonify({'error': 'ingredient_id is required'}), 400
        
        # Get the ingredient
        ingredient = db.session.query(Ingredient).filter(
            Ingredient.id == ingredient_id
        ).first()
        
        if not ingredient:
            return jsonify({'error': 'Ingredient not found'}), 404
        
        # Check if nutrition facts already exist
        existing_nutrition = db.session.query(NutritionFacts).filter(
            NutritionFacts.ingredient_id == ingredient_id
        ).first()
        
        if existing_nutrition and not data.get('force_update', False):
            return jsonify({
                'success': False,
                'message': 'Nutrition facts already exist. Use force_update=true to override.'
            }), 409
        
        # Get API key from environment or use demo key
        api_key = os.getenv('USDA_API_KEY', 'DEMO_KEY')
        
        # Find nutrition match
        nutrition_data = find_best_nutrition_match(ingredient.name, api_key)
        
        if not nutrition_data:
            return jsonify({
                'success': False,
                'message': 'No suitable nutrition match found'
            }), 404
        
        # Update or create nutrition facts
        if existing_nutrition:
            # Update existing
            for key, value in nutrition_data.items():
                if key not in ['usda_food_id', 'match_score'] and hasattr(existing_nutrition, key):
                    setattr(existing_nutrition, key, value)
            
            # Update ingredient's USDA food ID
            ingredient.usda_food_id = nutrition_data.get('usda_food_id')
            
            db.session.commit()
            nutrition_facts = existing_nutrition
        else:
            # Create new nutrition facts
            nutrition_facts = NutritionFacts(
                ingredient_id=ingredient_id,
                calories=nutrition_data.get('calories'),
                protein_g=nutrition_data.get('protein_g'),
                carbs_g=nutrition_data.get('carbs_g'),
                fat_g=nutrition_data.get('fat_g'),
                fiber_g=nutrition_data.get('fiber_g'),
                sugar_g=nutrition_data.get('sugar_g'),
                sodium_mg=nutrition_data.get('sodium_mg'),
                serving_size=nutrition_data.get('serving_size'),
                usda_source=nutrition_data.get('usda_source', True)
            )
            
            # Update ingredient's USDA food ID
            ingredient.usda_food_id = nutrition_data.get('usda_food_id')
            
            db.session.add(nutrition_facts)
            db.session.commit()
        
        return jsonify({
            'success': True,
            'nutrition_facts': nutrition_facts.to_dict(),
            'match_score': nutrition_data.get('match_score', 0.0),
            'message': 'Nutrition facts updated successfully'
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@usda_bp.route('/test-connection', methods=['GET'])
def test_usda_connection():
    """Test USDA API connection"""
    try:
        api_key = os.getenv('USDA_API_KEY', 'DEMO_KEY')
        client = USDAClient(api_key)
        
        # Test with a simple search
        foods = client.search_foods("apple", page_size=1)
        
        if foods:
            return jsonify({
                'success': True,
                'message': 'USDA API connection successful',
                'api_key_type': 'DEMO_KEY' if api_key == 'DEMO_KEY' else 'CUSTOM',
                'sample_result': {
                    'fdc_id': foods[0].fdc_id,
                    'description': foods[0].description,
                    'data_type': foods[0].data_type,
                    'nutrient_count': len(foods[0].nutrients)
                }
            }), 200
        else:
            return jsonify({
                'success': False,
                'message': 'USDA API returned no results'
            }), 500
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@usda_bp.route('/bulk-auto-fill', methods=['POST'])
def bulk_auto_fill_nutrition():
    """Auto-fill nutrition data for multiple ingredients"""
    try:
        data = request.get_json()
        ingredient_ids = data.get('ingredient_ids', [])
        force_update = data.get('force_update', False)
        
        if not ingredient_ids:
            return jsonify({'error': 'ingredient_ids is required'}), 400
        
        api_key = os.getenv('USDA_API_KEY', 'DEMO_KEY')
        results = []
        
        for ingredient_id in ingredient_ids:
            try:
                # Get the ingredient
                ingredient = db.session.query(Ingredient).filter(
                    Ingredient.id == ingredient_id
                ).first()
                
                if not ingredient:
                    results.append({
                        'ingredient_id': ingredient_id,
                        'success': False,
                        'message': 'Ingredient not found'
                    })
                    continue
                
                # Check if nutrition facts already exist
                existing_nutrition = db.session.query(NutritionFacts).filter(
                    NutritionFacts.ingredient_id == ingredient_id
                ).first()
                
                if existing_nutrition and not force_update:
                    results.append({
                        'ingredient_id': ingredient_id,
                        'ingredient_name': ingredient.name,
                        'success': False,
                        'message': 'Nutrition facts already exist'
                    })
                    continue
                
                # Find nutrition match
                nutrition_data = find_best_nutrition_match(ingredient.name, api_key)
                
                if not nutrition_data:
                    results.append({
                        'ingredient_id': ingredient_id,
                        'ingredient_name': ingredient.name,
                        'success': False,
                        'message': 'No suitable nutrition match found'
                    })
                    continue
                
                # Update or create nutrition facts
                if existing_nutrition:
                    # Update existing
                    for key, value in nutrition_data.items():
                        if key not in ['usda_food_id', 'match_score'] and hasattr(existing_nutrition, key):
                            setattr(existing_nutrition, key, value)
                    
                    ingredient.usda_food_id = nutrition_data.get('usda_food_id')
                    db.session.commit()
                    
                    results.append({
                        'ingredient_id': ingredient_id,
                        'ingredient_name': ingredient.name,
                        'success': True,
                        'message': 'Nutrition facts updated',
                        'match_score': nutrition_data.get('match_score', 0.0)
                    })
                else:
                    # Create new nutrition facts
                    nutrition_facts = NutritionFacts(
                        ingredient_id=ingredient_id,
                        calories=nutrition_data.get('calories'),
                        protein_g=nutrition_data.get('protein_g'),
                        carbs_g=nutrition_data.get('carbs_g'),
                        fat_g=nutrition_data.get('fat_g'),
                        fiber_g=nutrition_data.get('fiber_g'),
                        sugar_g=nutrition_data.get('sugar_g'),
                        sodium_mg=nutrition_data.get('sodium_mg'),
                        serving_size=nutrition_data.get('serving_size'),
                        usda_source=nutrition_data.get('usda_source', True)
                    )
                    
                    ingredient.usda_food_id = nutrition_data.get('usda_food_id')
                    
                    db.session.add(nutrition_facts)
                    db.session.commit()
                    
                    results.append({
                        'ingredient_id': ingredient_id,
                        'ingredient_name': ingredient.name,
                        'success': True,
                        'message': 'Nutrition facts created',
                        'match_score': nutrition_data.get('match_score', 0.0)
                    })
                    
            except Exception as e:
                db.session.rollback()
                results.append({
                    'ingredient_id': ingredient_id,
                    'success': False,
                    'message': f'Error: {str(e)}'
                })
        
        # Calculate summary statistics
        successful = sum(1 for r in results if r['success'])
        total = len(results)
        
        return jsonify({
            'success': True,
            'summary': {
                'total_processed': total,
                'successful': successful,
                'failed': total - successful,
                'success_rate': (successful / total * 100) if total > 0 else 0
            },
            'results': results
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

