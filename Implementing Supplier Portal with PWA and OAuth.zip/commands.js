// cypress/support/commands.js

// Custom command to login as supplier
Cypress.Commands.add('loginAsSupplier', (username = 'supplier1', password = 'password123') => {
  cy.visit('/login')
  cy.get('[data-testid="username-input"]').type(username)
  cy.get('[data-testid="password-input"]').type(password)
  cy.get('[data-testid="login-button"]').click()
  cy.url().should('include', '/dashboard')
  cy.get('[data-testid="dashboard-header"]').should('be.visible')
})

// Custom command to setup test data
Cypress.Commands.add('setupTestData', () => {
  cy.request({
    method: 'POST',
    url: 'http://localhost:5000/api/test/setup',
    failOnStatusCode: false
  })
})

// Custom command to clear test data
Cypress.Commands.add('clearTestData', () => {
  cy.request({
    method: 'DELETE',
    url: 'http://localhost:5000/api/test/cleanup',
    failOnStatusCode: false
  })
})

// Custom command to wait for API response
Cypress.Commands.add('waitForApi', (alias) => {
  cy.wait(alias).then((interception) => {
    expect(interception.response.statusCode).to.be.oneOf([200, 201, 204])
  })
})

// Custom command to check notification
Cypress.Commands.add('checkNotification', (message) => {
  cy.get('[data-testid="notification-bell"]').click()
  cy.get('[data-testid="notification-panel"]').should('be.visible')
  cy.get('[data-testid="notification-item"]').should('contain', message)
})

