#!/usr/bin/env python3
"""
Sample data creation script for Supplier Portal
Creates sample POs, receipts, and invoices for testing
"""

import requests
import json
from datetime import datetime, timedelta

BASE_URL = "http://localhost:5000/api"

def create_sample_data():
    """Create sample data for testing"""
    
    # First, create a buyer user for creating POs
    buyer_data = {
        "username": "buyer1",
        "email": "buyer1@company.com",
        "password": "password123",
        "company_name": "Acme Corp",
        "contact_person": "Jane Smith"
    }
    
    # Login as buyer (skip registration since user exists)
    print("Logging in as buyer...")
    login_response = requests.post(f"{BASE_URL}/auth/login", json={
        "username": "buyer1",
        "password": "password123"
    })
    
    if login_response.status_code != 200:
        print(f"✗ Failed to login as buyer: {login_response.text}")
        return
    
    buyer_token = login_response.json()['access_token']
    buyer_headers = {"Authorization": f"Bearer {buyer_token}", "Content-Type": "application/json"}
    
    # Create sample purchase order
    print("Creating sample purchase order...")
    po_data = {
        "po_number": "PO-2024-001",
        "supplier_id": 1,  # Our supplier from earlier
        "total_amount": 15000.00,
        "currency": "USD",
        "expected_delivery_date": (datetime.now() + timedelta(days=30)).isoformat(),
        "notes": "Sample purchase order for testing",
        "line_items": [
            {
                "line_number": 1,
                "description": "Office Chairs - Ergonomic",
                "quantity": 10,
                "unit_price": 500.00,
                "total_price": 5000.00,
                "unit_of_measure": "EA"
            },
            {
                "line_number": 2,
                "description": "Standing Desks - Adjustable",
                "quantity": 5,
                "unit_price": 800.00,
                "total_price": 4000.00,
                "unit_of_measure": "EA"
            },
            {
                "line_number": 3,
                "description": "Monitor Arms - Dual",
                "quantity": 15,
                "unit_price": 150.00,
                "total_price": 2250.00,
                "unit_of_measure": "EA"
            },
            {
                "line_number": 4,
                "description": "Keyboard Trays",
                "quantity": 20,
                "unit_price": 75.00,
                "total_price": 1500.00,
                "unit_of_measure": "EA"
            },
            {
                "line_number": 5,
                "description": "Cable Management Kit",
                "quantity": 25,
                "unit_price": 50.00,
                "total_price": 1250.00,
                "unit_of_measure": "EA"
            },
            {
                "line_number": 6,
                "description": "Desk Lamps - LED",
                "quantity": 12,
                "unit_price": 95.00,
                "total_price": 1140.00,
                "unit_of_measure": "EA"
            },
            {
                "line_number": 7,
                "description": "Footrests - Adjustable",
                "quantity": 8,
                "unit_price": 45.00,
                "total_price": 360.00,
                "unit_of_measure": "EA"
            }
        ]
    }
    
    po_response = requests.post(f"{BASE_URL}/purchase-orders", json=po_data, headers=buyer_headers)
    if po_response.status_code == 201:
        po_id = po_response.json()['purchase_order']['id']
        print(f"✓ Purchase order created with ID: {po_id}")
        
        # Send the PO to supplier
        send_response = requests.post(f"{BASE_URL}/purchase-orders/{po_id}/send", headers=buyer_headers)
        if send_response.status_code == 200:
            print("✓ Purchase order sent to supplier")
        else:
            print(f"✗ Failed to send PO: {send_response.text}")
            
    else:
        print(f"✗ Failed to create PO: {po_response.text}")
        return
    
    # Create another PO
    po_data2 = {
        "po_number": "PO-2024-002",
        "supplier_id": 1,
        "total_amount": 8500.00,
        "currency": "USD",
        "expected_delivery_date": (datetime.now() + timedelta(days=45)).isoformat(),
        "notes": "Second sample purchase order",
        "line_items": [
            {
                "line_number": 1,
                "description": "Conference Table - Large",
                "quantity": 1,
                "unit_price": 2500.00,
                "total_price": 2500.00,
                "unit_of_measure": "EA"
            },
            {
                "line_number": 2,
                "description": "Conference Chairs",
                "quantity": 12,
                "unit_price": 300.00,
                "total_price": 3600.00,
                "unit_of_measure": "EA"
            },
            {
                "line_number": 3,
                "description": "Whiteboard - Interactive",
                "quantity": 2,
                "unit_price": 1200.00,
                "total_price": 2400.00,
                "unit_of_measure": "EA"
            }
        ]
    }
    
    po_response2 = requests.post(f"{BASE_URL}/purchase-orders", json=po_data2, headers=buyer_headers)
    if po_response2.status_code == 201:
        po_id2 = po_response2.json()['purchase_order']['id']
        print(f"✓ Second purchase order created with ID: {po_id2}")
        
        # Send the second PO
        send_response2 = requests.post(f"{BASE_URL}/purchase-orders/{po_id2}/send", headers=buyer_headers)
        if send_response2.status_code == 200:
            print("✓ Second purchase order sent to supplier")
        else:
            print(f"✗ Failed to send second PO: {send_response2.text}")
    else:
        print(f"✗ Failed to create second PO: {po_response2.text}")
    
    print("\n" + "="*50)
    print("SAMPLE DATA CREATION COMPLETE")
    print("="*50)
    print(f"Supplier Login: supplier1 / password123")
    print(f"Buyer Login: buyer1 / password123")
    print(f"Purchase Orders Created: PO-2024-001, PO-2024-002")
    print(f"Supplier can now:")
    print(f"  - View purchase orders")
    print(f"  - Confirm purchase orders")
    print(f"  - Create and submit invoices")
    print("="*50)

if __name__ == "__main__":
    create_sample_data()

