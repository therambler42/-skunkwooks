// API configuration and service functions
const API_BASE_URL = 'http://localhost:5000/api';

class ApiService {
  constructor() {
    this.token = localStorage.getItem('authToken');
  }

  setToken(token) {
    this.token = token;
    if (token) {
      localStorage.setItem('authToken', token);
    } else {
      localStorage.removeItem('authToken');
    }
  }

  getHeaders() {
    const headers = {
      'Content-Type': 'application/json',
    };
    if (this.token) {
      headers.Authorization = `Bearer ${this.token}`;
    }
    return headers;
  }

  async request(endpoint, options = {}) {
    const url = `${API_BASE_URL}${endpoint}`;
    const config = {
      headers: this.getHeaders(),
      ...options,
    };

    try {
      const response = await fetch(url, config);
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || `HTTP error! status: ${response.status}`);
      }

      return data;
    } catch (error) {
      console.error('API request failed:', error);
      throw error;
    }
  }

  // Authentication
  async login(username, password) {
    const response = await this.request('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    });
    
    if (response.access_token) {
      this.setToken(response.access_token);
    }
    
    return response;
  }

  async register(userData) {
    return this.request('/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData),
    });
  }

  async getProfile() {
    return this.request('/auth/profile');
  }

  async updateProfile(profileData) {
    return this.request('/auth/profile', {
      method: 'PUT',
      body: JSON.stringify(profileData),
    });
  }

  async verifyToken() {
    return this.request('/auth/verify', {
      method: 'POST',
    });
  }

  logout() {
    this.setToken(null);
  }

  // Purchase Orders
  async getPurchaseOrders() {
    return this.request('/purchase-orders');
  }

  async getPurchaseOrder(id) {
    return this.request(`/purchase-orders/${id}`);
  }

  async confirmPurchaseOrder(id, notes = '') {
    return this.request(`/purchase-orders/${id}/confirm`, {
      method: 'POST',
      body: JSON.stringify({ notes }),
    });
  }

  // Invoices
  async getInvoices() {
    return this.request('/invoices');
  }

  async getInvoice(id) {
    return this.request(`/invoices/${id}`);
  }

  async createInvoice(poId, invoiceData) {
    return this.request(`/purchase-orders/${poId}/invoices`, {
      method: 'POST',
      body: JSON.stringify(invoiceData),
    });
  }

  async uploadInvoiceFile(invoiceId, file) {
    const formData = new FormData();
    formData.append('file', file);

    const url = `${API_BASE_URL}/invoices/${invoiceId}/upload`;
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${this.token}`,
      },
      body: formData,
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || `HTTP error! status: ${response.status}`);
    }

    return data;
  }

  async submitInvoice(invoiceId) {
    return this.request(`/invoices/${invoiceId}/submit`, {
      method: 'POST',
    });
  }

  // Three-way match
  async getThreeWayMatchStatus(invoiceId) {
    return this.request(`/invoices/${invoiceId}/three-way-match`);
  }
}

export default new ApiService();
export const api = new ApiService();

