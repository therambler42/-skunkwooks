from flask_socketio import SocketIO, emit, join_room, leave_room
from flask import request
from src.auth import verify_token
import json

socketio = SocketIO(cors_allowed_origins="*")

# Store active connections by user ID
active_connections = {}

@socketio.on('connect')
def handle_connect(auth):
    """Handle client connection with authentication"""
    try:
        # Verify JWT token from auth data
        if auth and 'token' in auth:
            user_data = verify_token(auth['token'])
            if user_data:
                user_id = user_data['user_id']
                active_connections[user_id] = request.sid
                join_room(f"user_{user_id}")
                emit('connected', {'status': 'authenticated', 'user_id': user_id})
                print(f"User {user_id} connected with session {request.sid}")
            else:
                emit('error', {'message': 'Invalid token'})
                return False
        else:
            emit('error', {'message': 'Authentication required'})
            return False
    except Exception as e:
        print(f"Connection error: {e}")
        emit('error', {'message': 'Connection failed'})
        return False

@socketio.on('disconnect')
def handle_disconnect():
    """Handle client disconnection"""
    # Remove from active connections
    for user_id, session_id in list(active_connections.items()):
        if session_id == request.sid:
            del active_connections[user_id]
            leave_room(f"user_{user_id}")
            print(f"User {user_id} disconnected")
            break

@socketio.on('join_po_room')
def handle_join_po_room(data):
    """Join a room for purchase order updates"""
    try:
        po_id = data.get('po_id')
        if po_id:
            join_room(f"po_{po_id}")
            emit('joined_room', {'room': f"po_{po_id}"})
    except Exception as e:
        emit('error', {'message': f'Failed to join room: {str(e)}'})

@socketio.on('leave_po_room')
def handle_leave_po_room(data):
    """Leave a purchase order room"""
    try:
        po_id = data.get('po_id')
        if po_id:
            leave_room(f"po_{po_id}")
            emit('left_room', {'room': f"po_{po_id}"})
    except Exception as e:
        emit('error', {'message': f'Failed to leave room: {str(e)}'})

def broadcast_po_update(po_id, update_data):
    """Broadcast purchase order updates to all connected clients in the PO room"""
    try:
        socketio.emit('po_updated', {
            'po_id': po_id,
            'data': update_data,
            'timestamp': update_data.get('updated_at')
        }, room=f"po_{po_id}")
        print(f"Broadcasted PO update for PO {po_id}")
    except Exception as e:
        print(f"Failed to broadcast PO update: {e}")

def broadcast_invoice_update(invoice_id, po_id, update_data):
    """Broadcast invoice updates to all connected clients"""
    try:
        socketio.emit('invoice_updated', {
            'invoice_id': invoice_id,
            'po_id': po_id,
            'data': update_data,
            'timestamp': update_data.get('updated_at')
        }, room=f"po_{po_id}")
        print(f"Broadcasted invoice update for invoice {invoice_id}")
    except Exception as e:
        print(f"Failed to broadcast invoice update: {e}")

def broadcast_three_way_match_update(po_id, match_status, details):
    """Broadcast three-way match status updates"""
    try:
        socketio.emit('three_way_match_updated', {
            'po_id': po_id,
            'match_status': match_status,
            'details': details,
            'timestamp': details.get('updated_at')
        }, room=f"po_{po_id}")
        print(f"Broadcasted three-way match update for PO {po_id}: {match_status}")
    except Exception as e:
        print(f"Failed to broadcast three-way match update: {e}")

def notify_user(user_id, notification_type, message, data=None):
    """Send notification to a specific user"""
    try:
        if user_id in active_connections:
            socketio.emit('notification', {
                'type': notification_type,
                'message': message,
                'data': data or {},
                'timestamp': data.get('timestamp') if data else None
            }, room=f"user_{user_id}")
            print(f"Sent notification to user {user_id}: {message}")
    except Exception as e:
        print(f"Failed to send notification to user {user_id}: {e}")

# Event handlers for business logic integration
def on_po_status_change(po_id, old_status, new_status, po_data):
    """Handle purchase order status changes"""
    update_data = {
        'status': new_status,
        'previous_status': old_status,
        'updated_at': po_data.get('updated_at'),
        'po_number': po_data.get('po_number')
    }
    broadcast_po_update(po_id, update_data)
    
    # Notify supplier
    if 'supplier_id' in po_data:
        notify_user(
            po_data['supplier_id'],
            'po_status_change',
            f"Purchase Order {po_data.get('po_number')} status changed to {new_status}",
            update_data
        )

def on_invoice_status_change(invoice_id, po_id, old_status, new_status, invoice_data):
    """Handle invoice status changes"""
    update_data = {
        'status': new_status,
        'previous_status': old_status,
        'updated_at': invoice_data.get('updated_at'),
        'invoice_number': invoice_data.get('invoice_number')
    }
    broadcast_invoice_update(invoice_id, po_id, update_data)
    
    # Notify supplier
    if 'supplier_id' in invoice_data:
        notify_user(
            invoice_data['supplier_id'],
            'invoice_status_change',
            f"Invoice {invoice_data.get('invoice_number')} status changed to {new_status}",
            update_data
        )

def on_three_way_match_complete(po_id, match_result, details):
    """Handle three-way match completion"""
    broadcast_three_way_match_update(po_id, match_result, details)
    
    # Notify relevant users
    if 'supplier_id' in details:
        message = f"Three-way match {'completed successfully' if match_result == 'MATCHED' else 'failed'} for PO {details.get('po_number')}"
        notify_user(
            details['supplier_id'],
            'three_way_match',
            message,
            details
        )

