import { createContext, useContext, useEffect, useState } from 'react';
import { io } from 'socket.io-client';
import { useAuth } from './AuthContext';

const SocketContext = createContext();

export const useSocket = () => {
  const context = useContext(SocketContext);
  if (!context) {
    throw new Error('useSocket must be used within a SocketProvider');
  }
  return context;
};

export const SocketProvider = ({ children }) => {
  const [socket, setSocket] = useState(null);
  const [connected, setConnected] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const { user, isAuthenticated } = useAuth();

  useEffect(() => {
    if (isAuthenticated && user) {
      const token = localStorage.getItem('authToken');
      if (token) {
        // Initialize socket connection
        const newSocket = io('http://localhost:5000', {
          auth: {
            token: token
          },
          transports: ['websocket', 'polling']
        });

        // Connection event handlers
        newSocket.on('connect', () => {
          console.log('Connected to server');
          setConnected(true);
        });

        newSocket.on('connected', (data) => {
          console.log('Authenticated:', data);
        });

        newSocket.on('disconnect', () => {
          console.log('Disconnected from server');
          setConnected(false);
        });

        newSocket.on('error', (error) => {
          console.error('Socket error:', error);
        });

        // Business event handlers
        newSocket.on('po_updated', (data) => {
          console.log('PO updated:', data);
          // Trigger a custom event that components can listen to
          window.dispatchEvent(new CustomEvent('poUpdated', { detail: data }));
          
          // Add notification
          addNotification({
            type: 'po_update',
            message: `Purchase Order ${data.data.po_number} status updated to ${data.data.status}`,
            timestamp: new Date().toISOString(),
            data: data
          });
        });

        newSocket.on('invoice_updated', (data) => {
          console.log('Invoice updated:', data);
          window.dispatchEvent(new CustomEvent('invoiceUpdated', { detail: data }));
          
          addNotification({
            type: 'invoice_update',
            message: `Invoice ${data.data.invoice_number} status updated to ${data.data.status}`,
            timestamp: new Date().toISOString(),
            data: data
          });
        });

        newSocket.on('three_way_match_updated', (data) => {
          console.log('Three-way match updated:', data);
          window.dispatchEvent(new CustomEvent('threeWayMatchUpdated', { detail: data }));
          
          const status = data.match_status === 'MATCHED' ? 'completed successfully' : 'failed';
          addNotification({
            type: 'three_way_match',
            message: `Three-way match ${status} for PO ${data.details.po_number}`,
            timestamp: new Date().toISOString(),
            data: data
          });
        });

        newSocket.on('notification', (data) => {
          console.log('Notification received:', data);
          addNotification({
            type: data.type,
            message: data.message,
            timestamp: data.timestamp || new Date().toISOString(),
            data: data.data
          });
        });

        setSocket(newSocket);

        return () => {
          newSocket.close();
        };
      }
    } else {
      // Disconnect socket if not authenticated
      if (socket) {
        socket.close();
        setSocket(null);
        setConnected(false);
      }
    }
  }, [isAuthenticated, user]);

  const addNotification = (notification) => {
    setNotifications(prev => [
      {
        id: Date.now(),
        ...notification
      },
      ...prev.slice(0, 9) // Keep only last 10 notifications
    ]);
  };

  const removeNotification = (id) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const clearNotifications = () => {
    setNotifications([]);
  };

  const joinPORoom = (poId) => {
    if (socket && connected) {
      socket.emit('join_po_room', { po_id: poId });
    }
  };

  const leavePORoom = (poId) => {
    if (socket && connected) {
      socket.emit('leave_po_room', { po_id: poId });
    }
  };

  const value = {
    socket,
    connected,
    notifications,
    addNotification,
    removeNotification,
    clearNotifications,
    joinPORoom,
    leavePORoom
  };

  return (
    <SocketContext.Provider value={value}>
      {children}
    </SocketContext.Provider>
  );
};

