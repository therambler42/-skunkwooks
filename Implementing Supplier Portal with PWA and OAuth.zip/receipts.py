from flask import Blueprint, jsonify, request
from src.models.supplier import Receipt, ReceiptItem, ReceiptStatus, PurchaseOrder, POStatus, POLineItem, db
from src.auth import require_auth
from datetime import datetime

receipt_bp = Blueprint('receipts', __name__)

@receipt_bp.route('/receipts', methods=['GET'])
@require_auth('read:receipts')
def get_receipts():
    """Get all receipts (for buyers/admin)"""
    try:
        role = request.current_user['role']
        if role not in ['BUYER', 'ADMIN']:
            return jsonify({'error': 'Access denied'}), 403
        
        receipts = Receipt.query.all()
        return jsonify([receipt.to_dict() for receipt in receipts]), 200
        
    except Exception as e:
        return jsonify({'error': 'Failed to get receipts', 'details': str(e)}), 500

@receipt_bp.route('/receipts/<int:receipt_id>', methods=['GET'])
@require_auth('read:receipts')
def get_receipt(receipt_id):
    """Get specific receipt details"""
    try:
        role = request.current_user['role']
        if role not in ['BUYER', 'ADMIN']:
            return jsonify({'error': 'Access denied'}), 403
        
        receipt = Receipt.query.get(receipt_id)
        if not receipt:
            return jsonify({'error': 'Receipt not found'}), 404
        
        return jsonify(receipt.to_dict()), 200
        
    except Exception as e:
        return jsonify({'error': 'Failed to get receipt', 'details': str(e)}), 500

@receipt_bp.route('/purchase-orders/<int:po_id>/receipts', methods=['POST'])
@require_auth('create:receipts')
def create_receipt(po_id):
    """Create receipt for a purchase order"""
    try:
        role = request.current_user['role']
        if role not in ['BUYER', 'ADMIN']:
            return jsonify({'error': 'Only buyers and admins can create receipts'}), 403
        
        po = PurchaseOrder.query.get(po_id)
        if not po:
            return jsonify({'error': 'Purchase order not found'}), 404
        
        if po.status not in [POStatus.CONFIRMED, POStatus.PARTIALLY_RECEIVED]:
            return jsonify({'error': 'Purchase order must be confirmed to create receipt'}), 400
        
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        # Validate required fields
        required_fields = ['receipt_number', 'received_by', 'receipt_items']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Check if receipt number already exists
        if Receipt.query.filter_by(receipt_number=data['receipt_number']).first():
            return jsonify({'error': 'Receipt number already exists'}), 409
        
        # Create receipt
        receipt = Receipt(
            po_id=po_id,
            receipt_number=data['receipt_number'],
            received_by=data['received_by'],
            notes=data.get('notes'),
            status=ReceiptStatus.RECEIVED
        )
        db.session.add(receipt)
        db.session.flush()  # Get receipt ID
        
        # Create receipt items
        total_received_qty = 0
        total_po_qty = 0
        
        for item_data in data['receipt_items']:
            receipt_item = ReceiptItem(
                receipt_id=receipt.id,
                po_line_item_id=item_data['po_line_item_id'],
                quantity_received=item_data['quantity_received'],
                condition=item_data.get('condition', 'Good'),
                notes=item_data.get('notes')
            )
            db.session.add(receipt_item)
            
            # Calculate totals for PO status update
            po_line_item = POLineItem.query.get(item_data['po_line_item_id'])
            if po_line_item:
                total_received_qty += float(item_data['quantity_received'])
                total_po_qty += float(po_line_item.quantity)
        
        # Update PO status based on received quantities
        if total_received_qty >= total_po_qty:
            po.status = POStatus.RECEIVED
        else:
            po.status = POStatus.PARTIALLY_RECEIVED
        
        db.session.commit()
        
        return jsonify({
            'message': 'Receipt created successfully',
            'receipt': receipt.to_dict(),
            'purchase_order_status': po.status.value
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Failed to create receipt', 'details': str(e)}), 500

@receipt_bp.route('/purchase-orders/<int:po_id>/receipts', methods=['GET'])
@require_auth('read:receipts')
def get_po_receipts(po_id):
    """Get all receipts for a purchase order"""
    try:
        role = request.current_user['role']
        if role not in ['BUYER', 'ADMIN']:
            return jsonify({'error': 'Access denied'}), 403
        
        po = PurchaseOrder.query.get(po_id)
        if not po:
            return jsonify({'error': 'Purchase order not found'}), 404
        
        receipts = Receipt.query.filter_by(po_id=po_id).all()
        return jsonify([receipt.to_dict() for receipt in receipts]), 200
        
    except Exception as e:
        return jsonify({'error': 'Failed to get receipts', 'details': str(e)}), 500

