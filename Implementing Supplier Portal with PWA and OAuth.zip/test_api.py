import pytest
import json
from src.main import app
from src.models.supplier import db, User, UserRole, SupplierProfile

@pytest.fixture
def client():
    """Create a test client for the Flask application"""
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    app.config['SECRET_KEY'] = 'test-secret-key'
    
    with app.test_client() as client:
        with app.app_context():
            db.create_all()
            yield client
            db.drop_all()

@pytest.fixture
def supplier_user(client):
    """Create a test supplier user"""
    with app.app_context():
        from src.auth import AuthService
        user = User(
            username='testsupplier',
            email='supplier@test.com',
            password_hash=AuthService.hash_password('password123'),
            role=UserRole.SUPPLIER
        )
        db.session.add(user)
        db.session.commit()
        
        profile = SupplierProfile(
            user_id=user.id,
            company_name='Test Supplier Inc',
            contact_person='John Doe',
            phone='+1-555-0123',
            address='123 Test St, Test City, TC 12345',
            credit_limit=50000.00,
            payment_terms='30 days'
        )
        db.session.add(profile)
        db.session.commit()
        
        # Return user data instead of object to avoid session issues
        return {
            'id': user.id,
            'username': user.username,
            'email': user.email,
            'role': user.role
        }

@pytest.fixture
def auth_headers(client, supplier_user):
    """Get authentication headers for test requests"""
    from src.auth import AuthService
    
    with app.app_context():
        token = AuthService.generate_token(supplier_user['id'], supplier_user['role'])
        return {'Authorization': f'Bearer {token}'}

class TestAuthEndpoints:
    """Test authentication endpoints"""
    
    def test_register_supplier(self, client):
        """Test supplier registration"""
        data = {
            'username': 'newsupplier',
            'email': 'new@supplier.com',
            'password': 'password123',
            'company_name': 'New Supplier Co',
            'contact_person': 'Jane Smith',
            'phone': '+1-555-0456',
            'address': '456 New St, New City, NC 67890'
        }
        
        response = client.post('/api/auth/register', 
                             data=json.dumps(data),
                             content_type='application/json')
        
        assert response.status_code == 201
        result = json.loads(response.data)
        assert 'user' in result
        assert result['user']['username'] == 'newsupplier'
        assert result['user']['role'] == 'SUPPLIER'
    
    def test_login_success(self, client, supplier_user):
        """Test successful login"""
        data = {
            'username': 'testsupplier',
            'password': 'password123'
        }
        
        response = client.post('/api/auth/login',
                             data=json.dumps(data),
                             content_type='application/json')
        
        assert response.status_code == 200
        result = json.loads(response.data)
        assert 'access_token' in result
        assert result['user']['username'] == 'testsupplier'
    
    def test_login_invalid_credentials(self, client, supplier_user):
        """Test login with invalid credentials"""
        data = {
            'username': 'testsupplier',
            'password': 'wrongpassword'
        }
        
        response = client.post('/api/auth/login',
                             data=json.dumps(data),
                             content_type='application/json')
        
        assert response.status_code == 401
        result = json.loads(response.data)
        assert 'error' in result
    
    def test_verify_token(self, client, auth_headers):
        """Test token verification"""
        response = client.get('/api/auth/verify',
                            headers=auth_headers)
        
        assert response.status_code == 200
        result = json.loads(response.data)
        assert result['valid'] is True
        assert 'user' in result

class TestPurchaseOrderEndpoints:
    """Test purchase order endpoints"""
    
    def test_get_purchase_orders_authenticated(self, client, auth_headers):
        """Test getting purchase orders with authentication"""
        response = client.get('/api/purchase-orders',
                            headers=auth_headers)
        
        assert response.status_code == 200
        result = json.loads(response.data)
        assert isinstance(result, list)
    
    def test_get_purchase_orders_unauthenticated(self, client):
        """Test getting purchase orders without authentication"""
        response = client.get('/api/purchase-orders')
        
        assert response.status_code == 401
        result = json.loads(response.data)
        assert 'error' in result
    
    def test_confirm_purchase_order(self, client, auth_headers, supplier_user):
        """Test confirming a purchase order"""
        # First create a purchase order
        from src.models.supplier import PurchaseOrder, POStatus
        with app.app_context():
            po = PurchaseOrder(
                po_number='PO-TEST-001',
                supplier_id=supplier_user['id'],
                total_amount=1000.00,
                status=POStatus.SENT
            )
            db.session.add(po)
            db.session.commit()
            po_id = po.id
        
        response = client.put(f'/api/purchase-orders/{po_id}/confirm',
                            headers=auth_headers)
        
        assert response.status_code == 200
        result = json.loads(response.data)
        assert result['status'] == 'CONFIRMED'

class TestInvoiceEndpoints:
    """Test invoice endpoints"""
    
    def test_create_invoice(self, client, auth_headers, supplier_user):
        """Test creating an invoice"""
        # First create a confirmed purchase order
        from src.models.supplier import PurchaseOrder, POStatus
        with app.app_context():
            po = PurchaseOrder(
                po_number='PO-TEST-002',
                supplier_id=supplier_user['id'],
                total_amount=2000.00,
                status=POStatus.CONFIRMED
            )
            db.session.add(po)
            db.session.commit()
            po_id = po.id
        
        data = {
            'po_id': po_id,
            'invoice_number': 'INV-TEST-001',
            'supplier_invoice_number': 'SUPP-INV-001',
            'total_amount': 2000.00,
            'tax_amount': 200.00,
            'due_date': '2025-07-08',
            'notes': 'Test invoice'
        }
        
        response = client.post('/api/invoices',
                             data=json.dumps(data),
                             content_type='application/json',
                             headers=auth_headers)
        
        assert response.status_code == 201
        result = json.loads(response.data)
        assert result['invoice_number'] == 'INV-TEST-001'
        assert result['status'] == 'DRAFT'
    
    def test_get_invoices(self, client, auth_headers):
        """Test getting invoices"""
        response = client.get('/api/invoices',
                            headers=auth_headers)
        
        assert response.status_code == 200
        result = json.loads(response.data)
        assert isinstance(result, list)

class TestThreeWayMatch:
    """Test three-way match functionality"""
    
    def test_three_way_match_process(self, client, auth_headers, supplier_user):
        """Test the three-way match process"""
        from src.models.supplier import PurchaseOrder, POStatus, Invoice, InvoiceStatus, Receipt
        
        with app.app_context():
            # Create PO
            po = PurchaseOrder(
                po_number='PO-MATCH-001',
                supplier_id=supplier_user['id'],
                total_amount=1500.00,
                status=POStatus.CONFIRMED
            )
            db.session.add(po)
            db.session.commit()
            
            # Create Invoice
            invoice = Invoice(
                po_id=po.id,
                supplier_id=supplier_user['id'],
                invoice_number='INV-MATCH-001',
                supplier_invoice_number='SUPP-MATCH-001',
                total_amount=1500.00,
                tax_amount=150.00,
                status=InvoiceStatus.DRAFT
            )
            db.session.add(invoice)
            db.session.commit()
            
            # Create Receipt
            receipt = Receipt(
                po_id=po.id,
                received_by=1,  # Buyer
                quantity_received=2,
                notes='All items received in good condition'
            )
            db.session.add(receipt)
            db.session.commit()
            
            po_id = po.id
        
        # Test three-way match endpoint
        response = client.post(f'/api/three-way-match/{po_id}',
                             headers=auth_headers)
        
        assert response.status_code == 200
        result = json.loads(response.data)
        assert 'match_result' in result

if __name__ == '__main__':
    pytest.main([__file__])

