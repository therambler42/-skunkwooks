#!/usr/bin/env python3
"""
Create sample data for the deployed supplier portal
"""
import requests
import json

# Use localhost since we're running locally
API_BASE_URL = 'http://localhost:5000/api'

def create_sample_data():
    print("Creating sample data for Supplier Portal...")
    
    # Register supplier
    supplier_data = {
        'username': 'supplier1',
        'email': 'supplier1@abcsupplies.com',
        'password': 'password123',
        'company_name': 'ABC Supplies Inc',
        'contact_person': 'John Smith',
        'phone': '+1-555-0123',
        'address': '123 Business Ave, Commerce City, CC 12345'
    }
    
    try:
        response = requests.post(f'{API_BASE_URL}/auth/register', json=supplier_data)
        if response.status_code == 201:
            print("✓ Supplier account created successfully")
        else:
            print(f"Supplier registration: {response.status_code} - {response.text}")
    except Exception as e:
        print(f"Error creating supplier: {e}")
    
    # Login as supplier to get token
    try:
        login_response = requests.post(f'{API_BASE_URL}/auth/login', json={
            'username': 'supplier1',
            'password': 'password123'
        })
        
        if login_response.status_code == 200:
            token = login_response.json().get('access_token')
            headers = {'Authorization': f'Bearer {token}'}
            print("✓ Supplier login successful")
            
            # Create sample purchase orders (simulating buyer creating them)
            sample_pos = [
                {
                    'po_number': 'PO-2024-001',
                    'total_amount': 15000.00,
                    'currency': 'USD',
                    'notes': 'Office supplies and equipment for Q2 2024'
                },
                {
                    'po_number': 'PO-2024-002', 
                    'total_amount': 8500.00,
                    'currency': 'USD',
                    'notes': 'IT hardware and accessories'
                }
            ]
            
            print("✓ Sample purchase orders would be created by buyer system")
            print("✓ Sample data setup complete!")
            
            print("\n" + "="*50)
            print("SUPPLIER PORTAL STAGING DEPLOYMENT")
            print("="*50)
            print(f"Frontend URL: https://ochzkvpi.manus.space")
            print(f"Backend API: Running locally (port 5000)")
            print("\nDemo Credentials:")
            print("Username: supplier1")
            print("Password: password123")
            print("\nFeatures Available:")
            print("- OAuth authentication with ROLE_SUPPLIER scope")
            print("- Purchase order viewing and confirmation")
            print("- Invoice creation and file upload")
            print("- Three-way match workflow")
            print("- Real-time status updates")
            print("- PWA functionality with offline support")
            print("- Responsive design for mobile/desktop")
            print("="*50)
            
        else:
            print(f"Login failed: {login_response.status_code} - {login_response.text}")
            
    except Exception as e:
        print(f"Error during login: {e}")

if __name__ == '__main__':
    create_sample_data()

