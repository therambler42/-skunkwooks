from flask import Blueprint, jsonify, request
from src.models.supplier import PurchaseOrder, POLineItem, POStatus, SupplierProfile, db
from src.auth import require_auth, require_supplier_role
from datetime import datetime

po_bp = Blueprint('purchase_orders', __name__)

@po_bp.route('/purchase-orders', methods=['GET'])
@require_auth('read:purchase_orders')
def get_purchase_orders():
    """Get purchase orders for the authenticated supplier"""
    try:
        user_id = request.current_user['user_id']
        role = request.current_user['role']
        
        if role == 'SUPPLIER':
            # Get supplier's profile
            supplier_profile = SupplierProfile.query.filter_by(user_id=user_id).first()
            if not supplier_profile:
                return jsonify({'error': 'Supplier profile not found'}), 404
            
            # Get POs for this supplier
            pos = PurchaseOrder.query.filter_by(supplier_id=supplier_profile.id).all()
        else:
            # Admin or buyer can see all POs
            pos = PurchaseOrder.query.all()
        
        return jsonify([po.to_dict() for po in pos]), 200
        
    except Exception as e:
        return jsonify({'error': 'Failed to get purchase orders', 'details': str(e)}), 500

@po_bp.route('/purchase-orders/<int:po_id>', methods=['GET'])
@require_auth('read:purchase_orders')
def get_purchase_order(po_id):
    """Get specific purchase order details"""
    try:
        user_id = request.current_user['user_id']
        role = request.current_user['role']
        
        po = PurchaseOrder.query.get(po_id)
        if not po:
            return jsonify({'error': 'Purchase order not found'}), 404
        
        # Check if supplier can access this PO
        if role == 'SUPPLIER':
            supplier_profile = SupplierProfile.query.filter_by(user_id=user_id).first()
            if not supplier_profile or po.supplier_id != supplier_profile.id:
                return jsonify({'error': 'Access denied'}), 403
        
        return jsonify(po.to_dict()), 200
        
    except Exception as e:
        return jsonify({'error': 'Failed to get purchase order', 'details': str(e)}), 500

@po_bp.route('/purchase-orders/<int:po_id>/confirm', methods=['POST'])
@require_auth('update:purchase_order_confirmation')
@require_supplier_role
def confirm_purchase_order(po_id):
    """Confirm purchase order by supplier"""
    try:
        user_id = request.current_user['user_id']
        supplier_profile = SupplierProfile.query.filter_by(user_id=user_id).first()
        
        if not supplier_profile:
            return jsonify({'error': 'Supplier profile not found'}), 404
        
        po = PurchaseOrder.query.get(po_id)
        if not po:
            return jsonify({'error': 'Purchase order not found'}), 404
        
        if po.supplier_id != supplier_profile.id:
            return jsonify({'error': 'Access denied'}), 403
        
        if po.status != POStatus.SENT:
            return jsonify({'error': 'Purchase order cannot be confirmed in current status'}), 400
        
        data = request.get_json() or {}
        
        # Update PO status
        po.status = POStatus.CONFIRMED
        po.confirmed_date = datetime.utcnow()
        if data.get('notes'):
            po.notes = data['notes']
        
        db.session.commit()
        
        return jsonify({
            'message': 'Purchase order confirmed successfully',
            'purchase_order': po.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Failed to confirm purchase order', 'details': str(e)}), 500

@po_bp.route('/purchase-orders', methods=['POST'])
@require_auth()
def create_purchase_order():
    """Create new purchase order (for buyers/admin)"""
    try:
        role = request.current_user['role']
        if role not in ['BUYER', 'ADMIN']:
            return jsonify({'error': 'Only buyers and admins can create purchase orders'}), 403
        
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        # Validate required fields
        required_fields = ['po_number', 'supplier_id', 'total_amount', 'line_items']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Check if PO number already exists
        if PurchaseOrder.query.filter_by(po_number=data['po_number']).first():
            return jsonify({'error': 'PO number already exists'}), 409
        
        # Validate supplier exists
        supplier = SupplierProfile.query.get(data['supplier_id'])
        if not supplier:
            return jsonify({'error': 'Supplier not found'}), 404
        
        # Create PO
        po = PurchaseOrder(
            po_number=data['po_number'],
            supplier_id=data['supplier_id'],
            total_amount=data['total_amount'],
            currency=data.get('currency', 'USD'),
            expected_delivery_date=datetime.fromisoformat(data['expected_delivery_date']) if data.get('expected_delivery_date') else None,
            notes=data.get('notes'),
            status=POStatus.DRAFT
        )
        db.session.add(po)
        db.session.flush()  # Get PO ID
        
        # Create line items
        for item_data in data['line_items']:
            line_item = POLineItem(
                po_id=po.id,
                line_number=item_data['line_number'],
                description=item_data['description'],
                quantity=item_data['quantity'],
                unit_price=item_data['unit_price'],
                total_price=item_data['total_price'],
                unit_of_measure=item_data.get('unit_of_measure', 'EA')
            )
            db.session.add(line_item)
        
        db.session.commit()
        
        return jsonify({
            'message': 'Purchase order created successfully',
            'purchase_order': po.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Failed to create purchase order', 'details': str(e)}), 500

@po_bp.route('/purchase-orders/<int:po_id>/send', methods=['POST'])
@require_auth()
def send_purchase_order(po_id):
    """Send purchase order to supplier"""
    try:
        role = request.current_user['role']
        if role not in ['BUYER', 'ADMIN']:
            return jsonify({'error': 'Only buyers and admins can send purchase orders'}), 403
        
        po = PurchaseOrder.query.get(po_id)
        if not po:
            return jsonify({'error': 'Purchase order not found'}), 404
        
        if po.status != POStatus.DRAFT:
            return jsonify({'error': 'Only draft purchase orders can be sent'}), 400
        
        po.status = POStatus.SENT
        po.order_date = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'message': 'Purchase order sent to supplier',
            'purchase_order': po.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Failed to send purchase order', 'details': str(e)}), 500

