from flask import Blueprint, jsonify, request
from src.models.supplier import User, SupplierProfile, UserRole, db
from src.auth import AuthService, require_auth

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['POST'])
def login():
    """OAuth-style login endpoint for suppliers"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        username = data.get('username')
        password = data.get('password')
        
        if not username or not password:
            return jsonify({'error': 'Username and password are required'}), 400
        
        # Find user
        user = User.query.filter_by(username=username).first()
        if not user or not AuthService.verify_password(password, user.password_hash):
            return jsonify({'error': 'Invalid credentials'}), 401
        
        if not user.is_active:
            return jsonify({'error': 'Account is deactivated'}), 401
        
        # Generate token with limited scope
        token = AuthService.generate_token(user.id, user.role)
        
        # Get user profile
        profile_data = None
        if user.role == UserRole.SUPPLIER and user.supplier_profile:
            profile_data = user.supplier_profile.to_dict()
        
        return jsonify({
            'access_token': token,
            'token_type': 'Bearer',
            'expires_in': 86400,  # 24 hours
            'scope': AuthService._get_scope_for_role(user.role),
            'user': user.to_dict(),
            'profile': profile_data
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Login failed', 'details': str(e)}), 500

@auth_bp.route('/register', methods=['POST'])
def register():
    """Register new supplier account"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        # Validate required fields
        required_fields = ['username', 'email', 'password', 'company_name', 'contact_person']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Check if user already exists
        if User.query.filter_by(username=data['username']).first():
            return jsonify({'error': 'Username already exists'}), 409
        
        if User.query.filter_by(email=data['email']).first():
            return jsonify({'error': 'Email already exists'}), 409
        
        # Create user
        user = User(
            username=data['username'],
            email=data['email'],
            password_hash=AuthService.hash_password(data['password']),
            role=UserRole.SUPPLIER
        )
        db.session.add(user)
        db.session.flush()  # Get user ID
        
        # Create supplier profile
        supplier_profile = SupplierProfile(
            user_id=user.id,
            company_name=data['company_name'],
            contact_person=data['contact_person'],
            phone=data.get('phone'),
            address=data.get('address'),
            tax_id=data.get('tax_id'),
            payment_terms=data.get('payment_terms', '30 days'),
            credit_limit=data.get('credit_limit', 0.00)
        )
        db.session.add(supplier_profile)
        db.session.commit()
        
        return jsonify({
            'message': 'Supplier account created successfully',
            'user': user.to_dict(),
            'profile': supplier_profile.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Registration failed', 'details': str(e)}), 500

@auth_bp.route('/profile', methods=['GET'])
@require_auth('read:profile')
def get_profile():
    """Get current user profile"""
    try:
        user_id = request.current_user['user_id']
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        profile_data = None
        if user.role == UserRole.SUPPLIER and user.supplier_profile:
            profile_data = user.supplier_profile.to_dict()
        
        return jsonify({
            'user': user.to_dict(),
            'profile': profile_data
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Failed to get profile', 'details': str(e)}), 500

@auth_bp.route('/profile', methods=['PUT'])
@require_auth('read:profile')
def update_profile():
    """Update current user profile"""
    try:
        user_id = request.current_user['user_id']
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        # Update user fields
        if 'email' in data:
            user.email = data['email']
        
        # Update supplier profile if exists
        if user.role == UserRole.SUPPLIER and user.supplier_profile:
            profile = user.supplier_profile
            profile.company_name = data.get('company_name', profile.company_name)
            profile.contact_person = data.get('contact_person', profile.contact_person)
            profile.phone = data.get('phone', profile.phone)
            profile.address = data.get('address', profile.address)
            profile.tax_id = data.get('tax_id', profile.tax_id)
            profile.payment_terms = data.get('payment_terms', profile.payment_terms)
        
        db.session.commit()
        
        profile_data = None
        if user.supplier_profile:
            profile_data = user.supplier_profile.to_dict()
        
        return jsonify({
            'message': 'Profile updated successfully',
            'user': user.to_dict(),
            'profile': profile_data
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Failed to update profile', 'details': str(e)}), 500

@auth_bp.route('/verify', methods=['POST'])
def verify_token():
    """Verify token validity"""
    try:
        token = request.headers.get('Authorization')
        if token:
            token = token.split(' ')[1]  # Remove 'Bearer '
        
        if not token:
            return jsonify({'valid': False, 'error': 'No token provided'}), 400
        
        payload = AuthService.verify_token(token)
        if payload:
            return jsonify({
                'valid': True,
                'user_id': payload['user_id'],
                'role': payload['role'],
                'scope': payload.get('scope', []),
                'expires_at': payload['exp']
            }), 200
        else:
            return jsonify({'valid': False, 'error': 'Invalid or expired token'}), 401
            
    except Exception as e:
        return jsonify({'valid': False, 'error': str(e)}), 500

