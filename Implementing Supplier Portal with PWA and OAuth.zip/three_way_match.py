from src.models.supplier import Invoice, InvoiceItem, PurchaseOrder, POLineItem, Receipt, ReceiptItem, POStatus, db
from decimal import Decimal

class ThreeWayMatchService:
    """Service for performing three-way match between PO, Receipt, and Invoice"""
    
    @staticmethod
    def perform_match(invoice_id):
        """
        Perform three-way match for an invoice
        Returns match result with status and discrepancies
        """
        try:
            invoice = Invoice.query.get(invoice_id)
            if not invoice:
                return {'status': 'ERROR', 'message': 'Invoice not found'}
            
            po = invoice.purchase_order
            if not po:
                return {'status': 'ERROR', 'message': 'Purchase order not found'}
            
            # Get receipts for this PO
            receipts = Receipt.query.filter_by(po_id=po.id).all()
            if not receipts:
                return {'status': 'PENDING', 'message': 'No receipts found for this PO'}
            
            # Perform the three-way match
            match_result = {
                'status': 'MATCHED',
                'discrepancies': [],
                'po_total': float(po.total_amount),
                'invoice_total': float(invoice.total_amount),
                'received_items': [],
                'invoice_items': [],
                'summary': {}
            }
            
            # Check amount match
            po_amount = float(po.total_amount)
            invoice_amount = float(invoice.total_amount)
            amount_tolerance = 0.01  # 1 cent tolerance
            
            if abs(po_amount - invoice_amount) > amount_tolerance:
                match_result['discrepancies'].append({
                    'type': 'AMOUNT_MISMATCH',
                    'description': f'PO amount ({po_amount}) does not match invoice amount ({invoice_amount})',
                    'po_amount': po_amount,
                    'invoice_amount': invoice_amount,
                    'difference': invoice_amount - po_amount
                })
            
            # Check line item matches
            invoice_items = InvoiceItem.query.filter_by(invoice_id=invoice_id).all()
            po_line_items = POLineItem.query.filter_by(po_id=po.id).all()
            
            # Create dictionaries for easier lookup
            po_items_dict = {item.id: item for item in po_line_items}
            received_quantities = {}
            
            # Calculate received quantities per PO line item
            for receipt in receipts:
                for receipt_item in receipt.receipt_items:
                    po_line_id = receipt_item.po_line_item_id
                    if po_line_id not in received_quantities:
                        received_quantities[po_line_id] = 0
                    received_quantities[po_line_id] += float(receipt_item.quantity_received)
            
            # Check each invoice item against PO and receipts
            for inv_item in invoice_items:
                po_line_item = po_items_dict.get(inv_item.po_line_item_id)
                if not po_line_item:
                    match_result['discrepancies'].append({
                        'type': 'INVALID_LINE_ITEM',
                        'description': f'Invoice line item references non-existent PO line item {inv_item.po_line_item_id}'
                    })
                    continue
                
                # Check quantity
                invoice_qty = float(inv_item.quantity)
                po_qty = float(po_line_item.quantity)
                received_qty = received_quantities.get(inv_item.po_line_item_id, 0)
                
                if invoice_qty > received_qty:
                    match_result['discrepancies'].append({
                        'type': 'QUANTITY_MISMATCH',
                        'description': f'Invoice quantity ({invoice_qty}) exceeds received quantity ({received_qty}) for item {po_line_item.description}',
                        'po_line_item_id': inv_item.po_line_item_id,
                        'invoice_quantity': invoice_qty,
                        'received_quantity': received_qty,
                        'po_quantity': po_qty
                    })
                
                # Check unit price
                invoice_price = float(inv_item.unit_price)
                po_price = float(po_line_item.unit_price)
                price_tolerance = 0.01  # 1 cent tolerance
                
                if abs(invoice_price - po_price) > price_tolerance:
                    match_result['discrepancies'].append({
                        'type': 'PRICE_MISMATCH',
                        'description': f'Invoice unit price ({invoice_price}) does not match PO unit price ({po_price}) for item {po_line_item.description}',
                        'po_line_item_id': inv_item.po_line_item_id,
                        'invoice_price': invoice_price,
                        'po_price': po_price,
                        'difference': invoice_price - po_price
                    })
                
                # Add to summary
                match_result['invoice_items'].append({
                    'po_line_item_id': inv_item.po_line_item_id,
                    'description': inv_item.description,
                    'invoice_quantity': invoice_qty,
                    'invoice_price': invoice_price,
                    'po_quantity': po_qty,
                    'po_price': po_price,
                    'received_quantity': received_qty
                })
            
            # Add received items summary
            for po_line_id, received_qty in received_quantities.items():
                po_line_item = po_items_dict.get(po_line_id)
                if po_line_item:
                    match_result['received_items'].append({
                        'po_line_item_id': po_line_id,
                        'description': po_line_item.description,
                        'po_quantity': float(po_line_item.quantity),
                        'received_quantity': received_qty
                    })
            
            # Determine final status
            if match_result['discrepancies']:
                match_result['status'] = 'DISCREPANCY'
                invoice.three_way_match_status = 'DISCREPANCY'
            else:
                match_result['status'] = 'MATCHED'
                invoice.three_way_match_status = 'MATCHED'
                # Update PO status to MATCHED if invoice is approved
                if invoice.status.value == 'APPROVED':
                    po.status = POStatus.MATCHED
            
            # Create summary
            match_result['summary'] = {
                'total_discrepancies': len(match_result['discrepancies']),
                'amount_match': abs(po_amount - invoice_amount) <= amount_tolerance,
                'all_items_received': all(
                    received_quantities.get(item.po_line_item_id, 0) >= float(item.quantity)
                    for item in invoice_items
                ),
                'price_match': not any(
                    disc['type'] == 'PRICE_MISMATCH' for disc in match_result['discrepancies']
                )
            }
            
            db.session.commit()
            return match_result
            
        except Exception as e:
            db.session.rollback()
            return {
                'status': 'ERROR',
                'message': f'Three-way match failed: {str(e)}'
            }
    
    @staticmethod
    def get_match_status(invoice_id):
        """Get current three-way match status for an invoice"""
        try:
            invoice = Invoice.query.get(invoice_id)
            if not invoice:
                return {'status': 'ERROR', 'message': 'Invoice not found'}
            
            return {
                'status': invoice.three_way_match_status,
                'invoice_id': invoice_id,
                'po_id': invoice.po_id,
                'last_updated': invoice.updated_at.isoformat() if invoice.updated_at else None
            }
            
        except Exception as e:
            return {
                'status': 'ERROR',
                'message': f'Failed to get match status: {str(e)}'
            }
    
    @staticmethod
    def approve_with_discrepancies(invoice_id, approved_by, notes=None):
        """Approve invoice even with discrepancies (requires special permission)"""
        try:
            invoice = Invoice.query.get(invoice_id)
            if not invoice:
                return {'status': 'ERROR', 'message': 'Invoice not found'}
            
            invoice.three_way_match_status = 'APPROVED_WITH_DISCREPANCIES'
            if notes:
                invoice.notes = f"{invoice.notes or ''}\n\nApproved with discrepancies by {approved_by}: {notes}"
            
            # Update PO status
            po = invoice.purchase_order
            po.status = POStatus.MATCHED
            
            db.session.commit()
            
            return {
                'status': 'SUCCESS',
                'message': 'Invoice approved with discrepancies',
                'invoice_id': invoice_id
            }
            
        except Exception as e:
            db.session.rollback()
            return {
                'status': 'ERROR',
                'message': f'Failed to approve invoice: {str(e)}'
            }

