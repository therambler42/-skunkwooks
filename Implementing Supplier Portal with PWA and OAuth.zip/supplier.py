from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import DECIMAL
from datetime import datetime
from enum import Enum

db = SQLAlchemy()

class UserRole(Enum):
    ADMIN = "ADMIN"
    SUPPLIER = "SUPPLIER"
    BUYER = "BUYER"

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.Enum(UserRole), nullable=False, default=UserRole.SUPPLIER)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationship to supplier profile
    supplier_profile = db.relationship('SupplierProfile', backref='user', uselist=False)

    def __repr__(self):
        return f'<User {self.username}>'

    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'role': self.role.value,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class SupplierProfile(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    company_name = db.Column(db.String(200), nullable=False)
    contact_person = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20))
    address = db.Column(db.Text)
    tax_id = db.Column(db.String(50))
    payment_terms = db.Column(db.String(100))
    credit_limit = db.Column(DECIMAL(15, 2), default=0.00)
    is_approved = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<SupplierProfile {self.company_name}>'

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'company_name': self.company_name,
            'contact_person': self.contact_person,
            'phone': self.phone,
            'address': self.address,
            'tax_id': self.tax_id,
            'payment_terms': self.payment_terms,
            'credit_limit': float(self.credit_limit) if self.credit_limit else 0.0,
            'is_approved': self.is_approved,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class POStatus(Enum):
    DRAFT = "DRAFT"
    SENT = "SENT"
    CONFIRMED = "CONFIRMED"
    PARTIALLY_RECEIVED = "PARTIALLY_RECEIVED"
    RECEIVED = "RECEIVED"
    INVOICED = "INVOICED"
    MATCHED = "MATCHED"
    PAID = "PAID"
    CANCELLED = "CANCELLED"

class PurchaseOrder(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    po_number = db.Column(db.String(50), unique=True, nullable=False)
    supplier_id = db.Column(db.Integer, db.ForeignKey('supplier_profile.id'), nullable=False)
    status = db.Column(db.Enum(POStatus), nullable=False, default=POStatus.DRAFT)
    total_amount = db.Column(DECIMAL(15, 2), nullable=False)
    currency = db.Column(db.String(3), default='USD')
    order_date = db.Column(db.DateTime, default=datetime.utcnow)
    expected_delivery_date = db.Column(db.DateTime)
    confirmed_date = db.Column(db.DateTime)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    supplier = db.relationship('SupplierProfile', backref='purchase_orders')
    line_items = db.relationship('POLineItem', backref='purchase_order', cascade='all, delete-orphan')
    receipts = db.relationship('Receipt', backref='purchase_order', cascade='all, delete-orphan')
    invoices = db.relationship('Invoice', backref='purchase_order', cascade='all, delete-orphan')

    def __repr__(self):
        return f'<PurchaseOrder {self.po_number}>'

    def to_dict(self):
        return {
            'id': self.id,
            'po_number': self.po_number,
            'supplier_id': self.supplier_id,
            'status': self.status.value,
            'total_amount': float(self.total_amount),
            'currency': self.currency,
            'order_date': self.order_date.isoformat() if self.order_date else None,
            'expected_delivery_date': self.expected_delivery_date.isoformat() if self.expected_delivery_date else None,
            'confirmed_date': self.confirmed_date.isoformat() if self.confirmed_date else None,
            'notes': self.notes,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'supplier': self.supplier.to_dict() if self.supplier else None,
            'line_items': [item.to_dict() for item in self.line_items],
            'receipts': [receipt.to_dict() for receipt in self.receipts],
            'invoices': [invoice.to_dict() for invoice in self.invoices]
        }

class POLineItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    po_id = db.Column(db.Integer, db.ForeignKey('purchase_order.id'), nullable=False)
    line_number = db.Column(db.Integer, nullable=False)
    description = db.Column(db.String(500), nullable=False)
    quantity = db.Column(DECIMAL(10, 2), nullable=False)
    unit_price = db.Column(DECIMAL(15, 2), nullable=False)
    total_price = db.Column(DECIMAL(15, 2), nullable=False)
    unit_of_measure = db.Column(db.String(20), default='EA')
    
    def __repr__(self):
        return f'<POLineItem {self.line_number}>'

    def to_dict(self):
        return {
            'id': self.id,
            'po_id': self.po_id,
            'line_number': self.line_number,
            'description': self.description,
            'quantity': float(self.quantity),
            'unit_price': float(self.unit_price),
            'total_price': float(self.total_price),
            'unit_of_measure': self.unit_of_measure
        }

class ReceiptStatus(Enum):
    PENDING = "PENDING"
    RECEIVED = "RECEIVED"
    REJECTED = "REJECTED"

class Receipt(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    po_id = db.Column(db.Integer, db.ForeignKey('purchase_order.id'), nullable=False)
    receipt_number = db.Column(db.String(50), unique=True, nullable=False)
    status = db.Column(db.Enum(ReceiptStatus), nullable=False, default=ReceiptStatus.PENDING)
    received_date = db.Column(db.DateTime, default=datetime.utcnow)
    received_by = db.Column(db.String(100))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    receipt_items = db.relationship('ReceiptItem', backref='receipt', cascade='all, delete-orphan')

    def __repr__(self):
        return f'<Receipt {self.receipt_number}>'

    def to_dict(self):
        return {
            'id': self.id,
            'po_id': self.po_id,
            'receipt_number': self.receipt_number,
            'status': self.status.value,
            'received_date': self.received_date.isoformat() if self.received_date else None,
            'received_by': self.received_by,
            'notes': self.notes,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'receipt_items': [item.to_dict() for item in self.receipt_items]
        }

class ReceiptItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    receipt_id = db.Column(db.Integer, db.ForeignKey('receipt.id'), nullable=False)
    po_line_item_id = db.Column(db.Integer, db.ForeignKey('po_line_item.id'), nullable=False)
    quantity_received = db.Column(DECIMAL(10, 2), nullable=False)
    condition = db.Column(db.String(50), default='Good')
    notes = db.Column(db.Text)
    
    # Relationships
    po_line_item = db.relationship('POLineItem', backref='receipt_items')

    def __repr__(self):
        return f'<ReceiptItem {self.id}>'

    def to_dict(self):
        return {
            'id': self.id,
            'receipt_id': self.receipt_id,
            'po_line_item_id': self.po_line_item_id,
            'quantity_received': float(self.quantity_received),
            'condition': self.condition,
            'notes': self.notes,
            'po_line_item': self.po_line_item.to_dict() if self.po_line_item else None
        }

class InvoiceStatus(Enum):
    DRAFT = "DRAFT"
    SUBMITTED = "SUBMITTED"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    PAID = "PAID"

class Invoice(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    po_id = db.Column(db.Integer, db.ForeignKey('purchase_order.id'), nullable=False)
    invoice_number = db.Column(db.String(50), unique=True, nullable=False)
    supplier_invoice_number = db.Column(db.String(50))
    status = db.Column(db.Enum(InvoiceStatus), nullable=False, default=InvoiceStatus.DRAFT)
    invoice_date = db.Column(db.DateTime, default=datetime.utcnow)
    due_date = db.Column(db.DateTime)
    total_amount = db.Column(DECIMAL(15, 2), nullable=False)
    tax_amount = db.Column(DECIMAL(15, 2), default=0.00)
    currency = db.Column(db.String(3), default='USD')
    file_path = db.Column(db.String(500))  # Path to uploaded invoice file
    notes = db.Column(db.Text)
    three_way_match_status = db.Column(db.String(50), default='PENDING')  # PENDING, MATCHED, DISCREPANCY
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    invoice_items = db.relationship('InvoiceItem', backref='invoice', cascade='all, delete-orphan')

    def __repr__(self):
        return f'<Invoice {self.invoice_number}>'

    def to_dict(self):
        return {
            'id': self.id,
            'po_id': self.po_id,
            'invoice_number': self.invoice_number,
            'supplier_invoice_number': self.supplier_invoice_number,
            'status': self.status.value,
            'invoice_date': self.invoice_date.isoformat() if self.invoice_date else None,
            'due_date': self.due_date.isoformat() if self.due_date else None,
            'total_amount': float(self.total_amount),
            'tax_amount': float(self.tax_amount),
            'currency': self.currency,
            'file_path': self.file_path,
            'notes': self.notes,
            'three_way_match_status': self.three_way_match_status,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'invoice_items': [item.to_dict() for item in self.invoice_items]
        }

class InvoiceItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    invoice_id = db.Column(db.Integer, db.ForeignKey('invoice.id'), nullable=False)
    po_line_item_id = db.Column(db.Integer, db.ForeignKey('po_line_item.id'), nullable=False)
    description = db.Column(db.String(500), nullable=False)
    quantity = db.Column(DECIMAL(10, 2), nullable=False)
    unit_price = db.Column(DECIMAL(15, 2), nullable=False)
    total_price = db.Column(DECIMAL(15, 2), nullable=False)
    
    # Relationships
    po_line_item = db.relationship('POLineItem', backref='invoice_items')

    def __repr__(self):
        return f'<InvoiceItem {self.id}>'

    def to_dict(self):
        return {
            'id': self.id,
            'invoice_id': self.invoice_id,
            'po_line_item_id': self.po_line_item_id,
            'description': self.description,
            'quantity': float(self.quantity),
            'unit_price': float(self.unit_price),
            'total_price': float(self.total_price),
            'po_line_item': self.po_line_item.to_dict() if self.po_line_item else None
        }

