#!/usr/bin/env python3
"""
Update user role in database
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from supplier-portal-api.src.models.supplier import User, UserRole, db
from supplier-portal-api.src.main import app

def update_user_role():
    with app.app_context():
        # Find buyer1 user
        user = User.query.filter_by(username='buyer1').first()
        if user:
            user.role = UserRole.BUYER
            db.session.commit()
            print(f"✓ Updated user {user.username} role to {user.role.value}")
        else:
            print("✗ User buyer1 not found")

if __name__ == "__main__":
    update_user_role()

