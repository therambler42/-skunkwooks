import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useSocket } from '../contexts/SocketContext';
import { api } from '../services/api';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import NotificationCenter from './NotificationCenter';
import {
  Package,
  FileText,
  DollarSign,
  Clock,
  CheckCircle,
  Building2,
  User,
  Mail,
  Phone,
  MapPin,
  CreditCard,
  Calendar,
  Loader2
} from 'lucide-react';
import '../App.css';

const Dashboard = ({ onViewInvoices }) => {
  const { user, profile, logout } = useAuth();
  const { joinPORoom, leavePORoom } = useSocket();
  const [purchaseOrders, setPurchaseOrders] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  // Listen for real-time updates
  useEffect(() => {
    const handlePOUpdate = (event) => {
      const { po_id, data } = event.detail;
      setPurchaseOrders(prev => 
        prev.map(po => 
          po.id === parseInt(po_id) 
            ? { ...po, status: data.status, updated_at: data.updated_at }
            : po
        )
      );
    };

    const handleInvoiceUpdate = (event) => {
      const { invoice_id, data } = event.detail;
      setInvoices(prev => 
        prev.map(invoice => 
          invoice.id === parseInt(invoice_id)
            ? { ...invoice, status: data.status, updated_at: data.updated_at }
            : invoice
        )
      );
    };

    const handleThreeWayMatchUpdate = (event) => {
      const { po_id, match_status, details } = event.detail;
      setPurchaseOrders(prev => 
        prev.map(po => 
          po.id === parseInt(po_id)
            ? { ...po, three_way_match_status: match_status, updated_at: details.updated_at }
            : po
        )
      );
    };

    window.addEventListener('poUpdated', handlePOUpdate);
    window.addEventListener('invoiceUpdated', handleInvoiceUpdate);
    window.addEventListener('threeWayMatchUpdated', handleThreeWayMatchUpdate);

    return () => {
      window.removeEventListener('poUpdated', handlePOUpdate);
      window.removeEventListener('invoiceUpdated', handleInvoiceUpdate);
      window.removeEventListener('threeWayMatchUpdated', handleThreeWayMatchUpdate);
    };
  }, []);

  // Join PO rooms for real-time updates
  useEffect(() => {
    purchaseOrders.forEach(po => {
      joinPORoom(po.id);
    });

    return () => {
      purchaseOrders.forEach(po => {
        leavePORoom(po.id);
      });
    };
  }, [purchaseOrders, joinPORoom, leavePORoom]);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [posResponse, invoicesResponse] = await Promise.all([
        api.get('/purchase-orders'),
        api.get('/invoices')
      ]);
      
      setPurchaseOrders(posResponse.data || []);
      setInvoices(invoicesResponse.data || []);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleConfirmPO = async (poId) => {
    try {
      await api.put(`/purchase-orders/${poId}/confirm`);
      // Update will come through real-time events
    } catch (error) {
      console.error('Error confirming PO:', error);
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      'DRAFT': { variant: 'secondary', className: 'bg-gray-100 text-gray-800' },
      'SENT': { variant: 'default', className: 'bg-blue-100 text-blue-800' },
      'CONFIRMED': { variant: 'default', className: 'bg-green-100 text-green-800' },
      'DELIVERED': { variant: 'default', className: 'bg-purple-100 text-purple-800' },
      'CANCELLED': { variant: 'destructive', className: 'bg-red-100 text-red-800' },
      'PENDING': { variant: 'default', className: 'bg-yellow-100 text-yellow-800' },
      'APPROVED': { variant: 'default', className: 'bg-green-100 text-green-800' },
      'REJECTED': { variant: 'destructive', className: 'bg-red-100 text-red-800' }
    };

    const config = statusConfig[status] || statusConfig['DRAFT'];
    return (
      <Badge variant={config.variant} className={config.className}>
        {status}
      </Badge>
    );
  };

  const stats = {
    totalPOs: purchaseOrders.length,
    pendingConfirmations: purchaseOrders.filter(po => po.status === 'SENT').length,
    totalInvoices: invoices.length,
    pendingInvoices: invoices.filter(inv => inv.status === 'PENDING').length
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-blue-600" />
          <p className="text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Building2 className="h-8 w-8 text-blue-600 mr-3" />
              <div>
                <h1 className="text-xl font-bold text-gray-900">Supplier Portal</h1>
                <p className="text-sm text-gray-500">ABC Supplies Inc</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <NotificationCenter />
              <div className="text-right">
                <p className="text-sm font-medium text-gray-900">{user?.username}</p>
                <p className="text-xs text-gray-500">{user?.email}</p>
              </div>
              <Button variant="outline" onClick={logout}>
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Package className="h-8 w-8 text-blue-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total Purchase Orders</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.totalPOs}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Clock className="h-8 w-8 text-orange-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Pending Confirmations</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.pendingConfirmations}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <FileText className="h-8 w-8 text-green-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total Invoices</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.totalInvoices}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <DollarSign className="h-8 w-8 text-purple-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Pending Invoices</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.pendingInvoices}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Purchase Orders */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Package className="h-5 w-5 mr-2" />
                  Recent Purchase Orders
                </CardTitle>
                <p className="text-sm text-gray-600">View and manage your purchase orders</p>
              </CardHeader>
              <CardContent>
                {purchaseOrders.length === 0 ? (
                  <div className="text-center py-8">
                    <Package className="h-12 w-12 mx-auto text-gray-300 mb-4" />
                    <p className="text-gray-500">No purchase orders found</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {purchaseOrders.map((po) => (
                      <div key={po.id} className="border rounded-lg p-4 hover:bg-gray-50">
                        <div className="flex justify-between items-start mb-2">
                          <h4 className="font-semibold text-gray-900">{po.po_number}</h4>
                          {getStatusBadge(po.status)}
                        </div>
                        <p className="text-sm text-gray-600 mb-2">
                          {po.item_count} items • {formatCurrency(po.total_amount)}
                        </p>
                        <div className="text-xs text-gray-500 space-y-1">
                          <span>Order Date: {formatDate(po.order_date)}</span>
                          {po.expected_delivery_date && (
                            <span>Expected: {formatDate(po.expected_delivery_date)}</span>
                          )}
                        </div>
                        {(po.status === 'SENT' || po.status === 'CONFIRMED') && (
                          <div className="mt-3">
                            {po.status === 'SENT' && (
                              <Button 
                                size="sm" 
                                className="mr-2"
                                onClick={() => handleConfirmPO(po.id)}
                              >
                                <CheckCircle className="h-4 w-4 mr-1" />
                                Confirm Order
                              </Button>
                            )}
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => onViewInvoices && onViewInvoices(po.id)}
                            >
                              {po.status === 'CONFIRMED' ? 'Create Invoice' : 'View Invoices'}
                            </Button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Company Profile & Recent Invoices */}
          <div className="space-y-6">
            {/* Company Profile */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Building2 className="h-5 w-5 mr-2" />
                  Company Profile
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {profile ? (
                  <>
                    <div className="flex items-center text-sm">
                      <User className="h-4 w-4 mr-2 text-gray-400" />
                      <span>Contact: {profile.contact_person}</span>
                    </div>
                    <div className="flex items-center text-sm">
                      <Mail className="h-4 w-4 mr-2 text-gray-400" />
                      <span>Email: {profile.email}</span>
                    </div>
                    <div className="flex items-center text-sm">
                      <Phone className="h-4 w-4 mr-2 text-gray-400" />
                      <span>Phone: {profile.phone}</span>
                    </div>
                    <div className="flex items-start text-sm">
                      <MapPin className="h-4 w-4 mr-2 text-gray-400 mt-0.5" />
                      <div>
                        <span>Address:</span>
                        <div className="text-gray-600 ml-6">
                          {profile.address}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center text-sm">
                      <CreditCard className="h-4 w-4 mr-2 text-gray-400" />
                      <span>Credit Limit: {formatCurrency(profile.credit_limit)}</span>
                    </div>
                    <div className="flex items-center text-sm">
                      <Calendar className="h-4 w-4 mr-2 text-gray-400" />
                      <span>Payment Terms: {profile.payment_terms}</span>
                    </div>
                  </>
                ) : (
                  <p className="text-gray-500">Loading profile...</p>
                )}
              </CardContent>
            </Card>

            {/* Recent Invoices */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <FileText className="h-5 w-5 mr-2" />
                  Recent Invoices
                </CardTitle>
              </CardHeader>
              <CardContent>
                {invoices.length === 0 ? (
                  <div className="text-center py-4">
                    <FileText className="h-8 w-8 mx-auto text-gray-300 mb-2" />
                    <p className="text-gray-500 text-sm">No invoices yet</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {invoices.slice(0, 5).map((invoice) => (
                      <div key={invoice.id} className="flex justify-between items-center py-2 border-b border-gray-100 last:border-b-0">
                        <div>
                          <p className="font-medium text-sm">{invoice.invoice_number}</p>
                          <p className="text-xs text-gray-500">{formatDate(invoice.created_at)}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-medium">{formatCurrency(invoice.total_amount)}</p>
                          {getStatusBadge(invoice.status)}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;

