import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import ApiService from '../services/api';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  FileText, 
  Upload, 
  DollarSign, 
  Calendar,
  CheckCircle,
  Clock,
  AlertCircle,
  ArrowLeft,
  Loader2,
  Plus,
  Trash2
} from 'lucide-react';
import '../App.css';

const InvoiceManagement = ({ poId, onBack }) => {
  const { user } = useAuth();
  const [purchaseOrder, setPurchaseOrder] = useState(null);
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [uploadingFile, setUploadingFile] = useState(null);

  const [invoiceForm, setInvoiceForm] = useState({
    invoice_number: '',
    supplier_invoice_number: '',
    total_amount: '',
    tax_amount: '',
    due_date: '',
    notes: '',
    invoice_items: []
  });

  useEffect(() => {
    loadData();
  }, [poId]);

  const loadData = async () => {
    try {
      setLoading(true);
      const [poResponse, invoicesResponse] = await Promise.all([
        ApiService.getPurchaseOrder(poId),
        ApiService.getInvoices()
      ]);

      setPurchaseOrder(poResponse);
      // Filter invoices for this PO
      const poInvoices = invoicesResponse.filter(inv => inv.po_id === poId);
      setInvoices(poInvoices);

      // Initialize invoice form with PO line items
      if (poResponse.line_items && poResponse.line_items.length > 0) {
        const items = poResponse.line_items.map(item => ({
          po_line_item_id: item.id,
          description: item.description,
          quantity: item.quantity,
          unit_price: item.unit_price,
          total_price: item.total_price
        }));
        setInvoiceForm(prev => ({
          ...prev,
          invoice_items: items,
          total_amount: poResponse.total_amount
        }));
      }
    } catch (err) {
      setError(err.message || 'Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateInvoice = async (e) => {
    e.preventDefault();
    try {
      setLoading(true);
      setError('');
      
      const response = await ApiService.createInvoice(poId, invoiceForm);
      setSuccess('Invoice created successfully!');
      setShowCreateForm(false);
      loadData();
      
      // Reset form
      setInvoiceForm({
        invoice_number: '',
        supplier_invoice_number: '',
        total_amount: '',
        tax_amount: '',
        due_date: '',
        notes: '',
        invoice_items: []
      });
    } catch (err) {
      setError(err.message || 'Failed to create invoice');
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (invoiceId, file) => {
    try {
      setUploadingFile(invoiceId);
      await ApiService.uploadInvoiceFile(invoiceId, file);
      setSuccess('Invoice file uploaded successfully!');
      loadData();
    } catch (err) {
      setError(err.message || 'Failed to upload file');
    } finally {
      setUploadingFile(null);
    }
  };

  const handleSubmitInvoice = async (invoiceId) => {
    try {
      await ApiService.submitInvoice(invoiceId);
      setSuccess('Invoice submitted for approval!');
      loadData();
    } catch (err) {
      setError(err.message || 'Failed to submit invoice');
    }
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      DRAFT: { variant: 'secondary', icon: Clock },
      SUBMITTED: { variant: 'default', icon: Clock },
      APPROVED: { variant: 'default', icon: CheckCircle },
      REJECTED: { variant: 'destructive', icon: AlertCircle },
      PAID: { variant: 'default', icon: DollarSign },
    };

    const config = statusConfig[status] || { variant: 'secondary', icon: Clock };
    const Icon = config.icon;

    return (
      <Badge variant={config.variant} className="flex items-center gap-1">
        <Icon className="h-3 w-3" />
        {status}
      </Badge>
    );
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  if (loading && !purchaseOrder) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-blue-600" />
          <p className="text-gray-600">Loading invoice management...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <Button variant="outline" onClick={onBack} className="mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
          
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Invoice Management</h1>
              <p className="text-gray-600">Purchase Order: {purchaseOrder?.po_number}</p>
            </div>
            <Button onClick={() => setShowCreateForm(true)} disabled={!purchaseOrder || purchaseOrder.status === 'DRAFT'}>
              <Plus className="h-4 w-4 mr-2" />
              Create Invoice
            </Button>
          </div>
        </div>

        {error && (
          <Alert className="mb-6 border-red-200 bg-red-50">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="text-red-800">{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="mb-6 border-green-200 bg-green-50">
            <CheckCircle className="h-4 w-4" />
            <AlertDescription className="text-green-800">{success}</AlertDescription>
          </Alert>
        )}

        {/* Purchase Order Summary */}
        {purchaseOrder && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Purchase Order Details</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <p className="text-sm text-gray-600">PO Number</p>
                  <p className="font-medium">{purchaseOrder.po_number}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Total Amount</p>
                  <p className="font-medium">{formatCurrency(purchaseOrder.total_amount)}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Status</p>
                  {getStatusBadge(purchaseOrder.status)}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Create Invoice Form */}
        {showCreateForm && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Create New Invoice</CardTitle>
              <CardDescription>Create an invoice for this purchase order</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleCreateInvoice} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="invoice_number">Invoice Number</Label>
                    <Input
                      id="invoice_number"
                      value={invoiceForm.invoice_number}
                      onChange={(e) => setInvoiceForm({...invoiceForm, invoice_number: e.target.value})}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="supplier_invoice_number">Your Invoice Number</Label>
                    <Input
                      id="supplier_invoice_number"
                      value={invoiceForm.supplier_invoice_number}
                      onChange={(e) => setInvoiceForm({...invoiceForm, supplier_invoice_number: e.target.value})}
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="total_amount">Total Amount</Label>
                    <Input
                      id="total_amount"
                      type="number"
                      step="0.01"
                      value={invoiceForm.total_amount}
                      onChange={(e) => setInvoiceForm({...invoiceForm, total_amount: e.target.value})}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="tax_amount">Tax Amount</Label>
                    <Input
                      id="tax_amount"
                      type="number"
                      step="0.01"
                      value={invoiceForm.tax_amount}
                      onChange={(e) => setInvoiceForm({...invoiceForm, tax_amount: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="due_date">Due Date</Label>
                    <Input
                      id="due_date"
                      type="date"
                      value={invoiceForm.due_date}
                      onChange={(e) => setInvoiceForm({...invoiceForm, due_date: e.target.value})}
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="notes">Notes</Label>
                  <Textarea
                    id="notes"
                    value={invoiceForm.notes}
                    onChange={(e) => setInvoiceForm({...invoiceForm, notes: e.target.value})}
                    rows={3}
                  />
                </div>

                <div className="flex justify-end space-x-2">
                  <Button type="button" variant="outline" onClick={() => setShowCreateForm(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={loading}>
                    {loading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Creating...
                      </>
                    ) : (
                      'Create Invoice'
                    )}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Invoices List */}
        <Card>
          <CardHeader>
            <CardTitle>Invoices</CardTitle>
            <CardDescription>Manage invoices for this purchase order</CardDescription>
          </CardHeader>
          <CardContent>
            {invoices.length === 0 ? (
              <div className="text-center py-8">
                <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">No invoices created yet</p>
                <p className="text-sm text-gray-400">Create an invoice to get started</p>
              </div>
            ) : (
              <div className="space-y-4">
                {invoices.map((invoice) => (
                  <div key={invoice.id} className="border rounded-lg p-4">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h4 className="font-medium text-gray-900">{invoice.invoice_number}</h4>
                        <p className="text-sm text-gray-600">
                          Supplier Invoice: {invoice.supplier_invoice_number}
                        </p>
                        <p className="text-sm text-gray-600">
                          Amount: {formatCurrency(invoice.total_amount)}
                        </p>
                      </div>
                      {getStatusBadge(invoice.status)}
                    </div>

                    <div className="flex justify-between items-center">
                      <div className="text-sm text-gray-500">
                        <span>Created: {formatDate(invoice.invoice_date)}</span>
                        {invoice.due_date && (
                          <span className="ml-4">Due: {formatDate(invoice.due_date)}</span>
                        )}
                      </div>

                      <div className="flex space-x-2">
                        {invoice.status === 'DRAFT' && (
                          <>
                            <div className="relative">
                              <input
                                type="file"
                                id={`file-${invoice.id}`}
                                className="hidden"
                                accept=".pdf,.png,.jpg,.jpeg,.gif,.doc,.docx"
                                onChange={(e) => {
                                  if (e.target.files[0]) {
                                    handleFileUpload(invoice.id, e.target.files[0]);
                                  }
                                }}
                              />
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => document.getElementById(`file-${invoice.id}`).click()}
                                disabled={uploadingFile === invoice.id}
                              >
                                {uploadingFile === invoice.id ? (
                                  <>
                                    <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                                    Uploading...
                                  </>
                                ) : (
                                  <>
                                    <Upload className="h-4 w-4 mr-1" />
                                    Upload File
                                  </>
                                )}
                              </Button>
                            </div>
                            <Button
                              size="sm"
                              onClick={() => handleSubmitInvoice(invoice.id)}
                            >
                              Submit for Approval
                            </Button>
                          </>
                        )}
                      </div>
                    </div>

                    {invoice.file_path && (
                      <div className="mt-2 text-sm text-green-600">
                        ✓ File uploaded
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default InvoiceManagement;

