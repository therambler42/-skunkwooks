from flask import Blueprint, jsonify, request
from werkzeug.utils import secure_filename
import os
from src.models.supplier import Invoice, InvoiceItem, InvoiceStatus, PurchaseOrder, POStatus, SupplierProfile, db
from src.auth import require_auth, require_supplier_role
from datetime import datetime

invoice_bp = Blueprint('invoices', __name__)

ALLOWED_EXTENSIONS = {'pdf', 'png', 'jpg', 'jpeg', 'gif', 'doc', 'docx'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@invoice_bp.route('/invoices', methods=['GET'])
@require_auth('read:invoices')
def get_invoices():
    """Get invoices for the authenticated user"""
    try:
        user_id = request.current_user['user_id']
        role = request.current_user['role']
        
        if role == 'SUPPLIER':
            # Get supplier's invoices through their POs
            supplier_profile = SupplierProfile.query.filter_by(user_id=user_id).first()
            if not supplier_profile:
                return jsonify({'error': 'Supplier profile not found'}), 404
            
            # Get invoices for POs belonging to this supplier
            invoices = db.session.query(Invoice).join(PurchaseOrder).filter(
                PurchaseOrder.supplier_id == supplier_profile.id
            ).all()
        else:
            # Admin or buyer can see all invoices
            invoices = Invoice.query.all()
        
        return jsonify([invoice.to_dict() for invoice in invoices]), 200
        
    except Exception as e:
        return jsonify({'error': 'Failed to get invoices', 'details': str(e)}), 500

@invoice_bp.route('/invoices/<int:invoice_id>', methods=['GET'])
@require_auth('read:invoices')
def get_invoice(invoice_id):
    """Get specific invoice details"""
    try:
        user_id = request.current_user['user_id']
        role = request.current_user['role']
        
        invoice = Invoice.query.get(invoice_id)
        if not invoice:
            return jsonify({'error': 'Invoice not found'}), 404
        
        # Check if supplier can access this invoice
        if role == 'SUPPLIER':
            supplier_profile = SupplierProfile.query.filter_by(user_id=user_id).first()
            if not supplier_profile or invoice.purchase_order.supplier_id != supplier_profile.id:
                return jsonify({'error': 'Access denied'}), 403
        
        return jsonify(invoice.to_dict()), 200
        
    except Exception as e:
        return jsonify({'error': 'Failed to get invoice', 'details': str(e)}), 500

@invoice_bp.route('/purchase-orders/<int:po_id>/invoices', methods=['POST'])
@require_auth('create:invoices')
@require_supplier_role
def create_invoice(po_id):
    """Create invoice for a purchase order"""
    try:
        user_id = request.current_user['user_id']
        supplier_profile = SupplierProfile.query.filter_by(user_id=user_id).first()
        
        if not supplier_profile:
            return jsonify({'error': 'Supplier profile not found'}), 404
        
        po = PurchaseOrder.query.get(po_id)
        if not po:
            return jsonify({'error': 'Purchase order not found'}), 404
        
        if po.supplier_id != supplier_profile.id:
            return jsonify({'error': 'Access denied'}), 403
        
        if po.status not in [POStatus.CONFIRMED, POStatus.PARTIALLY_RECEIVED, POStatus.RECEIVED]:
            return jsonify({'error': 'Purchase order must be confirmed or received to create invoice'}), 400
        
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        # Validate required fields
        required_fields = ['invoice_number', 'supplier_invoice_number', 'total_amount', 'invoice_items']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Check if invoice number already exists
        if Invoice.query.filter_by(invoice_number=data['invoice_number']).first():
            return jsonify({'error': 'Invoice number already exists'}), 409
        
        # Create invoice
        invoice = Invoice(
            po_id=po_id,
            invoice_number=data['invoice_number'],
            supplier_invoice_number=data['supplier_invoice_number'],
            total_amount=data['total_amount'],
            tax_amount=data.get('tax_amount', 0.00),
            currency=data.get('currency', 'USD'),
            due_date=datetime.fromisoformat(data['due_date']) if data.get('due_date') else None,
            notes=data.get('notes'),
            status=InvoiceStatus.DRAFT
        )
        db.session.add(invoice)
        db.session.flush()  # Get invoice ID
        
        # Create invoice items
        for item_data in data['invoice_items']:
            invoice_item = InvoiceItem(
                invoice_id=invoice.id,
                po_line_item_id=item_data['po_line_item_id'],
                description=item_data['description'],
                quantity=item_data['quantity'],
                unit_price=item_data['unit_price'],
                total_price=item_data['total_price']
            )
            db.session.add(invoice_item)
        
        db.session.commit()
        
        return jsonify({
            'message': 'Invoice created successfully',
            'invoice': invoice.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Failed to create invoice', 'details': str(e)}), 500

@invoice_bp.route('/invoices/<int:invoice_id>/upload', methods=['POST'])
@require_auth('update:invoices')
@require_supplier_role
def upload_invoice_file(invoice_id):
    """Upload invoice file"""
    try:
        user_id = request.current_user['user_id']
        supplier_profile = SupplierProfile.query.filter_by(user_id=user_id).first()
        
        if not supplier_profile:
            return jsonify({'error': 'Supplier profile not found'}), 404
        
        invoice = Invoice.query.get(invoice_id)
        if not invoice:
            return jsonify({'error': 'Invoice not found'}), 404
        
        if invoice.purchase_order.supplier_id != supplier_profile.id:
            return jsonify({'error': 'Access denied'}), 403
        
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if not allowed_file(file.filename):
            return jsonify({'error': 'File type not allowed'}), 400
        
        # Save file
        filename = secure_filename(f"invoice_{invoice_id}_{file.filename}")
        upload_folder = request.current_app.config['UPLOAD_FOLDER']
        file_path = os.path.join(upload_folder, filename)
        file.save(file_path)
        
        # Update invoice with file path
        invoice.file_path = file_path
        db.session.commit()
        
        return jsonify({
            'message': 'Invoice file uploaded successfully',
            'file_path': file_path,
            'invoice': invoice.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Failed to upload invoice file', 'details': str(e)}), 500

@invoice_bp.route('/invoices/<int:invoice_id>/submit', methods=['POST'])
@require_auth('update:invoices')
@require_supplier_role
def submit_invoice(invoice_id):
    """Submit invoice for approval"""
    try:
        user_id = request.current_user['user_id']
        supplier_profile = SupplierProfile.query.filter_by(user_id=user_id).first()
        
        if not supplier_profile:
            return jsonify({'error': 'Supplier profile not found'}), 404
        
        invoice = Invoice.query.get(invoice_id)
        if not invoice:
            return jsonify({'error': 'Invoice not found'}), 404
        
        if invoice.purchase_order.supplier_id != supplier_profile.id:
            return jsonify({'error': 'Access denied'}), 403
        
        if invoice.status != InvoiceStatus.DRAFT:
            return jsonify({'error': 'Only draft invoices can be submitted'}), 400
        
        invoice.status = InvoiceStatus.SUBMITTED
        db.session.commit()
        
        # Trigger three-way match process
        from src.services.three_way_match import ThreeWayMatchService
        match_result = ThreeWayMatchService.perform_match(invoice.id)
        
        return jsonify({
            'message': 'Invoice submitted successfully',
            'invoice': invoice.to_dict(),
            'three_way_match': match_result
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Failed to submit invoice', 'details': str(e)}), 500

