import os
import sys
# DON'T CHANGE THIS PATH
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from flask import Flask
from flask_cors import CORS
from flask_socketio import SocketIO
from src.models.supplier import db
from src.routes.auth import auth_bp
from src.routes.purchase_orders import po_bp
from src.routes.invoices import invoice_bp
from src.routes.receipts import receipt_bp
from src.routes.three_way_match import three_way_match_bp
from src.events import socketio

def create_app():
    app = Flask(__name__)
    
    # Configuration
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
    app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'sqlite:///supplier_portal.db')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    # Initialize extensions
    db.init_app(app)
    CORS(app, origins="*")
    socketio.init_app(app, cors_allowed_origins="*")
    
    # Register blueprints
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(po_bp, url_prefix='/api/purchase-orders')
    app.register_blueprint(invoice_bp, url_prefix='/api/invoices')
    app.register_blueprint(receipt_bp, url_prefix='/api/receipts')
    app.register_blueprint(three_way_match_bp, url_prefix='/api/three-way-match')
    
    # Health check endpoint
    @app.route('/health')
    def health_check():
        return {'status': 'healthy', 'service': 'supplier-portal-api'}
    
    @app.route('/')
    def index():
        return {'message': 'Supplier Portal API', 'version': '1.0.0'}
    
    # Create tables
    with app.app_context():
        db.create_all()
    
    return app

# Create the app instance
app = create_app()

if __name__ == '__main__':
    # For development only
    socketio.run(app, host='0.0.0.0', port=5000, debug=True, allow_unsafe_werkzeug=True)

