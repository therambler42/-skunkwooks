describe('Supplier Portal E2E Tests', () => {
  beforeEach(() => {
    // Setup test data before each test
    cy.setupTestData()
    
    // Intercept API calls
    cy.intercept('POST', '/api/auth/login').as('login')
    cy.intercept('GET', '/api/purchase-orders').as('getPOs')
    cy.intercept('PUT', '/api/purchase-orders/*/confirm').as('confirmPO')
    cy.intercept('POST', '/api/invoices').as('createInvoice')
    cy.intercept('GET', '/api/invoices').as('getInvoices')
  })

  afterEach(() => {
    // Clean up test data after each test
    cy.clearTestData()
  })

  describe('Authentication Flow', () => {
    it('should allow supplier to login successfully', () => {
      cy.visit('/login')
      
      // Check login form is visible
      cy.get('[data-testid="login-form"]').should('be.visible')
      cy.get('[data-testid="username-input"]').should('be.visible')
      cy.get('[data-testid="password-input"]').should('be.visible')
      cy.get('[data-testid="login-button"]').should('be.visible')
      
      // Fill in credentials
      cy.get('[data-testid="username-input"]').type('supplier1')
      cy.get('[data-testid="password-input"]').type('password123')
      
      // Submit login
      cy.get('[data-testid="login-button"]').click()
      
      // Wait for login API call
      cy.waitForApi('@login')
      
      // Should redirect to dashboard
      cy.url().should('include', '/dashboard')
      cy.get('[data-testid="dashboard-header"]').should('contain', 'Supplier Portal')
    })

    it('should show error for invalid credentials', () => {
      cy.visit('/login')
      
      cy.get('[data-testid="username-input"]').type('invalid')
      cy.get('[data-testid="password-input"]').type('wrongpassword')
      cy.get('[data-testid="login-button"]').click()
      
      cy.get('[data-testid="error-message"]').should('be.visible')
      cy.get('[data-testid="error-message"]').should('contain', 'Invalid credentials')
    })

    it('should allow supplier to logout', () => {
      cy.loginAsSupplier()
      
      cy.get('[data-testid="logout-button"]').click()
      cy.url().should('include', '/login')
    })
  })

  describe('Dashboard Functionality', () => {
    beforeEach(() => {
      cy.loginAsSupplier()
    })

    it('should display dashboard with stats and purchase orders', () => {
      // Wait for POs to load
      cy.waitForApi('@getPOs')
      
      // Check stats cards
      cy.get('[data-testid="stats-total-pos"]').should('be.visible')
      cy.get('[data-testid="stats-pending-confirmations"]').should('be.visible')
      cy.get('[data-testid="stats-total-invoices"]').should('be.visible')
      cy.get('[data-testid="stats-pending-invoices"]').should('be.visible')
      
      // Check purchase orders section
      cy.get('[data-testid="purchase-orders-section"]').should('be.visible')
      cy.get('[data-testid="po-item"]').should('have.length.at.least', 1)
    })

    it('should display company profile information', () => {
      cy.get('[data-testid="company-profile"]').should('be.visible')
      cy.get('[data-testid="company-name"]').should('contain', 'ABC Supplies Inc')
      cy.get('[data-testid="contact-person"]').should('be.visible')
      cy.get('[data-testid="company-email"]').should('be.visible')
      cy.get('[data-testid="company-phone"]').should('be.visible')
      cy.get('[data-testid="company-address"]').should('be.visible')
      cy.get('[data-testid="credit-limit"]').should('be.visible')
      cy.get('[data-testid="payment-terms"]').should('be.visible')
    })
  })

  describe('Purchase Order Management', () => {
    beforeEach(() => {
      cy.loginAsSupplier()
      cy.waitForApi('@getPOs')
    })

    it('should allow supplier to confirm a purchase order', () => {
      // Find a PO with SENT status
      cy.get('[data-testid="po-item"]')
        .contains('SENT')
        .parent()
        .within(() => {
          cy.get('[data-testid="confirm-po-button"]').click()
        })
      
      // Wait for confirmation API call
      cy.waitForApi('@confirmPO')
      
      // Check that status updated to CONFIRMED
      cy.get('[data-testid="po-item"]')
        .first()
        .should('contain', 'CONFIRMED')
    })

    it('should show purchase order details correctly', () => {
      cy.get('[data-testid="po-item"]').first().within(() => {
        // Check PO number is displayed
        cy.get('[data-testid="po-number"]').should('be.visible')
        
        // Check amount is displayed
        cy.get('[data-testid="po-amount"]').should('be.visible')
        
        // Check status badge is displayed
        cy.get('[data-testid="po-status"]').should('be.visible')
        
        // Check order date is displayed
        cy.get('[data-testid="po-order-date"]').should('be.visible')
      })
    })
  })

  describe('Invoice Management', () => {
    beforeEach(() => {
      cy.loginAsSupplier()
      cy.waitForApi('@getPOs')
    })

    it('should allow supplier to create an invoice for confirmed PO', () => {
      // Find a confirmed PO and click Create Invoice
      cy.get('[data-testid="po-item"]')
        .contains('CONFIRMED')
        .parent()
        .within(() => {
          cy.get('[data-testid="create-invoice-button"]').click()
        })
      
      // Should navigate to invoice creation form
      cy.get('[data-testid="invoice-form"]').should('be.visible')
      
      // Fill in invoice details
      cy.get('[data-testid="invoice-number-input"]').type('INV-E2E-001')
      cy.get('[data-testid="supplier-invoice-number-input"]').type('SUPP-E2E-001')
      cy.get('[data-testid="tax-amount-input"]').type('150')
      cy.get('[data-testid="due-date-input"]').type('2025-07-08')
      cy.get('[data-testid="notes-input"]').type('E2E test invoice')
      
      // Submit invoice
      cy.get('[data-testid="create-invoice-button"]').click()
      
      // Wait for invoice creation
      cy.waitForApi('@createInvoice')
      
      // Should show success message
      cy.get('[data-testid="success-message"]').should('contain', 'Invoice created successfully')
    })

    it('should allow supplier to upload invoice file', () => {
      // Create an invoice first
      cy.get('[data-testid="po-item"]')
        .contains('CONFIRMED')
        .parent()
        .within(() => {
          cy.get('[data-testid="create-invoice-button"]').click()
        })
      
      cy.get('[data-testid="invoice-number-input"]').type('INV-E2E-002')
      cy.get('[data-testid="supplier-invoice-number-input"]').type('SUPP-E2E-002')
      cy.get('[data-testid="tax-amount-input"]').type('200')
      cy.get('[data-testid="due-date-input"]').type('2025-07-15')
      cy.get('[data-testid="create-invoice-button"]').click()
      
      cy.waitForApi('@createInvoice')
      
      // Upload file
      cy.get('[data-testid="file-upload-input"]').selectFile('cypress/fixtures/sample-invoice.pdf', { force: true })
      cy.get('[data-testid="upload-button"]').click()
      
      // Should show upload success
      cy.get('[data-testid="upload-success"]').should('be.visible')
    })

    it('should display invoice list with correct information', () => {
      // Navigate to invoices view
      cy.get('[data-testid="view-invoices-button"]').first().click()
      
      cy.waitForApi('@getInvoices')
      
      // Check invoice list
      cy.get('[data-testid="invoice-list"]').should('be.visible')
      cy.get('[data-testid="invoice-item"]').should('have.length.at.least', 0)
      
      // If invoices exist, check their structure
      cy.get('body').then(($body) => {
        if ($body.find('[data-testid="invoice-item"]').length > 0) {
          cy.get('[data-testid="invoice-item"]').first().within(() => {
            cy.get('[data-testid="invoice-number"]').should('be.visible')
            cy.get('[data-testid="invoice-amount"]').should('be.visible')
            cy.get('[data-testid="invoice-status"]').should('be.visible')
            cy.get('[data-testid="invoice-date"]').should('be.visible')
          })
        }
      })
    })
  })

  describe('Real-time Updates', () => {
    beforeEach(() => {
      cy.loginAsSupplier()
      cy.waitForApi('@getPOs')
    })

    it('should show notification center with connection status', () => {
      // Check notification bell is visible
      cy.get('[data-testid="notification-bell"]').should('be.visible')
      
      // Click to open notification panel
      cy.get('[data-testid="notification-bell"]').click()
      cy.get('[data-testid="notification-panel"]').should('be.visible')
      
      // Check connection status indicator
      cy.get('[data-testid="connection-status"]').should('be.visible')
      cy.get('[data-testid="connection-status"]').should('contain', 'Connected')
    })

    it('should receive real-time notifications for PO updates', () => {
      // Confirm a PO to trigger real-time update
      cy.get('[data-testid="po-item"]')
        .contains('SENT')
        .parent()
        .within(() => {
          cy.get('[data-testid="confirm-po-button"]').click()
        })
      
      cy.waitForApi('@confirmPO')
      
      // Check for notification
      cy.get('[data-testid="notification-bell"]').should('have.class', 'has-notifications')
      
      // Open notifications and check message
      cy.checkNotification('Purchase Order')
    })
  })

  describe('Responsive Design', () => {
    beforeEach(() => {
      cy.loginAsSupplier()
    })

    it('should work correctly on mobile viewport', () => {
      cy.viewport('iphone-x')
      
      // Check that dashboard is responsive
      cy.get('[data-testid="dashboard-header"]').should('be.visible')
      cy.get('[data-testid="stats-cards"]').should('be.visible')
      cy.get('[data-testid="purchase-orders-section"]').should('be.visible')
      
      // Check mobile navigation if applicable
      cy.get('body').then(($body) => {
        if ($body.find('[data-testid="mobile-menu-button"]').length > 0) {
          cy.get('[data-testid="mobile-menu-button"]').click()
          cy.get('[data-testid="mobile-menu"]').should('be.visible')
        }
      })
    })

    it('should work correctly on tablet viewport', () => {
      cy.viewport('ipad-2')
      
      cy.get('[data-testid="dashboard-header"]').should('be.visible')
      cy.get('[data-testid="stats-cards"]').should('be.visible')
      cy.get('[data-testid="purchase-orders-section"]').should('be.visible')
      cy.get('[data-testid="company-profile"]').should('be.visible')
    })
  })

  describe('PWA Features', () => {
    it('should have service worker registered', () => {
      cy.visit('/')
      
      cy.window().then((win) => {
        expect(win.navigator.serviceWorker).to.exist
      })
    })

    it('should have manifest.json accessible', () => {
      cy.request('/manifest.json').then((response) => {
        expect(response.status).to.eq(200)
        expect(response.body).to.have.property('name')
        expect(response.body).to.have.property('short_name')
        expect(response.body).to.have.property('icons')
      })
    })
  })
})

