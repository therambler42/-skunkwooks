from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from functools import wraps
from src.models.user import db, User, UserRole, Organization, AIUsage, AISession, PromptTemplate
from sqlalchemy import func, desc
from datetime import datetime, timedelta

operator_bp = Blueprint('operator', __name__)

def require_operator_role(f):
    """Decorator to require OPERATOR role"""
    @wraps(f)
    @jwt_required()
    def decorated_function(*args, **kwargs):
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        if not user or user.role != UserRole.OPERATOR:
            return jsonify({'error': 'Operator access required'}), 403
        
        return f(*args, **kwargs)
    return decorated_function

@operator_bp.route('/usage', methods=['GET'])
@require_operator_role
def get_usage_metrics():
    """Get AI usage metrics for operator dashboard"""
    try:
        # Get query parameters for filtering
        period = request.args.get('period', 'day')  # day, week, month
        org_id = request.args.get('org_id')
        user_id = request.args.get('user_id')
        
        # Calculate date range based on period
        now = datetime.utcnow()
        if period == 'day':
            start_date = now - timedelta(days=1)
        elif period == 'week':
            start_date = now - timedelta(weeks=1)
        elif period == 'month':
            start_date = now - timedelta(days=30)
        else:
            start_date = now - timedelta(days=1)
        
        # Base query
        query = AIUsage.query.filter(AIUsage.timestamp >= start_date)
        
        # Apply filters
        if org_id:
            query = query.filter(AIUsage.organization_id == org_id)
        if user_id:
            query = query.filter(AIUsage.user_id == user_id)
        
        # Get usage by organization
        org_usage = db.session.query(
            Organization.id,
            Organization.name,
            func.sum(AIUsage.credits_used).label('total_credits'),
            func.count(AIUsage.id).label('total_requests')
        ).join(AIUsage).filter(
            AIUsage.timestamp >= start_date
        ).group_by(Organization.id, Organization.name).all()
        
        # Get usage by user
        user_usage = db.session.query(
            User.id,
            User.username,
            User.organization_id,
            func.sum(AIUsage.credits_used).label('total_credits'),
            func.count(AIUsage.id).label('total_requests')
        ).join(AIUsage).filter(
            AIUsage.timestamp >= start_date
        ).group_by(User.id, User.username, User.organization_id).all()
        
        # Get usage by model
        model_usage = db.session.query(
            AIUsage.model_name,
            func.sum(AIUsage.credits_used).label('total_credits'),
            func.count(AIUsage.id).label('total_requests')
        ).filter(
            AIUsage.timestamp >= start_date
        ).group_by(AIUsage.model_name).all()
        
        # Get daily usage trend
        daily_usage = db.session.query(
            func.date(AIUsage.timestamp).label('date'),
            func.sum(AIUsage.credits_used).label('total_credits'),
            func.count(AIUsage.id).label('total_requests')
        ).filter(
            AIUsage.timestamp >= start_date
        ).group_by(func.date(AIUsage.timestamp)).order_by('date').all()
        
        # Get organization credit limits and usage
        org_limits = db.session.query(
            Organization.id,
            Organization.name,
            Organization.credit_limit,
            Organization.credits_used,
            Organization.rate_limit_per_hour
        ).all()
        
        return jsonify({
            'period': period,
            'start_date': start_date.isoformat(),
            'end_date': now.isoformat(),
            'organization_usage': [
                {
                    'org_id': org.id,
                    'org_name': org.name,
                    'total_credits': int(org.total_credits or 0),
                    'total_requests': int(org.total_requests or 0)
                }
                for org in org_usage
            ],
            'user_usage': [
                {
                    'user_id': user.id,
                    'username': user.username,
                    'organization_id': user.organization_id,
                    'total_credits': int(user.total_credits or 0),
                    'total_requests': int(user.total_requests or 0)
                }
                for user in user_usage
            ],
            'model_usage': [
                {
                    'model_name': model.model_name,
                    'total_credits': int(model.total_credits or 0),
                    'total_requests': int(model.total_requests or 0)
                }
                for model in model_usage
            ],
            'daily_trend': [
                {
                    'date': day.date.isoformat(),
                    'total_credits': int(day.total_credits or 0),
                    'total_requests': int(day.total_requests or 0)
                }
                for day in daily_usage
            ],
            'organization_limits': [
                {
                    'org_id': org.id,
                    'org_name': org.name,
                    'credit_limit': org.credit_limit,
                    'credits_used': org.credits_used,
                    'credits_remaining': org.credit_limit - org.credits_used,
                    'rate_limit_per_hour': org.rate_limit_per_hour
                }
                for org in org_limits
            ]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@operator_bp.route('/sessions', methods=['GET'])
@require_operator_role
def get_flagged_sessions():
    """Get flagged AI sessions for review"""
    try:
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 20))
        flagged_only = request.args.get('flagged_only', 'true').lower() == 'true'
        
        query = AISession.query
        
        if flagged_only:
            query = query.filter(AISession.is_flagged == True)
        
        # Order by most recent first
        query = query.order_by(desc(AISession.created_at))
        
        # Paginate results
        sessions = query.paginate(
            page=page, 
            per_page=per_page, 
            error_out=False
        )
        
        return jsonify({
            'sessions': [session.to_dict() for session in sessions.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': sessions.total,
                'pages': sessions.pages,
                'has_next': sessions.has_next,
                'has_prev': sessions.has_prev
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@operator_bp.route('/sessions/<int:session_id>', methods=['PATCH'])
@require_operator_role
def update_session(session_id):
    """Flag/unflag or edit AI session response"""
    try:
        session = AISession.query.get(session_id)
        if not session:
            return jsonify({'error': 'Session not found'}), 404
        
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        operator_id = get_jwt_identity()
        
        # Handle flagging/unflagging
        if 'is_flagged' in data:
            session.is_flagged = data['is_flagged']
            session.flag_reason = data.get('flag_reason')
        
        # Handle response editing
        if 'response' in data:
            # Store original response if not already stored
            if not session.original_response:
                session.original_response = session.response
            
            session.response = data['response']
            session.is_edited = True
            session.edited_by = operator_id
        
        session.updated_at = datetime.utcnow()
        db.session.commit()
        
        # Broadcast real-time update
        from src.websocket_handlers import broadcast_session_update
        broadcast_session_update(session_id, session.to_dict(), 'updated')
        
        return jsonify({
            'message': 'Session updated successfully',
            'session': session.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@operator_bp.route('/prompts', methods=['GET'])
@require_operator_role
def get_prompt_templates():
    """Get all prompt templates"""
    try:
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 20))
        active_only = request.args.get('active_only', 'false').lower() == 'true'
        
        query = PromptTemplate.query
        
        if active_only:
            query = query.filter(PromptTemplate.is_active == True)
        
        # Order by most recent first
        query = query.order_by(desc(PromptTemplate.updated_at))
        
        # Paginate results
        templates = query.paginate(
            page=page, 
            per_page=per_page, 
            error_out=False
        )
        
        return jsonify({
            'templates': [template.to_dict() for template in templates.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': templates.total,
                'pages': templates.pages,
                'has_next': templates.has_next,
                'has_prev': templates.has_prev
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@operator_bp.route('/prompts', methods=['POST'])
@require_operator_role
def create_prompt_template():
    """Create a new prompt template"""
    try:
        data = request.get_json()
        required_fields = ['name', 'template', 'model_name']
        
        if not data or not all(field in data for field in required_fields):
            return jsonify({'error': 'Name, template, and model_name required'}), 400
        
        operator_id = get_jwt_identity()
        
        # Check if template name already exists
        existing = PromptTemplate.query.filter_by(name=data['name']).first()
        if existing:
            return jsonify({'error': 'Template name already exists'}), 409
        
        template = PromptTemplate(
            name=data['name'],
            description=data.get('description'),
            template=data['template'],
            model_name=data['model_name'],
            version=1,
            created_by=operator_id
        )
        
        db.session.add(template)
        db.session.commit()
        
        return jsonify({
            'message': 'Template created successfully',
            'template': template.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@operator_bp.route('/prompts/<int:template_id>', methods=['PUT'])
@require_operator_role
def update_prompt_template(template_id):
    """Update an existing prompt template"""
    try:
        template = PromptTemplate.query.get(template_id)
        if not template:
            return jsonify({'error': 'Template not found'}), 404
        
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        # Update fields
        if 'name' in data:
            template.name = data['name']
        if 'description' in data:
            template.description = data['description']
        if 'template' in data:
            template.template = data['template']
        if 'model_name' in data:
            template.model_name = data['model_name']
        if 'is_active' in data:
            template.is_active = data['is_active']
        
        # Increment version if template content changed
        if 'template' in data:
            template.version += 1
        
        template.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'message': 'Template updated successfully',
            'template': template.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@operator_bp.route('/prompts/<int:template_id>', methods=['DELETE'])
@require_operator_role
def delete_prompt_template(template_id):
    """Delete a prompt template"""
    try:
        template = PromptTemplate.query.get(template_id)
        if not template:
            return jsonify({'error': 'Template not found'}), 404
        
        db.session.delete(template)
        db.session.commit()
        
        return jsonify({'message': 'Template deleted successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@operator_bp.route('/organizations/<int:org_id>/limits', methods=['PATCH'])
@require_operator_role
def update_organization_limits(org_id):
    """Update organization credit and rate limits"""
    try:
        org = Organization.query.get(org_id)
        if not org:
            return jsonify({'error': 'Organization not found'}), 404
        
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        # Validate credit limit (must be <= 1000)
        if 'credit_limit' in data:
            credit_limit = data['credit_limit']
            if credit_limit > 1000:
                return jsonify({'error': 'Credit limit cannot exceed 1000'}), 400
            org.credit_limit = credit_limit
        
        if 'rate_limit_per_hour' in data:
            org.rate_limit_per_hour = data['rate_limit_per_hour']
        
        db.session.commit()
        
        return jsonify({
            'message': 'Organization limits updated successfully',
            'organization': org.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

