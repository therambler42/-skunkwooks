#!/usr/bin/env python3
"""
Test runner for the Operator Dashboard
Runs all tests and generates coverage report
"""

import sys
import os
import unittest
import coverage

# Add the project root to the Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

def run_tests():
    """Run all tests with coverage"""
    
    # Initialize coverage
    cov = coverage.Coverage()
    cov.start()
    
    # Discover and run tests
    loader = unittest.TestLoader()
    start_dir = os.path.dirname(__file__)
    suite = loader.discover(start_dir, pattern='test_*.py')
    
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # Stop coverage and generate report
    cov.stop()
    cov.save()
    
    print("\n" + "="*50)
    print("COVERAGE REPORT")
    print("="*50)
    
    # Generate coverage report
    cov.report(show_missing=True)
    
    # Generate HTML coverage report
    try:
        cov.html_report(directory='htmlcov')
        print(f"\nHTML coverage report generated in: {os.path.abspath('htmlcov')}")
    except Exception as e:
        print(f"Could not generate HTML report: {e}")
    
    # Check if coverage meets minimum requirement (90%)
    total_coverage = cov.report(show_missing=False)
    
    print(f"\nTotal Coverage: {total_coverage:.1f}%")
    
    if total_coverage >= 90.0:
        print("✅ Coverage requirement met (≥90%)")
        coverage_passed = True
    else:
        print("❌ Coverage requirement not met (≥90%)")
        coverage_passed = False
    
    # Return overall test result
    tests_passed = result.wasSuccessful()
    
    print(f"\nTests Passed: {'✅' if tests_passed else '❌'}")
    print(f"Coverage Passed: {'✅' if coverage_passed else '❌'}")
    
    return tests_passed and coverage_passed

if __name__ == '__main__':
    success = run_tests()
    sys.exit(0 if success else 1)

