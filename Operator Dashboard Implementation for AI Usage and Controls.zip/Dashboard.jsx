import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { useAuth } from '../hooks/useAuth'
import { useWebSocket } from '../hooks/useWebSocket'
import { UsageMetrics } from './UsageMetrics'
import { SessionsManager } from './SessionsManager'
import { PromptTemplateManager } from './PromptTemplateManager'
import { OrganizationLimits } from './OrganizationLimits'
import { LogOut, BarChart3, MessageSquare, FileText, Settings, Wifi, WifiOff, Bell } from 'lucide-react'

export function Dashboard() {
  const { user, logout } = useAuth()
  const { 
    connected, 
    sessionUpdates, 
    usageUpdates, 
    templateUpdates, 
    organizationUpdates,
    clearSessionUpdates,
    clearUsageUpdates,
    clearTemplateUpdates,
    clearOrganizationUpdates
  } = useWebSocket()
  
  const [showNotifications, setShowNotifications] = useState(false)

  const totalUpdates = sessionUpdates.length + templateUpdates.length + organizationUpdates.length

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <BarChart3 className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-gray-900">AI Operator Dashboard</h1>
              <p className="text-sm text-gray-500">Monitor and control AI usage across organizations</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            {/* WebSocket Connection Status */}
            <div className="flex items-center space-x-2">
              {connected ? (
                <Badge variant="default" className="flex items-center space-x-1">
                  <Wifi className="w-3 h-3" />
                  <span>Live</span>
                </Badge>
              ) : (
                <Badge variant="destructive" className="flex items-center space-x-1">
                  <WifiOff className="w-3 h-3" />
                  <span>Offline</span>
                </Badge>
              )}
            </div>

            {/* Real-time Notifications */}
            {totalUpdates > 0 && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowNotifications(!showNotifications)}
                className="relative"
              >
                <Bell className="w-4 h-4" />
                <Badge 
                  variant="destructive" 
                  className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs"
                >
                  {totalUpdates}
                </Badge>
              </Button>
            )}
            
            <div className="text-right">
              <p className="text-sm font-medium text-gray-900">{user?.username}</p>
              <p className="text-xs text-gray-500 capitalize">{user?.role}</p>
            </div>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={logout}
              className="flex items-center space-x-2"
            >
              <LogOut className="w-4 h-4" />
              <span>Logout</span>
            </Button>
          </div>
        </div>

        {/* Real-time Updates Panel */}
        {showNotifications && totalUpdates > 0 && (
          <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-medium text-blue-900">Real-time Updates</h3>
              <div className="flex space-x-2">
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => {
                    clearSessionUpdates()
                    clearUsageUpdates()
                    clearTemplateUpdates()
                    clearOrganizationUpdates()
                  }}
                >
                  Clear All
                </Button>
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => setShowNotifications(false)}
                >
                  Hide
                </Button>
              </div>
            </div>
            
            <div className="space-y-2 max-h-40 overflow-y-auto">
              {sessionUpdates.slice(0, 5).map((update, index) => (
                <div key={index} className="text-xs text-blue-700 bg-white p-2 rounded">
                  <span className="font-medium">Session #{update.session_id}</span> was {update.update_type}
                  <span className="text-blue-500 ml-2">{new Date(update.timestamp).toLocaleTimeString()}</span>
                </div>
              ))}
              
              {templateUpdates.slice(0, 5).map((update, index) => (
                <div key={index} className="text-xs text-green-700 bg-white p-2 rounded">
                  <span className="font-medium">Template "{update.template.name}"</span> was {update.update_type}
                  <span className="text-green-500 ml-2">{new Date(update.timestamp).toLocaleTimeString()}</span>
                </div>
              ))}
              
              {organizationUpdates.slice(0, 5).map((update, index) => (
                <div key={index} className="text-xs text-purple-700 bg-white p-2 rounded">
                  <span className="font-medium">Organization limits</span> were {update.update_type}
                  <span className="text-purple-500 ml-2">{new Date().toLocaleTimeString()}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="p-6">
        <Tabs defaultValue="usage" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="usage" className="flex items-center space-x-2">
              <BarChart3 className="w-4 h-4" />
              <span>Usage Metrics</span>
            </TabsTrigger>
            <TabsTrigger value="sessions" className="flex items-center space-x-2 relative">
              <MessageSquare className="w-4 h-4" />
              <span>Sessions</span>
              {sessionUpdates.length > 0 && (
                <Badge variant="destructive" className="ml-1 h-4 w-4 rounded-full p-0 text-xs">
                  {sessionUpdates.length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="prompts" className="flex items-center space-x-2 relative">
              <FileText className="w-4 h-4" />
              <span>Prompt Templates</span>
              {templateUpdates.length > 0 && (
                <Badge variant="destructive" className="ml-1 h-4 w-4 rounded-full p-0 text-xs">
                  {templateUpdates.length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="limits" className="flex items-center space-x-2 relative">
              <Settings className="w-4 h-4" />
              <span>Organization Limits</span>
              {organizationUpdates.length > 0 && (
                <Badge variant="destructive" className="ml-1 h-4 w-4 rounded-full p-0 text-xs">
                  {organizationUpdates.length}
                </Badge>
              )}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="usage" className="space-y-6">
            <UsageMetrics usageUpdates={usageUpdates} />
          </TabsContent>

          <TabsContent value="sessions" className="space-y-6">
            <SessionsManager sessionUpdates={sessionUpdates} />
          </TabsContent>

          <TabsContent value="prompts" className="space-y-6">
            <PromptTemplateManager templateUpdates={templateUpdates} />
          </TabsContent>

          <TabsContent value="limits" className="space-y-6">
            <OrganizationLimits organizationUpdates={organizationUpdates} />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

