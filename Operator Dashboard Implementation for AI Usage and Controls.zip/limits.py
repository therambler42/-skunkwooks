from flask import request, jsonify, g
from flask_jwt_extended import get_jwt_identity, jwt_required
from functools import wraps
from src.models.user import db, User, Organization, AIUsage
from datetime import datetime, timedelta
import redis
import os
import logging

# Initialize Redis for rate limiting (fallback to in-memory if Redis not available)
try:
    redis_client = redis.Redis(
        host=os.getenv('REDIS_HOST', 'localhost'),
        port=int(os.getenv('REDIS_PORT', 6379)),
        db=0,
        decode_responses=True
    )
    redis_client.ping()
    REDIS_AVAILABLE = True
except:
    REDIS_AVAILABLE = False
    # Fallback to in-memory storage
    rate_limit_storage = {}

def check_credit_limit(f):
    """Decorator to check organization credit limits"""
    @wraps(f)
    @jwt_required()
    def decorated_function(*args, **kwargs):
        try:
            user_id = get_jwt_identity()
            user = User.query.get(user_id)
            
            if not user or not user.organization_id:
                return jsonify({'error': 'User or organization not found'}), 404
            
            org = Organization.query.get(user.organization_id)
            if not org:
                return jsonify({'error': 'Organization not found'}), 404
            
            # Check if organization has exceeded credit limit
            if org.credits_used >= org.credit_limit:
                logging.warning(f"Credit limit exceeded for org {org.id}: {org.credits_used}/{org.credit_limit}")
                return jsonify({
                    'error': 'Credit limit exceeded',
                    'credits_used': org.credits_used,
                    'credit_limit': org.credit_limit,
                    'message': 'Your organization has exceeded its credit limit. Please contact support.'
                }), 429
            
            # Store user and org in g for use in the route
            g.current_user = user
            g.current_org = org
            
            return f(*args, **kwargs)
            
        except Exception as e:
            logging.error(f"Error checking credit limit: {e}")
            return jsonify({'error': 'Internal server error'}), 500
    
    return decorated_function

def check_rate_limit(f):
    """Decorator to check organization rate limits"""
    @wraps(f)
    @jwt_required()
    def decorated_function(*args, **kwargs):
        try:
            user_id = get_jwt_identity()
            user = User.query.get(user_id)
            
            if not user or not user.organization_id:
                return jsonify({'error': 'User or organization not found'}), 404
            
            org = Organization.query.get(user.organization_id)
            if not org:
                return jsonify({'error': 'Organization not found'}), 404
            
            # Check rate limit
            current_hour = datetime.utcnow().strftime('%Y-%m-%d-%H')
            rate_key = f"rate_limit:org:{org.id}:{current_hour}"
            
            if REDIS_AVAILABLE:
                current_requests = redis_client.get(rate_key)
                current_requests = int(current_requests) if current_requests else 0
                
                if current_requests >= org.rate_limit_per_hour:
                    logging.warning(f"Rate limit exceeded for org {org.id}: {current_requests}/{org.rate_limit_per_hour}")
                    return jsonify({
                        'error': 'Rate limit exceeded',
                        'requests_made': current_requests,
                        'rate_limit': org.rate_limit_per_hour,
                        'reset_time': f"{current_hour}:59:59",
                        'message': f'Your organization has exceeded its rate limit of {org.rate_limit_per_hour} requests per hour.'
                    }), 429
                
                # Increment counter
                redis_client.incr(rate_key)
                redis_client.expire(rate_key, 3600)  # Expire after 1 hour
                
            else:
                # Fallback to in-memory storage
                if rate_key not in rate_limit_storage:
                    rate_limit_storage[rate_key] = {'count': 0, 'expires': datetime.utcnow() + timedelta(hours=1)}
                
                # Clean expired entries
                expired_keys = [k for k, v in rate_limit_storage.items() if v['expires'] < datetime.utcnow()]
                for k in expired_keys:
                    del rate_limit_storage[k]
                
                current_requests = rate_limit_storage[rate_key]['count']
                
                if current_requests >= org.rate_limit_per_hour:
                    logging.warning(f"Rate limit exceeded for org {org.id}: {current_requests}/{org.rate_limit_per_hour}")
                    return jsonify({
                        'error': 'Rate limit exceeded',
                        'requests_made': current_requests,
                        'rate_limit': org.rate_limit_per_hour,
                        'reset_time': f"{current_hour}:59:59",
                        'message': f'Your organization has exceeded its rate limit of {org.rate_limit_per_hour} requests per hour.'
                    }), 429
                
                rate_limit_storage[rate_key]['count'] += 1
            
            # Store user and org in g for use in the route
            g.current_user = user
            g.current_org = org
            
            return f(*args, **kwargs)
            
        except Exception as e:
            logging.error(f"Error checking rate limit: {e}")
            return jsonify({'error': 'Internal server error'}), 500
    
    return decorated_function

def track_ai_usage(credits_used, model_name, prompt_tokens=0, completion_tokens=0, session_id=None):
    """Track AI usage and update organization credits"""
    try:
        if not hasattr(g, 'current_user') or not hasattr(g, 'current_org'):
            logging.error("User or organization not found in request context")
            return False
        
        user = g.current_user
        org = g.current_org
        
        # Create usage record
        usage = AIUsage(
            user_id=user.id,
            organization_id=org.id,
            session_id=session_id,
            credits_used=credits_used,
            model_name=model_name,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens
        )
        
        # Update organization credits
        org.credits_used += credits_used
        
        db.session.add(usage)
        db.session.commit()
        
        logging.info(f"Tracked {credits_used} credits for user {user.id}, org {org.id}")
        return True
        
    except Exception as e:
        logging.error(f"Error tracking AI usage: {e}")
        db.session.rollback()
        return False

def combined_limits_check(f):
    """Combined decorator for both credit and rate limit checks"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # Apply rate limit check first
        rate_check = check_rate_limit(lambda: None)
        try:
            rate_check()
        except Exception as e:
            if hasattr(e, 'response') and e.response.status_code == 429:
                return e.response
        
        # Then apply credit limit check
        credit_check = check_credit_limit(lambda: None)
        try:
            credit_check()
        except Exception as e:
            if hasattr(e, 'response') and e.response.status_code == 429:
                return e.response
        
        return f(*args, **kwargs)
    
    return decorated_function

def get_rate_limit_status(org_id):
    """Get current rate limit status for an organization"""
    try:
        current_hour = datetime.utcnow().strftime('%Y-%m-%d-%H')
        rate_key = f"rate_limit:org:{org_id}:{current_hour}"
        
        if REDIS_AVAILABLE:
            current_requests = redis_client.get(rate_key)
            current_requests = int(current_requests) if current_requests else 0
        else:
            current_requests = rate_limit_storage.get(rate_key, {'count': 0})['count']
        
        org = Organization.query.get(org_id)
        if not org:
            return None
        
        return {
            'current_requests': current_requests,
            'rate_limit': org.rate_limit_per_hour,
            'remaining_requests': max(0, org.rate_limit_per_hour - current_requests),
            'reset_time': f"{current_hour}:59:59"
        }
        
    except Exception as e:
        logging.error(f"Error getting rate limit status: {e}")
        return None

def reset_rate_limits():
    """Reset all rate limits (for testing purposes)"""
    try:
        if REDIS_AVAILABLE:
            # Delete all rate limit keys
            keys = redis_client.keys("rate_limit:*")
            if keys:
                redis_client.delete(*keys)
        else:
            rate_limit_storage.clear()
        
        logging.info("Rate limits reset successfully")
        return True
        
    except Exception as e:
        logging.error(f"Error resetting rate limits: {e}")
        return False

