import { useEffect, useRef, useState } from 'react'
import { io } from 'socket.io-client'
import { useAuth } from './useAuth'

export function useWebSocket() {
  const { user } = useAuth()
  const [socket, setSocket] = useState(null)
  const [connected, setConnected] = useState(false)
  const [sessionUpdates, setSessionUpdates] = useState([])
  const [usageUpdates, setUsageUpdates] = useState(null)
  const [templateUpdates, setTemplateUpdates] = useState([])
  const [organizationUpdates, setOrganizationUpdates] = useState([])
  const reconnectAttempts = useRef(0)
  const maxReconnectAttempts = 5

  useEffect(() => {
    if (user && user.role === 'operator') {
      connectWebSocket()
    }

    return () => {
      if (socket) {
        socket.disconnect()
      }
    }
  }, [user])

  const connectWebSocket = () => {
    try {
      const token = localStorage.getItem('token')
      if (!token) return

      const newSocket = io('http://localhost:5000', {
        auth: { token },
        transports: ['websocket', 'polling']
      })

      newSocket.on('connect', () => {
        console.log('WebSocket connected')
        setConnected(true)
        reconnectAttempts.current = 0
      })

      newSocket.on('disconnect', () => {
        console.log('WebSocket disconnected')
        setConnected(false)
        
        // Attempt to reconnect
        if (reconnectAttempts.current < maxReconnectAttempts) {
          setTimeout(() => {
            reconnectAttempts.current++
            connectWebSocket()
          }, 2000 * reconnectAttempts.current)
        }
      })

      newSocket.on('connect_error', (error) => {
        console.error('WebSocket connection error:', error)
        setConnected(false)
      })

      // Listen for session updates
      newSocket.on('session_updated', (data) => {
        console.log('Session updated:', data)
        setSessionUpdates(prev => [data, ...prev.slice(0, 49)]) // Keep last 50 updates
      })

      // Listen for usage updates
      newSocket.on('usage_updated', (data) => {
        console.log('Usage updated:', data)
        setUsageUpdates(data)
      })

      // Listen for template updates
      newSocket.on('template_updated', (data) => {
        console.log('Template updated:', data)
        setTemplateUpdates(prev => [data, ...prev.slice(0, 49)])
      })

      // Listen for organization updates
      newSocket.on('organization_updated', (data) => {
        console.log('Organization updated:', data)
        setOrganizationUpdates(prev => [data, ...prev.slice(0, 49)])
      })

      setSocket(newSocket)
    } catch (error) {
      console.error('Failed to connect WebSocket:', error)
    }
  }

  const joinSessionRoom = (sessionId) => {
    if (socket && connected) {
      socket.emit('join_session_room', { session_id: sessionId })
    }
  }

  const leaveSessionRoom = (sessionId) => {
    if (socket && connected) {
      socket.emit('leave_session_room', { session_id: sessionId })
    }
  }

  const clearSessionUpdates = () => {
    setSessionUpdates([])
  }

  const clearUsageUpdates = () => {
    setUsageUpdates(null)
  }

  const clearTemplateUpdates = () => {
    setTemplateUpdates([])
  }

  const clearOrganizationUpdates = () => {
    setOrganizationUpdates([])
  }

  return {
    socket,
    connected,
    sessionUpdates,
    usageUpdates,
    templateUpdates,
    organizationUpdates,
    joinSessionRoom,
    leaveSessionRoom,
    clearSessionUpdates,
    clearUsageUpdates,
    clearTemplateUpdates,
    clearOrganizationUpdates
  }
}

