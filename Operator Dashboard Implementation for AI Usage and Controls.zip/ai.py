from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.user import db, User, AISession
from src.middleware.limits import combined_limits_check, track_ai_usage, get_rate_limit_status
from datetime import datetime
import random

ai_bp = Blueprint('ai', __name__)

@ai_bp.route('/chat', methods=['POST'])
@combined_limits_check
def ai_chat():
    """Simulate AI chat API with credit and rate limiting"""
    try:
        data = request.get_json()
        if not data or 'prompt' not in data:
            return jsonify({'error': 'Prompt is required'}), 400
        
        prompt = data['prompt']
        model_name = data.get('model_name', 'gpt-3.5-turbo')
        
        # Simulate AI processing
        response_text = f"This is a simulated AI response to: {prompt[:50]}..."
        
        # Calculate simulated usage
        prompt_tokens = len(prompt.split()) * 1.3  # Rough token estimation
        completion_tokens = len(response_text.split()) * 1.3
        
        # Calculate credits based on model and tokens
        model_costs = {
            'gpt-4': 0.03,
            'gpt-3.5-turbo': 0.002,
            'claude-3-opus': 0.015,
            'claude-3-sonnet': 0.003,
            'claude-3-haiku': 0.00025,
            'gemini-pro': 0.001,
            'llama-2-70b': 0.0007
        }
        
        cost_per_token = model_costs.get(model_name, 0.002)
        credits_used = int((prompt_tokens + completion_tokens) * cost_per_token * 1000)  # Convert to credits
        
        # Create session record
        user_id = get_jwt_identity()
        session = AISession(
            user_id=user_id,
            prompt=prompt,
            response=response_text,
            model_name=model_name
        )
        
        db.session.add(session)
        db.session.flush()  # Get session ID
        
        # Track usage
        success = track_ai_usage(
            credits_used=credits_used,
            model_name=model_name,
            prompt_tokens=int(prompt_tokens),
            completion_tokens=int(completion_tokens),
            session_id=session.id
        )
        
        if not success:
            db.session.rollback()
            return jsonify({'error': 'Failed to track usage'}), 500
        
        db.session.commit()
        
        return jsonify({
            'response': response_text,
            'session_id': session.id,
            'model_name': model_name,
            'usage': {
                'prompt_tokens': int(prompt_tokens),
                'completion_tokens': int(completion_tokens),
                'total_tokens': int(prompt_tokens + completion_tokens),
                'credits_used': credits_used
            }
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@ai_bp.route('/models', methods=['GET'])
@jwt_required()
def get_available_models():
    """Get list of available AI models"""
    models = [
        {
            'name': 'gpt-4',
            'description': 'Most capable GPT model',
            'cost_per_1k_tokens': 30
        },
        {
            'name': 'gpt-3.5-turbo',
            'description': 'Fast and efficient GPT model',
            'cost_per_1k_tokens': 2
        },
        {
            'name': 'claude-3-opus',
            'description': 'Most powerful Claude model',
            'cost_per_1k_tokens': 15
        },
        {
            'name': 'claude-3-sonnet',
            'description': 'Balanced Claude model',
            'cost_per_1k_tokens': 3
        },
        {
            'name': 'claude-3-haiku',
            'description': 'Fastest Claude model',
            'cost_per_1k_tokens': 0.25
        },
        {
            'name': 'gemini-pro',
            'description': 'Google\'s advanced model',
            'cost_per_1k_tokens': 1
        },
        {
            'name': 'llama-2-70b',
            'description': 'Open source large model',
            'cost_per_1k_tokens': 0.7
        }
    ]
    
    return jsonify({'models': models}), 200

@ai_bp.route('/usage/current', methods=['GET'])
@jwt_required()
def get_current_usage():
    """Get current usage and limits for the user's organization"""
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        if not user or not user.organization_id:
            return jsonify({'error': 'User or organization not found'}), 404
        
        org = user.organization
        rate_status = get_rate_limit_status(org.id)
        
        return jsonify({
            'organization': {
                'id': org.id,
                'name': org.name,
                'credit_limit': org.credit_limit,
                'credits_used': org.credits_used,
                'credits_remaining': org.credit_limit - org.credits_used,
                'usage_percentage': (org.credits_used / org.credit_limit) * 100
            },
            'rate_limit': rate_status
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@ai_bp.route('/test/load', methods=['POST'])
@jwt_required()
def test_load():
    """Test endpoint to simulate load and trigger rate limits"""
    try:
        data = request.get_json()
        num_requests = data.get('num_requests', 5)
        
        if num_requests > 50:
            return jsonify({'error': 'Maximum 50 requests allowed for testing'}), 400
        
        results = []
        
        for i in range(num_requests):
            try:
                # Simulate AI request
                response = ai_chat()
                results.append({
                    'request': i + 1,
                    'status': 'success' if response[1] == 200 else 'failed',
                    'status_code': response[1]
                })
            except Exception as e:
                results.append({
                    'request': i + 1,
                    'status': 'error',
                    'error': str(e)
                })
        
        return jsonify({
            'message': f'Completed {num_requests} test requests',
            'results': results
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

