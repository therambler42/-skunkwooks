import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Textarea } from '@/components/ui/textarea'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useAuth } from '../hooks/useAuth'
import { Flag, Edit, Eye, Save, X, RefreshCw, AlertTriangle } from 'lucide-react'

export function SessionsManager() {
  const { apiCall } = useAuth()
  const [sessions, setSessions] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [selectedSession, setSelectedSession] = useState(null)
  const [editingSession, setEditingSession] = useState(null)
  const [editedResponse, setEditedResponse] = useState('')
  const [flagReason, setFlagReason] = useState('')
  const [showFlaggedOnly, setShowFlaggedOnly] = useState(true)
  const [pagination, setPagination] = useState({ page: 1, total: 0, pages: 0 })

  useEffect(() => {
    fetchSessions()
  }, [showFlaggedOnly, pagination.page])

  const fetchSessions = async () => {
    try {
      setLoading(true)
      setError('')
      const response = await apiCall(`/operator/sessions?flagged_only=${showFlaggedOnly}&page=${pagination.page}&per_page=20`)
      
      if (response.ok) {
        const data = await response.json()
        setSessions(data.sessions)
        setPagination(data.pagination)
      } else {
        const errorData = await response.json()
        setError(errorData.error || 'Failed to fetch sessions')
      }
    } catch (error) {
      setError('Network error')
    } finally {
      setLoading(false)
    }
  }

  const handleFlagSession = async (sessionId, isFlagged, reason = '') => {
    try {
      const response = await apiCall(`/operator/sessions/${sessionId}`, {
        method: 'PATCH',
        body: JSON.stringify({
          is_flagged: isFlagged,
          flag_reason: reason
        })
      })

      if (response.ok) {
        fetchSessions()
        setSelectedSession(null)
      } else {
        const errorData = await response.json()
        setError(errorData.error || 'Failed to update session')
      }
    } catch (error) {
      setError('Network error')
    }
  }

  const handleEditResponse = async (sessionId, newResponse) => {
    try {
      const response = await apiCall(`/operator/sessions/${sessionId}`, {
        method: 'PATCH',
        body: JSON.stringify({
          response: newResponse
        })
      })

      if (response.ok) {
        fetchSessions()
        setEditingSession(null)
        setEditedResponse('')
      } else {
        const errorData = await response.json()
        setError(errorData.error || 'Failed to update response')
      }
    } catch (error) {
      setError('Network error')
    }
  }

  const startEditing = (session) => {
    setEditingSession(session.id)
    setEditedResponse(session.response)
  }

  const cancelEditing = () => {
    setEditingSession(null)
    setEditedResponse('')
  }

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleString()
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <RefreshCw className="w-6 h-6 animate-spin" />
        <span className="ml-2">Loading sessions...</span>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">AI Sessions</h2>
          <p className="text-gray-600">Review and manage AI conversation sessions</p>
        </div>
        <div className="flex items-center space-x-4">
          <Select value={showFlaggedOnly.toString()} onValueChange={(value) => setShowFlaggedOnly(value === 'true')}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="true">Flagged Sessions Only</SelectItem>
              <SelectItem value="false">All Sessions</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={fetchSessions} variant="outline" size="sm">
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {error && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-4">
            <div className="flex items-center text-red-600">
              <AlertTriangle className="w-4 h-4 mr-2" />
              <span>{error}</span>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Sessions List */}
      <div className="space-y-4">
        {sessions.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-gray-500">No sessions found</p>
            </CardContent>
          </Card>
        ) : (
          sessions.map((session) => (
            <Card key={session.id} className={session.is_flagged ? 'border-red-200 bg-red-50' : ''}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <CardTitle className="text-lg">Session #{session.id}</CardTitle>
                    {session.is_flagged && (
                      <Badge variant="destructive" className="flex items-center space-x-1">
                        <Flag className="w-3 h-3" />
                        <span>Flagged</span>
                      </Badge>
                    )}
                    {session.is_edited && (
                      <Badge variant="secondary" className="flex items-center space-x-1">
                        <Edit className="w-3 h-3" />
                        <span>Edited</span>
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center space-x-2">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm" onClick={() => setSelectedSession(session)}>
                          <Eye className="w-4 h-4 mr-2" />
                          View Details
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                        <DialogHeader>
                          <DialogTitle>Session #{session.id} Details</DialogTitle>
                          <DialogDescription>
                            Created: {formatDate(session.created_at)} | Model: {session.model_name}
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <Label className="text-sm font-medium">Prompt</Label>
                            <div className="mt-1 p-3 bg-gray-50 rounded-md">
                              <p className="text-sm whitespace-pre-wrap">{session.prompt}</p>
                            </div>
                          </div>
                          
                          <div>
                            <Label className="text-sm font-medium">
                              Response {session.is_edited && '(Edited)'}
                            </Label>
                            {editingSession === session.id ? (
                              <div className="space-y-2">
                                <Textarea
                                  value={editedResponse}
                                  onChange={(e) => setEditedResponse(e.target.value)}
                                  rows={10}
                                  className="mt-1"
                                />
                                <div className="flex space-x-2">
                                  <Button 
                                    size="sm" 
                                    onClick={() => handleEditResponse(session.id, editedResponse)}
                                  >
                                    <Save className="w-4 h-4 mr-2" />
                                    Save Changes
                                  </Button>
                                  <Button size="sm" variant="outline" onClick={cancelEditing}>
                                    <X className="w-4 h-4 mr-2" />
                                    Cancel
                                  </Button>
                                </div>
                              </div>
                            ) : (
                              <div className="mt-1 p-3 bg-gray-50 rounded-md">
                                <p className="text-sm whitespace-pre-wrap">{session.response}</p>
                                <div className="mt-2 flex space-x-2">
                                  <Button size="sm" variant="outline" onClick={() => startEditing(session)}>
                                    <Edit className="w-4 h-4 mr-2" />
                                    Edit Response
                                  </Button>
                                </div>
                              </div>
                            )}
                          </div>

                          {session.original_response && (
                            <div>
                              <Label className="text-sm font-medium">Original Response</Label>
                              <div className="mt-1 p-3 bg-yellow-50 rounded-md">
                                <p className="text-sm whitespace-pre-wrap">{session.original_response}</p>
                              </div>
                            </div>
                          )}

                          <div className="flex items-center justify-between pt-4 border-t">
                            <div className="space-y-2">
                              {session.is_flagged ? (
                                <div>
                                  <p className="text-sm text-red-600">
                                    Flagged: {session.flag_reason || 'No reason provided'}
                                  </p>
                                  <Button 
                                    size="sm" 
                                    variant="outline"
                                    onClick={() => handleFlagSession(session.id, false)}
                                  >
                                    Remove Flag
                                  </Button>
                                </div>
                              ) : (
                                <div className="space-y-2">
                                  <Input
                                    placeholder="Reason for flagging..."
                                    value={flagReason}
                                    onChange={(e) => setFlagReason(e.target.value)}
                                  />
                                  <Button 
                                    size="sm" 
                                    variant="destructive"
                                    onClick={() => {
                                      handleFlagSession(session.id, true, flagReason)
                                      setFlagReason('')
                                    }}
                                  >
                                    <Flag className="w-4 h-4 mr-2" />
                                    Flag Session
                                  </Button>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
                <CardDescription>
                  User ID: {session.user_id} | Model: {session.model_name} | {formatDate(session.created_at)}
                  {session.flag_reason && (
                    <span className="block text-red-600 mt-1">Reason: {session.flag_reason}</span>
                  )}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div>
                    <Label className="text-sm font-medium text-gray-700">Prompt (Preview)</Label>
                    <p className="text-sm text-gray-600 line-clamp-2">
                      {session.prompt.length > 150 ? session.prompt.substring(0, 150) + '...' : session.prompt}
                    </p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-700">Response (Preview)</Label>
                    <p className="text-sm text-gray-600 line-clamp-2">
                      {session.response.length > 150 ? session.response.substring(0, 150) + '...' : session.response}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Pagination */}
      {pagination.pages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-gray-600">
            Page {pagination.page} of {pagination.pages} ({pagination.total} total sessions)
          </p>
          <div className="flex space-x-2">
            <Button 
              variant="outline" 
              size="sm" 
              disabled={!pagination.has_prev}
              onClick={() => setPagination(prev => ({ ...prev, page: prev.page - 1 }))}
            >
              Previous
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              disabled={!pagination.has_next}
              onClick={() => setPagination(prev => ({ ...prev, page: prev.page + 1 }))}
            >
              Next
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}

