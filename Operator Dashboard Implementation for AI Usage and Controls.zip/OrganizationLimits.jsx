import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Progress } from '@/components/ui/progress'
import { useAuth } from '../hooks/useAuth'
import { Settings, Save, X, RefreshCw, AlertTriangle, Building, CreditCard, Clock } from 'lucide-react'

export function OrganizationLimits() {
  const { apiCall } = useAuth()
  const [organizations, setOrganizations] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [editingOrg, setEditingOrg] = useState(null)
  const [formData, setFormData] = useState({
    credit_limit: '',
    rate_limit_per_hour: ''
  })

  useEffect(() => {
    fetchOrganizations()
  }, [])

  const fetchOrganizations = async () => {
    try {
      setLoading(true)
      setError('')
      // Get organization limits from usage endpoint
      const response = await apiCall('/operator/usage')
      
      if (response.ok) {
        const data = await response.json()
        setOrganizations(data.organization_limits || [])
      } else {
        const errorData = await response.json()
        setError(errorData.error || 'Failed to fetch organization data')
      }
    } catch (error) {
      setError('Network error')
    } finally {
      setLoading(false)
    }
  }

  const handleUpdateLimits = async (orgId) => {
    try {
      const response = await apiCall(`/operator/organizations/${orgId}/limits`, {
        method: 'PATCH',
        body: JSON.stringify({
          credit_limit: parseInt(formData.credit_limit),
          rate_limit_per_hour: parseInt(formData.rate_limit_per_hour)
        })
      })

      if (response.ok) {
        fetchOrganizations()
        setEditingOrg(null)
        resetForm()
      } else {
        const errorData = await response.json()
        setError(errorData.error || 'Failed to update limits')
      }
    } catch (error) {
      setError('Network error')
    }
  }

  const startEditing = (org) => {
    setEditingOrg(org.org_id)
    setFormData({
      credit_limit: org.credit_limit.toString(),
      rate_limit_per_hour: org.rate_limit_per_hour.toString()
    })
  }

  const resetForm = () => {
    setFormData({
      credit_limit: '',
      rate_limit_per_hour: ''
    })
  }

  const cancelEditing = () => {
    setEditingOrg(null)
    resetForm()
  }

  const getUsagePercentage = (used, limit) => {
    return Math.min((used / limit) * 100, 100)
  }

  const getUsageColor = (percentage) => {
    if (percentage >= 90) return 'bg-red-500'
    if (percentage >= 75) return 'bg-yellow-500'
    return 'bg-green-500'
  }

  const getUsageStatus = (used, limit) => {
    const percentage = getUsagePercentage(used, limit)
    if (percentage >= 100) return { text: 'Limit Exceeded', variant: 'destructive' }
    if (percentage >= 90) return { text: 'Near Limit', variant: 'destructive' }
    if (percentage >= 75) return { text: 'High Usage', variant: 'secondary' }
    return { text: 'Normal', variant: 'default' }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <RefreshCw className="w-6 h-6 animate-spin" />
        <span className="ml-2">Loading organization data...</span>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Organization Limits</h2>
          <p className="text-gray-600">Manage credit and rate limits for organizations</p>
        </div>
        <Button onClick={fetchOrganizations} variant="outline" size="sm">
          <RefreshCw className="w-4 h-4 mr-2" />
          Refresh
        </Button>
      </div>

      {error && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-4">
            <div className="flex items-center text-red-600">
              <AlertTriangle className="w-4 h-4 mr-2" />
              <span>{error}</span>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Organizations Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {organizations.length === 0 ? (
          <Card className="lg:col-span-2">
            <CardContent className="p-8 text-center">
              <Building className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">No organizations found</p>
            </CardContent>
          </Card>
        ) : (
          organizations.map((org) => {
            const creditUsagePercentage = getUsagePercentage(org.credits_used, org.credit_limit)
            const creditStatus = getUsageStatus(org.credits_used, org.credit_limit)
            
            return (
              <Card key={org.org_id} className={creditUsagePercentage >= 100 ? 'border-red-200 bg-red-50' : ''}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Building className="w-5 h-5 text-gray-500" />
                      <CardTitle className="text-lg">{org.org_name}</CardTitle>
                      <Badge variant={creditStatus.variant}>
                        {creditStatus.text}
                      </Badge>
                    </div>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm" onClick={() => startEditing(org)}>
                          <Settings className="w-4 h-4 mr-2" />
                          Edit Limits
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Edit Limits: {org.org_name}</DialogTitle>
                          <DialogDescription>
                            Update credit and rate limits for this organization
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="credit_limit">Credit Limit (Max: 1,000)</Label>
                            <Input
                              id="credit_limit"
                              type="number"
                              min="1"
                              max="1000"
                              value={formData.credit_limit}
                              onChange={(e) => setFormData(prev => ({ ...prev, credit_limit: e.target.value }))}
                              placeholder="Enter credit limit"
                            />
                            <p className="text-xs text-gray-500 mt-1">
                              Maximum credits this organization can use
                            </p>
                          </div>
                          
                          <div>
                            <Label htmlFor="rate_limit">Rate Limit (Requests per hour)</Label>
                            <Input
                              id="rate_limit"
                              type="number"
                              min="1"
                              value={formData.rate_limit_per_hour}
                              onChange={(e) => setFormData(prev => ({ ...prev, rate_limit_per_hour: e.target.value }))}
                              placeholder="Enter rate limit"
                            />
                            <p className="text-xs text-gray-500 mt-1">
                              Maximum API requests per hour
                            </p>
                          </div>

                          <div className="flex justify-end space-x-2 pt-4">
                            <Button variant="outline" onClick={cancelEditing}>
                              <X className="w-4 h-4 mr-2" />
                              Cancel
                            </Button>
                            <Button onClick={() => handleUpdateLimits(org.org_id)}>
                              <Save className="w-4 h-4 mr-2" />
                              Update Limits
                            </Button>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                  <CardDescription>
                    Organization ID: {org.org_id}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Credit Usage */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <CreditCard className="w-4 h-4 text-gray-500" />
                        <Label className="text-sm font-medium">Credit Usage</Label>
                      </div>
                      <span className="text-sm text-gray-600">
                        {org.credits_used.toLocaleString()} / {org.credit_limit.toLocaleString()}
                      </span>
                    </div>
                    <Progress 
                      value={creditUsagePercentage} 
                      className="h-2"
                    />
                    <div className="flex justify-between text-xs text-gray-500 mt-1">
                      <span>{creditUsagePercentage.toFixed(1)}% used</span>
                      <span>{org.credits_remaining.toLocaleString()} remaining</span>
                    </div>
                  </div>

                  {/* Rate Limit Info */}
                  <div>
                    <div className="flex items-center space-x-2 mb-2">
                      <Clock className="w-4 h-4 text-gray-500" />
                      <Label className="text-sm font-medium">Rate Limit</Label>
                    </div>
                    <div className="p-3 bg-gray-50 rounded-md">
                      <p className="text-sm text-gray-600">
                        <span className="font-medium">{org.rate_limit_per_hour.toLocaleString()}</span> requests per hour
                      </p>
                    </div>
                  </div>

                  {/* Status Indicators */}
                  <div className="grid grid-cols-2 gap-4 pt-2">
                    <div className="text-center">
                      <p className="text-2xl font-bold text-blue-600">{org.credits_used.toLocaleString()}</p>
                      <p className="text-xs text-gray-500">Credits Used</p>
                    </div>
                    <div className="text-center">
                      <p className="text-2xl font-bold text-green-600">{org.credits_remaining.toLocaleString()}</p>
                      <p className="text-xs text-gray-500">Credits Remaining</p>
                    </div>
                  </div>

                  {/* Warning Messages */}
                  {creditUsagePercentage >= 100 && (
                    <div className="p-3 bg-red-100 border border-red-200 rounded-md">
                      <div className="flex items-center text-red-700">
                        <AlertTriangle className="w-4 h-4 mr-2" />
                        <span className="text-sm font-medium">Credit limit exceeded!</span>
                      </div>
                      <p className="text-xs text-red-600 mt-1">
                        New API requests will be blocked with 429 status
                      </p>
                    </div>
                  )}
                  
                  {creditUsagePercentage >= 90 && creditUsagePercentage < 100 && (
                    <div className="p-3 bg-yellow-100 border border-yellow-200 rounded-md">
                      <div className="flex items-center text-yellow-700">
                        <AlertTriangle className="w-4 h-4 mr-2" />
                        <span className="text-sm font-medium">Approaching credit limit</span>
                      </div>
                      <p className="text-xs text-yellow-600 mt-1">
                        Consider increasing the limit or monitoring usage closely
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            )
          })
        )}
      </div>

      {/* Summary Statistics */}
      {organizations.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Summary Statistics</CardTitle>
            <CardDescription>Overall organization limits and usage</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-blue-600">{organizations.length}</p>
                <p className="text-sm text-gray-500">Total Organizations</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-green-600">
                  {organizations.reduce((sum, org) => sum + org.credit_limit, 0).toLocaleString()}
                </p>
                <p className="text-sm text-gray-500">Total Credit Limit</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-red-600">
                  {organizations.reduce((sum, org) => sum + org.credits_used, 0).toLocaleString()}
                </p>
                <p className="text-sm text-gray-500">Total Credits Used</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-purple-600">
                  {organizations.filter(org => getUsagePercentage(org.credits_used, org.credit_limit) >= 90).length}
                </p>
                <p className="text-sm text-gray-500">Organizations Near Limit</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

