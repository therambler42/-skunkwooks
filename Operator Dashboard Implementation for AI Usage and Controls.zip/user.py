from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from enum import Enum

db = SQLAlchemy()

class UserRole(Enum):
    USER = "user"
    ADMIN = "admin"
    OPERATOR = "operator"

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.Enum(UserRole), default=UserRole.USER, nullable=False)
    organization_id = db.Column(db.Integer, db.ForeignKey('organization.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)

    # Relationships
    organization = db.relationship('Organization', back_populates='users')
    ai_usage = db.relationship('AIUsage', back_populates='user', cascade='all, delete-orphan')
    sessions = db.relationship('AISession', foreign_keys='AISession.user_id', back_populates='user', cascade='all, delete-orphan')

    def __repr__(self):
        return f'<User {self.username}>'

    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'role': self.role.value if self.role else None,
            'organization_id': self.organization_id,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'is_active': self.is_active
        }

    def has_role(self, role):
        return self.role == role

class Organization(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), unique=True, nullable=False)
    credit_limit = db.Column(db.Integer, default=1000, nullable=False)
    credits_used = db.Column(db.Integer, default=0, nullable=False)
    rate_limit_per_hour = db.Column(db.Integer, default=100, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)

    # Relationships
    users = db.relationship('User', back_populates='organization')
    ai_usage = db.relationship('AIUsage', back_populates='organization', cascade='all, delete-orphan')

    def __repr__(self):
        return f'<Organization {self.name}>'

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'credit_limit': self.credit_limit,
            'credits_used': self.credits_used,
            'rate_limit_per_hour': self.rate_limit_per_hour,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'is_active': self.is_active,
            'credits_remaining': self.credit_limit - self.credits_used
        }

class AIUsage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    organization_id = db.Column(db.Integer, db.ForeignKey('organization.id'), nullable=False)
    session_id = db.Column(db.Integer, db.ForeignKey('ai_session.id'), nullable=True)
    credits_used = db.Column(db.Integer, nullable=False)
    model_name = db.Column(db.String(100), nullable=False)
    prompt_tokens = db.Column(db.Integer, default=0)
    completion_tokens = db.Column(db.Integer, default=0)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    user = db.relationship('User', back_populates='ai_usage')
    organization = db.relationship('Organization', back_populates='ai_usage')
    session = db.relationship('AISession', back_populates='usage_records')

    def __repr__(self):
        return f'<AIUsage {self.id}: {self.credits_used} credits>'

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'organization_id': self.organization_id,
            'session_id': self.session_id,
            'credits_used': self.credits_used,
            'model_name': self.model_name,
            'prompt_tokens': self.prompt_tokens,
            'completion_tokens': self.completion_tokens,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None
        }

class AISession(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    prompt = db.Column(db.Text, nullable=False)
    response = db.Column(db.Text, nullable=False)
    original_response = db.Column(db.Text, nullable=True)  # Store original before edits
    model_name = db.Column(db.String(100), nullable=False)
    is_flagged = db.Column(db.Boolean, default=False)
    flag_reason = db.Column(db.String(255), nullable=True)
    is_edited = db.Column(db.Boolean, default=False)
    edited_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    user = db.relationship('User', foreign_keys=[user_id], back_populates='sessions')
    editor = db.relationship('User', foreign_keys=[edited_by])
    usage_records = db.relationship('AIUsage', back_populates='session', cascade='all, delete-orphan')

    def __repr__(self):
        return f'<AISession {self.id}: {"Flagged" if self.is_flagged else "Normal"}>'

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'prompt': self.prompt,
            'response': self.response,
            'original_response': self.original_response,
            'model_name': self.model_name,
            'is_flagged': self.is_flagged,
            'flag_reason': self.flag_reason,
            'is_edited': self.is_edited,
            'edited_by': self.edited_by,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class PromptTemplate(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    description = db.Column(db.Text, nullable=True)
    template = db.Column(db.Text, nullable=False)
    model_name = db.Column(db.String(100), nullable=False)
    version = db.Column(db.Integer, default=1, nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    created_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    creator = db.relationship('User')

    def __repr__(self):
        return f'<PromptTemplate {self.name} v{self.version}>'

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'template': self.template,
            'model_name': self.model_name,
            'version': self.version,
            'is_active': self.is_active,
            'created_by': self.created_by,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
