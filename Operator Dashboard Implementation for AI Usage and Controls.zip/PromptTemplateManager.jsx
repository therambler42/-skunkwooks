import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { useAuth } from '../hooks/useAuth'
import { Plus, Edit, Trash2, Save, X, RefreshCw, FileText, AlertTriangle } from 'lucide-react'

const AI_MODELS = [
  'gpt-4',
  'gpt-3.5-turbo',
  'claude-3-opus',
  'claude-3-sonnet',
  'claude-3-haiku',
  'gemini-pro',
  'llama-2-70b'
]

export function PromptTemplateManager() {
  const { apiCall } = useAuth()
  const [templates, setTemplates] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [showCreateDialog, setShowCreateDialog] = useState(false)
  const [editingTemplate, setEditingTemplate] = useState(null)
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    template: '',
    model_name: '',
    is_active: true
  })
  const [pagination, setPagination] = useState({ page: 1, total: 0, pages: 0 })

  useEffect(() => {
    fetchTemplates()
  }, [pagination.page])

  const fetchTemplates = async () => {
    try {
      setLoading(true)
      setError('')
      const response = await apiCall(`/operator/prompts?page=${pagination.page}&per_page=20`)
      
      if (response.ok) {
        const data = await response.json()
        setTemplates(data.templates)
        setPagination(data.pagination)
      } else {
        const errorData = await response.json()
        setError(errorData.error || 'Failed to fetch templates')
      }
    } catch (error) {
      setError('Network error')
    } finally {
      setLoading(false)
    }
  }

  const handleCreateTemplate = async () => {
    try {
      const response = await apiCall('/operator/prompts', {
        method: 'POST',
        body: JSON.stringify(formData)
      })

      if (response.ok) {
        fetchTemplates()
        setShowCreateDialog(false)
        resetForm()
      } else {
        const errorData = await response.json()
        setError(errorData.error || 'Failed to create template')
      }
    } catch (error) {
      setError('Network error')
    }
  }

  const handleUpdateTemplate = async (templateId) => {
    try {
      const response = await apiCall(`/operator/prompts/${templateId}`, {
        method: 'PUT',
        body: JSON.stringify(formData)
      })

      if (response.ok) {
        fetchTemplates()
        setEditingTemplate(null)
        resetForm()
      } else {
        const errorData = await response.json()
        setError(errorData.error || 'Failed to update template')
      }
    } catch (error) {
      setError('Network error')
    }
  }

  const handleDeleteTemplate = async (templateId) => {
    if (!confirm('Are you sure you want to delete this template?')) {
      return
    }

    try {
      const response = await apiCall(`/operator/prompts/${templateId}`, {
        method: 'DELETE'
      })

      if (response.ok) {
        fetchTemplates()
      } else {
        const errorData = await response.json()
        setError(errorData.error || 'Failed to delete template')
      }
    } catch (error) {
      setError('Network error')
    }
  }

  const startEditing = (template) => {
    setEditingTemplate(template.id)
    setFormData({
      name: template.name,
      description: template.description || '',
      template: template.template,
      model_name: template.model_name,
      is_active: template.is_active
    })
  }

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      template: '',
      model_name: '',
      is_active: true
    })
  }

  const cancelEditing = () => {
    setEditingTemplate(null)
    setShowCreateDialog(false)
    resetForm()
  }

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleString()
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <RefreshCw className="w-6 h-6 animate-spin" />
        <span className="ml-2">Loading templates...</span>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Prompt Templates</h2>
          <p className="text-gray-600">Manage AI prompt templates with versioning</p>
        </div>
        <div className="flex items-center space-x-4">
          <Button onClick={fetchTemplates} variant="outline" size="sm">
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
          <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Create Template
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create New Prompt Template</DialogTitle>
                <DialogDescription>
                  Create a new prompt template for AI models
                </DialogDescription>
              </DialogHeader>
              <TemplateForm
                formData={formData}
                setFormData={setFormData}
                onSave={handleCreateTemplate}
                onCancel={cancelEditing}
                isEditing={false}
              />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {error && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-4">
            <div className="flex items-center text-red-600">
              <AlertTriangle className="w-4 h-4 mr-2" />
              <span>{error}</span>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Templates List */}
      <div className="space-y-4">
        {templates.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">No prompt templates found</p>
              <Button className="mt-4" onClick={() => setShowCreateDialog(true)}>
                Create Your First Template
              </Button>
            </CardContent>
          </Card>
        ) : (
          templates.map((template) => (
            <Card key={template.id}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <CardTitle className="text-lg">{template.name}</CardTitle>
                    <Badge variant={template.is_active ? 'default' : 'secondary'}>
                      v{template.version}
                    </Badge>
                    {template.is_active ? (
                      <Badge variant="default">Active</Badge>
                    ) : (
                      <Badge variant="secondary">Inactive</Badge>
                    )}
                    <Badge variant="outline">{template.model_name}</Badge>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm" onClick={() => startEditing(template)}>
                          <Edit className="w-4 h-4 mr-2" />
                          Edit
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-2xl">
                        <DialogHeader>
                          <DialogTitle>Edit Template: {template.name}</DialogTitle>
                          <DialogDescription>
                            Modify the prompt template (will increment version)
                          </DialogDescription>
                        </DialogHeader>
                        <TemplateForm
                          formData={formData}
                          setFormData={setFormData}
                          onSave={() => handleUpdateTemplate(template.id)}
                          onCancel={cancelEditing}
                          isEditing={true}
                        />
                      </DialogContent>
                    </Dialog>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => handleDeleteTemplate(template.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                <CardDescription>
                  {template.description || 'No description provided'}
                </CardDescription>
                <div className="text-sm text-gray-500">
                  Created: {formatDate(template.created_at)} | 
                  Updated: {formatDate(template.updated_at)}
                </div>
              </CardHeader>
              <CardContent>
                <div>
                  <Label className="text-sm font-medium text-gray-700">Template Content</Label>
                  <div className="mt-1 p-3 bg-gray-50 rounded-md">
                    <pre className="text-sm whitespace-pre-wrap font-mono">
                      {template.template.length > 300 
                        ? template.template.substring(0, 300) + '...' 
                        : template.template}
                    </pre>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Pagination */}
      {pagination.pages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-gray-600">
            Page {pagination.page} of {pagination.pages} ({pagination.total} total templates)
          </p>
          <div className="flex space-x-2">
            <Button 
              variant="outline" 
              size="sm" 
              disabled={!pagination.has_prev}
              onClick={() => setPagination(prev => ({ ...prev, page: prev.page - 1 }))}
            >
              Previous
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              disabled={!pagination.has_next}
              onClick={() => setPagination(prev => ({ ...prev, page: prev.page + 1 }))}
            >
              Next
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}

function TemplateForm({ formData, setFormData, onSave, onCancel, isEditing }) {
  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="name">Template Name</Label>
          <Input
            id="name"
            value={formData.name}
            onChange={(e) => handleInputChange('name', e.target.value)}
            placeholder="Enter template name"
            required
          />
        </div>
        <div>
          <Label htmlFor="model">AI Model</Label>
          <Select value={formData.model_name} onValueChange={(value) => handleInputChange('model_name', value)}>
            <SelectTrigger>
              <SelectValue placeholder="Select AI model" />
            </SelectTrigger>
            <SelectContent>
              {AI_MODELS.map((model) => (
                <SelectItem key={model} value={model}>
                  {model}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div>
        <Label htmlFor="description">Description (Optional)</Label>
        <Input
          id="description"
          value={formData.description}
          onChange={(e) => handleInputChange('description', e.target.value)}
          placeholder="Describe what this template is for"
        />
      </div>

      <div>
        <Label htmlFor="template">Template Content</Label>
        <Textarea
          id="template"
          value={formData.template}
          onChange={(e) => handleInputChange('template', e.target.value)}
          placeholder="Enter your prompt template here..."
          rows={8}
          required
        />
        <p className="text-xs text-gray-500 mt-1">
          Use variables like {'{user_input}'} or {'{context}'} for dynamic content
        </p>
      </div>

      <div className="flex items-center space-x-2">
        <Switch
          id="is_active"
          checked={formData.is_active}
          onCheckedChange={(checked) => handleInputChange('is_active', checked)}
        />
        <Label htmlFor="is_active">Active Template</Label>
      </div>

      <div className="flex justify-end space-x-2 pt-4">
        <Button variant="outline" onClick={onCancel}>
          <X className="w-4 h-4 mr-2" />
          Cancel
        </Button>
        <Button onClick={onSave}>
          <Save className="w-4 h-4 mr-2" />
          {isEditing ? 'Update Template' : 'Create Template'}
        </Button>
      </div>
    </div>
  )
}

