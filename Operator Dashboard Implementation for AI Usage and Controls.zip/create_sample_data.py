#!/usr/bin/env python3
"""
Sample data generator for Operator Dashboard
Creates test organizations, users, sessions, and usage data
"""

import sys
import os
import random
from datetime import datetime, timedelta
from werkzeug.security import generate_password_hash

# Add the project root to the Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.main import app, db
from src.models.user import User, Organization, AISession, AIUsage, PromptTemplate, UserRole

def create_sample_data():
    """Create comprehensive sample data for testing"""
    
    with app.app_context():
        # Clear existing data
        print("Clearing existing data...")
        db.drop_all()
        db.create_all()
        
        # Create sample organizations
        print("Creating sample organizations...")
        organizations = [
            Organization(
                name='Acme Corporation',
                credit_limit=1000,
                credits_used=750,
                rate_limit_per_hour=100
            ),
            Organization(
                name='TechStart Inc',
                credit_limit=500,
                credits_used=120,
                rate_limit_per_hour=50
            ),
            Organization(
                name='Global Enterprises',
                credit_limit=800,
                credits_used=950,  # Over limit for testing
                rate_limit_per_hour=80
            ),
            Organization(
                name='Innovation Labs',
                credit_limit=300,
                credits_used=45,
                rate_limit_per_hour=30
            )
        ]
        
        for org in organizations:
            db.session.add(org)
        
        db.session.flush()  # Get organization IDs
        
        # Create sample users
        print("Creating sample users...")
        users = [
            # Operators
            User(
                username='operator1',
                email='operator1@acme.com',
                password_hash=generate_password_hash('operator123'),
                role=UserRole.OPERATOR,
                organization_id=organizations[0].id
            ),
            User(
                username='operator2',
                email='operator2@techstart.com',
                password_hash=generate_password_hash('operator123'),
                role=UserRole.OPERATOR,
                organization_id=organizations[1].id
            ),
            
            # Admins
            User(
                username='admin1',
                email='admin1@acme.com',
                password_hash=generate_password_hash('admin123'),
                role=UserRole.ADMIN,
                organization_id=organizations[0].id
            ),
            
            # Regular users
            User(
                username='john_doe',
                email='john@acme.com',
                password_hash=generate_password_hash('user123'),
                role=UserRole.USER,
                organization_id=organizations[0].id
            ),
            User(
                username='jane_smith',
                email='jane@techstart.com',
                password_hash=generate_password_hash('user123'),
                role=UserRole.USER,
                organization_id=organizations[1].id
            ),
            User(
                username='bob_wilson',
                email='bob@global.com',
                password_hash=generate_password_hash('user123'),
                role=UserRole.USER,
                organization_id=organizations[2].id
            ),
            User(
                username='alice_brown',
                email='alice@innovation.com',
                password_hash=generate_password_hash('user123'),
                role=UserRole.USER,
                organization_id=organizations[3].id
            ),
            User(
                username='charlie_davis',
                email='charlie@acme.com',
                password_hash=generate_password_hash('user123'),
                role=UserRole.USER,
                organization_id=organizations[0].id
            )
        ]
        
        for user in users:
            db.session.add(user)
        
        db.session.flush()  # Get user IDs
        
        # Create sample prompt templates
        print("Creating sample prompt templates...")
        templates = [
            PromptTemplate(
                name='Customer Support Response',
                description='Template for generating customer support responses',
                template='You are a helpful customer support agent. Please respond to this customer inquiry: {inquiry}\n\nProvide a professional and helpful response.',
                model_name='gpt-3.5-turbo',
                created_by=users[0].id,  # operator1
                version=1
            ),
            PromptTemplate(
                name='Code Review Assistant',
                description='Template for code review and suggestions',
                template='Please review the following code and provide constructive feedback:\n\n{code}\n\nFocus on: {focus_areas}',
                model_name='gpt-4',
                created_by=users[0].id,  # operator1
                version=1
            ),
            PromptTemplate(
                name='Content Summarizer',
                description='Template for summarizing long content',
                template='Please provide a concise summary of the following content:\n\n{content}\n\nSummary length: {length}',
                model_name='claude-3-sonnet',
                created_by=users[1].id,  # operator2
                version=2
            ),
            PromptTemplate(
                name='Email Composer',
                description='Template for composing professional emails',
                template='Compose a professional email with the following details:\nTo: {recipient}\nSubject: {subject}\nTone: {tone}\nKey points: {key_points}',
                model_name='gpt-3.5-turbo',
                created_by=users[0].id,  # operator1
                version=1
            )
        ]
        
        for template in templates:
            db.session.add(template)
        
        db.session.flush()
        
        # Create sample AI sessions
        print("Creating sample AI sessions...")
        models = ['gpt-4', 'gpt-3.5-turbo', 'claude-3-opus', 'claude-3-sonnet', 'claude-3-haiku', 'gemini-pro']
        sample_prompts = [
            "How do I implement authentication in a Flask application?",
            "Explain the concept of machine learning in simple terms",
            "Write a Python function to calculate fibonacci numbers",
            "What are the best practices for database design?",
            "How can I optimize my website's performance?",
            "Explain the difference between SQL and NoSQL databases",
            "Write a React component for a user profile page",
            "How do I handle errors in JavaScript?",
            "What is the purpose of Docker containers?",
            "Explain REST API design principles"
        ]
        
        sample_responses = [
            "Here's a comprehensive guide to implementing authentication in Flask...",
            "Machine learning is a subset of artificial intelligence that enables computers to learn...",
            "Here's an efficient Python function for calculating Fibonacci numbers...",
            "Database design best practices include normalization, proper indexing...",
            "Website performance can be optimized through various techniques...",
            "SQL and NoSQL databases differ in their structure and use cases...",
            "Here's a React component for a user profile page with modern hooks...",
            "Error handling in JavaScript can be done using try-catch blocks...",
            "Docker containers provide a lightweight way to package applications...",
            "REST API design follows principles like statelessness and resource-based URLs..."
        ]
        
        regular_users = [u for u in users if u.role == UserRole.USER]
        
        sessions = []
        for i in range(50):  # Create 50 sample sessions
            user = random.choice(regular_users)
            prompt = random.choice(sample_prompts)
            response = random.choice(sample_responses)
            model = random.choice(models)
            
            # Some sessions are flagged
            is_flagged = random.random() < 0.1  # 10% chance
            flag_reason = "Inappropriate content detected" if is_flagged else None
            
            # Some sessions are edited
            is_edited = random.random() < 0.05  # 5% chance
            original_response = response if is_edited else None
            edited_by = users[0].id if is_edited else None  # operator1
            
            # Random timestamp within last 30 days
            created_at = datetime.utcnow() - timedelta(days=random.randint(0, 30))
            
            session = AISession(
                user_id=user.id,
                prompt=prompt,
                response=response,
                model_name=model,
                is_flagged=is_flagged,
                flag_reason=flag_reason,
                is_edited=is_edited,
                original_response=original_response,
                edited_by=edited_by,
                created_at=created_at,
                updated_at=created_at
            )
            
            sessions.append(session)
            db.session.add(session)
        
        db.session.flush()
        
        # Create sample AI usage records
        print("Creating sample AI usage records...")
        for session in sessions:
            # Calculate token usage based on content length
            prompt_tokens = len(session.prompt.split()) * 1.3
            completion_tokens = len(session.response.split()) * 1.3
            
            # Calculate credits based on model
            model_costs = {
                'gpt-4': 0.03,
                'gpt-3.5-turbo': 0.002,
                'claude-3-opus': 0.015,
                'claude-3-sonnet': 0.003,
                'claude-3-haiku': 0.00025,
                'gemini-pro': 0.001
            }
            
            cost_per_token = model_costs.get(session.model_name, 0.002)
            credits_used = int((prompt_tokens + completion_tokens) * cost_per_token * 1000)
            
            usage = AIUsage(
                user_id=session.user_id,
                organization_id=User.query.get(session.user_id).organization_id,
                session_id=session.id,
                credits_used=credits_used,
                model_name=session.model_name,
                prompt_tokens=int(prompt_tokens),
                completion_tokens=int(completion_tokens),
                timestamp=session.created_at
            )
            
            db.session.add(usage)
        
        # Commit all changes
        db.session.commit()
        
        print("Sample data created successfully!")
        print(f"Created {len(organizations)} organizations")
        print(f"Created {len(users)} users")
        print(f"Created {len(templates)} prompt templates")
        print(f"Created {len(sessions)} AI sessions")
        print(f"Created {len(sessions)} usage records")
        
        # Print login credentials
        print("\n" + "="*50)
        print("LOGIN CREDENTIALS")
        print("="*50)
        print("Operators:")
        print("  Username: operator1, Password: operator123")
        print("  Username: operator2, Password: operator123")
        print("\nAdmins:")
        print("  Username: admin1, Password: admin123")
        print("\nRegular Users:")
        print("  Username: john_doe, Password: user123")
        print("  Username: jane_smith, Password: user123")
        print("  Username: bob_wilson, Password: user123")
        print("  Username: alice_brown, Password: user123")
        print("  Username: charlie_davis, Password: user123")

if __name__ == '__main__':
    create_sample_data()

