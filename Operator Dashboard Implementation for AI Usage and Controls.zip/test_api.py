import unittest
import json
import tempfile
import os
from src.main import app, db
from src.models.user import User, Organization, AISession, PromptTemplate, UserRole
from werkzeug.security import generate_password_hash

class BaseTestCase(unittest.TestCase):
    """Base test case with common setup and teardown"""
    
    def setUp(self):
        """Set up test database and client"""
        self.db_fd, app.config['DATABASE'] = tempfile.mkstemp()
        app.config['TESTING'] = True
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        app.config['WTF_CSRF_ENABLED'] = False
        
        self.app = app.test_client()
        self.app_context = app.app_context()
        self.app_context.push()
        
        db.create_all()
        self.create_test_data()
    
    def tearDown(self):
        """Clean up after tests"""
        db.session.remove()
        db.drop_all()
        self.app_context.pop()
        os.close(self.db_fd)
        os.unlink(app.config['DATABASE'])
    
    def create_test_data(self):
        """Create test users and organizations"""
        # Create test organization
        self.test_org = Organization(
            name='Test Organization',
            credit_limit=1000,
            credits_used=100,
            rate_limit_per_hour=100
        )
        db.session.add(self.test_org)
        db.session.flush()
        
        # Create test users
        self.test_user = User(
            username='testuser',
            email='test@example.com',
            password_hash=generate_password_hash('password123'),
            role=UserRole.USER,
            organization_id=self.test_org.id
        )
        
        self.test_operator = User(
            username='operator',
            email='operator@example.com',
            password_hash=generate_password_hash('operator123'),
            role=UserRole.OPERATOR,
            organization_id=self.test_org.id
        )
        
        self.test_admin = User(
            username='admin',
            email='admin@example.com',
            password_hash=generate_password_hash('admin123'),
            role=UserRole.ADMIN,
            organization_id=self.test_org.id
        )
        
        db.session.add_all([self.test_user, self.test_operator, self.test_admin])
        db.session.commit()
    
    def get_auth_token(self, username, password):
        """Get JWT token for authentication"""
        response = self.app.post('/api/auth/login', 
                                data=json.dumps({
                                    'username': username,
                                    'password': password
                                }),
                                content_type='application/json')
        
        if response.status_code == 200:
            data = json.loads(response.data)
            return data['access_token']
        return None
    
    def get_auth_headers(self, token):
        """Get authorization headers with token"""
        return {'Authorization': f'Bearer {token}'}

class AuthTestCase(BaseTestCase):
    """Test authentication endpoints"""
    
    def test_login_success(self):
        """Test successful login"""
        response = self.app.post('/api/auth/login',
                                data=json.dumps({
                                    'username': 'testuser',
                                    'password': 'password123'
                                }),
                                content_type='application/json')
        
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('access_token', data)
        self.assertIn('user', data)
        self.assertEqual(data['user']['username'], 'testuser')
    
    def test_login_invalid_credentials(self):
        """Test login with invalid credentials"""
        response = self.app.post('/api/auth/login',
                                data=json.dumps({
                                    'username': 'testuser',
                                    'password': 'wrongpassword'
                                }),
                                content_type='application/json')
        
        self.assertEqual(response.status_code, 401)
        data = json.loads(response.data)
        self.assertIn('error', data)
    
    def test_login_missing_fields(self):
        """Test login with missing fields"""
        response = self.app.post('/api/auth/login',
                                data=json.dumps({
                                    'username': 'testuser'
                                }),
                                content_type='application/json')
        
        self.assertEqual(response.status_code, 400)
        data = json.loads(response.data)
        self.assertIn('error', data)
    
    def test_register_success(self):
        """Test successful user registration"""
        response = self.app.post('/api/auth/register',
                                data=json.dumps({
                                    'username': 'newuser',
                                    'email': 'newuser@example.com',
                                    'password': 'newpassword123',
                                    'organization_id': self.test_org.id
                                }),
                                content_type='application/json')
        
        self.assertEqual(response.status_code, 201)
        data = json.loads(response.data)
        self.assertIn('user', data)
        self.assertEqual(data['user']['username'], 'newuser')
    
    def test_register_duplicate_username(self):
        """Test registration with duplicate username"""
        response = self.app.post('/api/auth/register',
                                data=json.dumps({
                                    'username': 'testuser',  # Already exists
                                    'email': 'newemail@example.com',
                                    'password': 'password123'
                                }),
                                content_type='application/json')
        
        self.assertEqual(response.status_code, 409)
        data = json.loads(response.data)
        self.assertIn('error', data)
    
    def test_get_current_user(self):
        """Test getting current user info"""
        token = self.get_auth_token('testuser', 'password123')
        headers = self.get_auth_headers(token)
        
        response = self.app.get('/api/auth/me', headers=headers)
        
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('user', data)
        self.assertEqual(data['user']['username'], 'testuser')

class OperatorTestCase(BaseTestCase):
    """Test operator endpoints"""
    
    def setUp(self):
        super().setUp()
        self.operator_token = self.get_auth_token('operator', 'operator123')
        self.operator_headers = self.get_auth_headers(self.operator_token)
        self.user_token = self.get_auth_token('testuser', 'password123')
        self.user_headers = self.get_auth_headers(self.user_token)
    
    def test_operator_access_required(self):
        """Test that operator endpoints require operator role"""
        response = self.app.get('/api/operator/usage', headers=self.user_headers)
        self.assertEqual(response.status_code, 403)
    
    def test_get_usage_metrics(self):
        """Test getting usage metrics"""
        response = self.app.get('/api/operator/usage', headers=self.operator_headers)
        
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('organization_usage', data)
        self.assertIn('user_usage', data)
        self.assertIn('model_usage', data)
        self.assertIn('daily_trend', data)
    
    def test_get_usage_metrics_with_period(self):
        """Test getting usage metrics with different periods"""
        for period in ['day', 'week', 'month']:
            response = self.app.get(f'/api/operator/usage?period={period}', 
                                  headers=self.operator_headers)
            self.assertEqual(response.status_code, 200)
            data = json.loads(response.data)
            self.assertEqual(data['period'], period)
    
    def test_get_sessions(self):
        """Test getting AI sessions"""
        response = self.app.get('/api/operator/sessions', headers=self.operator_headers)
        
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('sessions', data)
        self.assertIn('pagination', data)
    
    def test_update_session_flag(self):
        """Test flagging/unflagging a session"""
        # Create a test session
        session = AISession(
            user_id=self.test_user.id,
            prompt='Test prompt',
            response='Test response',
            model_name='gpt-3.5-turbo'
        )
        db.session.add(session)
        db.session.commit()
        
        # Flag the session
        response = self.app.patch(f'/api/operator/sessions/{session.id}',
                                 data=json.dumps({
                                     'is_flagged': True,
                                     'flag_reason': 'Test flag reason'
                                 }),
                                 content_type='application/json',
                                 headers=self.operator_headers)
        
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertTrue(data['session']['is_flagged'])
        self.assertEqual(data['session']['flag_reason'], 'Test flag reason')
    
    def test_update_session_response(self):
        """Test editing a session response"""
        # Create a test session
        session = AISession(
            user_id=self.test_user.id,
            prompt='Test prompt',
            response='Original response',
            model_name='gpt-3.5-turbo'
        )
        db.session.add(session)
        db.session.commit()
        
        # Edit the response
        new_response = 'Edited response'
        response = self.app.patch(f'/api/operator/sessions/{session.id}',
                                 data=json.dumps({
                                     'response': new_response
                                 }),
                                 content_type='application/json',
                                 headers=self.operator_headers)
        
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertEqual(data['session']['response'], new_response)
        self.assertTrue(data['session']['is_edited'])
        self.assertEqual(data['session']['original_response'], 'Original response')
    
    def test_get_prompt_templates(self):
        """Test getting prompt templates"""
        response = self.app.get('/api/operator/prompts', headers=self.operator_headers)
        
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('templates', data)
        self.assertIn('pagination', data)
    
    def test_create_prompt_template(self):
        """Test creating a prompt template"""
        template_data = {
            'name': 'Test Template',
            'description': 'A test template',
            'template': 'This is a test template with {variable}',
            'model_name': 'gpt-3.5-turbo'
        }
        
        response = self.app.post('/api/operator/prompts',
                                data=json.dumps(template_data),
                                content_type='application/json',
                                headers=self.operator_headers)
        
        self.assertEqual(response.status_code, 201)
        data = json.loads(response.data)
        self.assertIn('template', data)
        self.assertEqual(data['template']['name'], 'Test Template')
    
    def test_update_prompt_template(self):
        """Test updating a prompt template"""
        # Create a test template
        template = PromptTemplate(
            name='Original Template',
            template='Original template content',
            model_name='gpt-3.5-turbo',
            created_by=self.test_operator.id
        )
        db.session.add(template)
        db.session.commit()
        
        # Update the template
        update_data = {
            'name': 'Updated Template',
            'template': 'Updated template content'
        }
        
        response = self.app.put(f'/api/operator/prompts/{template.id}',
                               data=json.dumps(update_data),
                               content_type='application/json',
                               headers=self.operator_headers)
        
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertEqual(data['template']['name'], 'Updated Template')
        self.assertEqual(data['template']['version'], 2)  # Version should increment
    
    def test_delete_prompt_template(self):
        """Test deleting a prompt template"""
        # Create a test template
        template = PromptTemplate(
            name='Template to Delete',
            template='Template content',
            model_name='gpt-3.5-turbo',
            created_by=self.test_operator.id
        )
        db.session.add(template)
        db.session.commit()
        
        # Delete the template
        response = self.app.delete(f'/api/operator/prompts/{template.id}',
                                  headers=self.operator_headers)
        
        self.assertEqual(response.status_code, 200)
        
        # Verify template is deleted
        deleted_template = PromptTemplate.query.get(template.id)
        self.assertIsNone(deleted_template)
    
    def test_update_organization_limits(self):
        """Test updating organization limits"""
        update_data = {
            'credit_limit': 500,
            'rate_limit_per_hour': 50
        }
        
        response = self.app.patch(f'/api/operator/organizations/{self.test_org.id}/limits',
                                 data=json.dumps(update_data),
                                 content_type='application/json',
                                 headers=self.operator_headers)
        
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertEqual(data['organization']['credit_limit'], 500)
        self.assertEqual(data['organization']['rate_limit_per_hour'], 50)
    
    def test_update_organization_limits_exceeds_max(self):
        """Test updating organization limits beyond maximum"""
        update_data = {
            'credit_limit': 1500  # Exceeds maximum of 1000
        }
        
        response = self.app.patch(f'/api/operator/organizations/{self.test_org.id}/limits',
                                 data=json.dumps(update_data),
                                 content_type='application/json',
                                 headers=self.operator_headers)
        
        self.assertEqual(response.status_code, 400)
        data = json.loads(response.data)
        self.assertIn('error', data)

if __name__ == '__main__':
    unittest.main()

