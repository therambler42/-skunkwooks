import unittest
import json
from unittest.mock import patch, MagicMock
from src.main import app, db
from src.models.user import User, Organization, AIUsage, UserRole
from src.middleware.limits import check_credit_limit, check_rate_limit, track_ai_usage
from werkzeug.security import generate_password_hash
from tests.test_api import BaseTestCase

class RateLimitingTestCase(BaseTestCase):
    """Test rate limiting and credit controls"""
    
    def setUp(self):
        super().setUp()
        self.user_token = self.get_auth_token('testuser', 'password123')
        self.user_headers = self.get_auth_headers(self.user_token)
        
        # Create organization with low limits for testing
        self.limited_org = Organization(
            name='Limited Organization',
            credit_limit=10,  # Very low limit
            credits_used=0,
            rate_limit_per_hour=2  # Very low rate limit
        )
        db.session.add(self.limited_org)
        db.session.flush()
        
        self.limited_user = User(
            username='limiteduser',
            email='limited@example.com',
            password_hash=generate_password_hash('password123'),
            role=UserRole.USER,
            organization_id=self.limited_org.id
        )
        db.session.add(self.limited_user)
        db.session.commit()
        
        self.limited_token = self.get_auth_token('limiteduser', 'password123')
        self.limited_headers = self.get_auth_headers(self.limited_token)
    
    def test_ai_chat_success(self):
        """Test successful AI chat request"""
        response = self.app.post('/api/ai/chat',
                                data=json.dumps({
                                    'prompt': 'Hello, how are you?',
                                    'model_name': 'gpt-3.5-turbo'
                                }),
                                content_type='application/json',
                                headers=self.user_headers)
        
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('response', data)
        self.assertIn('session_id', data)
        self.assertIn('usage', data)
        self.assertIn('credits_used', data['usage'])
    
    def test_ai_chat_missing_prompt(self):
        """Test AI chat request without prompt"""
        response = self.app.post('/api/ai/chat',
                                data=json.dumps({
                                    'model_name': 'gpt-3.5-turbo'
                                }),
                                content_type='application/json',
                                headers=self.user_headers)
        
        self.assertEqual(response.status_code, 400)
        data = json.loads(response.data)
        self.assertIn('error', data)
    
    def test_credit_limit_enforcement(self):
        """Test that credit limits are enforced"""
        # Exhaust the credit limit
        self.limited_org.credits_used = self.limited_org.credit_limit
        db.session.commit()
        
        response = self.app.post('/api/ai/chat',
                                data=json.dumps({
                                    'prompt': 'This should be blocked',
                                    'model_name': 'gpt-3.5-turbo'
                                }),
                                content_type='application/json',
                                headers=self.limited_headers)
        
        self.assertEqual(response.status_code, 429)
        data = json.loads(response.data)
        self.assertIn('Credit limit exceeded', data['error'])
        self.assertIn('credits_used', data)
        self.assertIn('credit_limit', data)
    
    @patch('src.middleware.limits.REDIS_AVAILABLE', False)
    def test_rate_limit_enforcement_memory(self):
        """Test rate limiting with in-memory storage"""
        # Make requests up to the limit
        for i in range(self.limited_org.rate_limit_per_hour):
            response = self.app.post('/api/ai/chat',
                                    data=json.dumps({
                                        'prompt': f'Request {i+1}',
                                        'model_name': 'gpt-3.5-turbo'
                                    }),
                                    content_type='application/json',
                                    headers=self.limited_headers)
            
            if response.status_code != 200:
                break
        
        # Next request should be rate limited
        response = self.app.post('/api/ai/chat',
                                data=json.dumps({
                                    'prompt': 'This should be rate limited',
                                    'model_name': 'gpt-3.5-turbo'
                                }),
                                content_type='application/json',
                                headers=self.limited_headers)
        
        self.assertEqual(response.status_code, 429)
        data = json.loads(response.data)
        self.assertIn('Rate limit exceeded', data['error'])
        self.assertIn('requests_made', data)
        self.assertIn('rate_limit', data)
    
    def test_get_available_models(self):
        """Test getting available AI models"""
        response = self.app.get('/api/ai/models', headers=self.user_headers)
        
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('models', data)
        self.assertIsInstance(data['models'], list)
        self.assertGreater(len(data['models']), 0)
        
        # Check model structure
        model = data['models'][0]
        self.assertIn('name', model)
        self.assertIn('description', model)
        self.assertIn('cost_per_1k_tokens', model)
    
    def test_get_current_usage(self):
        """Test getting current usage and limits"""
        response = self.app.get('/api/ai/usage/current', headers=self.user_headers)
        
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('organization', data)
        self.assertIn('rate_limit', data)
        
        org_data = data['organization']
        self.assertIn('credit_limit', org_data)
        self.assertIn('credits_used', org_data)
        self.assertIn('credits_remaining', org_data)
        self.assertIn('usage_percentage', org_data)
    
    def test_track_ai_usage(self):
        """Test AI usage tracking"""
        # Make an AI request
        response = self.app.post('/api/ai/chat',
                                data=json.dumps({
                                    'prompt': 'Test usage tracking',
                                    'model_name': 'gpt-3.5-turbo'
                                }),
                                content_type='application/json',
                                headers=self.user_headers)
        
        self.assertEqual(response.status_code, 200)
        
        # Check that usage was tracked
        usage_records = AIUsage.query.filter_by(user_id=self.test_user.id).all()
        self.assertGreater(len(usage_records), 0)
        
        latest_usage = usage_records[-1]
        self.assertEqual(latest_usage.model_name, 'gpt-3.5-turbo')
        self.assertGreater(latest_usage.credits_used, 0)
        self.assertGreater(latest_usage.prompt_tokens, 0)
        self.assertGreater(latest_usage.completion_tokens, 0)
    
    def test_different_model_costs(self):
        """Test that different models have different costs"""
        models_to_test = ['gpt-4', 'gpt-3.5-turbo', 'claude-3-haiku']
        costs = []
        
        for model in models_to_test:
            response = self.app.post('/api/ai/chat',
                                    data=json.dumps({
                                        'prompt': 'Test prompt for cost comparison',
                                        'model_name': model
                                    }),
                                    content_type='application/json',
                                    headers=self.user_headers)
            
            if response.status_code == 200:
                data = json.loads(response.data)
                costs.append(data['usage']['credits_used'])
        
        # Verify that costs are different (GPT-4 should be most expensive)
        if len(costs) >= 2:
            self.assertNotEqual(costs[0], costs[1])
    
    def test_unauthorized_access(self):
        """Test that AI endpoints require authentication"""
        response = self.app.post('/api/ai/chat',
                                data=json.dumps({
                                    'prompt': 'This should fail',
                                    'model_name': 'gpt-3.5-turbo'
                                }),
                                content_type='application/json')
        
        self.assertEqual(response.status_code, 401)
    
    def test_organization_not_found(self):
        """Test behavior when user has no organization"""
        # Create user without organization
        orphan_user = User(
            username='orphanuser',
            email='orphan@example.com',
            password_hash=generate_password_hash('password123'),
            role=UserRole.USER,
            organization_id=None
        )
        db.session.add(orphan_user)
        db.session.commit()
        
        orphan_token = self.get_auth_token('orphanuser', 'password123')
        orphan_headers = self.get_auth_headers(orphan_token)
        
        response = self.app.post('/api/ai/chat',
                                data=json.dumps({
                                    'prompt': 'This should fail',
                                    'model_name': 'gpt-3.5-turbo'
                                }),
                                content_type='application/json',
                                headers=orphan_headers)
        
        self.assertEqual(response.status_code, 404)
        data = json.loads(response.data)
        self.assertIn('organization not found', data['error'].lower())

class CreditTrackingTestCase(BaseTestCase):
    """Test credit tracking functionality"""
    
    def setUp(self):
        super().setUp()
        self.user_token = self.get_auth_token('testuser', 'password123')
        self.user_headers = self.get_auth_headers(self.user_token)
    
    def test_credits_accumulate(self):
        """Test that credits accumulate with multiple requests"""
        initial_credits = self.test_org.credits_used
        
        # Make multiple requests
        for i in range(3):
            response = self.app.post('/api/ai/chat',
                                    data=json.dumps({
                                        'prompt': f'Request {i+1} to accumulate credits',
                                        'model_name': 'gpt-3.5-turbo'
                                    }),
                                    content_type='application/json',
                                    headers=self.user_headers)
            
            self.assertEqual(response.status_code, 200)
        
        # Refresh organization data
        db.session.refresh(self.test_org)
        
        # Credits should have increased
        self.assertGreater(self.test_org.credits_used, initial_credits)
    
    def test_usage_records_created(self):
        """Test that usage records are created for each request"""
        initial_count = AIUsage.query.count()
        
        response = self.app.post('/api/ai/chat',
                                data=json.dumps({
                                    'prompt': 'Test usage record creation',
                                    'model_name': 'gpt-3.5-turbo'
                                }),
                                content_type='application/json',
                                headers=self.user_headers)
        
        self.assertEqual(response.status_code, 200)
        
        # Should have one more usage record
        final_count = AIUsage.query.count()
        self.assertEqual(final_count, initial_count + 1)
        
        # Check the usage record details
        latest_usage = AIUsage.query.order_by(AIUsage.id.desc()).first()
        self.assertEqual(latest_usage.user_id, self.test_user.id)
        self.assertEqual(latest_usage.organization_id, self.test_org.id)
        self.assertEqual(latest_usage.model_name, 'gpt-3.5-turbo')

if __name__ == '__main__':
    unittest.main()

