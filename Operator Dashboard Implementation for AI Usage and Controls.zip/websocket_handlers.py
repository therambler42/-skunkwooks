from flask_socketio import emit, join_room, leave_room
from flask_jwt_extended import jwt_required, get_jwt_identity, decode_token
from src.models.user import User, UserRole
from src.main import socketio
import logging

# Store connected operators
connected_operators = set()

@socketio.on('connect')
def handle_connect(auth):
    """Handle WebSocket connection"""
    try:
        # Verify JWT token from auth
        if not auth or 'token' not in auth:
            return False
        
        token = auth['token']
        decoded_token = decode_token(token)
        user_id = decoded_token['sub']
        
        user = User.query.get(user_id)
        if not user or user.role != UserRole.OPERATOR:
            return False
        
        # Join operator room for broadcasts
        join_room('operators')
        connected_operators.add(user_id)
        
        emit('connected', {'message': 'Connected to operator dashboard'})
        logging.info(f"Operator {user.username} connected via WebSocket")
        
    except Exception as e:
        logging.error(f"WebSocket connection error: {e}")
        return False

@socketio.on('disconnect')
def handle_disconnect():
    """Handle WebSocket disconnection"""
    try:
        # Remove from connected operators if present
        # Note: In a production environment, you'd want to track user_id more precisely
        leave_room('operators')
        logging.info("Operator disconnected from WebSocket")
        
    except Exception as e:
        logging.error(f"WebSocket disconnection error: {e}")

@socketio.on('join_session_room')
def handle_join_session_room(data):
    """Join a specific session room for updates"""
    try:
        session_id = data.get('session_id')
        if session_id:
            join_room(f'session_{session_id}')
            emit('joined_session_room', {'session_id': session_id})
            
    except Exception as e:
        logging.error(f"Error joining session room: {e}")

@socketio.on('leave_session_room')
def handle_leave_session_room(data):
    """Leave a specific session room"""
    try:
        session_id = data.get('session_id')
        if session_id:
            leave_room(f'session_{session_id}')
            emit('left_session_room', {'session_id': session_id})
            
    except Exception as e:
        logging.error(f"Error leaving session room: {e}")

def broadcast_session_update(session_id, session_data, update_type='updated'):
    """Broadcast session updates to connected operators"""
    try:
        socketio.emit('session_updated', {
            'session_id': session_id,
            'session': session_data,
            'update_type': update_type,
            'timestamp': session_data.get('updated_at')
        }, room='operators')
        
        # Also emit to specific session room
        socketio.emit('session_updated', {
            'session_id': session_id,
            'session': session_data,
            'update_type': update_type,
            'timestamp': session_data.get('updated_at')
        }, room=f'session_{session_id}')
        
    except Exception as e:
        logging.error(f"Error broadcasting session update: {e}")

def broadcast_usage_update(usage_data):
    """Broadcast usage metrics updates to connected operators"""
    try:
        socketio.emit('usage_updated', {
            'usage_data': usage_data,
            'timestamp': usage_data.get('timestamp')
        }, room='operators')
        
    except Exception as e:
        logging.error(f"Error broadcasting usage update: {e}")

def broadcast_template_update(template_id, template_data, update_type='updated'):
    """Broadcast prompt template updates to connected operators"""
    try:
        socketio.emit('template_updated', {
            'template_id': template_id,
            'template': template_data,
            'update_type': update_type,
            'timestamp': template_data.get('updated_at')
        }, room='operators')
        
    except Exception as e:
        logging.error(f"Error broadcasting template update: {e}")

def broadcast_organization_update(org_id, org_data, update_type='updated'):
    """Broadcast organization limit updates to connected operators"""
    try:
        socketio.emit('organization_updated', {
            'org_id': org_id,
            'organization': org_data,
            'update_type': update_type
        }, room='operators')
        
    except Exception as e:
        logging.error(f"Error broadcasting organization update: {e}")

