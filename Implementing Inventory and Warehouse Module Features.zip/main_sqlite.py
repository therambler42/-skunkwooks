import os
import sys
# DON'T CHANGE: Add the src directory to the Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))

from flask import Flask, jsonify
from flask_cors import CORS

# Import routes
from routes.warehouses import warehouses_bp
from routes.items import items_bp
from routes.lots import lots_bp
from routes.inventory import inventory_bp

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Register blueprints
app.register_blueprint(warehouses_bp, url_prefix='/api')
app.register_blueprint(items_bp, url_prefix='/api')
app.register_blueprint(lots_bp, url_prefix='/api')
app.register_blueprint(inventory_bp, url_prefix='/api')

@app.route('/')
def index():
    return {'message': 'Inventory & Warehouse Management API', 'version': '1.0.0'}

@app.route('/api/health')
def health_check():
    return {'status': 'healthy', 'service': 'inventory-warehouse-api'}

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001, debug=True)

