from flask import Blueprint, request, jsonify
from models.database import get_db_connection

lots_bp = Blueprint('lots', __name__)

@lots_bp.route('/lots')
def get_lots():
    """Get all lots"""
    try:
        with get_db_connection() as conn:
            cursor = conn.execute('''
                SELECT l.*, i.sku, i.name as item_name 
                FROM inventory_lots l
                JOIN items i ON l.item_id = i.id
                WHERE l.is_active = 1 
                ORDER BY l.lot_number
            ''')
            lots = [dict(row) for row in cursor.fetchall()]
            return jsonify(lots)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@lots_bp.route('/lots/recall')
def lot_recall():
    """Get lot recall information"""
    try:
        lot_number = request.args.get('lot_number')
        if not lot_number:
            return jsonify({'error': 'lot_number parameter required'}), 400
        
        with get_db_connection() as conn:
            cursor = conn.execute('''
                SELECT 
                    il.*,
                    i.sku,
                    i.name as item_name,
                    lot.lot_number,
                    lot.manufactured_date,
                    lot.expiry_date,
                    w.code as warehouse_code,
                    w.name as warehouse_name,
                    lb.bin_code
                FROM inventory_ledger il
                JOIN items i ON il.item_id = i.id
                JOIN inventory_lots lot ON il.lot_id = lot.id
                JOIN warehouses w ON il.warehouse_id = w.id
                LEFT JOIN location_bins lb ON il.location_bin_id = lb.id
                WHERE lot.lot_number = ?
                ORDER BY il.created_at DESC
            ''', (lot_number,))
            
            recall_data = [dict(row) for row in cursor.fetchall()]
            return jsonify(recall_data)
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

