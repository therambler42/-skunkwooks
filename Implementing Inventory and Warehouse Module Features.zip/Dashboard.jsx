import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Package, AlertTriangle, TrendingUp, Warehouse } from 'lucide-react'

export default function Dashboard() {
  const [stats, setStats] = useState({
    totalItems: 0,
    totalQuantity: 0,
    expiringLots: 0,
    warehouses: 0
  })

  useEffect(() => {
    // Mock data for dashboard
    setStats({
      totalItems: 1247,
      totalQuantity: 45678,
      expiringLots: 23,
      warehouses: 5
    })
  }, [])

  const statCards = [
    {
      title: 'Total Items',
      value: stats.totalItems.toLocaleString(),
      description: 'Active inventory items',
      icon: Package,
      color: 'text-blue-600'
    },
    {
      title: 'Total Quantity',
      value: stats.totalQuantity.toLocaleString(),
      description: 'Units in stock',
      icon: TrendingUp,
      color: 'text-green-600'
    },
    {
      title: 'Expiring Soon',
      value: stats.expiringLots,
      description: 'Lots expiring in 30 days',
      icon: AlertTriangle,
      color: 'text-orange-600'
    },
    {
      title: 'Warehouses',
      value: stats.warehouses,
      description: 'Active locations',
      icon: Warehouse,
      color: 'text-purple-600'
    }
  ]

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Welcome to Inventory Management</h2>
        <p className="text-muted-foreground">
          Monitor your warehouse operations and inventory levels in real-time.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {statCards.map((stat) => {
          const Icon = stat.icon
          return (
            <Card key={stat.title}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  {stat.title}
                </CardTitle>
                <Icon className={`h-4 w-4 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
                <p className="text-xs text-muted-foreground">
                  {stat.description}
                </p>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Quick Actions */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Latest inventory movements</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Badge variant="outline">RECEIVE</Badge>
                  <span className="text-sm">SKU-001 received</span>
                </div>
                <span className="text-xs text-muted-foreground">2h ago</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Badge variant="outline">TRANSFER</Badge>
                  <span className="text-sm">SKU-002 transferred</span>
                </div>
                <span className="text-xs text-muted-foreground">4h ago</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Badge variant="outline">ADJUST</Badge>
                  <span className="text-sm">SKU-003 adjusted</span>
                </div>
                <span className="text-xs text-muted-foreground">6h ago</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Expiring Items</CardTitle>
            <CardDescription>Items requiring attention</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-medium">LOT-2024-001</div>
                  <div className="text-xs text-muted-foreground">SKU-FOOD-001</div>
                </div>
                <Badge variant="destructive">5 days</Badge>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-medium">LOT-2024-002</div>
                  <div className="text-xs text-muted-foreground">SKU-FOOD-002</div>
                </div>
                <Badge variant="destructive">12 days</Badge>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-medium">LOT-2024-003</div>
                  <div className="text-xs text-muted-foreground">SKU-FOOD-003</div>
                </div>
                <Badge variant="secondary">25 days</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Low Stock Alerts</CardTitle>
            <CardDescription>Items below minimum levels</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-medium">SKU-PART-001</div>
                  <div className="text-xs text-muted-foreground">Warehouse A</div>
                </div>
                <Badge variant="outline">5 units</Badge>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-medium">SKU-PART-002</div>
                  <div className="text-xs text-muted-foreground">Warehouse B</div>
                </div>
                <Badge variant="outline">12 units</Badge>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-medium">SKU-PART-003</div>
                  <div className="text-xs text-muted-foreground">Warehouse C</div>
                </div>
                <Badge variant="outline">8 units</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

