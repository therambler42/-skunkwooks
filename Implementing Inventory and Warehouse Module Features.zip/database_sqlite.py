import sqlite3
import os
from contextlib import contextmanager

# Use SQLite for deployment compatibility
DATABASE_PATH = os.path.join(os.path.dirname(__file__), '..', 'inventory.db')

@contextmanager
def get_db_connection():
    """Get database connection context manager"""
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row  # Enable column access by name
    try:
        yield conn
    finally:
        conn.close()

def init_db():
    """Initialize SQLite database with schema"""
    with get_db_connection() as conn:
        # Create tables for SQLite
        conn.executescript('''
            CREATE TABLE IF NOT EXISTS warehouses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                code TEXT UNIQUE NOT NULL,
                name TEXT NOT NULL,
                address TEXT,
                city TEXT,
                state TEXT,
                country TEXT,
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sku TEXT UNIQUE NOT NULL,
                name TEXT NOT NULL,
                description TEXT,
                category TEXT,
                unit_of_measure TEXT DEFAULT 'EA',
                requires_lot_tracking BOOLEAN DEFAULT 1,
                requires_expiry_tracking BOOLEAN DEFAULT 0,
                shelf_life_days INTEGER,
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS inventory_lots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                item_id INTEGER NOT NULL,
                lot_number TEXT NOT NULL,
                manufactured_date DATE,
                expiry_date DATE,
                supplier_id INTEGER,
                quality_status TEXT DEFAULT 'APPROVED',
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (item_id) REFERENCES items (id),
                UNIQUE (item_id, lot_number)
            );

            CREATE TABLE IF NOT EXISTS location_bins (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                warehouse_id INTEGER NOT NULL,
                zone TEXT,
                aisle TEXT,
                rack TEXT,
                shelf TEXT,
                bin TEXT,
                bin_code TEXT UNIQUE NOT NULL,
                bin_type TEXT DEFAULT 'STORAGE',
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (warehouse_id) REFERENCES warehouses (id)
            );

            CREATE TABLE IF NOT EXISTS inventory_ledger (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                transaction_id TEXT NOT NULL,
                item_id INTEGER NOT NULL,
                lot_id INTEGER,
                warehouse_id INTEGER NOT NULL,
                location_bin_id INTEGER,
                movement_type TEXT NOT NULL,
                quantity_change DECIMAL(15,6) NOT NULL,
                quantity_before DECIMAL(15,6) DEFAULT 0,
                quantity_after DECIMAL(15,6) DEFAULT 0,
                unit_cost DECIMAL(10,2),
                total_cost DECIMAL(15,2),
                reason_code TEXT,
                reference_document TEXT,
                notes TEXT,
                created_by TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (item_id) REFERENCES items (id),
                FOREIGN KEY (lot_id) REFERENCES inventory_lots (id),
                FOREIGN KEY (warehouse_id) REFERENCES warehouses (id),
                FOREIGN KEY (location_bin_id) REFERENCES location_bins (id)
            );

            -- Insert sample data
            INSERT OR IGNORE INTO warehouses (code, name, address, city, state, country) VALUES
            ('WH-001', 'Main Warehouse', '100 Industrial Blvd', 'City 1', 'CA', 'USA'),
            ('WH-002', 'Distribution Center', '200 Industrial Blvd', 'City 2', 'CA', 'USA');

            INSERT OR IGNORE INTO items (sku, name, description, category, requires_expiry_tracking, shelf_life_days) VALUES
            ('SKU-FOOD-001', 'Organic Apples', 'Fresh organic apples', 'Food', 1, 30),
            ('SKU-ELEC-001', 'Smartphone', 'Latest smartphone model', 'Electronics', 0, NULL),
            ('SKU-PHARM-001', 'Vitamin C', 'Vitamin C supplements', 'Pharmaceuticals', 1, 365);

            INSERT OR IGNORE INTO location_bins (warehouse_id, zone, aisle, rack, shelf, bin, bin_code) VALUES
            (1, 'A', '01', '01', '01', '01', 'A-01-01-01'),
            (1, 'A', '01', '01', '02', '01', 'A-01-01-02'),
            (2, 'B', '01', '01', '01', '01', 'B-01-01-01');

            INSERT OR IGNORE INTO inventory_lots (item_id, lot_number, manufactured_date, expiry_date) VALUES
            (1, 'LOT-2024-001', '2024-06-01', '2024-07-01'),
            (2, 'LOT-2024-002', '2024-06-01', NULL),
            (3, 'LOT-2024-003', '2024-06-01', '2025-06-01');

            INSERT OR IGNORE INTO inventory_ledger (transaction_id, item_id, lot_id, warehouse_id, location_bin_id, movement_type, quantity_change, quantity_before, quantity_after, created_by) VALUES
            ('TXN-001', 1, 1, 1, 1, 'RECEIVE', 100, 0, 100, 'system'),
            ('TXN-002', 2, 2, 1, 2, 'RECEIVE', 50, 0, 50, 'system'),
            ('TXN-003', 3, 3, 2, 3, 'RECEIVE', 200, 0, 200, 'system');
        ''')
        conn.commit()

# Initialize database on import
init_db()

