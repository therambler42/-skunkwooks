import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { Toaster } from '@/components/ui/sonner'
import Layout from './components/Layout'
import InventoryList from './pages/InventoryList'
import InventoryTransfer from './pages/InventoryTransfer'
import InventoryAdjust from './pages/InventoryAdjust'
import InventoryReceive from './pages/InventoryReceive'
import Dashboard from './pages/Dashboard'
import './App.css'

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Layout>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/inventory" element={<InventoryList />} />
            <Route path="/transfer" element={<InventoryTransfer />} />
            <Route path="/adjust" element={<InventoryAdjust />} />
            <Route path="/receive" element={<InventoryReceive />} />
          </Routes>
        </Layout>
        <Toaster />
      </div>
    </Router>
  )
}

export default App

