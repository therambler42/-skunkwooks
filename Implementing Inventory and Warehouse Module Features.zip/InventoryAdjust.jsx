import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { useToast } from '@/hooks/use-toast'
import { Settings, Package, TrendingUp, TrendingDown } from 'lucide-react'

const API_BASE_URL = 'https://r19hnincw78w.manus.space/api'

const REASON_CODES = [
  { value: 'CYCLE_COUNT', label: 'Cycle Count Adjustment' },
  { value: 'DAMAGE', label: 'Damaged Goods' },
  { value: 'EXPIRED', label: 'Expired Items' },
  { value: 'FOUND', label: 'Found Inventory' },
  { value: 'LOST', label: 'Lost/Missing Inventory' },
  { value: 'QUALITY', label: 'Quality Issues' },
  { value: 'SYSTEM_ERROR', label: 'System Error Correction' },
  { value: 'OTHER', label: 'Other' }
]

export default function InventoryAdjust() {
  const [inventory, setInventory] = useState([])
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    item_id: '',
    lot_id: '',
    warehouse_id: '',
    location_bin_id: '',
    quantity_change: '',
    reason_code: '',
    reference_document: '',
    notes: ''
  })
  const { toast } = useToast()

  useEffect(() => {
    fetchInventory()
  }, [])

  const fetchInventory = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/inventory/current`)
      if (response.ok) {
        const data = await response.json()
        setInventory(data)
      }
    } catch (error) {
      console.error('Error fetching inventory:', error)
    }
  }

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }))
  }

  const handleInventorySelection = (inventoryKey) => {
    const [itemId, lotId, warehouseId, locationId] = inventoryKey.split('-')
    setFormData(prev => ({
      ...prev,
      item_id: itemId,
      lot_id: lotId,
      warehouse_id: warehouseId,
      location_bin_id: locationId
    }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)

    try {
      const adjustData = {
        item_id: parseInt(formData.item_id),
        lot_id: parseInt(formData.lot_id),
        warehouse_id: parseInt(formData.warehouse_id),
        location_bin_id: parseInt(formData.location_bin_id),
        quantity_change: parseFloat(formData.quantity_change),
        reason_code: formData.reason_code,
        reference_document: formData.reference_document || null,
        notes: formData.notes || null,
        created_by: 'user'
      }

      const response = await fetch(`${API_BASE_URL}/inventory/adjust`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(adjustData),
      })

      if (response.ok) {
        const result = await response.json()
        const adjustmentType = parseFloat(formData.quantity_change) > 0 ? 'increased' : 'decreased'
        toast({
          title: "Adjustment Completed",
          description: `Successfully ${adjustmentType} inventory by ${Math.abs(parseFloat(formData.quantity_change))} units. Transaction ID: ${result.transaction_id}`,
        })
        
        // Reset form
        setFormData({
          item_id: '',
          lot_id: '',
          warehouse_id: '',
          location_bin_id: '',
          quantity_change: '',
          reason_code: '',
          reference_document: '',
          notes: ''
        })
        
        // Refresh inventory
        fetchInventory()
      } else {
        const error = await response.json()
        throw new Error(error.error || 'Failed to adjust inventory')
      }
    } catch (error) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const selectedInventoryItem = inventory.find(item => 
    item.item_id === parseInt(formData.item_id) &&
    item.lot_id === parseInt(formData.lot_id) &&
    item.warehouse_id === parseInt(formData.warehouse_id) &&
    item.location_bin_id === parseInt(formData.location_bin_id)
  )

  const currentQuantity = selectedInventoryItem ? parseFloat(selectedInventoryItem.current_quantity) : 0
  const quantityChange = parseFloat(formData.quantity_change) || 0
  const newQuantity = currentQuantity + quantityChange
  const isIncrease = quantityChange > 0
  const isDecrease = quantityChange < 0

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Adjust Inventory</h2>
        <p className="text-muted-foreground">
          Make inventory adjustments for cycle counts, damages, and corrections
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Main Form */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Settings className="mr-2 h-5 w-5" />
                Adjustment Details
              </CardTitle>
              <CardDescription>
                Select inventory and specify the adjustment amount
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Inventory Selection */}
                <div className="space-y-2">
                  <Label htmlFor="inventory_item">Inventory Item *</Label>
                  <Select 
                    value={`${formData.item_id}-${formData.lot_id}-${formData.warehouse_id}-${formData.location_bin_id}`}
                    onValueChange={handleInventorySelection}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select inventory to adjust" />
                    </SelectTrigger>
                    <SelectContent>
                      {inventory.map((item) => (
                        <SelectItem 
                          key={`${item.item_id}-${item.lot_id}-${item.warehouse_id}-${item.location_bin_id}`}
                          value={`${item.item_id}-${item.lot_id}-${item.warehouse_id}-${item.location_bin_id}`}
                        >
                          {item.sku} - {item.lot_number} @ {item.warehouse_code}/{item.bin_code} ({parseFloat(item.current_quantity).toLocaleString()} {item.unit_of_measure})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Adjustment Amount */}
                <div className="space-y-2">
                  <Label htmlFor="quantity_change">Quantity Change *</Label>
                  <Input
                    id="quantity_change"
                    type="number"
                    step="0.001"
                    value={formData.quantity_change}
                    onChange={(e) => handleInputChange('quantity_change', e.target.value)}
                    placeholder="Enter adjustment amount (+ for increase, - for decrease)"
                    required
                  />
                  <p className="text-sm text-muted-foreground">
                    Use positive numbers to increase inventory, negative numbers to decrease
                  </p>
                  {selectedInventoryItem && quantityChange !== 0 && (
                    <div className="text-sm">
                      <span className="text-muted-foreground">Current: </span>
                      <span className="font-medium">{currentQuantity.toLocaleString()}</span>
                      <span className="mx-2">→</span>
                      <span className="font-medium">{newQuantity.toLocaleString()}</span>
                      <span className="text-muted-foreground"> {selectedInventoryItem.unit_of_measure}</span>
                    </div>
                  )}
                </div>

                {/* Reason Code */}
                <div className="space-y-2">
                  <Label htmlFor="reason_code">Reason Code *</Label>
                  <Select value={formData.reason_code} onValueChange={(value) => handleInputChange('reason_code', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select reason for adjustment" />
                    </SelectTrigger>
                    <SelectContent>
                      {REASON_CODES.map((reason) => (
                        <SelectItem key={reason.value} value={reason.value}>
                          {reason.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Reference Document */}
                <div className="space-y-2">
                  <Label htmlFor="reference_document">Reference Document</Label>
                  <Input
                    id="reference_document"
                    value={formData.reference_document}
                    onChange={(e) => handleInputChange('reference_document', e.target.value)}
                    placeholder="Cycle count sheet, damage report, etc."
                  />
                </div>

                {/* Notes */}
                <div className="space-y-2">
                  <Label htmlFor="notes">Notes *</Label>
                  <Textarea
                    id="notes"
                    value={formData.notes}
                    onChange={(e) => handleInputChange('notes', e.target.value)}
                    placeholder="Detailed explanation of the adjustment reason"
                    rows={4}
                    required
                  />
                </div>

                <Button 
                  type="submit" 
                  disabled={loading || !selectedInventoryItem || !formData.quantity_change || newQuantity < 0} 
                  className="w-full"
                >
                  {loading ? 'Processing Adjustment...' : 'Apply Adjustment'}
                </Button>
                
                {newQuantity < 0 && (
                  <p className="text-sm text-red-600">
                    ⚠️ Adjustment would result in negative inventory
                  </p>
                )}
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Summary Panel */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Package className="mr-2 h-5 w-5" />
                Adjustment Summary
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {selectedInventoryItem ? (
                <>
                  <div>
                    <Label className="text-sm font-medium">Item</Label>
                    <p className="text-sm text-muted-foreground">{selectedInventoryItem.sku}</p>
                    <p className="font-medium">{selectedInventoryItem.item_name}</p>
                  </div>
                  
                  <div>
                    <Label className="text-sm font-medium">Lot Number</Label>
                    <p className="font-medium">{selectedInventoryItem.lot_number}</p>
                  </div>
                  
                  <div>
                    <Label className="text-sm font-medium">Location</Label>
                    <p className="font-medium">
                      {selectedInventoryItem.warehouse_code} / {selectedInventoryItem.bin_code}
                    </p>
                  </div>
                  
                  <div>
                    <Label className="text-sm font-medium">Current Quantity</Label>
                    <p className="font-medium">
                      {currentQuantity.toLocaleString()} {selectedInventoryItem.unit_of_measure}
                    </p>
                  </div>
                  
                  {quantityChange !== 0 && (
                    <>
                      <div className="border-t pt-4">
                        <div className="flex items-center space-x-2 mb-2">
                          {isIncrease ? (
                            <TrendingUp className="h-4 w-4 text-green-600" />
                          ) : (
                            <TrendingDown className="h-4 w-4 text-red-600" />
                          )}
                          <Label className="text-sm font-medium">
                            {isIncrease ? 'Increase' : 'Decrease'}
                          </Label>
                        </div>
                        <p className={`font-medium ${isIncrease ? 'text-green-600' : 'text-red-600'}`}>
                          {isIncrease ? '+' : ''}{quantityChange.toLocaleString()} {selectedInventoryItem.unit_of_measure}
                        </p>
                      </div>
                      
                      <div>
                        <Label className="text-sm font-medium">New Quantity</Label>
                        <p className="font-medium text-lg">
                          {newQuantity.toLocaleString()} {selectedInventoryItem.unit_of_measure}
                        </p>
                      </div>
                    </>
                  )}
                  
                  {selectedInventoryItem.expiry_date && (
                    <div>
                      <Label className="text-sm font-medium">Expiry Date</Label>
                      <p className="font-medium">
                        {new Date(selectedInventoryItem.expiry_date).toLocaleDateString()}
                      </p>
                    </div>
                  )}
                  
                  {formData.reason_code && (
                    <div>
                      <Label className="text-sm font-medium">Reason</Label>
                      <p className="font-medium">
                        {REASON_CODES.find(r => r.value === formData.reason_code)?.label}
                      </p>
                    </div>
                  )}
                </>
              ) : (
                <p className="text-sm text-muted-foreground">
                  Select inventory to see adjustment summary
                </p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

