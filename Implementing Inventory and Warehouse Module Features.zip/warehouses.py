from flask import Blueprint, request, jsonify
from models.database import get_db_connection

warehouses_bp = Blueprint('warehouses', __name__)

@warehouses_bp.route('/warehouses')
def get_warehouses():
    """Get all warehouses"""
    try:
        with get_db_connection() as conn:
            cursor = conn.execute('SELECT * FROM warehouses WHERE is_active = 1 ORDER BY code')
            warehouses = [dict(row) for row in cursor.fetchall()]
            return jsonify(warehouses)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@warehouses_bp.route('/warehouses/<int:warehouse_id>')
def get_warehouse(warehouse_id):
    """Get warehouse by ID"""
    try:
        with get_db_connection() as conn:
            cursor = conn.execute('SELECT * FROM warehouses WHERE id = ? AND is_active = 1', (warehouse_id,))
            warehouse = cursor.fetchone()
            if warehouse:
                return jsonify(dict(warehouse))
            return jsonify({'error': 'Warehouse not found'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500

