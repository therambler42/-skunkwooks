from flask import Blueprint, request, jsonify
from models.database_sqlite import get_db_connection

inventory_bp = Blueprint('inventory', __name__)

@inventory_bp.route('/inventory/current')
def get_current_inventory():
    """Get current inventory levels"""
    try:
        limit = request.args.get('limit', 100, type=int)
        warehouse_id = request.args.get('warehouse_id', type=int)
        
        with get_db_connection() as conn:
            query = '''
                SELECT 
                    il.item_id,
                    i.sku,
                    i.name as item_name,
                    i.unit_of_measure,
                    il.lot_id,
                    lot.lot_number,
                    lot.manufactured_date,
                    lot.expiry_date,
                    il.warehouse_id,
                    w.code as warehouse_code,
                    w.name as warehouse_name,
                    il.location_bin_id,
                    lb.bin_code,
                    lb.bin_type,
                    SUM(il.quantity_change) as current_quantity,
                    MAX(il.created_at) as last_movement_date
                FROM inventory_ledger il
                JOIN items i ON il.item_id = i.id
                LEFT JOIN inventory_lots lot ON il.lot_id = lot.id
                JOIN warehouses w ON il.warehouse_id = w.id
                LEFT JOIN location_bins lb ON il.location_bin_id = lb.id
                WHERE i.is_active = 1
            '''
            
            params = []
            if warehouse_id:
                query += ' AND il.warehouse_id = ?'
                params.append(warehouse_id)
            
            query += '''
                GROUP BY il.item_id, il.lot_id, il.warehouse_id, il.location_bin_id
                HAVING SUM(il.quantity_change) > 0
                ORDER BY i.sku, lot.expiry_date ASC
                LIMIT ?
            '''
            params.append(limit)
            
            cursor = conn.execute(query, params)
            inventory = [dict(row) for row in cursor.fetchall()]
            
            return jsonify(inventory)
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@inventory_bp.route('/inventory/receive', methods=['POST'])
def receive_inventory():
    """Receive inventory into warehouse"""
    try:
        data = request.get_json()
        
        with get_db_connection() as conn:
            # Insert into ledger
            conn.execute('''
                INSERT INTO inventory_ledger 
                (transaction_id, item_id, lot_id, warehouse_id, location_bin_id, 
                 movement_type, quantity_change, quantity_before, quantity_after, 
                 unit_cost, total_cost, created_by)
                VALUES (?, ?, ?, ?, ?, 'RECEIVE', ?, 0, ?, ?, ?, ?)
            ''', (
                data['transaction_id'],
                data['item_id'],
                data['lot_id'],
                data['warehouse_id'],
                data['location_bin_id'],
                data['quantity'],
                data['quantity'],
                data.get('unit_cost'),
                data.get('total_cost'),
                data.get('created_by', 'system')
            ))
            conn.commit()
            
            return jsonify({'message': 'Inventory received successfully'})
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@inventory_bp.route('/lots/recall')
def lot_recall():
    """Get lot recall information"""
    try:
        lot_number = request.args.get('lot_number')
        if not lot_number:
            return jsonify({'error': 'lot_number parameter required'}), 400
        
        with get_db_connection() as conn:
            cursor = conn.execute('''
                SELECT 
                    il.*,
                    i.sku,
                    i.name as item_name,
                    lot.lot_number,
                    lot.manufactured_date,
                    lot.expiry_date,
                    w.code as warehouse_code,
                    w.name as warehouse_name,
                    lb.bin_code
                FROM inventory_ledger il
                JOIN items i ON il.item_id = i.id
                JOIN inventory_lots lot ON il.lot_id = lot.id
                JOIN warehouses w ON il.warehouse_id = w.id
                LEFT JOIN location_bins lb ON il.location_bin_id = lb.id
                WHERE lot.lot_number = ?
                ORDER BY il.created_at DESC
            ''', (lot_number,))
            
            recall_data = [dict(row) for row in cursor.fetchall()]
            return jsonify(recall_data)
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

