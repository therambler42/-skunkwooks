import http from 'k6/http';
import { check, sleep } from 'k6';
import { Rate } from 'k6/metrics';

// Custom metrics
const errorRate = new Rate('errors');

// Test configuration
export const options = {
  stages: [
    { duration: '30s', target: 10 }, // Ramp up to 10 users
    { duration: '1m', target: 20 },  // Stay at 20 users
    { duration: '30s', target: 0 },  // Ramp down
  ],
  thresholds: {
    http_req_duration: ['p(95)<2000'], // 95% of requests must complete within 2s
    errors: ['rate<0.1'], // Error rate must be less than 10%
  },
};

const BASE_URL = 'http://localhost:5000/api';

// Test data - lot numbers to query
const testLotNumbers = [
  'LOT-2024-001', 'LOT-2024-002', 'LOT-2024-003', 'LOT-2024-004', 'LOT-2024-005',
  'LOT-2024-006', 'LOT-2024-007', 'LOT-2024-008', 'LOT-2024-009', 'LOT-2024-010',
  'LOT-2024-011', 'LOT-2024-012', 'LOT-2024-013', 'LOT-2024-014', 'LOT-2024-015',
  'LOT-2024-016', 'LOT-2024-017', 'LOT-2024-018', 'LOT-2024-019', 'LOT-2024-020',
];

export default function () {
  // Select a random lot number for testing
  const lotNumber = testLotNumbers[Math.floor(Math.random() * testLotNumbers.length)];
  
  // Test lot recall query
  const recallResponse = http.get(`${BASE_URL}/lots/recall?lot_number=${lotNumber}`);
  
  const recallSuccess = check(recallResponse, {
    'recall query status is 200': (r) => r.status === 200,
    'recall query response time < 2s': (r) => r.timings.duration < 2000,
    'recall query returns data': (r) => {
      try {
        const data = JSON.parse(r.body);
        return Array.isArray(data);
      } catch (e) {
        return false;
      }
    },
  });
  
  if (!recallSuccess) {
    errorRate.add(1);
  }
  
  // Test current inventory query
  const inventoryResponse = http.get(`${BASE_URL}/inventory/current?limit=100`);
  
  const inventorySuccess = check(inventoryResponse, {
    'inventory query status is 200': (r) => r.status === 200,
    'inventory query response time < 1s': (r) => r.timings.duration < 1000,
    'inventory query returns data': (r) => {
      try {
        const data = JSON.parse(r.body);
        return Array.isArray(data);
      } catch (e) {
        return false;
      }
    },
  });
  
  if (!inventorySuccess) {
    errorRate.add(1);
  }
  
  // Test FEFO picking query
  const fefoResponse = http.post(`${BASE_URL}/inventory/pick/fefo`, 
    JSON.stringify({
      item_id: Math.floor(Math.random() * 100) + 1,
      warehouse_id: Math.floor(Math.random() * 5) + 1,
      quantity_needed: Math.floor(Math.random() * 100) + 1
    }),
    {
      headers: {
        'Content-Type': 'application/json',
      },
    }
  );
  
  const fefoSuccess = check(fefoResponse, {
    'FEFO query status is 200 or 404': (r) => r.status === 200 || r.status === 404,
    'FEFO query response time < 1s': (r) => r.timings.duration < 1000,
  });
  
  if (!fefoSuccess && fefoResponse.status !== 404) {
    errorRate.add(1);
  }
  
  // Small delay between requests
  sleep(0.1);
}

