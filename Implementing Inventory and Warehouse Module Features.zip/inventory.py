from flask import Blueprint, request, jsonify
from src.models.database import db
import uuid
from datetime import datetime
from decimal import Decimal

inventory_bp = Blueprint('inventory', __name__)

@inventory_bp.route('/current', methods=['GET'])
def get_current_inventory():
    """Get current inventory with optional filtering"""
    try:
        warehouse_id = request.args.get('warehouse_id')
        item_id = request.args.get('item_id')
        location_id = request.args.get('location_id')
        
        query = """
            SELECT ci.item_id, ci.lot_id, ci.warehouse_id, ci.location_bin_id,
                   ci.current_quantity, ci.last_movement_date,
                   i.sku, i.name as item_name, i.unit_of_measure,
                   il.lot_number, il.expiry_date, il.manufactured_date,
                   w.code as warehouse_code, w.name as warehouse_name,
                   lb.bin_code, lb.bin_type
            FROM current_inventory ci
            JOIN items i ON ci.item_id = i.id
            JOIN inventory_lots il ON ci.lot_id = il.id
            JOIN warehouses w ON ci.warehouse_id = w.id
            JOIN location_bins lb ON ci.location_bin_id = lb.id
            WHERE ci.current_quantity > 0
        """
        
        params = []
        
        if warehouse_id:
            query += " AND ci.warehouse_id = %s"
            params.append(warehouse_id)
            
        if item_id:
            query += " AND ci.item_id = %s"
            params.append(item_id)
            
        if location_id:
            query += " AND ci.location_bin_id = %s"
            params.append(location_id)
            
        query += " ORDER BY i.sku, il.expiry_date ASC, w.code, lb.bin_code"
        
        with db.get_cursor() as cursor:
            cursor.execute(query, params)
            inventory = cursor.fetchall()
            return jsonify([dict(inv) for inv in inventory])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@inventory_bp.route('/receive', methods=['POST'])
def receive_inventory():
    """Receive inventory into warehouse"""
    try:
        data = request.get_json()
        required_fields = ['item_id', 'lot_id', 'warehouse_id', 'location_bin_id', 'quantity']
        
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        transaction_id = str(uuid.uuid4())
        
        with db.get_cursor() as cursor:
            # Get current quantity for this location
            cursor.execute("""
                SELECT COALESCE(current_quantity, 0) as current_qty
                FROM current_inventory
                WHERE item_id = %s AND lot_id = %s 
                AND warehouse_id = %s AND location_bin_id = %s
            """, (data['item_id'], data['lot_id'], data['warehouse_id'], data['location_bin_id']))
            
            result = cursor.fetchone()
            current_qty = result['current_qty'] if result else Decimal('0')
            new_qty = current_qty + Decimal(str(data['quantity']))
            
            # Insert into inventory ledger
            cursor.execute("""
                INSERT INTO inventory_ledger (
                    transaction_id, item_id, lot_id, warehouse_id, location_bin_id,
                    movement_type, quantity_change, quantity_before, quantity_after,
                    unit_cost, total_cost, reference_document, reference_line_number,
                    reason_code, notes, created_by
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING id, created_at
            """, (
                transaction_id,
                data['item_id'],
                data['lot_id'],
                data['warehouse_id'],
                data['location_bin_id'],
                'RECEIVE',
                data['quantity'],
                current_qty,
                new_qty,
                data.get('unit_cost'),
                data.get('total_cost'),
                data.get('reference_document'),
                data.get('reference_line_number'),
                data.get('reason_code'),
                data.get('notes'),
                data.get('created_by', 'system')
            ))
            
            ledger_entry = cursor.fetchone()
            
            # Refresh materialized view
            cursor.execute("REFRESH MATERIALIZED VIEW CONCURRENTLY current_inventory")
            
            return jsonify({
                'transaction_id': transaction_id,
                'ledger_id': ledger_entry['id'],
                'quantity_received': data['quantity'],
                'new_quantity': float(new_qty),
                'created_at': ledger_entry['created_at'].isoformat()
            }), 201
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@inventory_bp.route('/transfer', methods=['POST'])
def transfer_inventory():
    """Transfer inventory between locations"""
    try:
        data = request.get_json()
        required_fields = ['item_id', 'lot_id', 'from_warehouse_id', 'from_location_bin_id',
                          'to_warehouse_id', 'to_location_bin_id', 'quantity']
        
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        transaction_id = str(uuid.uuid4())
        
        with db.get_cursor() as cursor:
            # Check available quantity at source location
            cursor.execute("""
                SELECT COALESCE(current_quantity, 0) as current_qty
                FROM current_inventory
                WHERE item_id = %s AND lot_id = %s 
                AND warehouse_id = %s AND location_bin_id = %s
            """, (data['item_id'], data['lot_id'], 
                  data['from_warehouse_id'], data['from_location_bin_id']))
            
            source_result = cursor.fetchone()
            source_qty = source_result['current_qty'] if source_result else Decimal('0')
            
            if source_qty < Decimal(str(data['quantity'])):
                return jsonify({'error': 'Insufficient quantity available'}), 400
            
            # Get current quantity at destination location
            cursor.execute("""
                SELECT COALESCE(current_quantity, 0) as current_qty
                FROM current_inventory
                WHERE item_id = %s AND lot_id = %s 
                AND warehouse_id = %s AND location_bin_id = %s
            """, (data['item_id'], data['lot_id'], 
                  data['to_warehouse_id'], data['to_location_bin_id']))
            
            dest_result = cursor.fetchone()
            dest_qty = dest_result['current_qty'] if dest_result else Decimal('0')
            
            transfer_qty = Decimal(str(data['quantity']))
            
            # Insert transfer out record
            cursor.execute("""
                INSERT INTO inventory_ledger (
                    transaction_id, item_id, lot_id, warehouse_id, location_bin_id,
                    movement_type, quantity_change, quantity_before, quantity_after,
                    reference_document, notes, created_by
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                transaction_id,
                data['item_id'],
                data['lot_id'],
                data['from_warehouse_id'],
                data['from_location_bin_id'],
                'TRANSFER_OUT',
                -transfer_qty,
                source_qty,
                source_qty - transfer_qty,
                data.get('reference_document'),
                data.get('notes'),
                data.get('created_by', 'system')
            ))
            
            # Insert transfer in record
            cursor.execute("""
                INSERT INTO inventory_ledger (
                    transaction_id, item_id, lot_id, warehouse_id, location_bin_id,
                    movement_type, quantity_change, quantity_before, quantity_after,
                    reference_document, notes, created_by
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                transaction_id,
                data['item_id'],
                data['lot_id'],
                data['to_warehouse_id'],
                data['to_location_bin_id'],
                'TRANSFER_IN',
                transfer_qty,
                dest_qty,
                dest_qty + transfer_qty,
                data.get('reference_document'),
                data.get('notes'),
                data.get('created_by', 'system')
            ))
            
            # Refresh materialized view
            cursor.execute("REFRESH MATERIALIZED VIEW CONCURRENTLY current_inventory")
            
            return jsonify({
                'transaction_id': transaction_id,
                'quantity_transferred': float(transfer_qty),
                'from_new_quantity': float(source_qty - transfer_qty),
                'to_new_quantity': float(dest_qty + transfer_qty)
            }), 201
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@inventory_bp.route('/adjust', methods=['POST'])
def adjust_inventory():
    """Adjust inventory quantity (cycle count, damage, etc.)"""
    try:
        data = request.get_json()
        required_fields = ['item_id', 'lot_id', 'warehouse_id', 'location_bin_id', 
                          'quantity_change', 'reason_code']
        
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        transaction_id = str(uuid.uuid4())
        
        with db.get_cursor() as cursor:
            # Get current quantity
            cursor.execute("""
                SELECT COALESCE(current_quantity, 0) as current_qty
                FROM current_inventory
                WHERE item_id = %s AND lot_id = %s 
                AND warehouse_id = %s AND location_bin_id = %s
            """, (data['item_id'], data['lot_id'], 
                  data['warehouse_id'], data['location_bin_id']))
            
            result = cursor.fetchone()
            current_qty = result['current_qty'] if result else Decimal('0')
            quantity_change = Decimal(str(data['quantity_change']))
            new_qty = current_qty + quantity_change
            
            if new_qty < 0:
                return jsonify({'error': 'Adjustment would result in negative inventory'}), 400
            
            movement_type = 'ADJUST_IN' if quantity_change > 0 else 'ADJUST_OUT'
            
            # Insert adjustment record
            cursor.execute("""
                INSERT INTO inventory_ledger (
                    transaction_id, item_id, lot_id, warehouse_id, location_bin_id,
                    movement_type, quantity_change, quantity_before, quantity_after,
                    reference_document, reason_code, notes, created_by
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING id, created_at
            """, (
                transaction_id,
                data['item_id'],
                data['lot_id'],
                data['warehouse_id'],
                data['location_bin_id'],
                movement_type,
                quantity_change,
                current_qty,
                new_qty,
                data.get('reference_document'),
                data['reason_code'],
                data.get('notes'),
                data.get('created_by', 'system')
            ))
            
            ledger_entry = cursor.fetchone()
            
            # Refresh materialized view
            cursor.execute("REFRESH MATERIALIZED VIEW CONCURRENTLY current_inventory")
            
            return jsonify({
                'transaction_id': transaction_id,
                'ledger_id': ledger_entry['id'],
                'quantity_change': float(quantity_change),
                'new_quantity': float(new_qty),
                'created_at': ledger_entry['created_at'].isoformat()
            }), 201
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@inventory_bp.route('/pick/fefo', methods=['POST'])
def pick_fefo():
    """Get FEFO picking recommendations"""
    try:
        data = request.get_json()
        required_fields = ['item_id', 'warehouse_id', 'quantity_needed']
        
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        with db.get_cursor() as cursor:
            cursor.execute("""
                SELECT * FROM get_fefo_picking_order(%s, %s, %s)
            """, (data['item_id'], data['warehouse_id'], data['quantity_needed']))
            
            picking_order = cursor.fetchall()
            return jsonify([dict(pick) for pick in picking_order])
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@inventory_bp.route('/pick/fifo', methods=['POST'])
def pick_fifo():
    """Get FIFO picking recommendations"""
    try:
        data = request.get_json()
        required_fields = ['item_id', 'warehouse_id', 'quantity_needed']
        
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        with db.get_cursor() as cursor:
            cursor.execute("""
                SELECT * FROM get_fifo_picking_order(%s, %s, %s)
            """, (data['item_id'], data['warehouse_id'], data['quantity_needed']))
            
            picking_order = cursor.fetchall()
            return jsonify([dict(pick) for pick in picking_order])
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@inventory_bp.route('/ledger', methods=['GET'])
def get_inventory_ledger():
    """Get inventory ledger entries with optional filtering"""
    try:
        item_id = request.args.get('item_id')
        lot_id = request.args.get('lot_id')
        warehouse_id = request.args.get('warehouse_id')
        movement_type = request.args.get('movement_type')
        transaction_id = request.args.get('transaction_id')
        limit = request.args.get('limit', 100, type=int)
        
        query = """
            SELECT il.id, il.transaction_id, il.item_id, il.lot_id,
                   il.warehouse_id, il.location_bin_id, il.movement_type,
                   il.quantity_change, il.quantity_before, il.quantity_after,
                   il.unit_cost, il.total_cost, il.reference_document,
                   il.reference_line_number, il.reason_code, il.notes,
                   il.created_by, il.created_at,
                   i.sku, i.name as item_name,
                   lot.lot_number,
                   w.code as warehouse_code,
                   lb.bin_code
            FROM inventory_ledger il
            JOIN items i ON il.item_id = i.id
            JOIN inventory_lots lot ON il.lot_id = lot.id
            JOIN warehouses w ON il.warehouse_id = w.id
            JOIN location_bins lb ON il.location_bin_id = lb.id
            WHERE 1=1
        """
        
        params = []
        
        if item_id:
            query += " AND il.item_id = %s"
            params.append(item_id)
            
        if lot_id:
            query += " AND il.lot_id = %s"
            params.append(lot_id)
            
        if warehouse_id:
            query += " AND il.warehouse_id = %s"
            params.append(warehouse_id)
            
        if movement_type:
            query += " AND il.movement_type = %s"
            params.append(movement_type)
            
        if transaction_id:
            query += " AND il.transaction_id = %s"
            params.append(transaction_id)
            
        query += " ORDER BY il.created_at DESC LIMIT %s"
        params.append(limit)
        
        with db.get_cursor() as cursor:
            cursor.execute(query, params)
            ledger_entries = cursor.fetchall()
            return jsonify([dict(entry) for entry in ledger_entries])
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

