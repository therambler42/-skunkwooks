# Inventory & Warehouse Module Database Schema

## Overview

This document outlines the database schema design for the Inventory & Warehouse Module, supporting multi-warehouse operations, FIFO/FEFO inventory management, lot tracking with expiry dates, and comprehensive audit logging through an immutable inventory ledger.

## Core Design Principles

The schema follows several key principles to ensure data integrity, performance, and compliance with inventory management best practices. First, the append-only ledger pattern ensures complete auditability of all inventory movements without the risk of data modification or deletion. Second, the lot-based tracking system enables precise FEFO (First Expired, First Out) and FIFO (First In, First Out) picking strategies. Third, the multi-warehouse architecture supports distributed inventory management across multiple physical locations.

## Table Definitions

### Warehouses Table

The warehouses table serves as the foundation for multi-location inventory management, storing essential information about each physical storage facility.

```sql
CREATE TABLE warehouses (
    id SERIAL PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    address TEXT,
    city VARCHAR(100),
    state VARCHAR(50),
    postal_code VARCHAR(20),
    country VARCHAR(100),
    phone VARCHAR(20),
    email VARCHAR(255),
    manager_name VARCHAR(255),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_warehouses_code ON warehouses(code);
CREATE INDEX idx_warehouses_active ON warehouses(is_active);
```

### Location Bins Table

Location bins represent specific storage locations within warehouses, enabling precise inventory placement and retrieval operations.

```sql
CREATE TABLE location_bins (
    id SERIAL PRIMARY KEY,
    warehouse_id INTEGER REFERENCES warehouses(id) ON DELETE CASCADE,
    zone VARCHAR(50),
    aisle VARCHAR(20),
    rack VARCHAR(20),
    shelf VARCHAR(20),
    bin VARCHAR(20),
    bin_code VARCHAR(100) UNIQUE NOT NULL,
    bin_type VARCHAR(50), -- 'RECEIVING', 'STORAGE', 'PICKING', 'SHIPPING'
    capacity_cubic_meters DECIMAL(10,3),
    max_weight_kg DECIMAL(10,2),
    temperature_controlled BOOLEAN DEFAULT false,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_location_bins_warehouse ON location_bins(warehouse_id);
CREATE INDEX idx_location_bins_code ON location_bins(bin_code);
CREATE INDEX idx_location_bins_type ON location_bins(bin_type);
CREATE INDEX idx_location_bins_active ON location_bins(is_active);
```

### Items Table

The items table contains master data for all inventory items, including product specifications and handling requirements.

```sql
CREATE TABLE items (
    id SERIAL PRIMARY KEY,
    sku VARCHAR(100) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(100),
    unit_of_measure VARCHAR(20),
    weight_kg DECIMAL(10,3),
    dimensions_length_cm DECIMAL(8,2),
    dimensions_width_cm DECIMAL(8,2),
    dimensions_height_cm DECIMAL(8,2),
    requires_lot_tracking BOOLEAN DEFAULT false,
    requires_expiry_tracking BOOLEAN DEFAULT false,
    shelf_life_days INTEGER,
    temperature_requirements VARCHAR(100),
    hazardous_material BOOLEAN DEFAULT false,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_items_sku ON items(sku);
CREATE INDEX idx_items_category ON items(category);
CREATE INDEX idx_items_lot_tracking ON items(requires_lot_tracking);
CREATE INDEX idx_items_expiry_tracking ON items(requires_expiry_tracking);
CREATE INDEX idx_items_active ON items(is_active);
```

### Inventory Lots Table

Inventory lots track specific batches of items with unique identifiers, manufacturing dates, and expiry information for FEFO compliance.

```sql
CREATE TABLE inventory_lots (
    id SERIAL PRIMARY KEY,
    item_id INTEGER REFERENCES items(id) ON DELETE CASCADE,
    lot_number VARCHAR(100) NOT NULL,
    manufactured_date DATE,
    expiry_date DATE,
    supplier_id INTEGER,
    supplier_lot_number VARCHAR(100),
    quality_status VARCHAR(50) DEFAULT 'APPROVED', -- 'APPROVED', 'QUARANTINE', 'REJECTED'
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(item_id, lot_number)
);

CREATE INDEX idx_inventory_lots_item ON inventory_lots(item_id);
CREATE INDEX idx_inventory_lots_number ON inventory_lots(lot_number);
CREATE INDEX idx_inventory_lots_expiry ON inventory_lots(expiry_date);
CREATE INDEX idx_inventory_lots_quality ON inventory_lots(quality_status);
CREATE INDEX idx_inventory_lots_item_expiry ON inventory_lots(item_id, expiry_date);
```

### Inventory Ledger Table (Append-Only)

The inventory ledger serves as the immutable record of all inventory movements, ensuring complete auditability and enabling accurate inventory calculations at any point in time.

```sql
CREATE TABLE inventory_ledger (
    id SERIAL PRIMARY KEY,
    transaction_id UUID NOT NULL,
    item_id INTEGER REFERENCES items(id) ON DELETE RESTRICT,
    lot_id INTEGER REFERENCES inventory_lots(id) ON DELETE RESTRICT,
    warehouse_id INTEGER REFERENCES warehouses(id) ON DELETE RESTRICT,
    location_bin_id INTEGER REFERENCES location_bins(id) ON DELETE RESTRICT,
    movement_type VARCHAR(50) NOT NULL, -- 'RECEIVE', 'TRANSFER_IN', 'TRANSFER_OUT', 'PICK', 'ADJUST_IN', 'ADJUST_OUT', 'CYCLE_COUNT'
    quantity_change DECIMAL(15,6) NOT NULL,
    quantity_before DECIMAL(15,6) NOT NULL,
    quantity_after DECIMAL(15,6) NOT NULL,
    unit_cost DECIMAL(12,4),
    total_cost DECIMAL(15,4),
    reference_document VARCHAR(100),
    reference_line_number INTEGER,
    reason_code VARCHAR(50),
    notes TEXT,
    created_by VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);

CREATE INDEX idx_inventory_ledger_transaction ON inventory_ledger(transaction_id);
CREATE INDEX idx_inventory_ledger_item ON inventory_ledger(item_id);
CREATE INDEX idx_inventory_ledger_lot ON inventory_ledger(lot_id);
CREATE INDEX idx_inventory_ledger_warehouse ON inventory_ledger(warehouse_id);
CREATE INDEX idx_inventory_ledger_location ON inventory_ledger(location_bin_id);
CREATE INDEX idx_inventory_ledger_type ON inventory_ledger(movement_type);
CREATE INDEX idx_inventory_ledger_created ON inventory_ledger(created_at);
CREATE INDEX idx_inventory_ledger_item_lot_location ON inventory_ledger(item_id, lot_id, location_bin_id);
```

### Current Inventory View

A materialized view provides real-time inventory balances by aggregating ledger entries, optimizing query performance for current stock levels.

```sql
CREATE MATERIALIZED VIEW current_inventory AS
SELECT 
    item_id,
    lot_id,
    warehouse_id,
    location_bin_id,
    SUM(quantity_change) as current_quantity,
    MAX(created_at) as last_movement_date
FROM inventory_ledger
GROUP BY item_id, lot_id, warehouse_id, location_bin_id
HAVING SUM(quantity_change) > 0;

CREATE UNIQUE INDEX idx_current_inventory_unique ON current_inventory(item_id, lot_id, warehouse_id, location_bin_id);
CREATE INDEX idx_current_inventory_item ON current_inventory(item_id);
CREATE INDEX idx_current_inventory_warehouse ON current_inventory(warehouse_id);
CREATE INDEX idx_current_inventory_location ON current_inventory(location_bin_id);
```

### Audit Log Table

The audit log captures all system changes for compliance and security monitoring, complementing the inventory ledger with broader system activity tracking.

```sql
CREATE TABLE audit_log (
    id SERIAL PRIMARY KEY,
    table_name VARCHAR(100) NOT NULL,
    record_id INTEGER NOT NULL,
    action VARCHAR(20) NOT NULL, -- 'INSERT', 'UPDATE', 'DELETE'
    old_values JSONB,
    new_values JSONB,
    changed_by VARCHAR(100) NOT NULL,
    changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ip_address INET,
    user_agent TEXT
);

CREATE INDEX idx_audit_log_table ON audit_log(table_name);
CREATE INDEX idx_audit_log_record ON audit_log(record_id);
CREATE INDEX idx_audit_log_action ON audit_log(action);
CREATE INDEX idx_audit_log_changed_by ON audit_log(changed_by);
CREATE INDEX idx_audit_log_changed_at ON audit_log(changed_at);
```

## Schema Relationships and Constraints

The database schema implements several critical relationships and constraints to maintain data integrity and enforce business rules. The warehouse-to-location-bins relationship establishes a hierarchical storage structure, where each bin belongs to exactly one warehouse. The items-to-lots relationship enables lot tracking for items that require it, while maintaining flexibility for items that don't need lot-level granularity.

The inventory ledger maintains foreign key relationships to all relevant entities while using RESTRICT on delete operations to prevent accidental data loss. This ensures that historical inventory movements remain intact even if master data changes. The append-only nature of the ledger is enforced through application logic and database triggers that prevent UPDATE and DELETE operations.

## FIFO/FEFO Implementation Strategy

The schema supports both FIFO and FEFO picking strategies through the inventory_lots table structure. For FEFO implementation, queries order lots by expiry_date ascending, ensuring items with the earliest expiration dates are picked first. For FIFO implementation, queries order by manufactured_date or created_at ascending, ensuring older inventory is consumed before newer stock.

The current_inventory materialized view enables efficient picking queries by pre-calculating available quantities for each lot and location combination. This eliminates the need for complex aggregations during picking operations, significantly improving performance for high-volume warehouses.

## Performance Optimization Considerations

Several design decisions optimize performance for large-scale inventory operations. The use of composite indexes on frequently queried column combinations reduces query execution time for common operations like lot lookups and inventory recalls. The materialized view strategy balances real-time accuracy with query performance, requiring periodic refresh operations to maintain current data.

Partitioning strategies can be implemented on the inventory_ledger table based on created_at timestamps to manage table size growth over time. This approach maintains query performance while preserving historical data for compliance requirements.

## Data Integrity and Validation Rules

The schema implements multiple layers of data validation to ensure inventory accuracy. Check constraints on quantity fields prevent negative inventory balances in the current_inventory view. Foreign key constraints maintain referential integrity across all related tables. Unique constraints on critical business keys like SKU and lot numbers prevent duplicate entries.

Application-level validation complements database constraints by implementing business rules such as expiry date validation against shelf life specifications and lot number format validation according to industry standards.

