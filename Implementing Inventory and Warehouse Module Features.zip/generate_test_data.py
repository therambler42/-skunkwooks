#!/usr/bin/env python3
"""
Generate test data for inventory warehouse system
Creates 10k+ lots across multiple items and warehouses for performance testing
"""

import psycopg2
import random
from datetime import datetime, timedelta
from decimal import Decimal
import uuid

# Database connection parameters
DB_CONFIG = {
    'host': 'localhost',
    'port': 5432,
    'database': 'inventory_db',
    'user': 'postgres',
    'password': 'password'
}

def generate_test_data():
    """Generate comprehensive test data for performance testing"""
    
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        cursor = conn.cursor()
        
        print("Creating test data...")
        
        # Create warehouses
        warehouses = []
        for i in range(1, 6):  # 5 warehouses
            cursor.execute("""
                INSERT INTO warehouses (code, name, address, city, state, country)
                VALUES (%s, %s, %s, %s, %s, %s)
                ON CONFLICT (code) DO NOTHING
                RETURNING id
            """, (
                f'WH-{i:03d}',
                f'Warehouse {i}',
                f'{i}00 Industrial Blvd',
                f'City {i}',
                'CA',
                'USA'
            ))
            result = cursor.fetchone()
            if result:
                warehouses.append(result[0])
            else:
                # Get existing warehouse ID
                cursor.execute("SELECT id FROM warehouses WHERE code = %s", (f'WH-{i:03d}',))
                warehouses.append(cursor.fetchone()[0])
        
        print(f"Created {len(warehouses)} warehouses")
        
        # Create location bins for each warehouse
        locations = []
        for warehouse_id in warehouses:
            for zone in ['A', 'B', 'C']:
                for aisle in range(1, 11):  # 10 aisles per zone
                    for rack in range(1, 6):  # 5 racks per aisle
                        for shelf in range(1, 4):  # 3 shelves per rack
                            bin_code = f'{zone}-{aisle:02d}-{rack:02d}-{shelf:02d}'
                            cursor.execute("""
                                INSERT INTO location_bins (warehouse_id, zone, aisle, rack, shelf, bin, bin_code, bin_type)
                                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                                ON CONFLICT (bin_code) DO NOTHING
                                RETURNING id
                            """, (
                                warehouse_id, zone, str(aisle), str(rack), str(shelf), '01',
                                bin_code, 'STORAGE'
                            ))
                            result = cursor.fetchone()
                            if result:
                                locations.append((result[0], warehouse_id))
        
        print(f"Created {len(locations)} location bins")
        
        # Create items
        categories = ['Electronics', 'Food', 'Pharmaceuticals', 'Automotive', 'Textiles']
        items = []
        for i in range(1, 501):  # 500 items
            category = random.choice(categories)
            requires_expiry = category in ['Food', 'Pharmaceuticals']
            
            cursor.execute("""
                INSERT INTO items (sku, name, description, category, unit_of_measure,
                                 requires_lot_tracking, requires_expiry_tracking, shelf_life_days)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (sku) DO NOTHING
                RETURNING id
            """, (
                f'SKU-{category[:4].upper()}-{i:04d}',
                f'{category} Item {i}',
                f'Test {category.lower()} item for performance testing',
                category,
                'EA',
                True,  # All items require lot tracking for testing
                requires_expiry,
                365 if requires_expiry else None
            ))
            result = cursor.fetchone()
            if result:
                items.append((result[0], requires_expiry))
            else:
                # Get existing item ID
                cursor.execute("SELECT id, requires_expiry_tracking FROM items WHERE sku = %s", 
                             (f'SKU-{category[:4].upper()}-{i:04d}',))
                result = cursor.fetchone()
                items.append((result[0], result[1]))
        
        print(f"Created {len(items)} items")
        
        # Create lots (10k+ lots)
        lots = []
        base_date = datetime.now() - timedelta(days=365)
        
        for i in range(1, 12001):  # 12k lots for good measure
            item_id, requires_expiry = random.choice(items)
            
            # Generate lot number
            lot_date = base_date + timedelta(days=random.randint(0, 365))
            lot_number = f'LOT-{lot_date.strftime("%Y-%m%d")}-{i:04d}'
            
            # Generate dates
            manufactured_date = lot_date
            expiry_date = None
            if requires_expiry:
                expiry_date = manufactured_date + timedelta(days=random.randint(30, 730))
            
            cursor.execute("""
                INSERT INTO inventory_lots (item_id, lot_number, manufactured_date, expiry_date,
                                          supplier_id, quality_status)
                VALUES (%s, %s, %s, %s, %s, %s)
                ON CONFLICT (item_id, lot_number) DO NOTHING
                RETURNING id
            """, (
                item_id,
                lot_number,
                manufactured_date.date(),
                expiry_date.date() if expiry_date else None,
                random.randint(1, 50),  # Random supplier ID
                'APPROVED'
            ))
            result = cursor.fetchone()
            if result:
                lots.append((result[0], item_id))
        
        print(f"Created {len(lots)} lots")
        
        # Create inventory ledger entries (simulate receiving inventory)
        transaction_count = 0
        for lot_id, item_id in lots:
            # Randomly assign to locations
            location_id, warehouse_id = random.choice(locations)
            
            # Random quantity
            quantity = Decimal(str(random.randint(1, 1000)))
            
            transaction_id = str(uuid.uuid4())
            
            cursor.execute("""
                INSERT INTO inventory_ledger (
                    transaction_id, item_id, lot_id, warehouse_id, location_bin_id,
                    movement_type, quantity_change, quantity_before, quantity_after,
                    unit_cost, total_cost, created_by
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                transaction_id,
                item_id,
                lot_id,
                warehouse_id,
                location_id,
                'RECEIVE',
                quantity,
                Decimal('0'),
                quantity,
                Decimal(str(random.uniform(1.0, 100.0))),
                quantity * Decimal(str(random.uniform(1.0, 100.0))),
                'test_data_generator'
            ))
            
            transaction_count += 1
            
            # Add some random movements for some lots
            if random.random() < 0.3:  # 30% chance of additional movements
                # Random adjustment
                adjustment = Decimal(str(random.randint(-50, 50)))
                if quantity + adjustment >= 0:
                    new_quantity = quantity + adjustment
                    movement_type = 'ADJUST_IN' if adjustment > 0 else 'ADJUST_OUT'
                    
                    cursor.execute("""
                        INSERT INTO inventory_ledger (
                            transaction_id, item_id, lot_id, warehouse_id, location_bin_id,
                            movement_type, quantity_change, quantity_before, quantity_after,
                            reason_code, created_by
                        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """, (
                        str(uuid.uuid4()),
                        item_id,
                        lot_id,
                        warehouse_id,
                        location_id,
                        movement_type,
                        adjustment,
                        quantity,
                        new_quantity,
                        'CYCLE_COUNT',
                        'test_data_generator'
                    ))
                    transaction_count += 1
        
        print(f"Created {transaction_count} inventory transactions")
        
        # Refresh materialized view
        print("Refreshing materialized view...")
        cursor.execute("REFRESH MATERIALIZED VIEW current_inventory")
        
        # Get statistics
        cursor.execute("SELECT COUNT(*) FROM inventory_lots")
        lot_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM current_inventory WHERE current_quantity > 0")
        active_inventory_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM inventory_ledger")
        ledger_count = cursor.fetchone()[0]
        
        conn.commit()
        
        print("\n=== Test Data Generation Complete ===")
        print(f"Total lots created: {lot_count}")
        print(f"Active inventory records: {active_inventory_count}")
        print(f"Total ledger entries: {ledger_count}")
        print(f"Warehouses: {len(warehouses)}")
        print(f"Location bins: {len(locations)}")
        print(f"Items: {len(items)}")
        
    except Exception as e:
        print(f"Error generating test data: {e}")
        if conn:
            conn.rollback()
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

if __name__ == "__main__":
    generate_test_data()

