from flask import Blueprint, request, jsonify
from models.database import get_db_connection

items_bp = Blueprint('items', __name__)

@items_bp.route('/items')
def get_items():
    """Get all items"""
    try:
        with get_db_connection() as conn:
            cursor = conn.execute('SELECT * FROM items WHERE is_active = 1 ORDER BY sku')
            items = [dict(row) for row in cursor.fetchall()]
            return jsonify(items)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@items_bp.route('/items/<int:item_id>')
def get_item(item_id):
    """Get item by ID"""
    try:
        with get_db_connection() as conn:
            cursor = conn.execute('SELECT * FROM items WHERE id = ? AND is_active = 1', (item_id,))
            item = cursor.fetchone()
            if item:
                return jsonify(dict(item))
            return jsonify({'error': 'Item not found'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500

