import http from 'k6/http';
import { check } from 'k6';
import { Rate } from 'k6/metrics';

// Custom metrics
const errorRate = new Rate('errors');

// Test configuration for recall query performance
export const options = {
  scenarios: {
    recall_performance: {
      executor: 'constant-vus',
      vus: 50, // 50 concurrent users
      duration: '2m',
    },
  },
  thresholds: {
    http_req_duration: ['p(95)<2000'], // 95% of requests must complete within 2s
    'http_req_duration{scenario:recall_performance}': ['p(99)<2000'], // 99% under 2s for recall
    errors: ['rate<0.05'], // Error rate must be less than 5%
  },
};

const BASE_URL = 'http://localhost:5001/api';

// Generate test lot numbers (simulating 10k lots)
function generateLotNumber() {
  const year = 2024;
  const month = String(Math.floor(Math.random() * 12) + 1).padStart(2, '0');
  const day = String(Math.floor(Math.random() * 28) + 1).padStart(2, '0');
  const sequence = String(Math.floor(Math.random() * 10000) + 1).padStart(4, '0');
  return `LOT-${year}-${month}${day}-${sequence}`;
}

export default function () {
  // Generate a random lot number for testing
  const lotNumber = generateLotNumber();
  
  // Test lot recall query - this is the critical performance test
  const startTime = Date.now();
  const recallResponse = http.get(`${BASE_URL}/lots/recall?lot_number=${lotNumber}`);
  const endTime = Date.now();
  const responseTime = endTime - startTime;
  
  const recallSuccess = check(recallResponse, {
    'recall query status is 200': (r) => r.status === 200,
    'recall query response time < 2000ms': (r) => responseTime < 2000,
    'recall query response time < 1000ms': (r) => responseTime < 1000,
    'recall query response time < 500ms': (r) => responseTime < 500,
    'recall query returns valid JSON': (r) => {
      try {
        const data = JSON.parse(r.body);
        return Array.isArray(data);
      } catch (e) {
        return false;
      }
    },
  });
  
  if (!recallSuccess) {
    errorRate.add(1);
  }
  
  // Log slow queries for analysis
  if (responseTime > 1000) {
    console.log(`Slow recall query: ${lotNumber} took ${responseTime}ms`);
  }
}

