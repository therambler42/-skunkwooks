import psycopg2
from psycopg2.extras import RealDictCursor
import os
from contextlib import contextmanager

class Database:
    def __init__(self):
        self.app = None
        
    def init_app(self, app):
        self.app = app
        self.database_url = app.config['DATABASE_URL']
        
    @contextmanager
    def get_connection(self):
        conn = None
        try:
            conn = psycopg2.connect(self.database_url, cursor_factory=RealDictCursor)
            yield conn
        except Exception as e:
            if conn:
                conn.rollback()
            raise e
        finally:
            if conn:
                conn.close()
                
    @contextmanager
    def get_cursor(self):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            try:
                yield cursor
                conn.commit()
            except Exception as e:
                conn.rollback()
                raise e
            finally:
                cursor.close()

db = Database()

