-- Inventory & Warehouse Module Database Schema
-- PostgreSQL Implementation

-- Enable UUID extension for transaction IDs
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Warehouses table
CREATE TABLE warehouses (
    id SERIAL PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    address TEXT,
    city VARCHAR(100),
    state VARCHAR(50),
    postal_code VARCHAR(20),
    country VARCHAR(100),
    phone VARCHAR(20),
    email VARCHAR(255),
    manager_name VARCHAR(255),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_warehouses_code ON warehouses(code);
CREATE INDEX idx_warehouses_active ON warehouses(is_active);

-- Location bins table
CREATE TABLE location_bins (
    id SERIAL PRIMARY KEY,
    warehouse_id INTEGER REFERENCES warehouses(id) ON DELETE CASCADE,
    zone VARCHAR(50),
    aisle VARCHAR(20),
    rack VARCHAR(20),
    shelf VARCHAR(20),
    bin VARCHAR(20),
    bin_code VARCHAR(100) UNIQUE NOT NULL,
    bin_type VARCHAR(50), -- 'RECEIVING', 'STORAGE', 'PICKING', 'SHIPPING'
    capacity_cubic_meters DECIMAL(10,3),
    max_weight_kg DECIMAL(10,2),
    temperature_controlled BOOLEAN DEFAULT false,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_location_bins_warehouse ON location_bins(warehouse_id);
CREATE INDEX idx_location_bins_code ON location_bins(bin_code);
CREATE INDEX idx_location_bins_type ON location_bins(bin_type);
CREATE INDEX idx_location_bins_active ON location_bins(is_active);

-- Items table
CREATE TABLE items (
    id SERIAL PRIMARY KEY,
    sku VARCHAR(100) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(100),
    unit_of_measure VARCHAR(20),
    weight_kg DECIMAL(10,3),
    dimensions_length_cm DECIMAL(8,2),
    dimensions_width_cm DECIMAL(8,2),
    dimensions_height_cm DECIMAL(8,2),
    requires_lot_tracking BOOLEAN DEFAULT false,
    requires_expiry_tracking BOOLEAN DEFAULT false,
    shelf_life_days INTEGER,
    temperature_requirements VARCHAR(100),
    hazardous_material BOOLEAN DEFAULT false,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_items_sku ON items(sku);
CREATE INDEX idx_items_category ON items(category);
CREATE INDEX idx_items_lot_tracking ON items(requires_lot_tracking);
CREATE INDEX idx_items_expiry_tracking ON items(requires_expiry_tracking);
CREATE INDEX idx_items_active ON items(is_active);

-- Inventory lots table
CREATE TABLE inventory_lots (
    id SERIAL PRIMARY KEY,
    item_id INTEGER REFERENCES items(id) ON DELETE CASCADE,
    lot_number VARCHAR(100) NOT NULL,
    manufactured_date DATE,
    expiry_date DATE,
    supplier_id INTEGER,
    supplier_lot_number VARCHAR(100),
    quality_status VARCHAR(50) DEFAULT 'APPROVED', -- 'APPROVED', 'QUARANTINE', 'REJECTED'
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(item_id, lot_number)
);

CREATE INDEX idx_inventory_lots_item ON inventory_lots(item_id);
CREATE INDEX idx_inventory_lots_number ON inventory_lots(lot_number);
CREATE INDEX idx_inventory_lots_expiry ON inventory_lots(expiry_date);
CREATE INDEX idx_inventory_lots_quality ON inventory_lots(quality_status);
CREATE INDEX idx_inventory_lots_item_expiry ON inventory_lots(item_id, expiry_date);

-- Inventory ledger table (append-only)
CREATE TABLE inventory_ledger (
    id SERIAL PRIMARY KEY,
    transaction_id UUID NOT NULL DEFAULT uuid_generate_v4(),
    item_id INTEGER REFERENCES items(id) ON DELETE RESTRICT,
    lot_id INTEGER REFERENCES inventory_lots(id) ON DELETE RESTRICT,
    warehouse_id INTEGER REFERENCES warehouses(id) ON DELETE RESTRICT,
    location_bin_id INTEGER REFERENCES location_bins(id) ON DELETE RESTRICT,
    movement_type VARCHAR(50) NOT NULL, -- 'RECEIVE', 'TRANSFER_IN', 'TRANSFER_OUT', 'PICK', 'ADJUST_IN', 'ADJUST_OUT', 'CYCLE_COUNT'
    quantity_change DECIMAL(15,6) NOT NULL,
    quantity_before DECIMAL(15,6) NOT NULL,
    quantity_after DECIMAL(15,6) NOT NULL,
    unit_cost DECIMAL(12,4),
    total_cost DECIMAL(15,4),
    reference_document VARCHAR(100),
    reference_line_number INTEGER,
    reason_code VARCHAR(50),
    notes TEXT,
    created_by VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);

CREATE INDEX idx_inventory_ledger_transaction ON inventory_ledger(transaction_id);
CREATE INDEX idx_inventory_ledger_item ON inventory_ledger(item_id);
CREATE INDEX idx_inventory_ledger_lot ON inventory_ledger(lot_id);
CREATE INDEX idx_inventory_ledger_warehouse ON inventory_ledger(warehouse_id);
CREATE INDEX idx_inventory_ledger_location ON inventory_ledger(location_bin_id);
CREATE INDEX idx_inventory_ledger_type ON inventory_ledger(movement_type);
CREATE INDEX idx_inventory_ledger_created ON inventory_ledger(created_at);
CREATE INDEX idx_inventory_ledger_item_lot_location ON inventory_ledger(item_id, lot_id, location_bin_id);

-- Current inventory materialized view
CREATE MATERIALIZED VIEW current_inventory AS
SELECT 
    item_id,
    lot_id,
    warehouse_id,
    location_bin_id,
    SUM(quantity_change) as current_quantity,
    MAX(created_at) as last_movement_date
FROM inventory_ledger
GROUP BY item_id, lot_id, warehouse_id, location_bin_id
HAVING SUM(quantity_change) > 0;

CREATE UNIQUE INDEX idx_current_inventory_unique ON current_inventory(item_id, lot_id, warehouse_id, location_bin_id);
CREATE INDEX idx_current_inventory_item ON current_inventory(item_id);
CREATE INDEX idx_current_inventory_warehouse ON current_inventory(warehouse_id);
CREATE INDEX idx_current_inventory_location ON current_inventory(location_bin_id);

-- Audit log table
CREATE TABLE audit_log (
    id SERIAL PRIMARY KEY,
    table_name VARCHAR(100) NOT NULL,
    record_id INTEGER NOT NULL,
    action VARCHAR(20) NOT NULL, -- 'INSERT', 'UPDATE', 'DELETE'
    old_values JSONB,
    new_values JSONB,
    changed_by VARCHAR(100) NOT NULL,
    changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ip_address INET,
    user_agent TEXT
);

CREATE INDEX idx_audit_log_table ON audit_log(table_name);
CREATE INDEX idx_audit_log_record ON audit_log(record_id);
CREATE INDEX idx_audit_log_action ON audit_log(action);
CREATE INDEX idx_audit_log_changed_by ON audit_log(changed_by);
CREATE INDEX idx_audit_log_changed_at ON audit_log(changed_at);

-- Trigger function for audit logging
CREATE OR REPLACE FUNCTION audit_trigger_function()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'DELETE' THEN
        INSERT INTO audit_log (table_name, record_id, action, old_values, changed_by)
        VALUES (TG_TABLE_NAME, OLD.id, TG_OP, row_to_json(OLD), current_user);
        RETURN OLD;
    ELSIF TG_OP = 'UPDATE' THEN
        INSERT INTO audit_log (table_name, record_id, action, old_values, new_values, changed_by)
        VALUES (TG_TABLE_NAME, NEW.id, TG_OP, row_to_json(OLD), row_to_json(NEW), current_user);
        RETURN NEW;
    ELSIF TG_OP = 'INSERT' THEN
        INSERT INTO audit_log (table_name, record_id, action, new_values, changed_by)
        VALUES (TG_TABLE_NAME, NEW.id, TG_OP, row_to_json(NEW), current_user);
        RETURN NEW;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Create audit triggers for key tables
CREATE TRIGGER audit_warehouses
    AFTER INSERT OR UPDATE OR DELETE ON warehouses
    FOR EACH ROW EXECUTE FUNCTION audit_trigger_function();

CREATE TRIGGER audit_location_bins
    AFTER INSERT OR UPDATE OR DELETE ON location_bins
    FOR EACH ROW EXECUTE FUNCTION audit_trigger_function();

CREATE TRIGGER audit_items
    AFTER INSERT OR UPDATE OR DELETE ON items
    FOR EACH ROW EXECUTE FUNCTION audit_trigger_function();

CREATE TRIGGER audit_inventory_lots
    AFTER INSERT OR UPDATE OR DELETE ON inventory_lots
    FOR EACH ROW EXECUTE FUNCTION audit_trigger_function();

-- Function to refresh current inventory view
CREATE OR REPLACE FUNCTION refresh_current_inventory()
RETURNS VOID AS $$
BEGIN
    REFRESH MATERIALIZED VIEW CONCURRENTLY current_inventory;
END;
$$ LANGUAGE plpgsql;

-- Function to get FEFO picking order
CREATE OR REPLACE FUNCTION get_fefo_picking_order(
    p_item_id INTEGER,
    p_warehouse_id INTEGER,
    p_quantity_needed DECIMAL(15,6)
)
RETURNS TABLE (
    lot_id INTEGER,
    location_bin_id INTEGER,
    available_quantity DECIMAL(15,6),
    expiry_date DATE,
    pick_quantity DECIMAL(15,6)
) AS $$
DECLARE
    remaining_quantity DECIMAL(15,6) := p_quantity_needed;
    lot_record RECORD;
BEGIN
    FOR lot_record IN
        SELECT 
            ci.lot_id,
            ci.location_bin_id,
            ci.current_quantity,
            il.expiry_date
        FROM current_inventory ci
        JOIN inventory_lots il ON ci.lot_id = il.id
        WHERE ci.item_id = p_item_id 
        AND ci.warehouse_id = p_warehouse_id
        AND ci.current_quantity > 0
        ORDER BY il.expiry_date ASC, il.created_at ASC
    LOOP
        IF remaining_quantity <= 0 THEN
            EXIT;
        END IF;
        
        lot_id := lot_record.lot_id;
        location_bin_id := lot_record.location_bin_id;
        available_quantity := lot_record.current_quantity;
        expiry_date := lot_record.expiry_date;
        
        IF lot_record.current_quantity >= remaining_quantity THEN
            pick_quantity := remaining_quantity;
            remaining_quantity := 0;
        ELSE
            pick_quantity := lot_record.current_quantity;
            remaining_quantity := remaining_quantity - lot_record.current_quantity;
        END IF;
        
        RETURN NEXT;
    END LOOP;
END;
$$ LANGUAGE plpgsql;

-- Function to get FIFO picking order
CREATE OR REPLACE FUNCTION get_fifo_picking_order(
    p_item_id INTEGER,
    p_warehouse_id INTEGER,
    p_quantity_needed DECIMAL(15,6)
)
RETURNS TABLE (
    lot_id INTEGER,
    location_bin_id INTEGER,
    available_quantity DECIMAL(15,6),
    manufactured_date DATE,
    pick_quantity DECIMAL(15,6)
) AS $$
DECLARE
    remaining_quantity DECIMAL(15,6) := p_quantity_needed;
    lot_record RECORD;
BEGIN
    FOR lot_record IN
        SELECT 
            ci.lot_id,
            ci.location_bin_id,
            ci.current_quantity,
            il.manufactured_date
        FROM current_inventory ci
        JOIN inventory_lots il ON ci.lot_id = il.id
        WHERE ci.item_id = p_item_id 
        AND ci.warehouse_id = p_warehouse_id
        AND ci.current_quantity > 0
        ORDER BY il.manufactured_date ASC, il.created_at ASC
    LOOP
        IF remaining_quantity <= 0 THEN
            EXIT;
        END IF;
        
        lot_id := lot_record.lot_id;
        location_bin_id := lot_record.location_bin_id;
        available_quantity := lot_record.current_quantity;
        manufactured_date := lot_record.manufactured_date;
        
        IF lot_record.current_quantity >= remaining_quantity THEN
            pick_quantity := remaining_quantity;
            remaining_quantity := 0;
        ELSE
            pick_quantity := lot_record.current_quantity;
            remaining_quantity := remaining_quantity - lot_record.current_quantity;
        END IF;
        
        RETURN NEXT;
    END LOOP;
END;
$$ LANGUAGE plpgsql;

-- Function for lot recall queries (optimized for performance)
CREATE OR REPLACE FUNCTION get_lot_recall_info(
    p_lot_number VARCHAR(100),
    p_item_id INTEGER DEFAULT NULL
)
RETURNS TABLE (
    item_sku VARCHAR(100),
    item_name VARCHAR(255),
    lot_number VARCHAR(100),
    warehouse_code VARCHAR(20),
    location_bin_code VARCHAR(100),
    current_quantity DECIMAL(15,6),
    expiry_date DATE,
    manufactured_date DATE,
    supplier_lot_number VARCHAR(100)
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        i.sku,
        i.name,
        il.lot_number,
        w.code,
        lb.bin_code,
        ci.current_quantity,
        il.expiry_date,
        il.manufactured_date,
        il.supplier_lot_number
    FROM current_inventory ci
    JOIN inventory_lots il ON ci.lot_id = il.id
    JOIN items i ON ci.item_id = i.id
    JOIN warehouses w ON ci.warehouse_id = w.id
    JOIN location_bins lb ON ci.location_bin_id = lb.id
    WHERE il.lot_number = p_lot_number
    AND (p_item_id IS NULL OR ci.item_id = p_item_id)
    AND ci.current_quantity > 0
    ORDER BY w.code, lb.bin_code;
END;
$$ LANGUAGE plpgsql;

