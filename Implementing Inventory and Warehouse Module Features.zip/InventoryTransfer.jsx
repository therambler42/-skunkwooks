import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { useToast } from '@/hooks/use-toast'
import { ArrowRightLeft, Package, MapPin } from 'lucide-react'

const API_BASE_URL = 'https://r19hnincw78w.manus.space/api'

export default function InventoryTransfer() {
  const [inventory, setInventory] = useState([])
  const [warehouses, setWarehouses] = useState([])
  const [fromLocations, setFromLocations] = useState([])
  const [toLocations, setToLocations] = useState([])
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    item_id: '',
    lot_id: '',
    from_warehouse_id: '',
    from_location_bin_id: '',
    to_warehouse_id: '',
    to_location_bin_id: '',
    quantity: '',
    reference_document: '',
    notes: ''
  })
  const { toast } = useToast()

  useEffect(() => {
    fetchInventory()
    fetchWarehouses()
  }, [])

  useEffect(() => {
    if (formData.from_warehouse_id) {
      fetchLocations(formData.from_warehouse_id, 'from')
    }
  }, [formData.from_warehouse_id])

  useEffect(() => {
    if (formData.to_warehouse_id) {
      fetchLocations(formData.to_warehouse_id, 'to')
    }
  }, [formData.to_warehouse_id])

  const fetchInventory = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/inventory/current`)
      if (response.ok) {
        const data = await response.json()
        setInventory(data)
      }
    } catch (error) {
      console.error('Error fetching inventory:', error)
    }
  }

  const fetchWarehouses = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/warehouses`)
      if (response.ok) {
        const data = await response.json()
        setWarehouses(data)
      }
    } catch (error) {
      console.error('Error fetching warehouses:', error)
    }
  }

  const fetchLocations = async (warehouseId, type) => {
    try {
      const response = await fetch(`${API_BASE_URL}/warehouses/${warehouseId}/locations`)
      if (response.ok) {
        const data = await response.json()
        if (type === 'from') {
          setFromLocations(data)
        } else {
          setToLocations(data)
        }
      }
    } catch (error) {
      console.error('Error fetching locations:', error)
    }
  }

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }))
  }

  const handleInventorySelection = (inventoryKey) => {
    const [itemId, lotId, warehouseId, locationId] = inventoryKey.split('-')
    setFormData(prev => ({
      ...prev,
      item_id: itemId,
      lot_id: lotId,
      from_warehouse_id: warehouseId,
      from_location_bin_id: locationId
    }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)

    try {
      const transferData = {
        item_id: parseInt(formData.item_id),
        lot_id: parseInt(formData.lot_id),
        from_warehouse_id: parseInt(formData.from_warehouse_id),
        from_location_bin_id: parseInt(formData.from_location_bin_id),
        to_warehouse_id: parseInt(formData.to_warehouse_id),
        to_location_bin_id: parseInt(formData.to_location_bin_id),
        quantity: parseFloat(formData.quantity),
        reference_document: formData.reference_document || null,
        notes: formData.notes || null,
        created_by: 'user'
      }

      const response = await fetch(`${API_BASE_URL}/inventory/transfer`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(transferData),
      })

      if (response.ok) {
        const result = await response.json()
        toast({
          title: "Transfer Completed",
          description: `Successfully transferred ${formData.quantity} units. Transaction ID: ${result.transaction_id}`,
        })
        
        // Reset form
        setFormData({
          item_id: '',
          lot_id: '',
          from_warehouse_id: '',
          from_location_bin_id: '',
          to_warehouse_id: '',
          to_location_bin_id: '',
          quantity: '',
          reference_document: '',
          notes: ''
        })
        setFromLocations([])
        setToLocations([])
        
        // Refresh inventory
        fetchInventory()
      } else {
        const error = await response.json()
        throw new Error(error.error || 'Failed to transfer inventory')
      }
    } catch (error) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const selectedInventoryItem = inventory.find(item => 
    item.item_id === parseInt(formData.item_id) &&
    item.lot_id === parseInt(formData.lot_id) &&
    item.warehouse_id === parseInt(formData.from_warehouse_id) &&
    item.location_bin_id === parseInt(formData.from_location_bin_id)
  )

  const maxQuantity = selectedInventoryItem ? parseFloat(selectedInventoryItem.current_quantity) : 0

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Transfer Inventory</h2>
        <p className="text-muted-foreground">
          Move inventory between warehouses and locations
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Main Form */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <ArrowRightLeft className="mr-2 h-5 w-5" />
                Transfer Details
              </CardTitle>
              <CardDescription>
                Select the inventory to transfer and destination
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Source Selection */}
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Source Location</h3>
                  
                  <div className="space-y-2">
                    <Label htmlFor="inventory_item">Available Inventory *</Label>
                    <Select 
                      value={`${formData.item_id}-${formData.lot_id}-${formData.from_warehouse_id}-${formData.from_location_bin_id}`}
                      onValueChange={handleInventorySelection}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select inventory to transfer" />
                      </SelectTrigger>
                      <SelectContent>
                        {inventory.map((item) => (
                          <SelectItem 
                            key={`${item.item_id}-${item.lot_id}-${item.warehouse_id}-${item.location_bin_id}`}
                            value={`${item.item_id}-${item.lot_id}-${item.warehouse_id}-${item.location_bin_id}`}
                          >
                            {item.sku} - {item.lot_number} @ {item.warehouse_code}/{item.bin_code} ({parseFloat(item.current_quantity).toLocaleString()} {item.unit_of_measure})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Destination Selection */}
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Destination Location</h3>
                  
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="to_warehouse">To Warehouse *</Label>
                      <Select value={formData.to_warehouse_id} onValueChange={(value) => handleInputChange('to_warehouse_id', value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select destination warehouse" />
                        </SelectTrigger>
                        <SelectContent>
                          {warehouses.map((warehouse) => (
                            <SelectItem key={warehouse.id} value={warehouse.id.toString()}>
                              {warehouse.code} - {warehouse.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="to_location">To Location *</Label>
                      <Select 
                        value={formData.to_location_bin_id} 
                        onValueChange={(value) => handleInputChange('to_location_bin_id', value)}
                        disabled={!formData.to_warehouse_id}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select destination location" />
                        </SelectTrigger>
                        <SelectContent>
                          {toLocations.map((location) => (
                            <SelectItem key={location.id} value={location.id.toString()}>
                              {location.bin_code}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                {/* Quantity */}
                <div className="space-y-2">
                  <Label htmlFor="quantity">Quantity to Transfer *</Label>
                  <Input
                    id="quantity"
                    type="number"
                    step="0.001"
                    min="0"
                    max={maxQuantity}
                    value={formData.quantity}
                    onChange={(e) => handleInputChange('quantity', e.target.value)}
                    placeholder="Enter quantity to transfer"
                    required
                  />
                  {maxQuantity > 0 && (
                    <p className="text-sm text-muted-foreground">
                      Available: {maxQuantity.toLocaleString()} units
                    </p>
                  )}
                </div>

                {/* Reference and Notes */}
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="reference_document">Reference Document</Label>
                    <Input
                      id="reference_document"
                      value={formData.reference_document}
                      onChange={(e) => handleInputChange('reference_document', e.target.value)}
                      placeholder="Transfer order, work order, etc."
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="notes">Notes</Label>
                    <Textarea
                      id="notes"
                      value={formData.notes}
                      onChange={(e) => handleInputChange('notes', e.target.value)}
                      placeholder="Reason for transfer, special instructions, etc."
                      rows={3}
                    />
                  </div>
                </div>

                <Button type="submit" disabled={loading || !selectedInventoryItem} className="w-full">
                  {loading ? 'Processing Transfer...' : 'Transfer Inventory'}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Summary Panel */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Package className="mr-2 h-5 w-5" />
                Transfer Summary
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {selectedInventoryItem ? (
                <>
                  <div>
                    <Label className="text-sm font-medium">Item</Label>
                    <p className="text-sm text-muted-foreground">{selectedInventoryItem.sku}</p>
                    <p className="font-medium">{selectedInventoryItem.item_name}</p>
                  </div>
                  
                  <div>
                    <Label className="text-sm font-medium">Lot Number</Label>
                    <p className="font-medium">{selectedInventoryItem.lot_number}</p>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center text-sm">
                      <MapPin className="mr-1 h-4 w-4" />
                      <span className="font-medium">From:</span>
                    </div>
                    <p className="text-sm pl-5">
                      {selectedInventoryItem.warehouse_code} / {selectedInventoryItem.bin_code}
                    </p>
                  </div>
                  
                  {formData.to_warehouse_id && formData.to_location_bin_id && (
                    <div className="space-y-2">
                      <div className="flex items-center text-sm">
                        <MapPin className="mr-1 h-4 w-4" />
                        <span className="font-medium">To:</span>
                      </div>
                      <p className="text-sm pl-5">
                        {warehouses.find(w => w.id === parseInt(formData.to_warehouse_id))?.code} / 
                        {toLocations.find(l => l.id === parseInt(formData.to_location_bin_id))?.bin_code}
                      </p>
                    </div>
                  )}
                  
                  <div>
                    <Label className="text-sm font-medium">Available Quantity</Label>
                    <p className="font-medium">
                      {parseFloat(selectedInventoryItem.current_quantity).toLocaleString()} {selectedInventoryItem.unit_of_measure}
                    </p>
                  </div>
                  
                  {formData.quantity && (
                    <div>
                      <Label className="text-sm font-medium">Transfer Quantity</Label>
                      <p className="font-medium">
                        {parseFloat(formData.quantity).toLocaleString()} {selectedInventoryItem.unit_of_measure}
                      </p>
                    </div>
                  )}
                  
                  {selectedInventoryItem.expiry_date && (
                    <div>
                      <Label className="text-sm font-medium">Expiry Date</Label>
                      <p className="font-medium">
                        {new Date(selectedInventoryItem.expiry_date).toLocaleDateString()}
                      </p>
                    </div>
                  )}
                </>
              ) : (
                <p className="text-sm text-muted-foreground">
                  Select inventory to see transfer summary
                </p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

