import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { useToast } from '@/hooks/use-toast'
import { Plus, Package } from 'lucide-react'

const API_BASE_URL = 'https://r19hnincw78w.manus.space/api'

export default function InventoryReceive() {
  const [items, setItems] = useState([])
  const [warehouses, setWarehouses] = useState([])
  const [locations, setLocations] = useState([])
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    item_id: '',
    lot_number: '',
    manufactured_date: '',
    expiry_date: '',
    warehouse_id: '',
    location_bin_id: '',
    quantity: '',
    unit_cost: '',
    reference_document: '',
    notes: ''
  })
  const { toast } = useToast()

  useEffect(() => {
    fetchItems()
    fetchWarehouses()
  }, [])

  useEffect(() => {
    if (formData.warehouse_id) {
      fetchLocations(formData.warehouse_id)
    }
  }, [formData.warehouse_id])

  const fetchItems = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/items`)
      if (response.ok) {
        const data = await response.json()
        setItems(data)
      }
    } catch (error) {
      console.error('Error fetching items:', error)
    }
  }

  const fetchWarehouses = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/warehouses`)
      if (response.ok) {
        const data = await response.json()
        setWarehouses(data)
      }
    } catch (error) {
      console.error('Error fetching warehouses:', error)
    }
  }

  const fetchLocations = async (warehouseId) => {
    try {
      const response = await fetch(`${API_BASE_URL}/warehouses/${warehouseId}/locations`)
      if (response.ok) {
        const data = await response.json()
        setLocations(data)
      }
    } catch (error) {
      console.error('Error fetching locations:', error)
    }
  }

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }))
  }

  const createLotIfNeeded = async () => {
    if (!formData.lot_number || !formData.item_id) return null

    try {
      const lotData = {
        item_id: parseInt(formData.item_id),
        lot_number: formData.lot_number,
        manufactured_date: formData.manufactured_date || null,
        expiry_date: formData.expiry_date || null,
        quality_status: 'APPROVED'
      }

      const response = await fetch(`${API_BASE_URL}/lots`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(lotData),
      })

      if (response.ok) {
        const lot = await response.json()
        return lot.id
      } else if (response.status === 500) {
        // Lot might already exist, try to find it
        const existingResponse = await fetch(`${API_BASE_URL}/lots?item_id=${formData.item_id}`)
        if (existingResponse.ok) {
          const lots = await existingResponse.json()
          const existingLot = lots.find(lot => lot.lot_number === formData.lot_number)
          if (existingLot) {
            return existingLot.id
          }
        }
      }
      throw new Error('Failed to create or find lot')
    } catch (error) {
      console.error('Error creating lot:', error)
      throw error
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)

    try {
      // Create lot if needed
      const lotId = await createLotIfNeeded()
      if (!lotId) {
        throw new Error('Failed to create or find lot')
      }

      // Calculate total cost
      const quantity = parseFloat(formData.quantity)
      const unitCost = parseFloat(formData.unit_cost) || 0
      const totalCost = quantity * unitCost

      const receiveData = {
        item_id: parseInt(formData.item_id),
        lot_id: lotId,
        warehouse_id: parseInt(formData.warehouse_id),
        location_bin_id: parseInt(formData.location_bin_id),
        quantity: quantity,
        unit_cost: unitCost || null,
        total_cost: totalCost || null,
        reference_document: formData.reference_document || null,
        notes: formData.notes || null,
        created_by: 'user'
      }

      const response = await fetch(`${API_BASE_URL}/inventory/receive`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(receiveData),
      })

      if (response.ok) {
        const result = await response.json()
        toast({
          title: "Inventory Received",
          description: `Successfully received ${quantity} units. Transaction ID: ${result.transaction_id}`,
        })
        
        // Reset form
        setFormData({
          item_id: '',
          lot_number: '',
          manufactured_date: '',
          expiry_date: '',
          warehouse_id: '',
          location_bin_id: '',
          quantity: '',
          unit_cost: '',
          reference_document: '',
          notes: ''
        })
        setLocations([])
      } else {
        const error = await response.json()
        throw new Error(error.error || 'Failed to receive inventory')
      }
    } catch (error) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const selectedItem = items.find(item => item.id === parseInt(formData.item_id))

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Receive Inventory</h2>
        <p className="text-muted-foreground">
          Record incoming inventory with lot tracking and expiry information
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Main Form */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Plus className="mr-2 h-5 w-5" />
                Receive Items
              </CardTitle>
              <CardDescription>
                Enter details for the inventory you're receiving
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Item Selection */}
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="item">Item *</Label>
                    <Select value={formData.item_id} onValueChange={(value) => handleInputChange('item_id', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select an item" />
                      </SelectTrigger>
                      <SelectContent>
                        {items.map((item) => (
                          <SelectItem key={item.id} value={item.id.toString()}>
                            {item.sku} - {item.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="lot_number">Lot Number *</Label>
                    <Input
                      id="lot_number"
                      value={formData.lot_number}
                      onChange={(e) => handleInputChange('lot_number', e.target.value)}
                      placeholder="Enter lot number"
                      required
                    />
                  </div>
                </div>

                {/* Dates */}
                {selectedItem?.requires_expiry_tracking && (
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="manufactured_date">Manufactured Date</Label>
                      <Input
                        id="manufactured_date"
                        type="date"
                        value={formData.manufactured_date}
                        onChange={(e) => handleInputChange('manufactured_date', e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="expiry_date">Expiry Date</Label>
                      <Input
                        id="expiry_date"
                        type="date"
                        value={formData.expiry_date}
                        onChange={(e) => handleInputChange('expiry_date', e.target.value)}
                      />
                    </div>
                  </div>
                )}

                {/* Location */}
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="warehouse">Warehouse *</Label>
                    <Select value={formData.warehouse_id} onValueChange={(value) => handleInputChange('warehouse_id', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select warehouse" />
                      </SelectTrigger>
                      <SelectContent>
                        {warehouses.map((warehouse) => (
                          <SelectItem key={warehouse.id} value={warehouse.id.toString()}>
                            {warehouse.code} - {warehouse.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="location">Location *</Label>
                    <Select 
                      value={formData.location_bin_id} 
                      onValueChange={(value) => handleInputChange('location_bin_id', value)}
                      disabled={!formData.warehouse_id}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select location" />
                      </SelectTrigger>
                      <SelectContent>
                        {locations.map((location) => (
                          <SelectItem key={location.id} value={location.id.toString()}>
                            {location.bin_code}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Quantity and Cost */}
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="quantity">Quantity *</Label>
                    <Input
                      id="quantity"
                      type="number"
                      step="0.001"
                      min="0"
                      value={formData.quantity}
                      onChange={(e) => handleInputChange('quantity', e.target.value)}
                      placeholder="Enter quantity"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="unit_cost">Unit Cost</Label>
                    <Input
                      id="unit_cost"
                      type="number"
                      step="0.01"
                      min="0"
                      value={formData.unit_cost}
                      onChange={(e) => handleInputChange('unit_cost', e.target.value)}
                      placeholder="Enter unit cost"
                    />
                  </div>
                </div>

                {/* Reference and Notes */}
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="reference_document">Reference Document</Label>
                    <Input
                      id="reference_document"
                      value={formData.reference_document}
                      onChange={(e) => handleInputChange('reference_document', e.target.value)}
                      placeholder="PO number, receipt number, etc."
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="notes">Notes</Label>
                    <Textarea
                      id="notes"
                      value={formData.notes}
                      onChange={(e) => handleInputChange('notes', e.target.value)}
                      placeholder="Additional notes about this receipt"
                      rows={3}
                    />
                  </div>
                </div>

                <Button type="submit" disabled={loading} className="w-full">
                  {loading ? 'Processing...' : 'Receive Inventory'}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Summary Panel */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Package className="mr-2 h-5 w-5" />
                Receipt Summary
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {selectedItem ? (
                <>
                  <div>
                    <Label className="text-sm font-medium">Item</Label>
                    <p className="text-sm text-muted-foreground">{selectedItem.sku}</p>
                    <p className="font-medium">{selectedItem.name}</p>
                  </div>
                  
                  {formData.lot_number && (
                    <div>
                      <Label className="text-sm font-medium">Lot Number</Label>
                      <p className="font-medium">{formData.lot_number}</p>
                    </div>
                  )}
                  
                  {formData.quantity && (
                    <div>
                      <Label className="text-sm font-medium">Quantity</Label>
                      <p className="font-medium">
                        {parseFloat(formData.quantity).toLocaleString()} {selectedItem.unit_of_measure}
                      </p>
                    </div>
                  )}
                  
                  {formData.unit_cost && formData.quantity && (
                    <div>
                      <Label className="text-sm font-medium">Total Value</Label>
                      <p className="font-medium">
                        ${(parseFloat(formData.unit_cost) * parseFloat(formData.quantity)).toFixed(2)}
                      </p>
                    </div>
                  )}
                  
                  {selectedItem.requires_lot_tracking && (
                    <div className="text-sm text-blue-600">
                      ℹ️ This item requires lot tracking
                    </div>
                  )}
                  
                  {selectedItem.requires_expiry_tracking && (
                    <div className="text-sm text-orange-600">
                      ⚠️ This item requires expiry tracking
                    </div>
                  )}
                </>
              ) : (
                <p className="text-sm text-muted-foreground">
                  Select an item to see receipt summary
                </p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

