import { Injectable, Logger } from '@nestjs/common';
import * as sgMail from '@sendgrid/mail';

@Injectable()
export class EmailService {
  private readonly logger = new Logger(EmailService.name);

  constructor() {
    // Mock SendGrid API key for development
    sgMail.setApiKey(process.env.SENDGRID_API_KEY || 'mock-api-key');
  }

  async sendMagicLink(email: string, token: string): Promise<void> {
    const magicLink = `${process.env.APP_URL || 'http://localhost:3000'}/auth/verify?token=${token}`;
    
    // Always log magic link to console for easy access
    this.logger.log(`=== MAGIC LINK GENERATED ===`);
    this.logger.log(`Email: ${email}`);
    this.logger.log(`Magic Link URL: ${magicLink}`);
    this.logger.log(`Token: ${token}`);
    this.logger.log(`Expires: ${new Date(Date.now() + 15 * 60 * 1000).toISOString()}`);
    this.logger.log(`============================`);

    // For production, you can still send emails if SENDGRID_API_KEY is properly configured
    // But magic link will always be logged to console for debugging
    if (process.env.SENDGRID_API_KEY && process.env.SENDGRID_API_KEY !== 'mock-api-key' && process.env.NODE_ENV === 'production') {
      const msg = {
        to: email,
        from: process.env.FROM_EMAIL || 'noreply@skunkwooks.com',
        subject: 'Your SkunkWookS login link',
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2>Welcome to SkunkWookS</h2>
            <p>Click the link below to log in to your account:</p>
            <a href="${magicLink}" style="background-color: #007bff; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; display: inline-block;">
              Log in to SkunkWookS
            </a>
            <p>This link will expire in 15 minutes.</p>
            <p>If you didn't request this login link, you can safely ignore this email.</p>
          </div>
        `,
      };

      try {
        await sgMail.send(msg);
        this.logger.log(`Magic link email also sent to ${email}`);
      } catch (error) {
        this.logger.error(`Failed to send email to ${email}:`, error);
        // Don't throw error - magic link is still logged to console
      }
    }
  }
}

