import { Controller, Post, Get, Body, Query, Res, HttpStatus } from '@nestjs/common';
import { Response } from 'express';
import { AuthService } from '../services/auth.service';
import { MagicLinkDto } from '../dto/magic-link.dto';

@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Post('magic-link')
  async sendMagicLink(@Body() magicLinkDto: MagicLinkDto) {
    return this.authService.sendMagicLink(magicLinkDto.email);
  }

  @Get('verify')
  async verifyMagicLink(
    @Query('token') token: string,
    @Res() res: Response,
  ) {
    try {
      const { user, accessToken } = await this.authService.verifyMagicLink(token);

      // Set JWT as HTTP-only cookie
      res.cookie('access_token', accessToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 24 * 60 * 60 * 1000, // 24 hours
      });

      // Redirect based on user role
      const redirectUrl = this.authService.getRoleRedirectUrl(user.role);
      return res.redirect(redirectUrl);
    } catch (error) {
      return res.status(HttpStatus.UNAUTHORIZED).json({
        message: error.message,
      });
    }
  }

  @Post('logout')
  async logout(@Res() res: Response) {
    res.clearCookie('access_token');
    return res.json({ message: 'Logged out successfully' });
  }
}

