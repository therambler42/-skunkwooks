# SkunkWookS Auth Module - Deployment Package

## Quick Deployment

```bash
unzip auth-module.zip
cd auth-module
flyctl deploy -a ochzkvpi
```

## Overview

This package contains a complete NestJS Auth module with magic-link login flow, ready for deployment to Fly.io app `ochzkvpi.manus.space`.

## What's Included

- **Compiled Application**: Pre-built TypeScript → JavaScript in `dist/` folder
- **Docker Configuration**: `Dockerfile` optimized for production
- **Fly.io Configuration**: `fly.toml` configured for ochzkvpi app
- **Dependencies**: Complete `package.json` and `package-lock.json`
- **Views**: Login page template in `views/login.hbs`
- **Environment Example**: `.env.example` with required variables

## Features Implemented

✅ **Magic-Link Authentication**
- Secure token generation (32-byte random hex)
- 15-minute expiration
- Email integration (SendGrid SDK)

✅ **RBAC (Role-Based Access Control)**
- Owner → `/dashboard/owner`
- Admin → `/dashboard/admin`
- Manager → `/dashboard/manager`
- Supplier → `/dashboard/supplier`

✅ **Security**
- JWT tokens with HTTP-only cookies
- CORS enabled
- Input validation
- PostgreSQL with SSL support

✅ **API Endpoints**
- `GET /login` - Login page
- `POST /auth/magic-link` - Send magic link
- `GET /auth/verify?token=` - Verify and redirect
- `POST /auth/logout` - Clear session

## Environment Variables

The application requires these environment variables to be set in Fly.io:

```bash
# Set these in Fly.io before deployment
flyctl secrets set -a ochzkvpi \
  NODE_ENV=production \
  JWT_SECRET=your-super-secret-jwt-key \
  SENDGRID_API_KEY=your-sendgrid-api-key \
  FROM_EMAIL=noreply@skunkwooks.com \
  APP_URL=https://ochzkvpi.manus.space \
  FRONTEND_URL=https://ochzkvpi.manus.space \
  DB_HOST=your-postgres-host \
  DB_PORT=5432 \
  DB_USERNAME=your-db-username \
  DB_PASSWORD=your-db-password \
  DB_NAME=your-db-name
```

## Database Setup

The application expects a PostgreSQL database with these tables (auto-created on first run):

### `users` table
- `id` (UUID, primary key)
- `email` (string, unique)
- `role` (enum: Owner, Admin, Manager, Supplier)
- `createdAt` (timestamp)

### `magic_links` table
- `id` (integer, primary key)
- `userId` (UUID, foreign key)
- `token` (string, unique)
- `expiresAt` (timestamp)
- `createdAt` (timestamp)

## Deployment Steps

1. **Extract the package**:
   ```bash
   unzip auth-module.zip
   cd auth-module
   ```

2. **Set environment variables** (replace with your actual values):
   ```bash
   flyctl secrets set -a ochzkvpi \
     JWT_SECRET=your-super-secret-jwt-key \
     SENDGRID_API_KEY=your-sendgrid-api-key \
     DB_HOST=your-postgres-host \
     DB_USERNAME=your-db-username \
     DB_PASSWORD=your-db-password \
     DB_NAME=your-db-name
   ```

3. **Deploy to Fly.io**:
   ```bash
   flyctl deploy -a ochzkvpi
   ```

4. **Verify deployment**:
   ```bash
   curl -I https://ochzkvpi.manus.space/login
   # Should return HTTP 200
   ```

## Testing the Magic-Link Flow

1. **Visit the login page**:
   https://ochzkvpi.manus.space/login

2. **Enter an email and submit**

3. **Check application logs for the magic link**:
   ```bash
   flyctl logs -a ochzkvpi
   ```

4. **Visit the magic link URL to complete authentication**

## Troubleshooting

### Database Connection Issues
- Ensure PostgreSQL is running and accessible
- Check database credentials in Fly.io secrets
- Verify SSL configuration if required

### Email Issues
- For development: Magic links are logged to console
- For production: Set valid SendGrid API key
- Check Fly.io logs for email service errors

### Authentication Issues
- Verify JWT_SECRET is set
- Check cookie settings (secure flag in production)
- Ensure CORS is properly configured

## Support

For issues or questions:
1. Check Fly.io logs: `flyctl logs -a ochzkvpi`
2. Verify environment variables: `flyctl secrets list -a ochzkvpi`
3. Check database connectivity
4. Review application logs for specific errors

## Architecture

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   Login Page    │───▶│  Magic Link API  │───▶│   Email Service │
│  /login (GET)   │    │ /auth/magic-link │    │   (SendGrid)    │
└─────────────────┘    │    (POST)        │    └─────────────────┘
                       └──────────────────┘
                                │
                                ▼
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   Dashboard     │◀───│  Verify Token    │───▶│   PostgreSQL    │
│ /dashboard/*    │    │ /auth/verify     │    │   Database      │
│   (RBAC)        │    │    (GET)         │    │                 │
└─────────────────┘    └──────────────────┘    └─────────────────┘
```

---

**Ready for deployment to ochzkvpi.manus.space** 🚀

