import React, { useState, useEffect } from 'react';
import {
  Page,
  Layout,
  Card,
  Text,
  Button,
  Badge,
  DataTable,
  Spinner,
  Pagination,
  ButtonGroup,
  Modal,
  TextContainer
} from '@shopify/polaris';
import { RefreshIcon, ViewIcon } from '@shopify/polaris-icons';
import axios from 'axios';
import { useAuth } from '../contexts/AuthContext';

const OrdersPage = ({ showToast }) => {
  const { API_BASE_URL } = useAuth();
  const [loading, setLoading] = useState(true);
  const [orders, setOrders] = useState([]);
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 20,
    total: 0,
    pages: 0
  });
  const [syncing, setSyncing] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [modalActive, setModalActive] = useState(false);

  const fetchOrders = async (page = 1) => {
    try {
      setLoading(true);
      
      const response = await axios.get(`${API_BASE_URL}/api/shopify/orders/local`, {
        params: {
          page,
          limit: pagination.limit
        },
        withCredentials: true
      });
      
      setOrders(response.data.orders || []);
      setPagination({
        ...pagination,
        page: response.data.page || 1,
        total: response.data.total || 0,
        pages: response.data.pages || 0
      });
      
    } catch (error) {
      console.error('Failed to fetch orders:', error);
      showToast('Failed to load orders', true);
    } finally {
      setLoading(false);
    }
  };

  const syncOrders = async () => {
    try {
      setSyncing(true);
      
      await axios.get(`${API_BASE_URL}/api/shopify/orders`, {
        withCredentials: true
      });
      
      showToast('Orders synced successfully');
      fetchOrders(pagination.page);
      
    } catch (error) {
      console.error('Order sync failed:', error);
      showToast('Order sync failed', true);
    } finally {
      setSyncing(false);
    }
  };

  const handlePageChange = (page) => {
    fetchOrders(page);
  };

  const handleOrderView = (order) => {
    setSelectedOrder(order);
    setModalActive(true);
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const formatPrice = (price) => {
    return price ? `$${parseFloat(price).toFixed(2)}` : 'N/A';
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString();
  };

  const getFinancialStatusBadge = (status) => {
    switch (status) {
      case 'paid':
        return <Badge tone="success">Paid</Badge>;
      case 'pending':
        return <Badge tone="warning">Pending</Badge>;
      case 'refunded':
        return <Badge tone="info">Refunded</Badge>;
      case 'voided':
        return <Badge tone="critical">Voided</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const getFulfillmentStatusBadge = (status) => {
    if (!status) return <Badge tone="subdued">Unfulfilled</Badge>;
    
    switch (status) {
      case 'fulfilled':
        return <Badge tone="success">Fulfilled</Badge>;
      case 'partial':
        return <Badge tone="warning">Partial</Badge>;
      case 'restocked':
        return <Badge tone="info">Restocked</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const orderRows = orders.map((order) => [
    order.order_number || `#${order.id}`,
    order.customer_email || 'N/A',
    formatPrice(order.total_price),
    getFinancialStatusBadge(order.financial_status),
    getFulfillmentStatusBadge(order.fulfillment_status),
    formatDate(order.processed_at),
    <ButtonGroup key={order.id}>
      <Button size="slim" onClick={() => handleOrderView(order)} icon={ViewIcon}>
        View
      </Button>
    </ButtonGroup>
  ]);

  if (loading && orders.length === 0) {
    return (
      <Page title="Orders">
        <Layout>
          <Layout.Section>
            <Card>
              <div style={{ textAlign: 'center', padding: '2rem' }}>
                <Spinner size="large" />
                <Text variant="bodyMd" as="p" tone="subdued">
                  Loading orders...
                </Text>
              </div>
            </Card>
          </Layout.Section>
        </Layout>
      </Page>
    );
  }

  return (
    <Page
      title="Orders"
      subtitle={`${pagination.total} orders total`}
      primaryAction={{
        content: 'Sync Orders',
        icon: RefreshIcon,
        loading: syncing,
        onAction: syncOrders
      }}
      secondaryActions={[
        {
          content: 'Refresh',
          icon: RefreshIcon,
          onAction: () => fetchOrders(pagination.page)
        }
      ]}
    >
      <Layout>
        <Layout.Section>
          <Card>
            <div style={{ padding: '1rem' }}>
              <DataTable
                columnContentTypes={['text', 'text', 'text', 'text', 'text', 'text', 'text']}
                headings={['Order', 'Customer', 'Total', 'Financial Status', 'Fulfillment', 'Date', 'Actions']}
                rows={orderRows}
                loading={loading}
              />
              
              {pagination.pages > 1 && (
                <div style={{ marginTop: '1rem', display: 'flex', justifyContent: 'center' }}>
                  <Pagination
                    hasPrevious={pagination.page > 1}
                    onPrevious={() => handlePageChange(pagination.page - 1)}
                    hasNext={pagination.page < pagination.pages}
                    onNext={() => handlePageChange(pagination.page + 1)}
                    label={`Page ${pagination.page} of ${pagination.pages}`}
                  />
                </div>
              )}
            </div>
          </Card>
        </Layout.Section>
      </Layout>

      <Modal
        open={modalActive}
        onClose={() => setModalActive(false)}
        title="Order Details"
        primaryAction={{
          content: 'Close',
          onAction: () => setModalActive(false)
        }}
        large
      >
        <Modal.Section>
          {selectedOrder && (
            <Layout>
              <Layout.Section variant="oneHalf">
                <Card>
                  <div style={{ padding: '1rem' }}>
                    <Text variant="headingMd" as="h3">
                      Order Information
                    </Text>
                    
                    <div style={{ marginTop: '1rem' }}>
                      <Text variant="bodyMd" as="p">
                        <strong>Order Number:</strong> {selectedOrder.order_number || `#${selectedOrder.id}`}
                      </Text>
                      <Text variant="bodyMd" as="p">
                        <strong>Email:</strong> {selectedOrder.email || 'N/A'}
                      </Text>
                      <Text variant="bodyMd" as="p">
                        <strong>Total:</strong> {formatPrice(selectedOrder.total_price)}
                      </Text>
                      <Text variant="bodyMd" as="p">
                        <strong>Subtotal:</strong> {formatPrice(selectedOrder.subtotal_price)}
                      </Text>
                      <Text variant="bodyMd" as="p">
                        <strong>Tax:</strong> {formatPrice(selectedOrder.total_tax)}
                      </Text>
                      <Text variant="bodyMd" as="p">
                        <strong>Currency:</strong> {selectedOrder.currency || 'USD'}
                      </Text>
                      <Text variant="bodyMd" as="p">
                        <strong>Financial Status:</strong> {getFinancialStatusBadge(selectedOrder.financial_status)}
                      </Text>
                      <Text variant="bodyMd" as="p">
                        <strong>Fulfillment Status:</strong> {getFulfillmentStatusBadge(selectedOrder.fulfillment_status)}
                      </Text>
                      <Text variant="bodyMd" as="p">
                        <strong>Processed:</strong> {formatDate(selectedOrder.processed_at)}
                      </Text>
                    </div>
                  </div>
                </Card>
              </Layout.Section>

              <Layout.Section variant="oneHalf">
                <Card>
                  <div style={{ padding: '1rem' }}>
                    <Text variant="headingMd" as="h3">
                      Customer Information
                    </Text>
                    
                    <div style={{ marginTop: '1rem' }}>
                      <Text variant="bodyMd" as="p">
                        <strong>Name:</strong> {selectedOrder.customer_first_name && selectedOrder.customer_last_name 
                          ? `${selectedOrder.customer_first_name} ${selectedOrder.customer_last_name}` 
                          : 'N/A'}
                      </Text>
                      <Text variant="bodyMd" as="p">
                        <strong>Email:</strong> {selectedOrder.customer_email || 'N/A'}
                      </Text>
                      <Text variant="bodyMd" as="p">
                        <strong>Customer ID:</strong> {selectedOrder.customer_id || 'N/A'}
                      </Text>
                    </div>
                  </div>
                </Card>
              </Layout.Section>

              {selectedOrder.line_items && selectedOrder.line_items.length > 0 && (
                <Layout.Section>
                  <Card>
                    <div style={{ padding: '1rem' }}>
                      <Text variant="headingMd" as="h3">
                        Line Items
                      </Text>
                      
                      <div style={{ marginTop: '1rem' }}>
                        <DataTable
                          columnContentTypes={['text', 'numeric', 'text', 'text']}
                          headings={['Product', 'Quantity', 'Price', 'SKU']}
                          rows={selectedOrder.line_items.map((item) => [
                            item.title,
                            item.quantity,
                            formatPrice(item.price),
                            item.sku || 'N/A'
                          ])}
                        />
                      </div>
                    </div>
                  </Card>
                </Layout.Section>
              )}
            </Layout>
          )}
        </Modal.Section>
      </Modal>
    </Page>
  );
};

export default OrdersPage;

