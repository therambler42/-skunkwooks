import React, { useState, useEffect } from 'react';
import {
  Page,
  Layout,
  Card,
  Text,
  Button,
  Badge,
  DataTable,
  Spinner,
  Pagination,
  Filters,
  TextField,
  Select,
  ButtonGroup,
  Modal,
  TextContainer
} from '@shopify/polaris';
import { RefreshIcon, ViewIcon } from '@shopify/polaris-icons';
import axios from 'axios';
import { useAuth } from '../contexts/AuthContext';

const ProductsPage = ({ showToast }) => {
  const { API_BASE_URL } = useAuth();
  const [loading, setLoading] = useState(true);
  const [products, setProducts] = useState([]);
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 20,
    total: 0,
    pages: 0
  });
  const [syncing, setSyncing] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [modalActive, setModalActive] = useState(false);
  const [filters, setFilters] = useState({
    search: '',
    status: '',
    syncStatus: ''
  });

  const fetchProducts = async (page = 1) => {
    try {
      setLoading(true);
      
      const response = await axios.get(`${API_BASE_URL}/api/shopify/products/local`, {
        params: {
          page,
          limit: pagination.limit
        },
        withCredentials: true
      });
      
      setProducts(response.data.products || []);
      setPagination({
        ...pagination,
        page: response.data.page || 1,
        total: response.data.total || 0,
        pages: response.data.pages || 0
      });
      
    } catch (error) {
      console.error('Failed to fetch products:', error);
      showToast('Failed to load products', true);
    } finally {
      setLoading(false);
    }
  };

  const syncProducts = async () => {
    try {
      setSyncing(true);
      
      await axios.get(`${API_BASE_URL}/api/shopify/products`, {
        withCredentials: true
      });
      
      showToast('Products synced successfully');
      fetchProducts(pagination.page);
      
    } catch (error) {
      console.error('Product sync failed:', error);
      showToast('Product sync failed', true);
    } finally {
      setSyncing(false);
    }
  };

  const syncSingleProduct = async (productId) => {
    try {
      await axios.get(`${API_BASE_URL}/api/shopify/products/${productId}/sync`, {
        withCredentials: true
      });
      
      showToast('Product synced successfully');
      fetchProducts(pagination.page);
      
    } catch (error) {
      console.error('Product sync failed:', error);
      showToast('Product sync failed', true);
    }
  };

  const handlePageChange = (page) => {
    fetchProducts(page);
  };

  const handleProductView = (product) => {
    setSelectedProduct(product);
    setModalActive(true);
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const formatPrice = (price) => {
    return price ? `$${parseFloat(price).toFixed(2)}` : 'N/A';
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'Never';
    return new Date(dateString).toLocaleDateString();
  };

  const getSyncStatusBadge = (status) => {
    switch (status) {
      case 'synced':
        return <Badge tone="success">Synced</Badge>;
      case 'pending':
        return <Badge tone="warning">Pending</Badge>;
      case 'error':
        return <Badge tone="critical">Error</Badge>;
      default:
        return <Badge>Unknown</Badge>;
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'active':
        return <Badge tone="success">Active</Badge>;
      case 'draft':
        return <Badge tone="info">Draft</Badge>;
      case 'archived':
        return <Badge tone="subdued">Archived</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const productRows = products.map((product) => [
    product.title,
    product.sku || 'N/A',
    formatPrice(product.price),
    product.inventory_quantity || 0,
    getStatusBadge(product.status),
    getSyncStatusBadge(product.sync_status),
    formatDate(product.last_synced_at),
    <ButtonGroup key={product.id}>
      <Button size="slim" onClick={() => handleProductView(product)} icon={ViewIcon}>
        View
      </Button>
      <Button 
        size="slim" 
        onClick={() => syncSingleProduct(product.id)}
        icon={RefreshIcon}
      >
        Sync
      </Button>
    </ButtonGroup>
  ]);

  if (loading && products.length === 0) {
    return (
      <Page title="Products">
        <Layout>
          <Layout.Section>
            <Card>
              <div style={{ textAlign: 'center', padding: '2rem' }}>
                <Spinner size="large" />
                <Text variant="bodyMd" as="p" tone="subdued">
                  Loading products...
                </Text>
              </div>
            </Card>
          </Layout.Section>
        </Layout>
      </Page>
    );
  }

  return (
    <Page
      title="Products"
      subtitle={`${pagination.total} products total`}
      primaryAction={{
        content: 'Sync All Products',
        icon: RefreshIcon,
        loading: syncing,
        onAction: syncProducts
      }}
      secondaryActions={[
        {
          content: 'Refresh',
          icon: RefreshIcon,
          onAction: () => fetchProducts(pagination.page)
        }
      ]}
    >
      <Layout>
        <Layout.Section>
          <Card>
            <div style={{ padding: '1rem' }}>
              <DataTable
                columnContentTypes={['text', 'text', 'text', 'numeric', 'text', 'text', 'text', 'text']}
                headings={['Title', 'SKU', 'Price', 'Inventory', 'Status', 'Sync Status', 'Last Synced', 'Actions']}
                rows={productRows}
                loading={loading}
              />
              
              {pagination.pages > 1 && (
                <div style={{ marginTop: '1rem', display: 'flex', justifyContent: 'center' }}>
                  <Pagination
                    hasPrevious={pagination.page > 1}
                    onPrevious={() => handlePageChange(pagination.page - 1)}
                    hasNext={pagination.page < pagination.pages}
                    onNext={() => handlePageChange(pagination.page + 1)}
                    label={`Page ${pagination.page} of ${pagination.pages}`}
                  />
                </div>
              )}
            </div>
          </Card>
        </Layout.Section>
      </Layout>

      <Modal
        open={modalActive}
        onClose={() => setModalActive(false)}
        title="Product Details"
        primaryAction={{
          content: 'Close',
          onAction: () => setModalActive(false)
        }}
        secondaryActions={[
          {
            content: 'Sync Product',
            onAction: () => {
              syncSingleProduct(selectedProduct.id);
              setModalActive(false);
            }
          }
        ]}
      >
        <Modal.Section>
          {selectedProduct && (
            <TextContainer>
              <Text variant="headingMd" as="h3">
                {selectedProduct.title}
              </Text>
              
              <div style={{ marginTop: '1rem' }}>
                <Text variant="bodyMd" as="p">
                  <strong>SKU:</strong> {selectedProduct.sku || 'N/A'}
                </Text>
                <Text variant="bodyMd" as="p">
                  <strong>Price:</strong> {formatPrice(selectedProduct.price)}
                </Text>
                <Text variant="bodyMd" as="p">
                  <strong>Inventory:</strong> {selectedProduct.inventory_quantity || 0}
                </Text>
                <Text variant="bodyMd" as="p">
                  <strong>Vendor:</strong> {selectedProduct.vendor || 'N/A'}
                </Text>
                <Text variant="bodyMd" as="p">
                  <strong>Product Type:</strong> {selectedProduct.product_type || 'N/A'}
                </Text>
                <Text variant="bodyMd" as="p">
                  <strong>Weight:</strong> {selectedProduct.weight ? `${selectedProduct.weight} ${selectedProduct.weight_unit}` : 'N/A'}
                </Text>
                <Text variant="bodyMd" as="p">
                  <strong>Status:</strong> {getStatusBadge(selectedProduct.status)}
                </Text>
                <Text variant="bodyMd" as="p">
                  <strong>Sync Status:</strong> {getSyncStatusBadge(selectedProduct.sync_status)}
                </Text>
                <Text variant="bodyMd" as="p">
                  <strong>Last Synced:</strong> {formatDate(selectedProduct.last_synced_at)}
                </Text>
                <Text variant="bodyMd" as="p">
                  <strong>Created:</strong> {formatDate(selectedProduct.created_at)}
                </Text>
                <Text variant="bodyMd" as="p">
                  <strong>Updated:</strong> {formatDate(selectedProduct.updated_at)}
                </Text>
              </div>
            </TextContainer>
          )}
        </Modal.Section>
      </Modal>
    </Page>
  );
};

export default ProductsPage;

