from flask import Blueprint, request, jsonify, session
from src.models.shopify_models import db, Shop, Product, Order, OrderLineItem
from src.routes.auth import require_auth, make_shopify_request
from datetime import datetime, timedelta
import json

order_management_bp = Blueprint('order_management', __name__)

@order_management_bp.route('/fulfillment', methods=['POST'])
@require_auth
def create_fulfillment():
    """Create fulfillment for order line items"""
    try:
        data = request.get_json()
        order_id = data.get('order_id')
        line_items = data.get('line_items', [])
        tracking_number = data.get('tracking_number', '')
        tracking_company = data.get('tracking_company', '')
        notify_customer = data.get('notify_customer', True)
        
        if not order_id or not line_items:
            return jsonify({'error': 'Order ID and line items are required'}), 400
        
        shop_domain = session.get('shop_domain')
        shop = Shop.query.filter_by(shop_domain=shop_domain).first()
        
        if not shop:
            return jsonify({'error': 'Shop not found'}), 404
        
        order = Order.query.filter_by(id=order_id, shop_id=shop.id).first()
        
        if not order:
            return jsonify({'error': 'Order not found'}), 404
        
        # Prepare fulfillment data for Shopify
        fulfillment_data = {
            'fulfillment': {
                'location_id': None,  # Use default location
                'tracking_number': tracking_number,
                'tracking_company': tracking_company,
                'notify_customer': notify_customer,
                'line_items': []
            }
        }
        
        # Add line items to fulfillment
        for item in line_items:
            line_item_id = item.get('line_item_id')
            quantity = item.get('quantity', 1)
            
            # Find the line item in our database
            db_line_item = OrderLineItem.query.filter_by(
                order_id=order.id,
                shopify_line_item_id=line_item_id
            ).first()
            
            if db_line_item:
                fulfillment_data['fulfillment']['line_items'].append({
                    'id': line_item_id,
                    'quantity': quantity
                })
        
        # Create fulfillment in Shopify
        response = make_shopify_request(
            f'orders/{order.shopify_order_id}/fulfillments.json',
            'POST',
            fulfillment_data
        )
        
        if response and 'fulfillment' in response:
            fulfillment_info = response['fulfillment']
            
            # Update local order fulfillment status
            order.fulfillment_status = 'fulfilled'
            order.updated_at = datetime.utcnow()
            
            # Update line item fulfillment status
            for item in line_items:
                line_item_id = item.get('line_item_id')
                db_line_item = OrderLineItem.query.filter_by(
                    order_id=order.id,
                    shopify_line_item_id=line_item_id
                ).first()
                
                if db_line_item:
                    db_line_item.fulfillment_status = 'fulfilled'
            
            db.session.commit()
            
            return jsonify({
                'message': 'Fulfillment created successfully',
                'fulfillment': {
                    'id': fulfillment_info.get('id'),
                    'status': fulfillment_info.get('status'),
                    'tracking_number': fulfillment_info.get('tracking_number'),
                    'tracking_company': fulfillment_info.get('tracking_company'),
                    'created_at': fulfillment_info.get('created_at')
                },
                'order': order.to_dict()
            })
        else:
            return jsonify({'error': 'Failed to create fulfillment in Shopify'}), 500
            
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Fulfillment creation failed: {str(e)}'}), 500

@order_management_bp.route('/refund', methods=['POST'])
@require_auth
def create_refund():
    """Create refund for order"""
    try:
        data = request.get_json()
        order_id = data.get('order_id')
        amount = data.get('amount')
        reason = data.get('reason', 'other')
        note = data.get('note', '')
        restock = data.get('restock', True)
        line_items = data.get('line_items', [])
        
        if not order_id:
            return jsonify({'error': 'Order ID is required'}), 400
        
        shop_domain = session.get('shop_domain')
        shop = Shop.query.filter_by(shop_domain=shop_domain).first()
        
        if not shop:
            return jsonify({'error': 'Shop not found'}), 404
        
        order = Order.query.filter_by(id=order_id, shop_id=shop.id).first()
        
        if not order:
            return jsonify({'error': 'Order not found'}), 404
        
        # Prepare refund data for Shopify
        refund_data = {
            'refund': {
                'note': note,
                'notify': True,
                'shipping': {
                    'full_refund': False
                },
                'refund_line_items': [],
                'transactions': []
            }
        }
        
        # Add line items to refund if specified
        if line_items:
            for item in line_items:
                line_item_id = item.get('line_item_id')
                quantity = item.get('quantity', 1)
                restock_type = 'return' if restock else 'no_restock'
                
                refund_data['refund']['refund_line_items'].append({
                    'line_item_id': line_item_id,
                    'quantity': quantity,
                    'restock_type': restock_type
                })
        
        # Add transaction for monetary refund if amount specified
        if amount:
            refund_data['refund']['transactions'] = [{
                'parent_id': None,  # Will be filled by Shopify
                'amount': amount,
                'kind': 'refund',
                'gateway': 'manual'
            }]
        
        # Create refund in Shopify
        response = make_shopify_request(
            f'orders/{order.shopify_order_id}/refunds.json',
            'POST',
            refund_data
        )
        
        if response and 'refund' in response:
            refund_info = response['refund']
            
            # Update local order status
            order.financial_status = 'refunded'
            order.updated_at = datetime.utcnow()
            
            # If restocking, update inventory
            if restock and line_items:
                for item in line_items:
                    line_item_id = item.get('line_item_id')
                    quantity = item.get('quantity', 1)
                    
                    db_line_item = OrderLineItem.query.filter_by(
                        order_id=order.id,
                        shopify_line_item_id=line_item_id
                    ).first()
                    
                    if db_line_item and db_line_item.product_id:
                        product = Product.query.filter_by(
                            shopify_product_id=db_line_item.product_id,
                            shop_id=shop.id
                        ).first()
                        
                        if product:
                            product.inventory_quantity += quantity
                            product.last_synced_at = datetime.utcnow()
            
            db.session.commit()
            
            return jsonify({
                'message': 'Refund created successfully',
                'refund': {
                    'id': refund_info.get('id'),
                    'created_at': refund_info.get('created_at'),
                    'note': refund_info.get('note'),
                    'total_refunded': refund_info.get('total_refunded')
                },
                'order': order.to_dict()
            })
        else:
            return jsonify({'error': 'Failed to create refund in Shopify'}), 500
            
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Refund creation failed: {str(e)}'}), 500

@order_management_bp.route('/cancel', methods=['POST'])
@require_auth
def cancel_order():
    """Cancel an order"""
    try:
        data = request.get_json()
        order_id = data.get('order_id')
        reason = data.get('reason', 'other')
        email = data.get('email', True)
        restock = data.get('restock', True)
        
        if not order_id:
            return jsonify({'error': 'Order ID is required'}), 400
        
        shop_domain = session.get('shop_domain')
        shop = Shop.query.filter_by(shop_domain=shop_domain).first()
        
        if not shop:
            return jsonify({'error': 'Shop not found'}), 404
        
        order = Order.query.filter_by(id=order_id, shop_id=shop.id).first()
        
        if not order:
            return jsonify({'error': 'Order not found'}), 404
        
        # Cancel order in Shopify
        cancel_data = {
            'reason': reason,
            'email': email,
            'restock': restock
        }
        
        response = make_shopify_request(
            f'orders/{order.shopify_order_id}/cancel.json',
            'POST',
            cancel_data
        )
        
        if response and 'order' in response:
            cancelled_order = response['order']
            
            # Update local order status
            order.financial_status = cancelled_order.get('financial_status', 'voided')
            order.fulfillment_status = cancelled_order.get('fulfillment_status')
            order.updated_at = datetime.utcnow()
            
            # If restocking, update inventory
            if restock:
                for line_item in order.line_items:
                    if line_item.product_id:
                        product = Product.query.filter_by(
                            shopify_product_id=line_item.product_id,
                            shop_id=shop.id
                        ).first()
                        
                        if product:
                            product.inventory_quantity += line_item.quantity
                            product.last_synced_at = datetime.utcnow()
            
            db.session.commit()
            
            return jsonify({
                'message': 'Order cancelled successfully',
                'order': order.to_dict()
            })
        else:
            return jsonify({'error': 'Failed to cancel order in Shopify'}), 500
            
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Order cancellation failed: {str(e)}'}), 500

@order_management_bp.route('/analytics')
@require_auth
def get_order_analytics():
    """Get order analytics and statistics"""
    try:
        days = request.args.get('days', 30, type=int)
        
        shop_domain = session.get('shop_domain')
        shop = Shop.query.filter_by(shop_domain=shop_domain).first()
        
        if not shop:
            return jsonify({'error': 'Shop not found'}), 404
        
        # Calculate date range
        end_date = datetime.utcnow()
        start_date = end_date - timedelta(days=days)
        
        # Get orders in date range
        orders = Order.query.filter(
            Order.shop_id == shop.id,
            Order.created_at >= start_date,
            Order.created_at <= end_date
        ).all()
        
        # Calculate analytics
        total_orders = len(orders)
        total_revenue = sum(float(order.total_price or 0) for order in orders)
        average_order_value = total_revenue / total_orders if total_orders > 0 else 0
        
        # Group by status
        status_counts = {}
        for order in orders:
            financial_status = order.financial_status or 'unknown'
            status_counts[financial_status] = status_counts.get(financial_status, 0) + 1
        
        # Group by fulfillment status
        fulfillment_counts = {}
        for order in orders:
            fulfillment_status = order.fulfillment_status or 'unfulfilled'
            fulfillment_counts[fulfillment_status] = fulfillment_counts.get(fulfillment_status, 0) + 1
        
        # Daily breakdown
        daily_stats = {}
        for order in orders:
            date_key = order.created_at.strftime('%Y-%m-%d')
            if date_key not in daily_stats:
                daily_stats[date_key] = {'orders': 0, 'revenue': 0}
            
            daily_stats[date_key]['orders'] += 1
            daily_stats[date_key]['revenue'] += float(order.total_price or 0)
        
        # Top products by quantity sold
        product_sales = {}
        for order in orders:
            for line_item in order.line_items:
                product_title = line_item.title
                quantity = line_item.quantity
                
                if product_title not in product_sales:
                    product_sales[product_title] = 0
                product_sales[product_title] += quantity
        
        top_products = sorted(product_sales.items(), key=lambda x: x[1], reverse=True)[:10]
        
        return jsonify({
            'period': {
                'start_date': start_date.isoformat(),
                'end_date': end_date.isoformat(),
                'days': days
            },
            'summary': {
                'total_orders': total_orders,
                'total_revenue': round(total_revenue, 2),
                'average_order_value': round(average_order_value, 2)
            },
            'status_breakdown': {
                'financial_status': status_counts,
                'fulfillment_status': fulfillment_counts
            },
            'daily_stats': daily_stats,
            'top_products': [{'title': title, 'quantity_sold': qty} for title, qty in top_products]
        })
        
    except Exception as e:
        return jsonify({'error': f'Failed to get order analytics: {str(e)}'}), 500

@order_management_bp.route('/inventory-adjustments', methods=['POST'])
@require_auth
def bulk_inventory_adjustment():
    """Perform bulk inventory adjustments based on order patterns"""
    try:
        data = request.get_json()
        adjustment_type = data.get('type', 'reorder_point')  # 'reorder_point', 'seasonal', 'manual'
        products = data.get('products', [])
        
        shop_domain = session.get('shop_domain')
        shop = Shop.query.filter_by(shop_domain=shop_domain).first()
        
        if not shop:
            return jsonify({'error': 'Shop not found'}), 404
        
        results = []
        
        if adjustment_type == 'reorder_point':
            # Calculate reorder points based on sales velocity
            days_to_analyze = 30
            end_date = datetime.utcnow()
            start_date = end_date - timedelta(days=days_to_analyze)
            
            # Get all products if none specified
            if not products:
                products = [{'product_id': p.id} for p in Product.query.filter_by(shop_id=shop.id).all()]
            
            for product_data in products:
                product_id = product_data.get('product_id')
                product = Product.query.filter_by(id=product_id, shop_id=shop.id).first()
                
                if not product:
                    results.append({
                        'product_id': product_id,
                        'status': 'error',
                        'message': 'Product not found'
                    })
                    continue
                
                # Calculate sales velocity
                total_sold = 0
                orders = Order.query.filter(
                    Order.shop_id == shop.id,
                    Order.created_at >= start_date,
                    Order.created_at <= end_date
                ).all()
                
                for order in orders:
                    for line_item in order.line_items:
                        if line_item.product_id == product.shopify_product_id:
                            total_sold += line_item.quantity
                
                # Calculate daily average and reorder point
                daily_average = total_sold / days_to_analyze if days_to_analyze > 0 else 0
                lead_time_days = product_data.get('lead_time_days', 7)  # Default 7 days lead time
                safety_stock_days = product_data.get('safety_stock_days', 3)  # Default 3 days safety stock
                
                reorder_point = daily_average * (lead_time_days + safety_stock_days)
                
                # Check if reorder is needed
                if product.inventory_quantity <= reorder_point:
                    suggested_order_quantity = daily_average * 30  # 30 days worth of stock
                    
                    results.append({
                        'product_id': product_id,
                        'product_title': product.title,
                        'status': 'reorder_needed',
                        'current_inventory': product.inventory_quantity,
                        'reorder_point': round(reorder_point, 2),
                        'daily_average_sales': round(daily_average, 2),
                        'suggested_order_quantity': round(suggested_order_quantity, 2),
                        'total_sold_period': total_sold
                    })
                else:
                    results.append({
                        'product_id': product_id,
                        'product_title': product.title,
                        'status': 'sufficient_stock',
                        'current_inventory': product.inventory_quantity,
                        'reorder_point': round(reorder_point, 2),
                        'daily_average_sales': round(daily_average, 2)
                    })
        
        elif adjustment_type == 'manual':
            # Manual inventory adjustments
            for product_data in products:
                product_id = product_data.get('product_id')
                adjustment_quantity = product_data.get('adjustment_quantity', 0)
                reason = product_data.get('reason', 'Manual adjustment')
                
                product = Product.query.filter_by(id=product_id, shop_id=shop.id).first()
                
                if not product:
                    results.append({
                        'product_id': product_id,
                        'status': 'error',
                        'message': 'Product not found'
                    })
                    continue
                
                old_quantity = product.inventory_quantity
                new_quantity = max(0, old_quantity + adjustment_quantity)
                
                # Update inventory in Shopify
                shopify_product = make_shopify_request(f'products/{product.shopify_product_id}.json')
                
                if shopify_product and 'product' in shopify_product:
                    variants = shopify_product['product'].get('variants', [])
                    if variants:
                        variant_id = variants[0]['id']
                        
                        inventory_update = {
                            'variant': {
                                'id': variant_id,
                                'inventory_quantity': new_quantity
                            }
                        }
                        
                        response = make_shopify_request(f'variants/{variant_id}.json', 'PUT', inventory_update)
                        
                        if response and 'variant' in response:
                            # Update local database
                            product.inventory_quantity = new_quantity
                            product.last_synced_at = datetime.utcnow()
                            product.sync_status = 'synced'
                            
                            results.append({
                                'product_id': product_id,
                                'product_title': product.title,
                                'status': 'success',
                                'old_quantity': old_quantity,
                                'new_quantity': new_quantity,
                                'adjustment': adjustment_quantity,
                                'reason': reason
                            })
                        else:
                            results.append({
                                'product_id': product_id,
                                'status': 'error',
                                'message': 'Failed to update inventory in Shopify'
                            })
                else:
                    results.append({
                        'product_id': product_id,
                        'status': 'error',
                        'message': 'Failed to fetch product from Shopify'
                    })
        
        db.session.commit()
        
        return jsonify({
            'message': 'Inventory adjustment completed',
            'adjustment_type': adjustment_type,
            'results': results,
            'total': len(products),
            'successful': len([r for r in results if r['status'] in ['success', 'sufficient_stock']]),
            'reorder_needed': len([r for r in results if r['status'] == 'reorder_needed']),
            'failed': len([r for r in results if r['status'] == 'error'])
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Inventory adjustment failed: {str(e)}'}), 500

@order_management_bp.route('/fulfillments/<int:order_id>')
@require_auth
def get_order_fulfillments(order_id):
    """Get fulfillments for a specific order"""
    try:
        shop_domain = session.get('shop_domain')
        shop = Shop.query.filter_by(shop_domain=shop_domain).first()
        
        if not shop:
            return jsonify({'error': 'Shop not found'}), 404
        
        order = Order.query.filter_by(id=order_id, shop_id=shop.id).first()
        
        if not order:
            return jsonify({'error': 'Order not found'}), 404
        
        # Get fulfillments from Shopify
        response = make_shopify_request(f'orders/{order.shopify_order_id}/fulfillments.json')
        
        if response and 'fulfillments' in response:
            fulfillments = response['fulfillments']
            
            fulfillment_list = []
            for fulfillment in fulfillments:
                fulfillment_list.append({
                    'id': fulfillment.get('id'),
                    'status': fulfillment.get('status'),
                    'tracking_number': fulfillment.get('tracking_number'),
                    'tracking_company': fulfillment.get('tracking_company'),
                    'tracking_url': fulfillment.get('tracking_url'),
                    'created_at': fulfillment.get('created_at'),
                    'updated_at': fulfillment.get('updated_at'),
                    'line_items': fulfillment.get('line_items', [])
                })
            
            return jsonify({
                'fulfillments': fulfillment_list,
                'total': len(fulfillment_list)
            })
        else:
            return jsonify({'error': 'Failed to fetch fulfillments from Shopify'}), 500
            
    except Exception as e:
        return jsonify({'error': f'Failed to get fulfillments: {str(e)}'}), 500

