# Shopify App Integration - Deployment Guide

## Overview

This guide provides step-by-step instructions for deploying the Native Shopify App Integration to production environments. The application consists of a Flask backend and React frontend that work together to provide comprehensive inventory management capabilities.

## Architecture Overview

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Shopify       │    │   Frontend      │    │   Backend       │
│   Admin         │◄──►│   (React)       │◄──►│   (Flask)       │
│                 │    │   Polaris UI    │    │   API Server    │
└─────────────────┘    └─────────────────┘    └─────────────────┘
                                                       │
                                               ┌─────────────────┐
                                               │   Database      │
                                               │   (MySQL)       │
                                               └─────────────────┘
```

## Prerequisites

### System Requirements
- **Operating System**: Ubuntu 20.04+ or CentOS 7+
- **Python**: 3.8 or higher
- **Node.js**: 16.0 or higher
- **Database**: MySQL 5.7+ or PostgreSQL 12+
- **Web Server**: Nginx (recommended) or Apache
- **SSL Certificate**: Required for production deployment

### Shopify Requirements
- Shopify Partner account
- App created in Partner Dashboard
- API credentials (API key, API secret)
- Webhook secret for secure communication

## Backend Deployment

### 1. Server Setup

```bash
# Update system packages
sudo apt update && sudo apt upgrade -y

# Install required packages
sudo apt install -y python3 python3-pip python3-venv nginx mysql-server

# Create application user
sudo useradd -m -s /bin/bash shopifyapp
sudo usermod -aG sudo shopifyapp
```

### 2. Database Configuration

```bash
# Secure MySQL installation
sudo mysql_secure_installation

# Create database and user
sudo mysql -u root -p
```

```sql
CREATE DATABASE shopify_app CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'shopifyapp'@'localhost' IDENTIFIED BY 'secure_password_here';
GRANT ALL PRIVILEGES ON shopify_app.* TO 'shopifyapp'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

### 3. Application Deployment

```bash
# Switch to application user
sudo su - shopifyapp

# Clone repository
git clone https://github.com/yourcompany/shopify-app-integration.git
cd shopify-app-integration/backend

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Set up environment variables
cp .env.example .env
nano .env
```

### 4. Environment Configuration

```bash
# Production environment variables
FLASK_ENV=production
FLASK_DEBUG=False

# Database configuration
DB_HOST=localhost
DB_PORT=3306
DB_NAME=shopify_app
DB_USERNAME=shopifyapp
DB_PASSWORD=secure_password_here

# Shopify configuration
SHOPIFY_API_KEY=your_api_key_here
SHOPIFY_API_SECRET=your_api_secret_here
SHOPIFY_WEBHOOK_SECRET=your_webhook_secret_here
SHOPIFY_SCOPES=read_products,write_products,read_orders,write_orders

# Security
SECRET_KEY=your_very_secure_secret_key_here
JWT_SECRET_KEY=your_jwt_secret_key_here

# Application URLs
APP_URL=https://yourapp.com
FRONTEND_URL=https://yourapp.com

# SSL and security
SSL_DISABLE=False
FORCE_HTTPS=True
```

### 5. Database Migration

```bash
# Initialize database
python src/main.py db init
python src/main.py db migrate
python src/main.py db upgrade
```

### 6. Systemd Service Configuration

```bash
# Create systemd service file
sudo nano /etc/systemd/system/shopifyapp.service
```

```ini
[Unit]
Description=Shopify App Integration Backend
After=network.target mysql.service

[Service]
Type=simple
User=shopifyapp
Group=shopifyapp
WorkingDirectory=/home/shopifyapp/shopify-app-integration/backend
Environment=PATH=/home/shopifyapp/shopify-app-integration/backend/venv/bin
ExecStart=/home/shopifyapp/shopify-app-integration/backend/venv/bin/python src/main.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

```bash
# Enable and start service
sudo systemctl daemon-reload
sudo systemctl enable shopifyapp
sudo systemctl start shopifyapp
sudo systemctl status shopifyapp
```

## Frontend Deployment

### 1. Build Process

```bash
# Navigate to frontend directory
cd /home/shopifyapp/shopify-app-integration/frontend

# Install dependencies
npm install

# Build for production
npm run build
```

### 2. Web Server Configuration

```bash
# Create Nginx configuration
sudo nano /etc/nginx/sites-available/shopifyapp
```

```nginx
server {
    listen 80;
    server_name yourapp.com www.yourapp.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name yourapp.com www.yourapp.com;

    # SSL configuration
    ssl_certificate /path/to/your/certificate.crt;
    ssl_certificate_key /path/to/your/private.key;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512;
    ssl_prefer_server_ciphers off;

    # Frontend static files
    location / {
        root /home/shopifyapp/shopify-app-integration/frontend/dist;
        try_files $uri $uri/ /index.html;
        
        # Security headers
        add_header X-Frame-Options "SAMEORIGIN" always;
        add_header X-Content-Type-Options "nosniff" always;
        add_header X-XSS-Protection "1; mode=block" always;
        add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    }

    # Backend API proxy
    location /api/ {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }

    # Webhook endpoints
    location /webhooks/ {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Auth endpoints
    location /auth/ {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Static assets caching
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        root /home/shopifyapp/shopify-app-integration/frontend/dist;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

```bash
# Enable site and restart Nginx
sudo ln -s /etc/nginx/sites-available/shopifyapp /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

## SSL Certificate Setup

### Using Let's Encrypt (Recommended)

```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx

# Obtain certificate
sudo certbot --nginx -d yourapp.com -d www.yourapp.com

# Test automatic renewal
sudo certbot renew --dry-run
```

## Monitoring and Logging

### 1. Application Logs

```bash
# View application logs
sudo journalctl -u shopifyapp -f

# Log rotation configuration
sudo nano /etc/logrotate.d/shopifyapp
```

```
/var/log/shopifyapp/*.log {
    daily
    missingok
    rotate 52
    compress
    delaycompress
    notifempty
    create 644 shopifyapp shopifyapp
    postrotate
        systemctl reload shopifyapp
    endscript
}
```

### 2. Nginx Logs

```bash
# Access logs
tail -f /var/log/nginx/access.log

# Error logs
tail -f /var/log/nginx/error.log
```

### 3. Database Monitoring

```bash
# MySQL performance monitoring
sudo mysql -u root -p -e "SHOW PROCESSLIST;"
sudo mysql -u root -p -e "SHOW STATUS LIKE 'Threads_connected';"
```

## Security Hardening

### 1. Firewall Configuration

```bash
# Configure UFW firewall
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow 'Nginx Full'
sudo ufw enable
```

### 2. Application Security

```bash
# Set proper file permissions
sudo chown -R shopifyapp:shopifyapp /home/shopifyapp/shopify-app-integration
sudo chmod -R 755 /home/shopifyapp/shopify-app-integration
sudo chmod 600 /home/shopifyapp/shopify-app-integration/backend/.env
```

### 3. Database Security

```bash
# Secure MySQL configuration
sudo mysql -u root -p
```

```sql
-- Remove anonymous users
DELETE FROM mysql.user WHERE User='';

-- Remove remote root access
DELETE FROM mysql.user WHERE User='root' AND Host NOT IN ('localhost', '127.0.0.1', '::1');

-- Remove test database
DROP DATABASE IF EXISTS test;
DELETE FROM mysql.db WHERE Db='test' OR Db='test\\_%';

-- Reload privileges
FLUSH PRIVILEGES;
```

## Backup Strategy

### 1. Database Backup

```bash
# Create backup script
nano /home/shopifyapp/backup-db.sh
```

```bash
#!/bin/bash
BACKUP_DIR="/home/shopifyapp/backups"
DATE=$(date +%Y%m%d_%H%M%S)
DB_NAME="shopify_app"
DB_USER="shopifyapp"
DB_PASS="secure_password_here"

mkdir -p $BACKUP_DIR
mysqldump -u $DB_USER -p$DB_PASS $DB_NAME > $BACKUP_DIR/shopify_app_$DATE.sql
gzip $BACKUP_DIR/shopify_app_$DATE.sql

# Keep only last 30 days of backups
find $BACKUP_DIR -name "shopify_app_*.sql.gz" -mtime +30 -delete
```

```bash
# Make executable and add to crontab
chmod +x /home/shopifyapp/backup-db.sh
crontab -e
```

```
# Daily database backup at 2 AM
0 2 * * * /home/shopifyapp/backup-db.sh
```

### 2. Application Backup

```bash
# Create application backup script
nano /home/shopifyapp/backup-app.sh
```

```bash
#!/bin/bash
BACKUP_DIR="/home/shopifyapp/backups"
DATE=$(date +%Y%m%d_%H%M%S)
APP_DIR="/home/shopifyapp/shopify-app-integration"

mkdir -p $BACKUP_DIR
tar -czf $BACKUP_DIR/app_backup_$DATE.tar.gz -C $APP_DIR .

# Keep only last 7 days of app backups
find $BACKUP_DIR -name "app_backup_*.tar.gz" -mtime +7 -delete
```

## Performance Optimization

### 1. Database Optimization

```sql
-- Add indexes for better performance
CREATE INDEX idx_products_shopify_id ON products(shopify_product_id);
CREATE INDEX idx_orders_shopify_id ON orders(shopify_order_id);
CREATE INDEX idx_products_sync_status ON products(sync_status);
CREATE INDEX idx_orders_created_at ON orders(created_at);
```

### 2. Application Caching

```python
# Redis configuration for caching
REDIS_URL = 'redis://localhost:6379/0'
CACHE_TYPE = 'redis'
CACHE_REDIS_URL = 'redis://localhost:6379/0'
```

### 3. Nginx Optimization

```nginx
# Add to nginx.conf
worker_processes auto;
worker_connections 1024;

# Enable gzip compression
gzip on;
gzip_vary on;
gzip_min_length 1024;
gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;
```

## Troubleshooting

### Common Issues

1. **Database Connection Errors**
   ```bash
   # Check MySQL status
   sudo systemctl status mysql
   
   # Check connection
   mysql -u shopifyapp -p shopify_app
   ```

2. **Application Not Starting**
   ```bash
   # Check logs
   sudo journalctl -u shopifyapp -n 50
   
   # Check environment variables
   source /home/shopifyapp/shopify-app-integration/backend/venv/bin/activate
   python -c "import os; print(os.environ.get('SHOPIFY_API_KEY'))"
   ```

3. **Nginx Configuration Issues**
   ```bash
   # Test configuration
   sudo nginx -t
   
   # Check error logs
   sudo tail -f /var/log/nginx/error.log
   ```

### Health Checks

```bash
# Create health check script
nano /home/shopifyapp/health-check.sh
```

```bash
#!/bin/bash
# Check if application is responding
curl -f http://localhost:5000/health || exit 1

# Check database connection
mysql -u shopifyapp -p$DB_PASSWORD -e "SELECT 1" shopify_app || exit 1

echo "All systems operational"
```

## Maintenance

### Regular Tasks

1. **Weekly Tasks**
   - Review application logs
   - Check disk space usage
   - Verify backup integrity
   - Update system packages

2. **Monthly Tasks**
   - Review security logs
   - Update SSL certificates if needed
   - Performance monitoring review
   - Database optimization

3. **Quarterly Tasks**
   - Security audit
   - Dependency updates
   - Disaster recovery testing
   - Performance benchmarking

### Update Procedure

```bash
# 1. Backup current version
/home/shopifyapp/backup-app.sh
/home/shopifyapp/backup-db.sh

# 2. Pull latest changes
cd /home/shopifyapp/shopify-app-integration
git pull origin main

# 3. Update backend dependencies
cd backend
source venv/bin/activate
pip install -r requirements.txt

# 4. Run database migrations
python src/main.py db upgrade

# 5. Update frontend
cd ../frontend
npm install
npm run build

# 6. Restart services
sudo systemctl restart shopifyapp
sudo systemctl reload nginx
```

## Support and Documentation

For additional support and detailed API documentation, please refer to:

- **API Documentation**: https://docs.yourapp.com/api
- **Troubleshooting Guide**: https://docs.yourapp.com/troubleshooting
- **Support Portal**: https://support.yourapp.com
- **Community Forum**: https://community.yourapp.com

---

*This deployment guide is regularly updated. For the latest version, please visit our documentation portal.*

