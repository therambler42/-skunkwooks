from flask import Blueprint, request, jsonify, session
from src.models.shopify_models import db, Shop, Product, Order, OrderLineItem
from src.routes.auth import require_auth, make_shopify_request
from datetime import datetime
import json

shopify_bp = Blueprint('shopify', __name__)

@shopify_bp.route('/shop/info')
@require_auth
def get_shop_info():
    """Get current shop information"""
    shop_data = make_shopify_request('shop.json')
    
    if shop_data:
        return jsonify(shop_data)
    else:
        return jsonify({'error': 'Failed to fetch shop information'}), 500

@shopify_bp.route('/products')
@require_auth
def get_products():
    """Get products from Shopify and sync with local database"""
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 50, type=int)
    
    # Fetch products from Shopify
    endpoint = f'products.json?limit={limit}&page={page}'
    products_data = make_shopify_request(endpoint)
    
    if not products_data:
        return jsonify({'error': 'Failed to fetch products from Shopify'}), 500
    
    products = products_data.get('products', [])
    
    # Get current shop
    shop_domain = session.get('shop_domain')
    shop = Shop.query.filter_by(shop_domain=shop_domain).first()
    
    if not shop:
        return jsonify({'error': 'Shop not found'}), 404
    
    synced_products = []
    
    for product_data in products:
        # Get the first variant for inventory and pricing info
        variants = product_data.get('variants', [])
        first_variant = variants[0] if variants else {}
        
        # Check if product already exists
        existing_product = Product.query.filter_by(
            shopify_product_id=product_data['id'],
            shop_id=shop.id
        ).first()
        
        if existing_product:
            # Update existing product
            existing_product.title = product_data.get('title', '')
            existing_product.handle = product_data.get('handle', '')
            existing_product.vendor = product_data.get('vendor', '')
            existing_product.product_type = product_data.get('product_type', '')
            existing_product.status = product_data.get('status', 'active')
            existing_product.inventory_quantity = first_variant.get('inventory_quantity', 0)
            existing_product.price = first_variant.get('price')
            existing_product.compare_at_price = first_variant.get('compare_at_price')
            existing_product.sku = first_variant.get('sku', '')
            existing_product.barcode = first_variant.get('barcode', '')
            existing_product.weight = first_variant.get('weight')
            existing_product.weight_unit = first_variant.get('weight_unit', 'kg')
            existing_product.requires_shipping = first_variant.get('requires_shipping', True)
            existing_product.taxable = first_variant.get('taxable', True)
            existing_product.sync_status = 'synced'
            existing_product.last_synced_at = datetime.utcnow()
            existing_product.updated_at = datetime.utcnow()
            
            synced_products.append(existing_product.to_dict())
        else:
            # Create new product
            new_product = Product(
                shopify_product_id=product_data['id'],
                shop_id=shop.id,
                title=product_data.get('title', ''),
                handle=product_data.get('handle', ''),
                vendor=product_data.get('vendor', ''),
                product_type=product_data.get('product_type', ''),
                status=product_data.get('status', 'active'),
                inventory_quantity=first_variant.get('inventory_quantity', 0),
                price=first_variant.get('price'),
                compare_at_price=first_variant.get('compare_at_price'),
                sku=first_variant.get('sku', ''),
                barcode=first_variant.get('barcode', ''),
                weight=first_variant.get('weight'),
                weight_unit=first_variant.get('weight_unit', 'kg'),
                requires_shipping=first_variant.get('requires_shipping', True),
                taxable=first_variant.get('taxable', True),
                sync_status='synced',
                last_synced_at=datetime.utcnow()
            )
            
            db.session.add(new_product)
            synced_products.append(new_product.to_dict())
    
    try:
        db.session.commit()
        return jsonify({
            'products': synced_products,
            'total': len(synced_products),
            'page': page,
            'limit': limit
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Database error: {str(e)}'}), 500

@shopify_bp.route('/products/local')
@require_auth
def get_local_products():
    """Get products from local database"""
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 50, type=int)
    
    shop_domain = session.get('shop_domain')
    shop = Shop.query.filter_by(shop_domain=shop_domain).first()
    
    if not shop:
        return jsonify({'error': 'Shop not found'}), 404
    
    # Paginate products
    products_query = Product.query.filter_by(shop_id=shop.id)
    total = products_query.count()
    
    products = products_query.offset((page - 1) * limit).limit(limit).all()
    
    return jsonify({
        'products': [product.to_dict() for product in products],
        'total': total,
        'page': page,
        'limit': limit,
        'pages': (total + limit - 1) // limit
    })

@shopify_bp.route('/products/<int:product_id>/sync')
@require_auth
def sync_product(product_id):
    """Sync a specific product with Shopify"""
    shop_domain = session.get('shop_domain')
    shop = Shop.query.filter_by(shop_domain=shop_domain).first()
    
    if not shop:
        return jsonify({'error': 'Shop not found'}), 404
    
    product = Product.query.filter_by(id=product_id, shop_id=shop.id).first()
    
    if not product:
        return jsonify({'error': 'Product not found'}), 404
    
    # Fetch product from Shopify
    product_data = make_shopify_request(f'products/{product.shopify_product_id}.json')
    
    if not product_data:
        return jsonify({'error': 'Failed to fetch product from Shopify'}), 500
    
    shopify_product = product_data.get('product', {})
    variants = shopify_product.get('variants', [])
    first_variant = variants[0] if variants else {}
    
    # Update product with Shopify data
    product.title = shopify_product.get('title', '')
    product.handle = shopify_product.get('handle', '')
    product.vendor = shopify_product.get('vendor', '')
    product.product_type = shopify_product.get('product_type', '')
    product.status = shopify_product.get('status', 'active')
    product.inventory_quantity = first_variant.get('inventory_quantity', 0)
    product.price = first_variant.get('price')
    product.compare_at_price = first_variant.get('compare_at_price')
    product.sku = first_variant.get('sku', '')
    product.barcode = first_variant.get('barcode', '')
    product.weight = first_variant.get('weight')
    product.weight_unit = first_variant.get('weight_unit', 'kg')
    product.requires_shipping = first_variant.get('requires_shipping', True)
    product.taxable = first_variant.get('taxable', True)
    product.sync_status = 'synced'
    product.last_synced_at = datetime.utcnow()
    product.updated_at = datetime.utcnow()
    
    try:
        db.session.commit()
        return jsonify({
            'message': 'Product synced successfully',
            'product': product.to_dict()
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Database error: {str(e)}'}), 500

@shopify_bp.route('/orders')
@require_auth
def get_orders():
    """Get orders from Shopify and sync with local database"""
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 50, type=int)
    status = request.args.get('status', 'any')
    
    # Fetch orders from Shopify
    endpoint = f'orders.json?limit={limit}&page={page}&status={status}'
    orders_data = make_shopify_request(endpoint)
    
    if not orders_data:
        return jsonify({'error': 'Failed to fetch orders from Shopify'}), 500
    
    orders = orders_data.get('orders', [])
    
    # Get current shop
    shop_domain = session.get('shop_domain')
    shop = Shop.query.filter_by(shop_domain=shop_domain).first()
    
    if not shop:
        return jsonify({'error': 'Shop not found'}), 404
    
    synced_orders = []
    
    for order_data in orders:
        # Check if order already exists
        existing_order = Order.query.filter_by(
            shopify_order_id=order_data['id'],
            shop_id=shop.id
        ).first()
        
        if existing_order:
            # Update existing order
            existing_order.order_number = order_data.get('order_number')
            existing_order.email = order_data.get('email')
            existing_order.financial_status = order_data.get('financial_status')
            existing_order.fulfillment_status = order_data.get('fulfillment_status')
            existing_order.total_price = order_data.get('total_price')
            existing_order.subtotal_price = order_data.get('subtotal_price')
            existing_order.total_tax = order_data.get('total_tax')
            existing_order.currency = order_data.get('currency', 'USD')
            
            # Update customer info
            customer = order_data.get('customer', {})
            if customer:
                existing_order.customer_id = customer.get('id')
                existing_order.customer_email = customer.get('email')
                existing_order.customer_first_name = customer.get('first_name')
                existing_order.customer_last_name = customer.get('last_name')
            
            # Parse processed_at
            if order_data.get('processed_at'):
                existing_order.processed_at = datetime.fromisoformat(
                    order_data['processed_at'].replace('Z', '+00:00')
                )
            
            existing_order.updated_at = datetime.utcnow()
            
            # Update line items
            OrderLineItem.query.filter_by(order_id=existing_order.id).delete()
            
            for line_item_data in order_data.get('line_items', []):
                line_item = OrderLineItem(
                    order_id=existing_order.id,
                    shopify_line_item_id=line_item_data.get('id'),
                    product_id=line_item_data.get('product_id'),
                    variant_id=line_item_data.get('variant_id'),
                    title=line_item_data.get('title'),
                    quantity=line_item_data.get('quantity', 0),
                    price=line_item_data.get('price'),
                    sku=line_item_data.get('sku'),
                    vendor=line_item_data.get('vendor'),
                    product_exists=line_item_data.get('product_exists', True),
                    fulfillable_quantity=line_item_data.get('fulfillable_quantity'),
                    fulfillment_service=line_item_data.get('fulfillment_service'),
                    fulfillment_status=line_item_data.get('fulfillment_status'),
                    requires_shipping=line_item_data.get('requires_shipping', True),
                    taxable=line_item_data.get('taxable', True)
                )
                db.session.add(line_item)
            
            synced_orders.append(existing_order.to_dict())
        else:
            # Create new order
            new_order = Order(
                shopify_order_id=order_data['id'],
                shop_id=shop.id,
                order_number=order_data.get('order_number'),
                email=order_data.get('email'),
                financial_status=order_data.get('financial_status'),
                fulfillment_status=order_data.get('fulfillment_status'),
                total_price=order_data.get('total_price'),
                subtotal_price=order_data.get('subtotal_price'),
                total_tax=order_data.get('total_tax'),
                currency=order_data.get('currency', 'USD')
            )
            
            # Add customer info
            customer = order_data.get('customer', {})
            if customer:
                new_order.customer_id = customer.get('id')
                new_order.customer_email = customer.get('email')
                new_order.customer_first_name = customer.get('first_name')
                new_order.customer_last_name = customer.get('last_name')
            
            # Parse processed_at
            if order_data.get('processed_at'):
                new_order.processed_at = datetime.fromisoformat(
                    order_data['processed_at'].replace('Z', '+00:00')
                )
            
            db.session.add(new_order)
            db.session.flush()  # Get the order ID
            
            # Add line items
            for line_item_data in order_data.get('line_items', []):
                line_item = OrderLineItem(
                    order_id=new_order.id,
                    shopify_line_item_id=line_item_data.get('id'),
                    product_id=line_item_data.get('product_id'),
                    variant_id=line_item_data.get('variant_id'),
                    title=line_item_data.get('title'),
                    quantity=line_item_data.get('quantity', 0),
                    price=line_item_data.get('price'),
                    sku=line_item_data.get('sku'),
                    vendor=line_item_data.get('vendor'),
                    product_exists=line_item_data.get('product_exists', True),
                    fulfillable_quantity=line_item_data.get('fulfillable_quantity'),
                    fulfillment_service=line_item_data.get('fulfillment_service'),
                    fulfillment_status=line_item_data.get('fulfillment_status'),
                    requires_shipping=line_item_data.get('requires_shipping', True),
                    taxable=line_item_data.get('taxable', True)
                )
                db.session.add(line_item)
            
            synced_orders.append(new_order.to_dict())
    
    try:
        db.session.commit()
        return jsonify({
            'orders': synced_orders,
            'total': len(synced_orders),
            'page': page,
            'limit': limit
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Database error: {str(e)}'}), 500

@shopify_bp.route('/orders/local')
@require_auth
def get_local_orders():
    """Get orders from local database"""
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 50, type=int)
    
    shop_domain = session.get('shop_domain')
    shop = Shop.query.filter_by(shop_domain=shop_domain).first()
    
    if not shop:
        return jsonify({'error': 'Shop not found'}), 404
    
    # Paginate orders
    orders_query = Order.query.filter_by(shop_id=shop.id).order_by(Order.created_at.desc())
    total = orders_query.count()
    
    orders = orders_query.offset((page - 1) * limit).limit(limit).all()
    
    return jsonify({
        'orders': [order.to_dict() for order in orders],
        'total': total,
        'page': page,
        'limit': limit,
        'pages': (total + limit - 1) // limit
    })

