from flask import Blueprint, request, jsonify, session
from src.models.shopify_models import db, Shop, Product, Order, OrderLineItem
from src.routes.auth import require_auth, make_shopify_request
from datetime import datetime
import json

inventory_bp = Blueprint('inventory', __name__)

@inventory_bp.route('/products/push', methods=['POST'])
@require_auth
def push_product_catalog():
    """Push local product catalog to Shopify"""
    try:
        data = request.get_json()
        products_data = data.get('products', [])
        
        if not products_data:
            return jsonify({'error': 'No products provided'}), 400
        
        shop_domain = session.get('shop_domain')
        shop = Shop.query.filter_by(shop_domain=shop_domain).first()
        
        if not shop:
            return jsonify({'error': 'Shop not found'}), 404
        
        results = []
        
        for product_data in products_data:
            try:
                # Prepare Shopify product data
                shopify_product = {
                    'product': {
                        'title': product_data.get('title'),
                        'body_html': product_data.get('description', ''),
                        'vendor': product_data.get('vendor', ''),
                        'product_type': product_data.get('product_type', ''),
                        'status': product_data.get('status', 'active'),
                        'variants': [{
                            'price': str(product_data.get('price', 0)),
                            'compare_at_price': str(product_data.get('compare_at_price', 0)) if product_data.get('compare_at_price') else None,
                            'sku': product_data.get('sku', ''),
                            'barcode': product_data.get('barcode', ''),
                            'inventory_quantity': product_data.get('inventory_quantity', 0),
                            'inventory_management': 'shopify',
                            'inventory_policy': 'deny',
                            'weight': product_data.get('weight', 0),
                            'weight_unit': product_data.get('weight_unit', 'kg'),
                            'requires_shipping': product_data.get('requires_shipping', True),
                            'taxable': product_data.get('taxable', True)
                        }]
                    }
                }
                
                # Create product in Shopify
                response = make_shopify_request('products.json', 'POST', shopify_product)
                
                if response and 'product' in response:
                    shopify_product_data = response['product']
                    first_variant = shopify_product_data.get('variants', [{}])[0]
                    
                    # Save to local database
                    new_product = Product(
                        shopify_product_id=shopify_product_data['id'],
                        shop_id=shop.id,
                        title=shopify_product_data.get('title', ''),
                        handle=shopify_product_data.get('handle', ''),
                        vendor=shopify_product_data.get('vendor', ''),
                        product_type=shopify_product_data.get('product_type', ''),
                        status=shopify_product_data.get('status', 'active'),
                        inventory_quantity=first_variant.get('inventory_quantity', 0),
                        price=first_variant.get('price'),
                        compare_at_price=first_variant.get('compare_at_price'),
                        sku=first_variant.get('sku', ''),
                        barcode=first_variant.get('barcode', ''),
                        weight=first_variant.get('weight'),
                        weight_unit=first_variant.get('weight_unit', 'kg'),
                        requires_shipping=first_variant.get('requires_shipping', True),
                        taxable=first_variant.get('taxable', True),
                        sync_status='synced',
                        last_synced_at=datetime.utcnow()
                    )
                    
                    db.session.add(new_product)
                    
                    results.append({
                        'status': 'success',
                        'product_id': shopify_product_data['id'],
                        'title': shopify_product_data.get('title'),
                        'message': 'Product created successfully'
                    })
                else:
                    results.append({
                        'status': 'error',
                        'title': product_data.get('title'),
                        'message': 'Failed to create product in Shopify'
                    })
                    
            except Exception as e:
                results.append({
                    'status': 'error',
                    'title': product_data.get('title'),
                    'message': f'Error creating product: {str(e)}'
                })
        
        db.session.commit()
        
        return jsonify({
            'message': 'Product catalog push completed',
            'results': results,
            'total': len(products_data),
            'successful': len([r for r in results if r['status'] == 'success']),
            'failed': len([r for r in results if r['status'] == 'error'])
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Product catalog push failed: {str(e)}'}), 500

@inventory_bp.route('/products/<int:product_id>/inventory', methods=['PUT'])
@require_auth
def update_product_inventory(product_id):
    """Update product inventory in both local database and Shopify"""
    try:
        data = request.get_json()
        new_quantity = data.get('quantity')
        
        if new_quantity is None:
            return jsonify({'error': 'Quantity is required'}), 400
        
        shop_domain = session.get('shop_domain')
        shop = Shop.query.filter_by(shop_domain=shop_domain).first()
        
        if not shop:
            return jsonify({'error': 'Shop not found'}), 404
        
        product = Product.query.filter_by(id=product_id, shop_id=shop.id).first()
        
        if not product:
            return jsonify({'error': 'Product not found'}), 404
        
        # Get product variants from Shopify
        shopify_product = make_shopify_request(f'products/{product.shopify_product_id}.json')
        
        if not shopify_product or 'product' not in shopify_product:
            return jsonify({'error': 'Failed to fetch product from Shopify'}), 500
        
        variants = shopify_product['product'].get('variants', [])
        if not variants:
            return jsonify({'error': 'No variants found for product'}), 404
        
        # Update the first variant's inventory
        variant = variants[0]
        variant_id = variant['id']
        
        # Update inventory in Shopify
        inventory_update = {
            'variant': {
                'id': variant_id,
                'inventory_quantity': new_quantity
            }
        }
        
        response = make_shopify_request(f'variants/{variant_id}.json', 'PUT', inventory_update)
        
        if response and 'variant' in response:
            # Update local database
            product.inventory_quantity = new_quantity
            product.last_synced_at = datetime.utcnow()
            product.sync_status = 'synced'
            
            db.session.commit()
            
            return jsonify({
                'message': 'Inventory updated successfully',
                'product': product.to_dict(),
                'old_quantity': variant.get('inventory_quantity'),
                'new_quantity': new_quantity
            })
        else:
            return jsonify({'error': 'Failed to update inventory in Shopify'}), 500
            
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Inventory update failed: {str(e)}'}), 500

@inventory_bp.route('/products/bulk-inventory', methods=['PUT'])
@require_auth
def bulk_update_inventory():
    """Bulk update inventory for multiple products"""
    try:
        data = request.get_json()
        updates = data.get('updates', [])
        
        if not updates:
            return jsonify({'error': 'No updates provided'}), 400
        
        shop_domain = session.get('shop_domain')
        shop = Shop.query.filter_by(shop_domain=shop_domain).first()
        
        if not shop:
            return jsonify({'error': 'Shop not found'}), 404
        
        results = []
        
        for update in updates:
            product_id = update.get('product_id')
            new_quantity = update.get('quantity')
            
            if not product_id or new_quantity is None:
                results.append({
                    'product_id': product_id,
                    'status': 'error',
                    'message': 'Product ID and quantity are required'
                })
                continue
            
            try:
                product = Product.query.filter_by(id=product_id, shop_id=shop.id).first()
                
                if not product:
                    results.append({
                        'product_id': product_id,
                        'status': 'error',
                        'message': 'Product not found'
                    })
                    continue
                
                # Get product variants from Shopify
                shopify_product = make_shopify_request(f'products/{product.shopify_product_id}.json')
                
                if not shopify_product or 'product' not in shopify_product:
                    results.append({
                        'product_id': product_id,
                        'status': 'error',
                        'message': 'Failed to fetch product from Shopify'
                    })
                    continue
                
                variants = shopify_product['product'].get('variants', [])
                if not variants:
                    results.append({
                        'product_id': product_id,
                        'status': 'error',
                        'message': 'No variants found for product'
                    })
                    continue
                
                # Update the first variant's inventory
                variant = variants[0]
                variant_id = variant['id']
                old_quantity = variant.get('inventory_quantity', 0)
                
                # Update inventory in Shopify
                inventory_update = {
                    'variant': {
                        'id': variant_id,
                        'inventory_quantity': new_quantity
                    }
                }
                
                response = make_shopify_request(f'variants/{variant_id}.json', 'PUT', inventory_update)
                
                if response and 'variant' in response:
                    # Update local database
                    product.inventory_quantity = new_quantity
                    product.last_synced_at = datetime.utcnow()
                    product.sync_status = 'synced'
                    
                    results.append({
                        'product_id': product_id,
                        'status': 'success',
                        'title': product.title,
                        'old_quantity': old_quantity,
                        'new_quantity': new_quantity,
                        'message': 'Inventory updated successfully'
                    })
                else:
                    results.append({
                        'product_id': product_id,
                        'status': 'error',
                        'message': 'Failed to update inventory in Shopify'
                    })
                    
            except Exception as e:
                results.append({
                    'product_id': product_id,
                    'status': 'error',
                    'message': f'Error updating inventory: {str(e)}'
                })
        
        db.session.commit()
        
        return jsonify({
            'message': 'Bulk inventory update completed',
            'results': results,
            'total': len(updates),
            'successful': len([r for r in results if r['status'] == 'success']),
            'failed': len([r for r in results if r['status'] == 'error'])
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Bulk inventory update failed: {str(e)}'}), 500

@inventory_bp.route('/products/mapping')
@require_auth
def get_product_mapping():
    """Get product mapping between local and Shopify products"""
    try:
        shop_domain = session.get('shop_domain')
        shop = Shop.query.filter_by(shop_domain=shop_domain).first()
        
        if not shop:
            return jsonify({'error': 'Shop not found'}), 404
        
        products = Product.query.filter_by(shop_id=shop.id).all()
        
        mapping = []
        for product in products:
            mapping.append({
                'local_id': product.id,
                'shopify_id': product.shopify_product_id,
                'title': product.title,
                'sku': product.sku,
                'sync_status': product.sync_status,
                'last_synced': product.last_synced_at.isoformat() if product.last_synced_at else None,
                'inventory_quantity': product.inventory_quantity
            })
        
        return jsonify({
            'mapping': mapping,
            'total': len(mapping)
        })
        
    except Exception as e:
        return jsonify({'error': f'Failed to get product mapping: {str(e)}'}), 500

@inventory_bp.route('/products/sync-status')
@require_auth
def get_sync_status():
    """Get synchronization status for all products"""
    try:
        shop_domain = session.get('shop_domain')
        shop = Shop.query.filter_by(shop_domain=shop_domain).first()
        
        if not shop:
            return jsonify({'error': 'Shop not found'}), 404
        
        # Get sync status counts
        total_products = Product.query.filter_by(shop_id=shop.id).count()
        synced_products = Product.query.filter_by(shop_id=shop.id, sync_status='synced').count()
        pending_products = Product.query.filter_by(shop_id=shop.id, sync_status='pending').count()
        error_products = Product.query.filter_by(shop_id=shop.id, sync_status='error').count()
        
        # Get products that need sync (older than 1 hour)
        from datetime import timedelta
        one_hour_ago = datetime.utcnow() - timedelta(hours=1)
        outdated_products = Product.query.filter(
            Product.shop_id == shop.id,
            Product.last_synced_at < one_hour_ago
        ).count()
        
        return jsonify({
            'total_products': total_products,
            'synced_products': synced_products,
            'pending_products': pending_products,
            'error_products': error_products,
            'outdated_products': outdated_products,
            'sync_percentage': round((synced_products / total_products * 100) if total_products > 0 else 0, 2)
        })
        
    except Exception as e:
        return jsonify({'error': f'Failed to get sync status: {str(e)}'}), 500

@inventory_bp.route('/products/low-stock')
@require_auth
def get_low_stock_products():
    """Get products with low stock levels"""
    try:
        threshold = request.args.get('threshold', 10, type=int)
        
        shop_domain = session.get('shop_domain')
        shop = Shop.query.filter_by(shop_domain=shop_domain).first()
        
        if not shop:
            return jsonify({'error': 'Shop not found'}), 404
        
        low_stock_products = Product.query.filter(
            Product.shop_id == shop.id,
            Product.inventory_quantity <= threshold,
            Product.status == 'active'
        ).all()
        
        products_data = []
        for product in low_stock_products:
            products_data.append({
                'id': product.id,
                'shopify_product_id': product.shopify_product_id,
                'title': product.title,
                'sku': product.sku,
                'inventory_quantity': product.inventory_quantity,
                'price': float(product.price) if product.price else None,
                'vendor': product.vendor,
                'last_synced_at': product.last_synced_at.isoformat() if product.last_synced_at else None
            })
        
        return jsonify({
            'low_stock_products': products_data,
            'total': len(products_data),
            'threshold': threshold
        })
        
    except Exception as e:
        return jsonify({'error': f'Failed to get low stock products: {str(e)}'}), 500

@inventory_bp.route('/inventory/adjustments', methods=['POST'])
@require_auth
def create_inventory_adjustment():
    """Create an inventory adjustment record"""
    try:
        data = request.get_json()
        product_id = data.get('product_id')
        adjustment_type = data.get('type')  # 'increase', 'decrease', 'set'
        quantity = data.get('quantity')
        reason = data.get('reason', '')
        
        if not all([product_id, adjustment_type, quantity is not None]):
            return jsonify({'error': 'Product ID, type, and quantity are required'}), 400
        
        shop_domain = session.get('shop_domain')
        shop = Shop.query.filter_by(shop_domain=shop_domain).first()
        
        if not shop:
            return jsonify({'error': 'Shop not found'}), 404
        
        product = Product.query.filter_by(id=product_id, shop_id=shop.id).first()
        
        if not product:
            return jsonify({'error': 'Product not found'}), 404
        
        old_quantity = product.inventory_quantity
        
        # Calculate new quantity based on adjustment type
        if adjustment_type == 'increase':
            new_quantity = old_quantity + quantity
        elif adjustment_type == 'decrease':
            new_quantity = max(0, old_quantity - quantity)
        elif adjustment_type == 'set':
            new_quantity = quantity
        else:
            return jsonify({'error': 'Invalid adjustment type'}), 400
        
        # Update inventory using the existing endpoint logic
        # Get product variants from Shopify
        shopify_product = make_shopify_request(f'products/{product.shopify_product_id}.json')
        
        if not shopify_product or 'product' not in shopify_product:
            return jsonify({'error': 'Failed to fetch product from Shopify'}), 500
        
        variants = shopify_product['product'].get('variants', [])
        if not variants:
            return jsonify({'error': 'No variants found for product'}), 404
        
        # Update the first variant's inventory
        variant = variants[0]
        variant_id = variant['id']
        
        # Update inventory in Shopify
        inventory_update = {
            'variant': {
                'id': variant_id,
                'inventory_quantity': new_quantity
            }
        }
        
        response = make_shopify_request(f'variants/{variant_id}.json', 'PUT', inventory_update)
        
        if response and 'variant' in response:
            # Update local database
            product.inventory_quantity = new_quantity
            product.last_synced_at = datetime.utcnow()
            product.sync_status = 'synced'
            
            db.session.commit()
            
            return jsonify({
                'message': 'Inventory adjustment completed successfully',
                'product': product.to_dict(),
                'adjustment': {
                    'type': adjustment_type,
                    'old_quantity': old_quantity,
                    'new_quantity': new_quantity,
                    'adjustment_amount': quantity,
                    'reason': reason
                }
            })
        else:
            return jsonify({'error': 'Failed to update inventory in Shopify'}), 500
            
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Inventory adjustment failed: {str(e)}'}), 500

