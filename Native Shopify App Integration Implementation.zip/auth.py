import os
import hmac
import hashlib
import base64
import json
from urllib.parse import urlencode, parse_qs
from flask import Blueprint, request, jsonify, redirect, session, url_for
from src.models.shopify_models import db, Shop
import requests
from datetime import datetime

auth_bp = Blueprint('auth', __name__)

# Shopify OAuth configuration
SHOPIFY_API_KEY = os.getenv('SHOPIFY_API_KEY')
SHOPIFY_API_SECRET = os.getenv('SHOPIFY_API_SECRET')
SHOPIFY_SCOPES = os.getenv('SHOPIFY_SCOPES', 'read_products,write_products,read_orders,write_orders,read_inventory,write_inventory')
SHOPIFY_APP_URL = os.getenv('SHOPIFY_APP_URL', 'http://localhost:5000')

def generate_nonce():
    """Generate a random nonce for OAuth security"""
    import secrets
    return secrets.token_urlsafe(32)

def verify_hmac(data, hmac_header):
    """Verify HMAC signature from Shopify"""
    if not hmac_header:
        return False
    
    calculated_hmac = base64.b64encode(
        hmac.new(
            SHOPIFY_API_SECRET.encode('utf-8'),
            data,
            hashlib.sha256
        ).digest()
    ).decode('utf-8')
    
    return hmac.compare_digest(calculated_hmac, hmac_header)

def verify_webhook_hmac(data, hmac_header):
    """Verify webhook HMAC signature from Shopify"""
    if not hmac_header:
        return False
    
    calculated_hmac = base64.b64encode(
        hmac.new(
            SHOPIFY_API_SECRET.encode('utf-8'),
            data,
            hashlib.sha256
        ).digest()
    ).decode('utf-8')
    
    return hmac.compare_digest(calculated_hmac, hmac_header)

@auth_bp.route('/install')
def install():
    """Initiate Shopify OAuth flow"""
    shop = request.args.get('shop')
    
    if not shop:
        return jsonify({'error': 'Shop parameter is required'}), 400
    
    # Validate shop domain
    if not shop.endswith('.myshopify.com'):
        shop = f"{shop}.myshopify.com"
    
    # Generate nonce for security
    nonce = generate_nonce()
    session['oauth_nonce'] = nonce
    session['shop'] = shop
    
    # Build OAuth URL
    oauth_params = {
        'client_id': SHOPIFY_API_KEY,
        'scope': SHOPIFY_SCOPES,
        'redirect_uri': f"{SHOPIFY_APP_URL}/auth/callback",
        'state': nonce
    }
    
    oauth_url = f"https://{shop}/admin/oauth/authorize?{urlencode(oauth_params)}"
    
    return redirect(oauth_url)

@auth_bp.route('/callback')
def callback():
    """Handle OAuth callback from Shopify"""
    shop = session.get('shop')
    nonce = session.get('oauth_nonce')
    
    if not shop or not nonce:
        return jsonify({'error': 'Invalid session'}), 400
    
    # Verify state parameter
    state = request.args.get('state')
    if state != nonce:
        return jsonify({'error': 'Invalid state parameter'}), 400
    
    # Get authorization code
    code = request.args.get('code')
    if not code:
        return jsonify({'error': 'Authorization code not provided'}), 400
    
    # Verify HMAC
    hmac_header = request.args.get('hmac')
    query_string = request.query_string.decode('utf-8')
    
    # Remove hmac from query string for verification
    query_params = parse_qs(query_string)
    if 'hmac' in query_params:
        del query_params['hmac']
    
    sorted_params = sorted(query_params.items())
    query_string_for_verification = urlencode(sorted_params, doseq=True)
    
    if not verify_hmac(query_string_for_verification.encode('utf-8'), hmac_header):
        return jsonify({'error': 'HMAC verification failed'}), 400
    
    # Exchange code for access token
    token_url = f"https://{shop}/admin/oauth/access_token"
    token_data = {
        'client_id': SHOPIFY_API_KEY,
        'client_secret': SHOPIFY_API_SECRET,
        'code': code
    }
    
    try:
        response = requests.post(token_url, json=token_data)
        response.raise_for_status()
        token_response = response.json()
        
        access_token = token_response.get('access_token')
        scope = token_response.get('scope')
        
        if not access_token:
            return jsonify({'error': 'Failed to obtain access token'}), 400
        
        # Store shop and token in database
        existing_shop = Shop.query.filter_by(shop_domain=shop).first()
        
        if existing_shop:
            existing_shop.access_token = access_token
            existing_shop.scope = scope
            existing_shop.updated_at = datetime.utcnow()
        else:
            new_shop = Shop(
                shop_domain=shop,
                access_token=access_token,
                scope=scope
            )
            db.session.add(new_shop)
        
        db.session.commit()
        
        # Clear session
        session.pop('oauth_nonce', None)
        session.pop('shop', None)
        
        # Set shop session for the app
        session['shop_domain'] = shop
        session['access_token'] = access_token
        
        # Redirect to app main page
        return redirect(f"https://{shop}/admin/apps/{SHOPIFY_API_KEY}")
        
    except requests.RequestException as e:
        return jsonify({'error': f'Failed to exchange code for token: {str(e)}'}), 500
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Database error: {str(e)}'}), 500

@auth_bp.route('/verify')
def verify():
    """Verify current authentication status"""
    shop_domain = session.get('shop_domain')
    access_token = session.get('access_token')
    
    if not shop_domain or not access_token:
        return jsonify({'authenticated': False}), 401
    
    # Verify token is still valid by making a test API call
    headers = {
        'X-Shopify-Access-Token': access_token,
        'Content-Type': 'application/json'
    }
    
    try:
        response = requests.get(f"https://{shop_domain}/admin/api/2023-10/shop.json", headers=headers)
        
        if response.status_code == 200:
            shop_info = response.json().get('shop', {})
            return jsonify({
                'authenticated': True,
                'shop': {
                    'domain': shop_domain,
                    'name': shop_info.get('name'),
                    'email': shop_info.get('email'),
                    'currency': shop_info.get('currency'),
                    'timezone': shop_info.get('iana_timezone')
                }
            })
        else:
            # Token is invalid, clear session
            session.pop('shop_domain', None)
            session.pop('access_token', None)
            return jsonify({'authenticated': False}), 401
            
    except requests.RequestException:
        return jsonify({'authenticated': False}), 401

@auth_bp.route('/logout')
def logout():
    """Logout and clear session"""
    session.pop('shop_domain', None)
    session.pop('access_token', None)
    return jsonify({'message': 'Logged out successfully'})

def require_auth(f):
    """Decorator to require authentication for routes"""
    from functools import wraps
    
    @wraps(f)
    def decorated_function(*args, **kwargs):
        shop_domain = session.get('shop_domain')
        access_token = session.get('access_token')
        
        if not shop_domain or not access_token:
            return jsonify({'error': 'Authentication required'}), 401
        
        # Add shop info to request context
        request.shop_domain = shop_domain
        request.access_token = access_token
        
        return f(*args, **kwargs)
    
    return decorated_function

def get_shopify_headers():
    """Get headers for Shopify API requests"""
    access_token = session.get('access_token')
    if not access_token:
        return None
    
    return {
        'X-Shopify-Access-Token': access_token,
        'Content-Type': 'application/json'
    }

def make_shopify_request(endpoint, method='GET', data=None):
    """Make authenticated request to Shopify API"""
    shop_domain = session.get('shop_domain')
    headers = get_shopify_headers()
    
    if not shop_domain or not headers:
        return None
    
    url = f"https://{shop_domain}/admin/api/2023-10/{endpoint}"
    
    try:
        if method == 'GET':
            response = requests.get(url, headers=headers)
        elif method == 'POST':
            response = requests.post(url, headers=headers, json=data)
        elif method == 'PUT':
            response = requests.put(url, headers=headers, json=data)
        elif method == 'DELETE':
            response = requests.delete(url, headers=headers)
        else:
            return None
        
        response.raise_for_status()
        return response.json()
        
    except requests.RequestException as e:
        print(f"Shopify API request failed: {e}")
        return None

