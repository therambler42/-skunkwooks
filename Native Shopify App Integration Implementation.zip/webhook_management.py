from flask import Blueprint, request, jsonify, session
from src.models.shopify_models import db, Shop
from src.routes.auth import require_auth, make_shopify_request
from datetime import datetime
import json

webhook_management_bp = Blueprint('webhook_management', __name__)

# Webhook topics that the app supports
SUPPORTED_WEBHOOKS = [
    'products/create',
    'products/update', 
    'products/delete',
    'orders/create',
    'orders/updated',
    'orders/paid',
    'orders/cancelled',
    'inventory_levels/update'
]

@webhook_management_bp.route('/register', methods=['POST'])
@require_auth
def register_webhooks():
    """Register webhooks with Shopify"""
    try:
        data = request.get_json()
        webhook_url_base = data.get('webhook_url_base')
        topics = data.get('topics', SUPPORTED_WEBHOOKS)
        
        if not webhook_url_base:
            return jsonify({'error': 'Webhook URL base is required'}), 400
        
        shop_domain = session.get('shop_domain')
        shop = Shop.query.filter_by(shop_domain=shop_domain).first()
        
        if not shop:
            return jsonify({'error': 'Shop not found'}), 404
        
        results = []
        
        for topic in topics:
            if topic not in SUPPORTED_WEBHOOKS:
                results.append({
                    'topic': topic,
                    'status': 'error',
                    'message': 'Unsupported webhook topic'
                })
                continue
            
            try:
                # Create webhook URL for this topic
                webhook_url = f"{webhook_url_base}/webhooks/{topic.replace('/', '/')}"
                
                # Register webhook with Shopify
                webhook_data = {
                    'webhook': {
                        'topic': topic,
                        'address': webhook_url,
                        'format': 'json'
                    }
                }
                
                response = make_shopify_request('webhooks.json', 'POST', webhook_data)
                
                if response and 'webhook' in response:
                    webhook_info = response['webhook']
                    results.append({
                        'topic': topic,
                        'status': 'success',
                        'webhook_id': webhook_info.get('id'),
                        'address': webhook_info.get('address'),
                        'message': 'Webhook registered successfully'
                    })
                else:
                    results.append({
                        'topic': topic,
                        'status': 'error',
                        'message': 'Failed to register webhook with Shopify'
                    })
                    
            except Exception as e:
                results.append({
                    'topic': topic,
                    'status': 'error',
                    'message': f'Error registering webhook: {str(e)}'
                })
        
        return jsonify({
            'message': 'Webhook registration completed',
            'results': results,
            'total': len(topics),
            'successful': len([r for r in results if r['status'] == 'success']),
            'failed': len([r for r in results if r['status'] == 'error'])
        })
        
    except Exception as e:
        return jsonify({'error': f'Webhook registration failed: {str(e)}'}), 500

@webhook_management_bp.route('/list')
@require_auth
def list_webhooks():
    """List all registered webhooks"""
    try:
        response = make_shopify_request('webhooks.json')
        
        if response and 'webhooks' in response:
            webhooks = response['webhooks']
            
            webhook_list = []
            for webhook in webhooks:
                webhook_list.append({
                    'id': webhook.get('id'),
                    'topic': webhook.get('topic'),
                    'address': webhook.get('address'),
                    'format': webhook.get('format'),
                    'created_at': webhook.get('created_at'),
                    'updated_at': webhook.get('updated_at')
                })
            
            return jsonify({
                'webhooks': webhook_list,
                'total': len(webhook_list)
            })
        else:
            return jsonify({'error': 'Failed to fetch webhooks from Shopify'}), 500
            
    except Exception as e:
        return jsonify({'error': f'Failed to list webhooks: {str(e)}'}), 500

@webhook_management_bp.route('/<int:webhook_id>', methods=['DELETE'])
@require_auth
def delete_webhook(webhook_id):
    """Delete a specific webhook"""
    try:
        response = make_shopify_request(f'webhooks/{webhook_id}.json', 'DELETE')
        
        # Shopify returns 200 for successful deletion
        return jsonify({
            'message': f'Webhook {webhook_id} deleted successfully'
        })
        
    except Exception as e:
        return jsonify({'error': f'Failed to delete webhook: {str(e)}'}), 500

@webhook_management_bp.route('/delete-all', methods=['DELETE'])
@require_auth
def delete_all_webhooks():
    """Delete all registered webhooks"""
    try:
        # First, get all webhooks
        response = make_shopify_request('webhooks.json')
        
        if not response or 'webhooks' not in response:
            return jsonify({'error': 'Failed to fetch webhooks from Shopify'}), 500
        
        webhooks = response['webhooks']
        results = []
        
        for webhook in webhooks:
            webhook_id = webhook.get('id')
            topic = webhook.get('topic')
            
            try:
                make_shopify_request(f'webhooks/{webhook_id}.json', 'DELETE')
                results.append({
                    'webhook_id': webhook_id,
                    'topic': topic,
                    'status': 'success',
                    'message': 'Webhook deleted successfully'
                })
            except Exception as e:
                results.append({
                    'webhook_id': webhook_id,
                    'topic': topic,
                    'status': 'error',
                    'message': f'Error deleting webhook: {str(e)}'
                })
        
        return jsonify({
            'message': 'Webhook deletion completed',
            'results': results,
            'total': len(webhooks),
            'successful': len([r for r in results if r['status'] == 'success']),
            'failed': len([r for r in results if r['status'] == 'error'])
        })
        
    except Exception as e:
        return jsonify({'error': f'Failed to delete webhooks: {str(e)}'}), 500

@webhook_management_bp.route('/test', methods=['POST'])
@require_auth
def test_webhook_connectivity():
    """Test webhook connectivity and processing"""
    try:
        data = request.get_json()
        webhook_url = data.get('webhook_url')
        
        if not webhook_url:
            return jsonify({'error': 'Webhook URL is required'}), 400
        
        # Create a test webhook for products/update
        webhook_data = {
            'webhook': {
                'topic': 'products/update',
                'address': webhook_url,
                'format': 'json'
            }
        }
        
        response = make_shopify_request('webhooks.json', 'POST', webhook_data)
        
        if response and 'webhook' in response:
            webhook_info = response['webhook']
            webhook_id = webhook_info.get('id')
            
            # Clean up test webhook after a short delay
            # In a real implementation, you might want to do this asynchronously
            try:
                make_shopify_request(f'webhooks/{webhook_id}.json', 'DELETE')
            except:
                pass  # Ignore cleanup errors
            
            return jsonify({
                'status': 'success',
                'message': 'Webhook connectivity test passed',
                'test_webhook_id': webhook_id,
                'address': webhook_info.get('address')
            })
        else:
            return jsonify({
                'status': 'error',
                'message': 'Failed to create test webhook'
            }), 500
            
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': f'Webhook connectivity test failed: {str(e)}'
        }), 500

@webhook_management_bp.route('/status')
@require_auth
def get_webhook_status():
    """Get webhook status and health information"""
    try:
        # Get registered webhooks
        response = make_shopify_request('webhooks.json')
        
        if not response or 'webhooks' not in response:
            return jsonify({'error': 'Failed to fetch webhooks from Shopify'}), 500
        
        webhooks = response['webhooks']
        
        # Categorize webhooks by topic
        webhook_status = {}
        for topic in SUPPORTED_WEBHOOKS:
            webhook_status[topic] = {
                'registered': False,
                'webhook_id': None,
                'address': None,
                'created_at': None
            }
        
        for webhook in webhooks:
            topic = webhook.get('topic')
            if topic in SUPPORTED_WEBHOOKS:
                webhook_status[topic] = {
                    'registered': True,
                    'webhook_id': webhook.get('id'),
                    'address': webhook.get('address'),
                    'created_at': webhook.get('created_at')
                }
        
        # Calculate summary statistics
        total_supported = len(SUPPORTED_WEBHOOKS)
        total_registered = len([w for w in webhook_status.values() if w['registered']])
        registration_percentage = round((total_registered / total_supported * 100) if total_supported > 0 else 0, 2)
        
        return jsonify({
            'webhook_status': webhook_status,
            'summary': {
                'total_supported': total_supported,
                'total_registered': total_registered,
                'registration_percentage': registration_percentage,
                'missing_webhooks': [topic for topic, status in webhook_status.items() if not status['registered']]
            }
        })
        
    except Exception as e:
        return jsonify({'error': f'Failed to get webhook status: {str(e)}'}), 500

@webhook_management_bp.route('/supported-topics')
def get_supported_topics():
    """Get list of supported webhook topics"""
    return jsonify({
        'supported_topics': SUPPORTED_WEBHOOKS,
        'total': len(SUPPORTED_WEBHOOKS)
    })

