import os
import sys
import unittest
import json
from unittest.mock import patch, MagicMock

# Set test environment variables before importing the app
os.environ['DB_USERNAME'] = 'test'
os.environ['DB_PASSWORD'] = 'test'
os.environ['DB_HOST'] = 'localhost'
os.environ['DB_PORT'] = '3306'
os.environ['DB_NAME'] = 'test_db'
os.environ['TESTING'] = 'True'

# Add the src directory to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

# Mock the database configuration before importing
with patch.dict(os.environ, {
    'DB_USERNAME': 'test',
    'DB_PASSWORD': 'test', 
    'DB_HOST': 'localhost',
    'DB_PORT': '3306',
    'DB_NAME': 'test_db'
}):
    from main import app
    from src.models.shopify_models import db, Shop, Product, Order

class TestShopifyAppIntegration(unittest.TestCase):
    """Test suite for Shopify App Integration"""
    
    @classmethod
    def setUpClass(cls):
        """Set up test environment once for all tests"""
        app.config['TESTING'] = True
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
        app.config['WTF_CSRF_ENABLED'] = False
    
    def setUp(self):
        """Set up test environment for each test"""
        self.app = app
        self.client = self.app.test_client()
        
        with self.app.app_context():
            db.create_all()
            
            # Create test shop
            self.test_shop = Shop(
                shop_domain='test-shop.myshopify.com',
                access_token='test_token',
                scope='read_products,write_products,read_orders,write_orders',
                is_active=True
            )
            db.session.add(self.test_shop)
            db.session.commit()
    
    def tearDown(self):
        """Clean up after each test"""
        with self.app.app_context():
            db.session.remove()
            db.drop_all()
    
    def test_app_initialization(self):
        """Test that the app initializes correctly"""
        response = self.client.get('/')
        self.assertEqual(response.status_code, 200)
    
    def test_oauth_authorization_url(self):
        """Test OAuth authorization URL generation"""
        response = self.client.get('/auth/authorize?shop=test-shop.myshopify.com')
        self.assertEqual(response.status_code, 302)
        self.assertIn('shopify.com', response.location)
    
    def test_product_list_unauthorized(self):
        """Test product list without authentication"""
        response = self.client.get('/api/shopify/products')
        self.assertEqual(response.status_code, 401)
    
    def test_webhook_verification(self):
        """Test webhook HMAC verification"""
        from src.routes.auth import verify_webhook_hmac
        
        # Test with valid HMAC
        payload = b'{"test": "data"}'
        secret = 'test_secret'
        
        import hmac
        import hashlib
        import base64
        
        calculated_hmac = base64.b64encode(
            hmac.new(secret.encode(), payload, hashlib.sha256).digest()
        ).decode()
        
        with patch.dict(os.environ, {'SHOPIFY_WEBHOOK_SECRET': secret}):
            self.assertTrue(verify_webhook_hmac(payload, calculated_hmac))
            self.assertFalse(verify_webhook_hmac(payload, 'invalid_hmac'))
    
    def test_frontend_files_exist(self):
        """Test that frontend files exist"""
        frontend_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'frontend')
        
        # Check if main files exist
        self.assertTrue(os.path.exists(os.path.join(frontend_dir, 'package.json')))
        self.assertTrue(os.path.exists(os.path.join(frontend_dir, 'src', 'App.jsx')))
        self.assertTrue(os.path.exists(os.path.join(frontend_dir, 'src', 'components')))

if __name__ == '__main__':
    unittest.main()

