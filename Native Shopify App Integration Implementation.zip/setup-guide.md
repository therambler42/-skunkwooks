# Shopify App Integration - Setup and Installation Guide

## Quick Start Guide

This guide will help you set up and install the Native Shopify App Integration in your development or production environment.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Development Setup](#development-setup)
3. [Production Deployment](#production-deployment)
4. [Shopify App Configuration](#shopify-app-configuration)
5. [Environment Variables](#environment-variables)
6. [Database Setup](#database-setup)
7. [Testing](#testing)
8. [Troubleshooting](#troubleshooting)

## Prerequisites

### System Requirements

- **Operating System**: macOS, Linux, or Windows with WSL2
- **Python**: 3.8 or higher
- **Node.js**: 16.0 or higher
- **Database**: MySQL 5.7+ or PostgreSQL 12+
- **Git**: Latest version

### Shopify Requirements

- Shopify Partner account
- Development store or access to a Shopify store
- Basic understanding of Shopify APIs and webhooks

## Development Setup

### 1. Clone the Repository

```bash
git clone https://github.com/yourcompany/shopify-app-integration.git
cd shopify-app-integration
```

### 2. Backend Setup

```bash
# Navigate to backend directory
cd backend

# Create virtual environment
python3 -m venv venv

# Activate virtual environment
# On macOS/Linux:
source venv/bin/activate
# On Windows:
# venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Copy environment template
cp .env.example .env

# Edit environment variables (see Environment Variables section)
nano .env
```

### 3. Frontend Setup

```bash
# Navigate to frontend directory
cd ../frontend

# Install dependencies
npm install

# Copy environment template
cp .env.example .env

# Edit environment variables
nano .env
```

### 4. Database Setup

#### MySQL Setup

```bash
# Install MySQL (Ubuntu/Debian)
sudo apt update
sudo apt install mysql-server

# Secure MySQL installation
sudo mysql_secure_installation

# Create database
mysql -u root -p
```

```sql
CREATE DATABASE shopify_app CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'shopifyapp'@'localhost' IDENTIFIED BY 'your_password';
GRANT ALL PRIVILEGES ON shopify_app.* TO 'shopifyapp'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

#### PostgreSQL Setup (Alternative)

```bash
# Install PostgreSQL (Ubuntu/Debian)
sudo apt update
sudo apt install postgresql postgresql-contrib

# Create database and user
sudo -u postgres psql
```

```sql
CREATE DATABASE shopify_app;
CREATE USER shopifyapp WITH PASSWORD 'your_password';
GRANT ALL PRIVILEGES ON DATABASE shopify_app TO shopifyapp;
\q
```

### 5. Initialize Database

```bash
# Navigate to backend directory
cd backend
source venv/bin/activate

# Initialize database tables
python src/main.py
```

### 6. Start Development Servers

#### Backend Server

```bash
# In backend directory
cd backend
source venv/bin/activate
python src/main.py
```

The backend will be available at `http://localhost:5000`

#### Frontend Server

```bash
# In frontend directory (new terminal)
cd frontend
npm run dev
```

The frontend will be available at `http://localhost:3000`

## Shopify App Configuration

### 1. Create Shopify App

1. Log in to your [Shopify Partner Dashboard](https://partners.shopify.com/)
2. Click "Apps" in the sidebar
3. Click "Create app"
4. Choose "Public app" or "Custom app" based on your needs
5. Fill in the app details:
   - **App name**: Your app name
   - **App URL**: `https://yourdomain.com` (for production) or `https://ngrok-url.ngrok.io` (for development)
   - **Allowed redirection URL(s)**: `https://yourdomain.com/auth/callback`

### 2. Configure App Settings

#### App URLs
- **App URL**: `https://yourdomain.com`
- **Allowed redirection URL(s)**: 
  - `https://yourdomain.com/auth/callback`
  - `http://localhost:3000/auth/callback` (for development)

#### Webhooks
Configure the following webhook endpoints:
- **Products update**: `https://yourdomain.com/webhooks/products/update`
- **Products create**: `https://yourdomain.com/webhooks/products/create`
- **Products delete**: `https://yourdomain.com/webhooks/products/delete`
- **Orders create**: `https://yourdomain.com/webhooks/orders/create`
- **Orders update**: `https://yourdomain.com/webhooks/orders/update`
- **Orders paid**: `https://yourdomain.com/webhooks/orders/paid`
- **Inventory levels update**: `https://yourdomain.com/webhooks/inventory/update`

#### App Permissions
Request the following scopes:
- `read_products`
- `write_products`
- `read_orders`
- `write_orders`
- `read_inventory`
- `write_inventory`
- `read_locations`

### 3. Get API Credentials

After creating the app, note down:
- **API key**
- **API secret key**
- **Webhook secret** (found in the webhook settings)

## Environment Variables

### Backend Environment Variables (.env)

```bash
# Flask Configuration
FLASK_ENV=development
FLASK_DEBUG=True
SECRET_KEY=your-secret-key-here

# Database Configuration
DB_HOST=localhost
DB_PORT=3306
DB_NAME=shopify_app
DB_USERNAME=shopifyapp
DB_PASSWORD=your_password

# For PostgreSQL, use:
# DATABASE_URL=postgresql://shopifyapp:your_password@localhost:5432/shopify_app

# Shopify Configuration
SHOPIFY_API_KEY=your_shopify_api_key
SHOPIFY_API_SECRET=your_shopify_api_secret
SHOPIFY_WEBHOOK_SECRET=your_webhook_secret
SHOPIFY_SCOPES=read_products,write_products,read_orders,write_orders,read_inventory,write_inventory

# Application URLs
APP_URL=http://localhost:5000
FRONTEND_URL=http://localhost:3000

# Security (generate secure random strings)
JWT_SECRET_KEY=your-jwt-secret-key
```

### Frontend Environment Variables (.env)

```bash
# API Configuration
VITE_API_URL=http://localhost:5000
VITE_SHOPIFY_API_KEY=your_shopify_api_key

# App Configuration
VITE_APP_NAME=Shopify Inventory Sync
VITE_APP_VERSION=1.0.0
```

## Production Deployment

### Using Docker (Recommended)

#### 1. Build Docker Images

```bash
# Build backend image
cd backend
docker build -t shopify-app-backend .

# Build frontend image
cd ../frontend
docker build -t shopify-app-frontend .
```

#### 2. Docker Compose Setup

```yaml
# docker-compose.yml
version: '3.8'

services:
  db:
    image: mysql:8.0
    environment:
      MYSQL_ROOT_PASSWORD: rootpassword
      MYSQL_DATABASE: shopify_app
      MYSQL_USER: shopifyapp
      MYSQL_PASSWORD: password
    volumes:
      - mysql_data:/var/lib/mysql
    ports:
      - "3306:3306"

  backend:
    image: shopify-app-backend
    environment:
      - DB_HOST=db
      - DB_NAME=shopify_app
      - DB_USERNAME=shopifyapp
      - DB_PASSWORD=password
      - SHOPIFY_API_KEY=your_api_key
      - SHOPIFY_API_SECRET=your_api_secret
    depends_on:
      - db
    ports:
      - "5000:5000"

  frontend:
    image: shopify-app-frontend
    environment:
      - VITE_API_URL=http://backend:5000
    depends_on:
      - backend
    ports:
      - "3000:3000"

  nginx:
    image: nginx:alpine
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
    depends_on:
      - frontend
      - backend
    ports:
      - "80:80"
      - "443:443"

volumes:
  mysql_data:
```

#### 3. Start Services

```bash
docker-compose up -d
```

### Manual Deployment

For detailed manual deployment instructions, see the [Deployment Guide](deployment-guide.md).

## Testing

### Backend Tests

```bash
cd backend
source venv/bin/activate
python -m pytest tests/ -v
```

### Frontend Tests

```bash
cd frontend
npm test
```

### Integration Tests

```bash
# Run full test suite
cd backend
python -m pytest tests/test_integration.py -v
```

## Development Tools

### Using ngrok for Local Development

For testing webhooks locally, use ngrok to expose your local server:

```bash
# Install ngrok
npm install -g ngrok

# Expose local backend
ngrok http 5000

# Use the ngrok URL in your Shopify app settings
```

### Database Management

#### View Database

```bash
# MySQL
mysql -u shopifyapp -p shopify_app

# PostgreSQL
psql -U shopifyapp -d shopify_app
```

#### Reset Database

```bash
cd backend
source venv/bin/activate
python -c "from src.models.shopify_models import db; db.drop_all(); db.create_all()"
```

## Troubleshooting

### Common Issues

#### 1. Database Connection Error

**Error**: `OperationalError: (pymysql.err.OperationalError) (2003, "Can't connect to MySQL server")`

**Solution**:
- Ensure MySQL is running: `sudo systemctl start mysql`
- Check database credentials in `.env` file
- Verify database exists: `mysql -u root -p -e "SHOW DATABASES;"`

#### 2. Module Not Found Error

**Error**: `ModuleNotFoundError: No module named 'requests'`

**Solution**:
- Activate virtual environment: `source venv/bin/activate`
- Install dependencies: `pip install -r requirements.txt`

#### 3. Frontend Build Errors

**Error**: Icon import errors or build failures

**Solution**:
- Clear node modules: `rm -rf node_modules package-lock.json`
- Reinstall dependencies: `npm install`
- Check for version conflicts in `package.json`

#### 4. Webhook Verification Failed

**Error**: `Invalid webhook signature`

**Solution**:
- Verify webhook secret in Shopify app settings
- Ensure webhook secret matches in `.env` file
- Check webhook URL is accessible from internet

#### 5. OAuth Flow Issues

**Error**: `Invalid redirect URI`

**Solution**:
- Verify redirect URI in Shopify app settings
- Ensure URL matches exactly (including protocol)
- Check for trailing slashes

### Debug Mode

Enable debug mode for detailed error messages:

```bash
# Backend debug mode
export FLASK_DEBUG=True

# Frontend debug mode
export NODE_ENV=development
```

### Logs

#### Backend Logs

```bash
# View application logs
tail -f logs/app.log

# View Flask development server logs
python src/main.py
```

#### Frontend Logs

```bash
# View development server logs
npm run dev

# View build logs
npm run build
```

## Getting Help

### Documentation

- [API Documentation](api-documentation.md)
- [Deployment Guide](deployment-guide.md)
- [App Listing Documentation](app-listing-documentation.md)

### Support Channels

- **GitHub Issues**: Report bugs and feature requests
- **Email Support**: support@yourcompany.com
- **Documentation**: https://docs.yourapp.com
- **Community Forum**: https://community.yourapp.com

### Useful Resources

- [Shopify API Documentation](https://shopify.dev/api)
- [Shopify App Development](https://shopify.dev/apps)
- [Shopify Polaris Design System](https://polaris.shopify.com/)
- [Flask Documentation](https://flask.palletsprojects.com/)
- [React Documentation](https://reactjs.org/docs/)

---

*This setup guide is regularly updated. For the latest version and additional resources, visit our documentation portal.*

