import React from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { AppBridgeProvider } from './contexts/AppBridgeContext';
import LoginPage from './components/LoginPage';
import MainApp from './components/MainApp';
import './App.css';

function AppContent() {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return <div>Loading...</div>;
  }

  return isAuthenticated ? <MainApp /> : <LoginPage />;
}

function App() {
  return (
    <AuthProvider>
      <AppBridgeProvider>
        <AppContent />
      </AppBridgeProvider>
    </AuthProvider>
  );
}

export default App;
