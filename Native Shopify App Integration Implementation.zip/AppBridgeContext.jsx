import React, { createContext, useContext, useState, useEffect } from 'react';
import { createApp } from '@shopify/app-bridge';
import { Redirect } from '@shopify/app-bridge/actions';

const AppBridgeContext = createContext();

export const useAppBridge = () => {
  const context = useContext(AppBridgeContext);
  if (!context) {
    throw new Error('useAppBridge must be used within an AppBridgeProvider');
  }
  return context;
};

export const AppBridgeProvider = ({ children }) => {
  const [app, setApp] = useState(null);
  const [isEmbedded, setIsEmbedded] = useState(false);

  useEffect(() => {
    // Check if we're running inside Shopify admin
    const urlParams = new URLSearchParams(window.location.search);
    const shop = urlParams.get('shop');
    const embedded = urlParams.get('embedded') === '1';
    
    setIsEmbedded(embedded);

    if (embedded && shop) {
      // Initialize App Bridge
      const appBridge = createApp({
        apiKey: import.meta.env.VITE_SHOPIFY_API_KEY || 'your_api_key_here',
        shop: shop,
        forceRedirect: true
      });

      setApp(appBridge);

      // Handle authentication redirects
      const redirect = Redirect.create(appBridge);
      
      // Listen for authentication events
      appBridge.subscribe(Redirect.Action.APP, (payload) => {
        console.log('App Bridge redirect:', payload);
      });

      return () => {
        // Cleanup if needed
      };
    }
  }, []);

  const redirectToAuth = (shop) => {
    if (app) {
      const redirect = Redirect.create(app);
      redirect.dispatch(Redirect.Action.REMOTE, {
        url: `${window.location.origin}/auth/install?shop=${shop}`,
        newContext: false
      });
    } else {
      // Fallback for non-embedded mode
      window.location.href = `/auth/install?shop=${shop}`;
    }
  };

  const value = {
    app,
    isEmbedded,
    redirectToAuth
  };

  return (
    <AppBridgeContext.Provider value={value}>
      {children}
    </AppBridgeContext.Provider>
  );
};

