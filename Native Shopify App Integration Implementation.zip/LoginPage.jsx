import React from 'react';
import { AppProvider } from '@shopify/polaris';
import '@shopify/polaris/build/esm/styles.css';
import { Card, Page, Layout, Button, Text, Banner, Spinner } from '@shopify/polaris';
import { useAuth } from '../contexts/AuthContext';
import { useAppBridge } from '../contexts/AppBridgeContext';

const LoginPage = () => {
  const { isAuthenticated, loading } = useAuth();
  const { redirectToAuth } = useAppBridge();
  const [shopDomain, setShopDomain] = React.useState('');
  const [isInstalling, setIsInstalling] = React.useState(false);

  const handleInstall = async () => {
    if (!shopDomain.trim()) {
      alert('Please enter your shop domain');
      return;
    }

    setIsInstalling(true);
    
    try {
      // Clean up shop domain
      let cleanDomain = shopDomain.trim().toLowerCase();
      if (!cleanDomain.includes('.myshopify.com')) {
        cleanDomain = `${cleanDomain}.myshopify.com`;
      }
      
      redirectToAuth(cleanDomain);
    } catch (error) {
      console.error('Installation failed:', error);
      alert('Installation failed. Please try again.');
    } finally {
      setIsInstalling(false);
    }
  };

  if (loading) {
    return (
      <AppProvider i18n={{}}>
        <Page>
          <Layout>
            <Layout.Section>
              <Card>
                <div style={{ textAlign: 'center', padding: '2rem' }}>
                  <Spinner size="large" />
                  <Text variant="bodyMd" as="p" tone="subdued">
                    Checking authentication...
                  </Text>
                </div>
              </Card>
            </Layout.Section>
          </Layout>
        </Page>
      </AppProvider>
    );
  }

  if (isAuthenticated) {
    return null; // This will be handled by the main app
  }

  return (
    <AppProvider i18n={{}}>
      <Page title="Install Shopify Inventory Sync App">
        <Layout>
          <Layout.Section>
            <Banner
              title="Welcome to Inventory Sync App"
              tone="info"
            >
              <p>
                This app helps you synchronize your product inventory in real-time with your Shopify store.
                Enter your shop domain below to get started.
              </p>
            </Banner>
          </Layout.Section>
          
          <Layout.Section>
            <Card>
              <div style={{ padding: '1.5rem' }}>
                <Text variant="headingMd" as="h2">
                  Connect Your Shopify Store
                </Text>
                
                <div style={{ marginTop: '1rem', marginBottom: '1rem' }}>
                  <label htmlFor="shop-domain" style={{ display: 'block', marginBottom: '0.5rem' }}>
                    <Text variant="bodyMd" as="span">
                      Shop Domain
                    </Text>
                  </label>
                  <input
                    id="shop-domain"
                    type="text"
                    value={shopDomain}
                    onChange={(e) => setShopDomain(e.target.value)}
                    placeholder="your-shop-name"
                    style={{
                      width: '100%',
                      padding: '0.75rem',
                      border: '1px solid #d1d5db',
                      borderRadius: '0.375rem',
                      fontSize: '1rem'
                    }}
                    onKeyPress={(e) => {
                      if (e.key === 'Enter') {
                        handleInstall();
                      }
                    }}
                  />
                  <Text variant="bodySm" as="p" tone="subdued" style={{ marginTop: '0.25rem' }}>
                    Enter your shop name (e.g., "my-store" for my-store.myshopify.com)
                  </Text>
                </div>
                
                <Button
                  primary
                  onClick={handleInstall}
                  loading={isInstalling}
                  disabled={!shopDomain.trim()}
                >
                  {isInstalling ? 'Installing...' : 'Install App'}
                </Button>
              </div>
            </Card>
          </Layout.Section>
          
          <Layout.Section>
            <Card>
              <div style={{ padding: '1.5rem' }}>
                <Text variant="headingMd" as="h3">
                  Features
                </Text>
                <ul style={{ marginTop: '1rem', paddingLeft: '1.5rem' }}>
                  <li>Real-time inventory synchronization</li>
                  <li>Product catalog management</li>
                  <li>Order tracking and fulfillment</li>
                  <li>Automated stock updates via webhooks</li>
                  <li>Comprehensive admin dashboard</li>
                </ul>
              </div>
            </Card>
          </Layout.Section>
        </Layout>
      </Page>
    </AppProvider>
  );
};

export default LoginPage;

