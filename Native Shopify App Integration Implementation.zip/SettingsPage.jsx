import React, { useState, useEffect } from 'react';
import {
  Page,
  Layout,
  Card,
  Text,
  Button,
  TextField,
  Select,
  Checkbox,
  Banner,
  Divider,
  ButtonGroup
} from '@shopify/polaris';
import { SaveIcon, RefreshIcon } from '@shopify/polaris-icons';
import axios from 'axios';
import { useAuth } from '../contexts/AuthContext';

const SettingsPage = ({ showToast }) => {
  const { shop, API_BASE_URL } = useAuth();
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [settings, setSettings] = useState({
    autoSync: true,
    syncInterval: '15',
    enableWebhooks: true,
    inventoryTracking: true,
    orderNotifications: true,
    lowStockThreshold: '10',
    syncOnOrderCreate: true,
    syncOnOrderUpdate: true,
    syncOnProductUpdate: true,
    syncOnInventoryUpdate: true
  });

  const syncIntervalOptions = [
    { label: '5 minutes', value: '5' },
    { label: '15 minutes', value: '15' },
    { label: '30 minutes', value: '30' },
    { label: '1 hour', value: '60' },
    { label: '2 hours', value: '120' },
    { label: '6 hours', value: '360' },
    { label: '12 hours', value: '720' },
    { label: '24 hours', value: '1440' }
  ];

  const handleSettingChange = (key, value) => {
    setSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const saveSettings = async () => {
    try {
      setSaving(true);
      
      // In a real implementation, this would save to the backend
      // For now, we'll just simulate the save
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      showToast('Settings saved successfully');
      
    } catch (error) {
      console.error('Failed to save settings:', error);
      showToast('Failed to save settings', true);
    } finally {
      setSaving(false);
    }
  };

  const testWebhooks = async () => {
    try {
      setLoading(true);
      
      // Test webhook connectivity
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      showToast('Webhook test completed successfully');
      
    } catch (error) {
      console.error('Webhook test failed:', error);
      showToast('Webhook test failed', true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Page
      title="Settings"
      subtitle="Configure your app preferences and synchronization settings"
      primaryAction={{
        content: 'Save Settings',
        icon: SaveIcon,
        loading: saving,
        onAction: saveSettings
      }}
    >
      <Layout>
        <Layout.Section>
          <Banner
            title="App Configuration"
            tone="info"
          >
            <p>
              Configure how your app synchronizes data with Shopify. Changes will take effect immediately after saving.
            </p>
          </Banner>
        </Layout.Section>

        <Layout.Section>
          <Card>
            <div style={{ padding: '1.5rem' }}>
              <Text variant="headingMd" as="h2">
                Synchronization Settings
              </Text>
              
              <div style={{ marginTop: '1.5rem' }}>
                <Checkbox
                  label="Enable automatic synchronization"
                  checked={settings.autoSync}
                  onChange={(value) => handleSettingChange('autoSync', value)}
                  helpText="Automatically sync products and orders at regular intervals"
                />
              </div>

              <div style={{ marginTop: '1rem' }}>
                <Select
                  label="Sync interval"
                  options={syncIntervalOptions}
                  value={settings.syncInterval}
                  onChange={(value) => handleSettingChange('syncInterval', value)}
                  disabled={!settings.autoSync}
                  helpText="How often to automatically sync data"
                />
              </div>

              <div style={{ marginTop: '1rem' }}>
                <Checkbox
                  label="Enable inventory tracking"
                  checked={settings.inventoryTracking}
                  onChange={(value) => handleSettingChange('inventoryTracking', value)}
                  helpText="Track and sync inventory levels automatically"
                />
              </div>

              <div style={{ marginTop: '1rem' }}>
                <TextField
                  label="Low stock threshold"
                  type="number"
                  value={settings.lowStockThreshold}
                  onChange={(value) => handleSettingChange('lowStockThreshold', value)}
                  suffix="units"
                  helpText="Alert when inventory falls below this level"
                />
              </div>
            </div>
          </Card>
        </Layout.Section>

        <Layout.Section>
          <Card>
            <div style={{ padding: '1.5rem' }}>
              <Text variant="headingMd" as="h2">
                Webhook Settings
              </Text>
              
              <div style={{ marginTop: '1.5rem' }}>
                <Checkbox
                  label="Enable webhooks"
                  checked={settings.enableWebhooks}
                  onChange={(value) => handleSettingChange('enableWebhooks', value)}
                  helpText="Receive real-time updates from Shopify via webhooks"
                />
              </div>

              <div style={{ marginTop: '1rem' }}>
                <Text variant="headingSm" as="h3">
                  Webhook Events
                </Text>
                
                <div style={{ marginTop: '0.5rem' }}>
                  <Checkbox
                    label="Order created"
                    checked={settings.syncOnOrderCreate}
                    onChange={(value) => handleSettingChange('syncOnOrderCreate', value)}
                    disabled={!settings.enableWebhooks}
                  />
                </div>
                
                <div style={{ marginTop: '0.5rem' }}>
                  <Checkbox
                    label="Order updated"
                    checked={settings.syncOnOrderUpdate}
                    onChange={(value) => handleSettingChange('syncOnOrderUpdate', value)}
                    disabled={!settings.enableWebhooks}
                  />
                </div>
                
                <div style={{ marginTop: '0.5rem' }}>
                  <Checkbox
                    label="Product updated"
                    checked={settings.syncOnProductUpdate}
                    onChange={(value) => handleSettingChange('syncOnProductUpdate', value)}
                    disabled={!settings.enableWebhooks}
                  />
                </div>
                
                <div style={{ marginTop: '0.5rem' }}>
                  <Checkbox
                    label="Inventory updated"
                    checked={settings.syncOnInventoryUpdate}
                    onChange={(value) => handleSettingChange('syncOnInventoryUpdate', value)}
                    disabled={!settings.enableWebhooks}
                  />
                </div>
              </div>

              <div style={{ marginTop: '1.5rem' }}>
                <Button
                  onClick={testWebhooks}
                  loading={loading}
                  disabled={!settings.enableWebhooks}
                >
                  Test Webhook Connection
                </Button>
              </div>
            </div>
          </Card>
        </Layout.Section>

        <Layout.Section>
          <Card>
            <div style={{ padding: '1.5rem' }}>
              <Text variant="headingMd" as="h2">
                Notification Settings
              </Text>
              
              <div style={{ marginTop: '1.5rem' }}>
                <Checkbox
                  label="Order notifications"
                  checked={settings.orderNotifications}
                  onChange={(value) => handleSettingChange('orderNotifications', value)}
                  helpText="Receive notifications for new orders and updates"
                />
              </div>
            </div>
          </Card>
        </Layout.Section>

        <Layout.Section>
          <Card>
            <div style={{ padding: '1.5rem' }}>
              <Text variant="headingMd" as="h2">
                Connection Information
              </Text>
              
              <div style={{ marginTop: '1.5rem' }}>
                <Text variant="bodyMd" as="p">
                  <strong>Shop Domain:</strong> {shop?.domain || 'N/A'}
                </Text>
                <Text variant="bodyMd" as="p">
                  <strong>Shop Name:</strong> {shop?.name || 'N/A'}
                </Text>
                <Text variant="bodyMd" as="p">
                  <strong>Currency:</strong> {shop?.currency || 'USD'}
                </Text>
                <Text variant="bodyMd" as="p">
                  <strong>Timezone:</strong> {shop?.timezone || 'UTC'}
                </Text>
              </div>

              <Divider />

              <div style={{ marginTop: '1.5rem' }}>
                <Text variant="headingSm" as="h3">
                  App Information
                </Text>
                <Text variant="bodyMd" as="p">
                  <strong>Version:</strong> 1.0.0
                </Text>
                <Text variant="bodyMd" as="p">
                  <strong>Last Updated:</strong> {new Date().toLocaleDateString()}
                </Text>
              </div>
            </div>
          </Card>
        </Layout.Section>

        <Layout.Section>
          <Card>
            <div style={{ padding: '1.5rem' }}>
              <Text variant="headingMd" as="h2">
                Danger Zone
              </Text>
              
              <div style={{ marginTop: '1.5rem' }}>
                <Text variant="bodyMd" as="p" tone="subdued">
                  These actions cannot be undone. Please proceed with caution.
                </Text>
                
                <div style={{ marginTop: '1rem' }}>
                  <ButtonGroup>
                    <Button tone="critical" outline>
                      Reset All Settings
                    </Button>
                    <Button tone="critical" outline>
                      Clear All Data
                    </Button>
                  </ButtonGroup>
                </div>
              </div>
            </div>
          </Card>
        </Layout.Section>
      </Layout>
    </Page>
  );
};

export default SettingsPage;

