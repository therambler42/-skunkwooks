from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Shop(db.Model):
    __tablename__ = 'shops'
    
    id = db.Column(db.Integer, primary_key=True)
    shop_domain = db.Column(db.String(255), unique=True, nullable=False)
    access_token = db.Column(db.Text, nullable=False)
    scope = db.Column(db.String(500))
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())
    updated_at = db.Column(db.DateTime, default=db.func.current_timestamp(), onupdate=db.func.current_timestamp())
    
    # Relationships
    products = db.relationship('Product', backref='shop', lazy=True, cascade='all, delete-orphan')
    orders = db.relationship('Order', backref='shop', lazy=True, cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Shop {self.shop_domain}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'shop_domain': self.shop_domain,
            'scope': self.scope,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class Product(db.Model):
    __tablename__ = 'products'
    
    id = db.Column(db.Integer, primary_key=True)
    shopify_product_id = db.Column(db.BigInteger, unique=True, nullable=False)
    shop_id = db.Column(db.Integer, db.ForeignKey('shops.id'), nullable=False)
    title = db.Column(db.String(255), nullable=False)
    handle = db.Column(db.String(255))
    vendor = db.Column(db.String(255))
    product_type = db.Column(db.String(255))
    status = db.Column(db.String(50), default='active')
    inventory_quantity = db.Column(db.Integer, default=0)
    price = db.Column(db.Numeric(10, 2))
    compare_at_price = db.Column(db.Numeric(10, 2))
    sku = db.Column(db.String(255))
    barcode = db.Column(db.String(255))
    weight = db.Column(db.Numeric(8, 2))
    weight_unit = db.Column(db.String(10), default='kg')
    requires_shipping = db.Column(db.Boolean, default=True)
    taxable = db.Column(db.Boolean, default=True)
    sync_status = db.Column(db.String(50), default='pending')  # pending, synced, error
    last_synced_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())
    updated_at = db.Column(db.DateTime, default=db.func.current_timestamp(), onupdate=db.func.current_timestamp())
    
    def __repr__(self):
        return f'<Product {self.title}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'shopify_product_id': self.shopify_product_id,
            'shop_id': self.shop_id,
            'title': self.title,
            'handle': self.handle,
            'vendor': self.vendor,
            'product_type': self.product_type,
            'status': self.status,
            'inventory_quantity': self.inventory_quantity,
            'price': float(self.price) if self.price else None,
            'compare_at_price': float(self.compare_at_price) if self.compare_at_price else None,
            'sku': self.sku,
            'barcode': self.barcode,
            'weight': float(self.weight) if self.weight else None,
            'weight_unit': self.weight_unit,
            'requires_shipping': self.requires_shipping,
            'taxable': self.taxable,
            'sync_status': self.sync_status,
            'last_synced_at': self.last_synced_at.isoformat() if self.last_synced_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class Order(db.Model):
    __tablename__ = 'orders'
    
    id = db.Column(db.Integer, primary_key=True)
    shopify_order_id = db.Column(db.BigInteger, unique=True, nullable=False)
    shop_id = db.Column(db.Integer, db.ForeignKey('shops.id'), nullable=False)
    order_number = db.Column(db.String(50))
    email = db.Column(db.String(255))
    financial_status = db.Column(db.String(50))
    fulfillment_status = db.Column(db.String(50))
    total_price = db.Column(db.Numeric(10, 2))
    subtotal_price = db.Column(db.Numeric(10, 2))
    total_tax = db.Column(db.Numeric(10, 2))
    currency = db.Column(db.String(3), default='USD')
    customer_id = db.Column(db.BigInteger)
    customer_email = db.Column(db.String(255))
    customer_first_name = db.Column(db.String(255))
    customer_last_name = db.Column(db.String(255))
    processed_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())
    updated_at = db.Column(db.DateTime, default=db.func.current_timestamp(), onupdate=db.func.current_timestamp())
    
    # Relationships
    line_items = db.relationship('OrderLineItem', backref='order', lazy=True, cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Order {self.order_number}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'shopify_order_id': self.shopify_order_id,
            'shop_id': self.shop_id,
            'order_number': self.order_number,
            'email': self.email,
            'financial_status': self.financial_status,
            'fulfillment_status': self.fulfillment_status,
            'total_price': float(self.total_price) if self.total_price else None,
            'subtotal_price': float(self.subtotal_price) if self.subtotal_price else None,
            'total_tax': float(self.total_tax) if self.total_tax else None,
            'currency': self.currency,
            'customer_id': self.customer_id,
            'customer_email': self.customer_email,
            'customer_first_name': self.customer_first_name,
            'customer_last_name': self.customer_last_name,
            'processed_at': self.processed_at.isoformat() if self.processed_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'line_items': [item.to_dict() for item in self.line_items]
        }

class OrderLineItem(db.Model):
    __tablename__ = 'order_line_items'
    
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('orders.id'), nullable=False)
    shopify_line_item_id = db.Column(db.BigInteger)
    product_id = db.Column(db.BigInteger)
    variant_id = db.Column(db.BigInteger)
    title = db.Column(db.String(255))
    quantity = db.Column(db.Integer, nullable=False)
    price = db.Column(db.Numeric(10, 2))
    sku = db.Column(db.String(255))
    vendor = db.Column(db.String(255))
    product_exists = db.Column(db.Boolean, default=True)
    fulfillable_quantity = db.Column(db.Integer)
    fulfillment_service = db.Column(db.String(255))
    fulfillment_status = db.Column(db.String(50))
    requires_shipping = db.Column(db.Boolean, default=True)
    taxable = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())
    updated_at = db.Column(db.DateTime, default=db.func.current_timestamp(), onupdate=db.func.current_timestamp())
    
    def __repr__(self):
        return f'<OrderLineItem {self.title}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'order_id': self.order_id,
            'shopify_line_item_id': self.shopify_line_item_id,
            'product_id': self.product_id,
            'variant_id': self.variant_id,
            'title': self.title,
            'quantity': self.quantity,
            'price': float(self.price) if self.price else None,
            'sku': self.sku,
            'vendor': self.vendor,
            'product_exists': self.product_exists,
            'fulfillable_quantity': self.fulfillable_quantity,
            'fulfillment_service': self.fulfillment_service,
            'fulfillment_status': self.fulfillment_status,
            'requires_shipping': self.requires_shipping,
            'taxable': self.taxable,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class WebhookEvent(db.Model):
    __tablename__ = 'webhook_events'
    
    id = db.Column(db.Integer, primary_key=True)
    shop_id = db.Column(db.Integer, db.ForeignKey('shops.id'), nullable=False)
    topic = db.Column(db.String(100), nullable=False)
    shopify_webhook_id = db.Column(db.String(255))
    payload = db.Column(db.Text)
    processed = db.Column(db.Boolean, default=False)
    processing_error = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())
    processed_at = db.Column(db.DateTime)
    
    def __repr__(self):
        return f'<WebhookEvent {self.topic}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'shop_id': self.shop_id,
            'topic': self.topic,
            'shopify_webhook_id': self.shopify_webhook_id,
            'processed': self.processed,
            'processing_error': self.processing_error,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'processed_at': self.processed_at.isoformat() if self.processed_at else None
        }

class AppSettings(db.Model):
    __tablename__ = 'app_settings'
    
    id = db.Column(db.Integer, primary_key=True)
    shop_id = db.Column(db.Integer, db.ForeignKey('shops.id'), nullable=False)
    setting_key = db.Column(db.String(100), nullable=False)
    setting_value = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())
    updated_at = db.Column(db.DateTime, default=db.func.current_timestamp(), onupdate=db.func.current_timestamp())
    
    __table_args__ = (db.UniqueConstraint('shop_id', 'setting_key', name='unique_shop_setting'),)
    
    def __repr__(self):
        return f'<AppSettings {self.setting_key}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'shop_id': self.shop_id,
            'setting_key': self.setting_key,
            'setting_value': self.setting_value,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

