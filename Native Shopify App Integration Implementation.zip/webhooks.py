import os
import hmac
import hashlib
import base64
import json
from flask import Blueprint, request, jsonify
from src.models.shopify_models import db, Shop, Product, Order, OrderLineItem, WebhookEvent
from src.routes.auth import verify_webhook_hmac
from datetime import datetime
import logging

webhooks_bp = Blueprint('webhooks', __name__)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def process_webhook_event(shop_domain, topic, payload):
    """Process webhook event and update local database"""
    try:
        shop = Shop.query.filter_by(shop_domain=shop_domain).first()
        if not shop:
            logger.error(f"Shop not found: {shop_domain}")
            return False
        
        if topic == 'products/update':
            return process_product_update(shop, payload)
        elif topic == 'products/create':
            return process_product_create(shop, payload)
        elif topic == 'products/delete':
            return process_product_delete(shop, payload)
        elif topic == 'orders/create':
            return process_order_create(shop, payload)
        elif topic == 'orders/updated':
            return process_order_update(shop, payload)
        elif topic == 'orders/paid':
            return process_order_paid(shop, payload)
        elif topic == 'orders/cancelled':
            return process_order_cancelled(shop, payload)
        elif topic == 'inventory_levels/update':
            return process_inventory_update(shop, payload)
        else:
            logger.warning(f"Unhandled webhook topic: {topic}")
            return True  # Return True for unhandled topics to avoid retries
            
    except Exception as e:
        logger.error(f"Error processing webhook event: {str(e)}")
        return False

def process_product_update(shop, payload):
    """Process product update webhook"""
    try:
        product_data = payload
        shopify_product_id = product_data.get('id')
        
        if not shopify_product_id:
            logger.error("Product ID not found in webhook payload")
            return False
        
        # Find existing product
        product = Product.query.filter_by(
            shopify_product_id=shopify_product_id,
            shop_id=shop.id
        ).first()
        
        if not product:
            # Product doesn't exist locally, create it
            return process_product_create(shop, payload)
        
        # Update product with new data
        variants = product_data.get('variants', [])
        first_variant = variants[0] if variants else {}
        
        product.title = product_data.get('title', '')
        product.handle = product_data.get('handle', '')
        product.vendor = product_data.get('vendor', '')
        product.product_type = product_data.get('product_type', '')
        product.status = product_data.get('status', 'active')
        product.inventory_quantity = first_variant.get('inventory_quantity', 0)
        product.price = first_variant.get('price')
        product.compare_at_price = first_variant.get('compare_at_price')
        product.sku = first_variant.get('sku', '')
        product.barcode = first_variant.get('barcode', '')
        product.weight = first_variant.get('weight')
        product.weight_unit = first_variant.get('weight_unit', 'kg')
        product.requires_shipping = first_variant.get('requires_shipping', True)
        product.taxable = first_variant.get('taxable', True)
        product.sync_status = 'synced'
        product.last_synced_at = datetime.utcnow()
        product.updated_at = datetime.utcnow()
        
        db.session.commit()
        logger.info(f"Product updated: {product.title} (ID: {shopify_product_id})")
        return True
        
    except Exception as e:
        logger.error(f"Error processing product update: {str(e)}")
        db.session.rollback()
        return False

def process_product_create(shop, payload):
    """Process product create webhook"""
    try:
        product_data = payload
        shopify_product_id = product_data.get('id')
        
        if not shopify_product_id:
            logger.error("Product ID not found in webhook payload")
            return False
        
        # Check if product already exists
        existing_product = Product.query.filter_by(
            shopify_product_id=shopify_product_id,
            shop_id=shop.id
        ).first()
        
        if existing_product:
            logger.info(f"Product already exists: {shopify_product_id}")
            return process_product_update(shop, payload)
        
        # Create new product
        variants = product_data.get('variants', [])
        first_variant = variants[0] if variants else {}
        
        new_product = Product(
            shopify_product_id=shopify_product_id,
            shop_id=shop.id,
            title=product_data.get('title', ''),
            handle=product_data.get('handle', ''),
            vendor=product_data.get('vendor', ''),
            product_type=product_data.get('product_type', ''),
            status=product_data.get('status', 'active'),
            inventory_quantity=first_variant.get('inventory_quantity', 0),
            price=first_variant.get('price'),
            compare_at_price=first_variant.get('compare_at_price'),
            sku=first_variant.get('sku', ''),
            barcode=first_variant.get('barcode', ''),
            weight=first_variant.get('weight'),
            weight_unit=first_variant.get('weight_unit', 'kg'),
            requires_shipping=first_variant.get('requires_shipping', True),
            taxable=first_variant.get('taxable', True),
            sync_status='synced',
            last_synced_at=datetime.utcnow()
        )
        
        db.session.add(new_product)
        db.session.commit()
        logger.info(f"Product created: {new_product.title} (ID: {shopify_product_id})")
        return True
        
    except Exception as e:
        logger.error(f"Error processing product create: {str(e)}")
        db.session.rollback()
        return False

def process_product_delete(shop, payload):
    """Process product delete webhook"""
    try:
        product_data = payload
        shopify_product_id = product_data.get('id')
        
        if not shopify_product_id:
            logger.error("Product ID not found in webhook payload")
            return False
        
        # Find and delete product
        product = Product.query.filter_by(
            shopify_product_id=shopify_product_id,
            shop_id=shop.id
        ).first()
        
        if product:
            db.session.delete(product)
            db.session.commit()
            logger.info(f"Product deleted: {product.title} (ID: {shopify_product_id})")
        else:
            logger.warning(f"Product not found for deletion: {shopify_product_id}")
        
        return True
        
    except Exception as e:
        logger.error(f"Error processing product delete: {str(e)}")
        db.session.rollback()
        return False

def process_order_create(shop, payload):
    """Process order create webhook"""
    try:
        order_data = payload
        shopify_order_id = order_data.get('id')
        
        if not shopify_order_id:
            logger.error("Order ID not found in webhook payload")
            return False
        
        # Check if order already exists
        existing_order = Order.query.filter_by(
            shopify_order_id=shopify_order_id,
            shop_id=shop.id
        ).first()
        
        if existing_order:
            logger.info(f"Order already exists: {shopify_order_id}")
            return process_order_update(shop, payload)
        
        # Create new order
        new_order = Order(
            shopify_order_id=shopify_order_id,
            shop_id=shop.id,
            order_number=order_data.get('order_number'),
            email=order_data.get('email'),
            financial_status=order_data.get('financial_status'),
            fulfillment_status=order_data.get('fulfillment_status'),
            total_price=order_data.get('total_price'),
            subtotal_price=order_data.get('subtotal_price'),
            total_tax=order_data.get('total_tax'),
            currency=order_data.get('currency', 'USD')
        )
        
        # Add customer info
        customer = order_data.get('customer', {})
        if customer:
            new_order.customer_id = customer.get('id')
            new_order.customer_email = customer.get('email')
            new_order.customer_first_name = customer.get('first_name')
            new_order.customer_last_name = customer.get('last_name')
        
        # Parse processed_at
        if order_data.get('processed_at'):
            new_order.processed_at = datetime.fromisoformat(
                order_data['processed_at'].replace('Z', '+00:00')
            )
        
        db.session.add(new_order)
        db.session.flush()  # Get the order ID
        
        # Add line items and update inventory
        for line_item_data in order_data.get('line_items', []):
            line_item = OrderLineItem(
                order_id=new_order.id,
                shopify_line_item_id=line_item_data.get('id'),
                product_id=line_item_data.get('product_id'),
                variant_id=line_item_data.get('variant_id'),
                title=line_item_data.get('title'),
                quantity=line_item_data.get('quantity', 0),
                price=line_item_data.get('price'),
                sku=line_item_data.get('sku'),
                vendor=line_item_data.get('vendor'),
                product_exists=line_item_data.get('product_exists', True),
                fulfillable_quantity=line_item_data.get('fulfillable_quantity'),
                fulfillment_service=line_item_data.get('fulfillment_service'),
                fulfillment_status=line_item_data.get('fulfillment_status'),
                requires_shipping=line_item_data.get('requires_shipping', True),
                taxable=line_item_data.get('taxable', True)
            )
            db.session.add(line_item)
            
            # Update product inventory if product exists locally
            if line_item_data.get('product_id'):
                product = Product.query.filter_by(
                    shopify_product_id=line_item_data['product_id'],
                    shop_id=shop.id
                ).first()
                
                if product:
                    # Decrease inventory by ordered quantity
                    product.inventory_quantity = max(0, product.inventory_quantity - line_item.quantity)
                    product.last_synced_at = datetime.utcnow()
        
        db.session.commit()
        logger.info(f"Order created: {new_order.order_number} (ID: {shopify_order_id})")
        return True
        
    except Exception as e:
        logger.error(f"Error processing order create: {str(e)}")
        db.session.rollback()
        return False

def process_order_update(shop, payload):
    """Process order update webhook"""
    try:
        order_data = payload
        shopify_order_id = order_data.get('id')
        
        if not shopify_order_id:
            logger.error("Order ID not found in webhook payload")
            return False
        
        # Find existing order
        order = Order.query.filter_by(
            shopify_order_id=shopify_order_id,
            shop_id=shop.id
        ).first()
        
        if not order:
            # Order doesn't exist locally, create it
            return process_order_create(shop, payload)
        
        # Update order with new data
        order.order_number = order_data.get('order_number')
        order.email = order_data.get('email')
        order.financial_status = order_data.get('financial_status')
        order.fulfillment_status = order_data.get('fulfillment_status')
        order.total_price = order_data.get('total_price')
        order.subtotal_price = order_data.get('subtotal_price')
        order.total_tax = order_data.get('total_tax')
        order.currency = order_data.get('currency', 'USD')
        
        # Update customer info
        customer = order_data.get('customer', {})
        if customer:
            order.customer_id = customer.get('id')
            order.customer_email = customer.get('email')
            order.customer_first_name = customer.get('first_name')
            order.customer_last_name = customer.get('last_name')
        
        # Parse processed_at
        if order_data.get('processed_at'):
            order.processed_at = datetime.fromisoformat(
                order_data['processed_at'].replace('Z', '+00:00')
            )
        
        order.updated_at = datetime.utcnow()
        
        # Update line items (simple approach: delete and recreate)
        OrderLineItem.query.filter_by(order_id=order.id).delete()
        
        for line_item_data in order_data.get('line_items', []):
            line_item = OrderLineItem(
                order_id=order.id,
                shopify_line_item_id=line_item_data.get('id'),
                product_id=line_item_data.get('product_id'),
                variant_id=line_item_data.get('variant_id'),
                title=line_item_data.get('title'),
                quantity=line_item_data.get('quantity', 0),
                price=line_item_data.get('price'),
                sku=line_item_data.get('sku'),
                vendor=line_item_data.get('vendor'),
                product_exists=line_item_data.get('product_exists', True),
                fulfillable_quantity=line_item_data.get('fulfillable_quantity'),
                fulfillment_service=line_item_data.get('fulfillment_service'),
                fulfillment_status=line_item_data.get('fulfillment_status'),
                requires_shipping=line_item_data.get('requires_shipping', True),
                taxable=line_item_data.get('taxable', True)
            )
            db.session.add(line_item)
        
        db.session.commit()
        logger.info(f"Order updated: {order.order_number} (ID: {shopify_order_id})")
        return True
        
    except Exception as e:
        logger.error(f"Error processing order update: {str(e)}")
        db.session.rollback()
        return False

def process_order_paid(shop, payload):
    """Process order paid webhook"""
    return process_order_update(shop, payload)

def process_order_cancelled(shop, payload):
    """Process order cancelled webhook"""
    try:
        order_data = payload
        shopify_order_id = order_data.get('id')
        
        if not shopify_order_id:
            logger.error("Order ID not found in webhook payload")
            return False
        
        # Find existing order
        order = Order.query.filter_by(
            shopify_order_id=shopify_order_id,
            shop_id=shop.id
        ).first()
        
        if order:
            # Restore inventory for cancelled order
            for line_item in order.line_items:
                if line_item.product_id:
                    product = Product.query.filter_by(
                        shopify_product_id=line_item.product_id,
                        shop_id=shop.id
                    ).first()
                    
                    if product:
                        # Restore inventory
                        product.inventory_quantity += line_item.quantity
                        product.last_synced_at = datetime.utcnow()
        
        # Update order status
        result = process_order_update(shop, payload)
        
        if result:
            logger.info(f"Order cancelled and inventory restored: {order.order_number if order else shopify_order_id}")
        
        return result
        
    except Exception as e:
        logger.error(f"Error processing order cancellation: {str(e)}")
        db.session.rollback()
        return False

def process_inventory_update(shop, payload):
    """Process inventory level update webhook"""
    try:
        inventory_data = payload
        variant_id = inventory_data.get('variant_id')
        available = inventory_data.get('available')
        
        if variant_id is None or available is None:
            logger.error("Variant ID or available quantity not found in webhook payload")
            return False
        
        # Find product by variant (this is simplified - in reality you'd need variant mapping)
        # For now, we'll update based on the first variant of products
        products = Product.query.filter_by(shop_id=shop.id).all()
        
        for product in products:
            # This is a simplified approach - in a real implementation,
            # you'd need to store variant IDs and map them properly
            if product.inventory_quantity != available:
                product.inventory_quantity = available
                product.last_synced_at = datetime.utcnow()
                product.sync_status = 'synced'
                logger.info(f"Inventory updated for product {product.title}: {available}")
                break
        
        db.session.commit()
        return True
        
    except Exception as e:
        logger.error(f"Error processing inventory update: {str(e)}")
        db.session.rollback()
        return False

@webhooks_bp.route('/products/update', methods=['POST'])
def webhook_product_update():
    """Handle product update webhook"""
    try:
        # Verify webhook authenticity
        hmac_header = request.headers.get('X-Shopify-Hmac-Sha256')
        shop_domain = request.headers.get('X-Shopify-Shop-Domain')
        topic = request.headers.get('X-Shopify-Topic')
        
        if not verify_webhook_hmac(request.get_data(), hmac_header):
            logger.error("Webhook HMAC verification failed")
            return jsonify({'error': 'Unauthorized'}), 401
        
        if not shop_domain:
            logger.error("Shop domain not found in webhook headers")
            return jsonify({'error': 'Shop domain required'}), 400
        
        payload = request.get_json()
        
        # Store webhook event
        shop = Shop.query.filter_by(shop_domain=shop_domain).first()
        if shop:
            webhook_event = WebhookEvent(
                shop_id=shop.id,
                topic=topic or 'products/update',
                shopify_webhook_id=request.headers.get('X-Shopify-Webhook-Id'),
                payload=json.dumps(payload)
            )
            db.session.add(webhook_event)
            db.session.commit()
            
            # Process the webhook
            success = process_webhook_event(shop_domain, 'products/update', payload)
            
            # Update webhook event status
            webhook_event.processed = success
            if not success:
                webhook_event.processing_error = "Failed to process webhook"
            webhook_event.processed_at = datetime.utcnow()
            db.session.commit()
            
            if success:
                return jsonify({'status': 'success'}), 200
            else:
                return jsonify({'error': 'Processing failed'}), 500
        else:
            logger.error(f"Shop not found: {shop_domain}")
            return jsonify({'error': 'Shop not found'}), 404
            
    except Exception as e:
        logger.error(f"Webhook processing error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@webhooks_bp.route('/products/create', methods=['POST'])
def webhook_product_create():
    """Handle product create webhook"""
    return webhook_product_update()  # Same processing logic

@webhooks_bp.route('/products/delete', methods=['POST'])
def webhook_product_delete():
    """Handle product delete webhook"""
    return webhook_product_update()  # Same processing logic

@webhooks_bp.route('/orders/create', methods=['POST'])
def webhook_order_create():
    """Handle order create webhook"""
    return webhook_product_update()  # Same processing logic

@webhooks_bp.route('/orders/updated', methods=['POST'])
def webhook_order_update():
    """Handle order update webhook"""
    return webhook_product_update()  # Same processing logic

@webhooks_bp.route('/orders/paid', methods=['POST'])
def webhook_order_paid():
    """Handle order paid webhook"""
    return webhook_product_update()  # Same processing logic

@webhooks_bp.route('/orders/cancelled', methods=['POST'])
def webhook_order_cancelled():
    """Handle order cancelled webhook"""
    return webhook_product_update()  # Same processing logic

@webhooks_bp.route('/inventory_levels/update', methods=['POST'])
def webhook_inventory_update():
    """Handle inventory level update webhook"""
    return webhook_product_update()  # Same processing logic

@webhooks_bp.route('/events')
def get_webhook_events():
    """Get webhook events for debugging"""
    try:
        page = request.args.get('page', 1, type=int)
        limit = request.args.get('limit', 50, type=int)
        
        events_query = WebhookEvent.query.order_by(WebhookEvent.created_at.desc())
        total = events_query.count()
        
        events = events_query.offset((page - 1) * limit).limit(limit).all()
        
        return jsonify({
            'events': [event.to_dict() for event in events],
            'total': total,
            'page': page,
            'limit': limit,
            'pages': (total + limit - 1) // limit
        })
        
    except Exception as e:
        return jsonify({'error': f'Failed to get webhook events: {str(e)}'}), 500

