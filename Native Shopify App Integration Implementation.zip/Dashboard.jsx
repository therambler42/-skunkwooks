import React, { useState, useEffect } from 'react';
import {
  Page,
  Layout,
  Card,
  Text,
  Button,
  Badge,
  DataTable,
  Spinner,
  Banner,
  ButtonGroup,
  Divider
} from '@shopify/polaris';
import { RefreshIcon } from '@shopify/polaris-icons';
import axios from 'axios';
import { useAuth } from '../contexts/AuthContext';

const Dashboard = ({ showToast }) => {
  const { shop, API_BASE_URL } = useAuth();
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalProducts: 0,
    syncedProducts: 0,
    totalOrders: 0,
    recentOrders: 0
  });
  const [recentActivity, setRecentActivity] = useState([]);
  const [syncing, setSyncing] = useState(false);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      
      // Fetch products stats
      const productsResponse = await axios.get(`${API_BASE_URL}/api/shopify/products/local?limit=1`, {
        withCredentials: true
      });
      
      // Fetch orders stats
      const ordersResponse = await axios.get(`${API_BASE_URL}/api/shopify/orders/local?limit=1`, {
        withCredentials: true
      });
      
      setStats({
        totalProducts: productsResponse.data.total || 0,
        syncedProducts: productsResponse.data.total || 0,
        totalOrders: ordersResponse.data.total || 0,
        recentOrders: ordersResponse.data.total || 0
      });
      
      // Mock recent activity for now
      setRecentActivity([
        ['Product sync completed', 'Success', '2 minutes ago'],
        ['New order received', 'Info', '5 minutes ago'],
        ['Inventory updated', 'Success', '10 minutes ago'],
        ['Webhook processed', 'Success', '15 minutes ago'],
      ]);
      
    } catch (error) {
      console.error('Failed to fetch dashboard data:', error);
      showToast('Failed to load dashboard data', true);
    } finally {
      setLoading(false);
    }
  };

  const handleSync = async () => {
    try {
      setSyncing(true);
      
      // Sync products
      await axios.get(`${API_BASE_URL}/api/shopify/products`, {
        withCredentials: true
      });
      
      // Sync orders
      await axios.get(`${API_BASE_URL}/api/shopify/orders`, {
        withCredentials: true
      });
      
      showToast('Sync completed successfully');
      fetchDashboardData();
      
    } catch (error) {
      console.error('Sync failed:', error);
      showToast('Sync failed', true);
    } finally {
      setSyncing(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  if (loading) {
    return (
      <Page title="Dashboard">
        <Layout>
          <Layout.Section>
            <Card>
              <div style={{ textAlign: 'center', padding: '2rem' }}>
                <Spinner size="large" />
                <Text variant="bodyMd" as="p" tone="subdued">
                  Loading dashboard...
                </Text>
              </div>
            </Card>
          </Layout.Section>
        </Layout>
      </Page>
    );
  }

  const activityTableRows = recentActivity.map((activity, index) => [
    activity[0],
    <Badge key={index} tone={activity[1] === 'Success' ? 'success' : 'info'}>
      {activity[1]}
    </Badge>,
    activity[2]
  ]);

  return (
    <Page
      title="Dashboard"
      subtitle={`Connected to ${shop?.name || shop?.domain || 'your store'}`}
      primaryAction={{
        content: 'Sync Now',
        icon: RefreshIcon,
        loading: syncing,
        onAction: handleSync
      }}
      secondaryActions={[
        {
          content: 'Refresh',
          icon: RefreshIcon,
          onAction: fetchDashboardData
        }
      ]}
    >
      <Layout>
        <Layout.Section>
          <Banner
            title="Welcome to your Inventory Sync Dashboard"
            tone="success"
          >
            <p>
              Your app is successfully connected to {shop?.name || 'your Shopify store'}. 
              Monitor your inventory synchronization and manage your products and orders from here.
            </p>
          </Banner>
        </Layout.Section>

        <Layout.Section>
          <Layout>
            <Layout.Section variant="oneThird">
              <Card>
                <div style={{ padding: '1rem', textAlign: 'center' }}>
                  <Text variant="headingXl" as="h3">
                    {stats.totalProducts}
                  </Text>
                  <Text variant="bodyMd" as="p" tone="subdued">
                    Total Products
                  </Text>
                  <div style={{ marginTop: '0.5rem' }}>
                    <Badge tone="success">
                      {stats.syncedProducts} synced
                    </Badge>
                  </div>
                </div>
              </Card>
            </Layout.Section>

            <Layout.Section variant="oneThird">
              <Card>
                <div style={{ padding: '1rem', textAlign: 'center' }}>
                  <Text variant="headingXl" as="h3">
                    {stats.totalOrders}
                  </Text>
                  <Text variant="bodyMd" as="p" tone="subdued">
                    Total Orders
                  </Text>
                  <div style={{ marginTop: '0.5rem' }}>
                    <Badge tone="info">
                      {stats.recentOrders} recent
                    </Badge>
                  </div>
                </div>
              </Card>
            </Layout.Section>

            <Layout.Section variant="oneThird">
              <Card>
                <div style={{ padding: '1rem', textAlign: 'center' }}>
                  <Text variant="headingXl" as="h3">
                    100%
                  </Text>
                  <Text variant="bodyMd" as="p" tone="subdued">
                    Sync Status
                  </Text>
                  <div style={{ marginTop: '0.5rem' }}>
                    <Badge tone="success">
                      Active
                    </Badge>
                  </div>
                </div>
              </Card>
            </Layout.Section>
          </Layout>
        </Layout.Section>

        <Layout.Section>
          <Card>
            <div style={{ padding: '1rem' }}>
              <Text variant="headingMd" as="h2">
                Recent Activity
              </Text>
              <div style={{ marginTop: '1rem' }}>
                <DataTable
                  columnContentTypes={['text', 'text', 'text']}
                  headings={['Activity', 'Status', 'Time']}
                  rows={activityTableRows}
                />
              </div>
            </div>
          </Card>
        </Layout.Section>

        <Layout.Section>
          <Layout>
            <Layout.Section variant="oneHalf">
              <Card>
                <div style={{ padding: '1rem' }}>
                  <Text variant="headingMd" as="h3">
                    Quick Actions
                  </Text>
                  <div style={{ marginTop: '1rem' }}>
                    <ButtonGroup>
                      <Button onClick={handleSync} loading={syncing}>
                        Sync Products
                      </Button>
                      <Button onClick={handleSync} loading={syncing}>
                        Sync Orders
                      </Button>
                    </ButtonGroup>
                  </div>
                </div>
              </Card>
            </Layout.Section>

            <Layout.Section variant="oneHalf">
              <Card>
                <div style={{ padding: '1rem' }}>
                  <Text variant="headingMd" as="h3">
                    Connection Status
                  </Text>
                  <div style={{ marginTop: '1rem' }}>
                    <Text variant="bodyMd" as="p">
                      <strong>Shop:</strong> {shop?.domain}
                    </Text>
                    <Text variant="bodyMd" as="p">
                      <strong>Currency:</strong> {shop?.currency || 'USD'}
                    </Text>
                    <Text variant="bodyMd" as="p">
                      <strong>Timezone:</strong> {shop?.timezone || 'UTC'}
                    </Text>
                  </div>
                </div>
              </Card>
            </Layout.Section>
          </Layout>
        </Layout.Section>
      </Layout>
    </Page>
  );
};

export default Dashboard;

