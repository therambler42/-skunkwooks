import React, { useState, useEffect } from 'react';
import { AppProvider, Frame, Navigation, TopBar, Toast } from '@shopify/polaris';
import { 
  HomeIcon, 
  SettingsIcon
} from '@shopify/polaris-icons';
import '@shopify/polaris/build/esm/styles.css';
import { useAuth } from '../contexts/AuthContext';
import Dashboard from './Dashboard';
import ProductsPage from './ProductsPage';
import OrdersPage from './OrdersPage';
import SettingsPage from './SettingsPage';

const MainApp = () => {
  const { shop, logout } = useAuth();
  const [selectedNavItem, setSelectedNavItem] = useState('dashboard');
  const [mobileNavigationActive, setMobileNavigationActive] = useState(false);
  const [toastActive, setToastActive] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [toastError, setToastError] = useState(false);

  const showToast = (message, isError = false) => {
    setToastMessage(message);
    setToastError(isError);
    setToastActive(true);
  };

  const toggleMobileNavigationActive = () => {
    setMobileNavigationActive(!mobileNavigationActive);
  };

  const handleLogout = async () => {
    try {
      await logout();
      showToast('Logged out successfully');
    } catch (error) {
      showToast('Logout failed', true);
    }
  };

  const navigationMarkup = (
    <Navigation location="/">
      <Navigation.Section
        items={[
          {
            label: 'Dashboard',
            icon: HomeIcon,
            selected: selectedNavItem === 'dashboard',
            onClick: () => setSelectedNavItem('dashboard'),
          },
          {
            label: 'Products',
                icon: HomeIcon,
            selected: selectedNavItem === 'products',
            onClick: () => setSelectedNavItem('products'),
          },
          {
            label: 'Orders',
                icon: HomeIcon,
            selected: selectedNavItem === 'orders',
            onClick: () => setSelectedNavItem('orders'),
          },
          {
            label: 'Settings',
            icon: SettingsIcon,
            selected: selectedNavItem === 'settings',
            onClick: () => setSelectedNavItem('settings'),
          },
        ]}
      />
      <Navigation.Section
        separator
        items={[
          {
            label: 'Logout',
            icon: SettingsIcon,
            onClick: handleLogout,
          },
        ]}
      />
    </Navigation>
  );

  const topBarMarkup = (
    <TopBar
      showNavigationToggle
      onNavigationToggle={toggleMobileNavigationActive}
    />
  );

  const renderCurrentPage = () => {
    switch (selectedNavItem) {
      case 'dashboard':
        return <Dashboard showToast={showToast} />;
      case 'products':
        return <ProductsPage showToast={showToast} />;
      case 'orders':
        return <OrdersPage showToast={showToast} />;
      case 'settings':
        return <SettingsPage showToast={showToast} />;
      default:
        return <Dashboard showToast={showToast} />;
    }
  };

  const toastMarkup = toastActive ? (
    <Toast
      content={toastMessage}
      onDismiss={() => setToastActive(false)}
      error={toastError}
    />
  ) : null;

  return (
    <AppProvider
      i18n={{}}
      features={{
        newDesignLanguage: true,
      }}
    >
      <Frame
        topBar={topBarMarkup}
        navigation={navigationMarkup}
        showMobileNavigation={mobileNavigationActive}
        onNavigationDismiss={toggleMobileNavigationActive}
      >
        {renderCurrentPage()}
        {toastMarkup}
      </Frame>
    </AppProvider>
  );
};

export default MainApp;

