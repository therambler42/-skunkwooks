import os
import sys
import unittest
import json
from unittest.mock import patch, MagicMock

# Set test environment variables before importing the app
os.environ['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
os.environ['TESTING'] = 'True'

# Add the src directory to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from main import app
from src.models.shopify_models import db, Shop, Product, Order

class TestShopifyAppIntegration(unittest.TestCase):
    """Test suite for Shopify App Integration"""
    
    @classmethod
    def setUpClass(cls):
        """Set up test environment once for all tests"""
        app.config['TESTING'] = True
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
        app.config['WTF_CSRF_ENABLED'] = False
    
    def setUp(self):
        """Set up test environment for each test"""
        self.app = app
        self.client = self.app.test_client()
        
        with self.app.app_context():
            db.create_all()
            
            # Create test shop
            self.test_shop = Shop(
                shop_domain='test-shop.myshopify.com',
                access_token='test_token',
                scope='read_products,write_products,read_orders,write_orders',
                is_active=True
            )
            db.session.add(self.test_shop)
            db.session.commit()
    
    def tearDown(self):
        """Clean up after each test"""
        with self.app.app_context():
            db.session.remove()
            db.drop_all()
    
    def test_app_initialization(self):
        """Test that the app initializes correctly"""
        response = self.client.get('/')
        self.assertEqual(response.status_code, 200)
    
    def test_oauth_authorization_url(self):
        """Test OAuth authorization URL generation"""
        response = self.client.get('/auth/authorize?shop=test-shop.myshopify.com')
        self.assertEqual(response.status_code, 302)
        self.assertIn('shopify.com', response.location)
    
    @patch('src.routes.auth.make_shopify_request')
    def test_oauth_callback(self, mock_request):
        """Test OAuth callback handling"""
        # Mock Shopify's token exchange response
        mock_request.return_value = {
            'access_token': 'new_test_token',
            'scope': 'read_products,write_products'
        }
        
        response = self.client.get('/auth/callback?shop=test-shop.myshopify.com&code=test_code&hmac=test_hmac&timestamp=1234567890')
        self.assertEqual(response.status_code, 302)
    
    def test_product_list_unauthorized(self):
        """Test product list without authentication"""
        response = self.client.get('/api/shopify/products')
        self.assertEqual(response.status_code, 401)
    
    def test_product_list_authorized(self):
        """Test product list with authentication"""
        with self.client.session_transaction() as sess:
            sess['shop_domain'] = 'test-shop.myshopify.com'
            sess['access_token'] = 'test_token'
        
        with patch('src.routes.shopify.make_shopify_request') as mock_request:
            mock_request.return_value = {
                'products': [
                    {
                        'id': 123,
                        'title': 'Test Product',
                        'variants': [{'inventory_quantity': 10}]
                    }
                ]
            }
            
            response = self.client.get('/api/shopify/products')
            self.assertEqual(response.status_code, 200)
            data = json.loads(response.data)
            self.assertIn('products', data)
    
    def test_inventory_update(self):
        """Test inventory update functionality"""
        with self.app.app_context():
            # Create test product
            product = Product(
                shopify_product_id=123,
                shop_id=self.test_shop.id,
                title='Test Product',
                inventory_quantity=10,
                sync_status='synced'
            )
            db.session.add(product)
            db.session.commit()
            
            with self.client.session_transaction() as sess:
                sess['shop_domain'] = 'test-shop.myshopify.com'
                sess['access_token'] = 'test_token'
            
            with patch('src.routes.inventory.make_shopify_request') as mock_request:
                # Mock Shopify product fetch
                mock_request.side_effect = [
                    {
                        'product': {
                            'variants': [{'id': 456, 'inventory_quantity': 10}]
                        }
                    },
                    {
                        'variant': {
                            'id': 456,
                            'inventory_quantity': 15
                        }
                    }
                ]
                
                response = self.client.put(
                    f'/api/inventory/products/{product.id}/inventory',
                    json={'quantity': 15}
                )
                self.assertEqual(response.status_code, 200)
                data = json.loads(response.data)
                self.assertEqual(data['new_quantity'], 15)
    
    def test_webhook_verification(self):
        """Test webhook HMAC verification"""
        from src.routes.auth import verify_webhook_hmac
        
        # Test with valid HMAC
        payload = b'{"test": "data"}'
        secret = 'test_secret'
        
        import hmac
        import hashlib
        import base64
        
        calculated_hmac = base64.b64encode(
            hmac.new(secret.encode(), payload, hashlib.sha256).digest()
        ).decode()
        
        with patch.dict(os.environ, {'SHOPIFY_WEBHOOK_SECRET': secret}):
            self.assertTrue(verify_webhook_hmac(payload, calculated_hmac))
            self.assertFalse(verify_webhook_hmac(payload, 'invalid_hmac'))
    
    def test_webhook_product_update(self):
        """Test webhook product update processing"""
        with self.app.app_context():
            webhook_payload = {
                'id': 123,
                'title': 'Updated Product',
                'variants': [{'inventory_quantity': 20}]
            }
            
            with patch('src.routes.webhooks.verify_webhook_hmac', return_value=True):
                response = self.client.post(
                    '/webhooks/products/update',
                    json=webhook_payload,
                    headers={
                        'X-Shopify-Hmac-Sha256': 'valid_hmac',
                        'X-Shopify-Shop-Domain': 'test-shop.myshopify.com',
                        'X-Shopify-Topic': 'products/update'
                    }
                )
                self.assertEqual(response.status_code, 200)
    
    def test_order_analytics(self):
        """Test order analytics functionality"""
        with self.app.app_context():
            # Create test order
            order = Order(
                shopify_order_id=789,
                shop_id=self.test_shop.id,
                order_number='1001',
                total_price='99.99',
                financial_status='paid'
            )
            db.session.add(order)
            db.session.commit()
            
            with self.client.session_transaction() as sess:
                sess['shop_domain'] = 'test-shop.myshopify.com'
                sess['access_token'] = 'test_token'
            
            response = self.client.get('/api/orders/analytics?days=30')
            self.assertEqual(response.status_code, 200)
            data = json.loads(response.data)
            self.assertIn('summary', data)
            self.assertIn('total_orders', data['summary'])
    
    def test_webhook_management(self):
        """Test webhook management functionality"""
        with self.client.session_transaction() as sess:
            sess['shop_domain'] = 'test-shop.myshopify.com'
            sess['access_token'] = 'test_token'
        
        with patch('src.routes.webhook_management.make_shopify_request') as mock_request:
            mock_request.return_value = {
                'webhooks': [
                    {
                        'id': 123,
                        'topic': 'products/update',
                        'address': 'https://example.com/webhooks/products/update'
                    }
                ]
            }
            
            response = self.client.get('/api/webhooks/list')
            self.assertEqual(response.status_code, 200)
            data = json.loads(response.data)
            self.assertIn('webhooks', data)
    
    def test_bulk_inventory_update(self):
        """Test bulk inventory update functionality"""
        with self.app.app_context():
            # Create test products
            product1 = Product(
                shopify_product_id=123,
                shop_id=self.test_shop.id,
                title='Product 1',
                inventory_quantity=5,
                sync_status='synced'
            )
            product2 = Product(
                shopify_product_id=124,
                shop_id=self.test_shop.id,
                title='Product 2',
                inventory_quantity=8,
                sync_status='synced'
            )
            db.session.add_all([product1, product2])
            db.session.commit()
            
            with self.client.session_transaction() as sess:
                sess['shop_domain'] = 'test-shop.myshopify.com'
                sess['access_token'] = 'test_token'
            
            with patch('src.routes.inventory.make_shopify_request') as mock_request:
                # Mock responses for both products
                mock_request.side_effect = [
                    {'product': {'variants': [{'id': 456, 'inventory_quantity': 5}]}},
                    {'variant': {'id': 456, 'inventory_quantity': 15}},
                    {'product': {'variants': [{'id': 457, 'inventory_quantity': 8}]}},
                    {'variant': {'id': 457, 'inventory_quantity': 20}}
                ]
                
                updates = [
                    {'product_id': product1.id, 'quantity': 15},
                    {'product_id': product2.id, 'quantity': 20}
                ]
                
                response = self.client.put(
                    '/api/inventory/products/bulk-inventory',
                    json={'updates': updates}
                )
                self.assertEqual(response.status_code, 200)
                data = json.loads(response.data)
                self.assertEqual(data['successful'], 2)
    
    def test_product_catalog_push(self):
        """Test product catalog push functionality"""
        with self.client.session_transaction() as sess:
            sess['shop_domain'] = 'test-shop.myshopify.com'
            sess['access_token'] = 'test_token'
        
        with patch('src.routes.inventory.make_shopify_request') as mock_request:
            mock_request.return_value = {
                'product': {
                    'id': 123,
                    'title': 'New Product',
                    'handle': 'new-product',
                    'variants': [{
                        'id': 456,
                        'price': '29.99',
                        'inventory_quantity': 100
                    }]
                }
            }
            
            products_data = [{
                'title': 'New Product',
                'description': 'A great new product',
                'price': 29.99,
                'inventory_quantity': 100
            }]
            
            response = self.client.post(
                '/api/inventory/products/push',
                json={'products': products_data}
            )
            self.assertEqual(response.status_code, 200)
            data = json.loads(response.data)
            self.assertEqual(data['successful'], 1)

class TestFrontendComponents(unittest.TestCase):
    """Test suite for frontend components"""
    
    def test_frontend_build(self):
        """Test that frontend builds successfully"""
        # This would typically involve running npm build and checking for errors
        # For now, we'll just verify the main files exist
        frontend_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'frontend')
        
        # Check if main files exist
        self.assertTrue(os.path.exists(os.path.join(frontend_dir, 'package.json')))
        self.assertTrue(os.path.exists(os.path.join(frontend_dir, 'src', 'App.jsx')))
        self.assertTrue(os.path.exists(os.path.join(frontend_dir, 'src', 'components')))

if __name__ == '__main__':
    unittest.main()

