from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from src.models.equipment import db

class SparePart(db.Model):
    __tablename__ = 'spare_part'
    
    id = db.Column(db.Integer, primary_key=True)
    part_number = db.Column(db.String(100), unique=True, nullable=False)
    name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text)
    category = db.Column(db.String(100), nullable=False)
    unit_of_measure = db.Column(db.String(50), nullable=False)
    unit_cost = db.Column(db.Float, nullable=False)
    current_stock = db.Column(db.Integer, default=0)
    minimum_stock = db.Column(db.Integer, default=0)
    maximum_stock = db.Column(db.Integer, default=100)
    reorder_point = db.Column(db.Integer, default=10)
    supplier = db.Column(db.String(255))
    location = db.Column(db.String(255))  # warehouse location
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    usages = db.relationship('SparePartUsage', backref='spare_part', lazy=True, cascade='all, delete-orphan')
    equipment_parts = db.relationship('EquipmentSparePart', backref='spare_part', lazy=True, cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<SparePart {self.part_number} - {self.name}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'part_number': self.part_number,
            'name': self.name,
            'description': self.description,
            'category': self.category,
            'unit_of_measure': self.unit_of_measure,
            'unit_cost': self.unit_cost,
            'current_stock': self.current_stock,
            'minimum_stock': self.minimum_stock,
            'maximum_stock': self.maximum_stock,
            'reorder_point': self.reorder_point,
            'supplier': self.supplier,
            'location': self.location,
            'stock_status': self.get_stock_status(),
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }
    
    def get_stock_status(self):
        """Get current stock status"""
        if self.current_stock <= 0:
            return 'out_of_stock'
        elif self.current_stock <= self.reorder_point:
            return 'low_stock'
        elif self.current_stock <= self.minimum_stock:
            return 'below_minimum'
        elif self.current_stock >= self.maximum_stock:
            return 'overstocked'
        else:
            return 'normal'
    
    def needs_reorder(self):
        """Check if part needs to be reordered"""
        return self.current_stock <= self.reorder_point


class SparePartUsage(db.Model):
    __tablename__ = 'spare_part_usage'
    
    id = db.Column(db.Integer, primary_key=True)
    spare_part_id = db.Column(db.Integer, db.ForeignKey('spare_part.id'), nullable=False)
    equipment_id = db.Column(db.Integer, db.ForeignKey('equipment.id'), nullable=False)
    maintenance_schedule_id = db.Column(db.Integer, db.ForeignKey('maintenance_schedule.id'), nullable=True)
    quantity_used = db.Column(db.Integer, nullable=False)
    usage_date = db.Column(db.DateTime, default=datetime.utcnow)
    technician = db.Column(db.String(255))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<SparePartUsage {self.spare_part.part_number} - {self.quantity_used}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'spare_part_id': self.spare_part_id,
            'spare_part_name': self.spare_part.name if self.spare_part else None,
            'part_number': self.spare_part.part_number if self.spare_part else None,
            'equipment_id': self.equipment_id,
            'equipment_name': self.equipment.name if self.equipment else None,
            'maintenance_schedule_id': self.maintenance_schedule_id,
            'quantity_used': self.quantity_used,
            'usage_date': self.usage_date.isoformat(),
            'technician': self.technician,
            'notes': self.notes,
            'created_at': self.created_at.isoformat()
        }


class EquipmentSparePart(db.Model):
    __tablename__ = 'equipment_spare_part'
    
    id = db.Column(db.Integer, primary_key=True)
    equipment_id = db.Column(db.Integer, db.ForeignKey('equipment.id'), nullable=False)
    spare_part_id = db.Column(db.Integer, db.ForeignKey('spare_part.id'), nullable=False)
    recommended_quantity = db.Column(db.Integer, default=1)
    critical = db.Column(db.Boolean, default=False)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<EquipmentSparePart {self.equipment.name} - {self.spare_part.part_number}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'equipment_id': self.equipment_id,
            'equipment_name': self.equipment.name if self.equipment else None,
            'spare_part_id': self.spare_part_id,
            'spare_part_name': self.spare_part.name if self.spare_part else None,
            'part_number': self.spare_part.part_number if self.spare_part else None,
            'recommended_quantity': self.recommended_quantity,
            'critical': self.critical,
            'notes': self.notes,
            'created_at': self.created_at.isoformat()
        }

