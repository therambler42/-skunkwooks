from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from src.models.equipment import db

class Alert(db.Model):
    __tablename__ = 'alert'
    
    id = db.Column(db.Integer, primary_key=True)
    alert_type = db.Column(db.String(100), nullable=False)  # maintenance_due, low_stock, equipment_failure, etc.
    title = db.Column(db.String(255), nullable=False)
    message = db.Column(db.Text, nullable=False)
    priority = db.Column(db.String(50), default='medium')  # low, medium, high, critical
    status = db.Column(db.String(50), default='active')  # active, acknowledged, resolved, dismissed
    
    # Related entities
    equipment_id = db.Column(db.Integer, db.ForeignKey('equipment.id'), nullable=True)
    spare_part_id = db.Column(db.Integer, db.ForeignKey('spare_part.id'), nullable=True)
    maintenance_schedule_id = db.Column(db.Integer, db.ForeignKey('maintenance_schedule.id'), nullable=True)
    
    # Notification settings
    email_sent = db.Column(db.Boolean, default=False)
    email_sent_at = db.Column(db.DateTime)
    in_app_read = db.Column(db.Boolean, default=False)
    in_app_read_at = db.Column(db.DateTime)
    
    # Metadata
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    resolved_at = db.Column(db.DateTime)
    resolved_by = db.Column(db.String(255))
    
    def __repr__(self):
        return f'<Alert {self.alert_type} - {self.title}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'alert_type': self.alert_type,
            'title': self.title,
            'message': self.message,
            'priority': self.priority,
            'status': self.status,
            'equipment_id': self.equipment_id,
            'equipment_name': self.equipment.name if self.equipment else None,
            'spare_part_id': self.spare_part_id,
            'spare_part_name': self.spare_part.name if self.spare_part else None,
            'maintenance_schedule_id': self.maintenance_schedule_id,
            'email_sent': self.email_sent,
            'email_sent_at': self.email_sent_at.isoformat() if self.email_sent_at else None,
            'in_app_read': self.in_app_read,
            'in_app_read_at': self.in_app_read_at.isoformat() if self.in_app_read_at else None,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
            'resolved_at': self.resolved_at.isoformat() if self.resolved_at else None,
            'resolved_by': self.resolved_by
        }
    
    def mark_as_read(self):
        """Mark alert as read in app"""
        self.in_app_read = True
        self.in_app_read_at = datetime.utcnow()
    
    def resolve(self, resolved_by=None):
        """Mark alert as resolved"""
        self.status = 'resolved'
        self.resolved_at = datetime.utcnow()
        self.resolved_by = resolved_by
    
    def dismiss(self):
        """Dismiss alert"""
        self.status = 'dismissed'


class NotificationSettings(db.Model):
    __tablename__ = 'notification_settings'
    
    id = db.Column(db.Integer, primary_key=True)
    user_email = db.Column(db.String(255), nullable=False)
    alert_type = db.Column(db.String(100), nullable=False)
    email_enabled = db.Column(db.Boolean, default=True)
    in_app_enabled = db.Column(db.Boolean, default=True)
    priority_threshold = db.Column(db.String(50), default='medium')  # only send if priority >= threshold
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<NotificationSettings {self.user_email} - {self.alert_type}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_email': self.user_email,
            'alert_type': self.alert_type,
            'email_enabled': self.email_enabled,
            'in_app_enabled': self.in_app_enabled,
            'priority_threshold': self.priority_threshold,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }

