import pytest
import sys
import os
from datetime import datetime, date, timedelta

# Add the src directory to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from src.main import app
from src.models.equipment import db, Equipment, MaintenanceSchedule
from src.models.downtime import DowntimeLog
from src.models.spare_parts import SparePart, SparePartUsage, EquipmentSparePart
from src.models.alerts import Alert, NotificationSettings

@pytest.fixture
def client():
    """Create a test client for the Flask application."""
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    with app.test_client() as client:
        with app.app_context():
            db.create_all()
            yield client
            db.drop_all()

@pytest.fixture
def sample_data(client):
    """Create comprehensive sample data for E2E testing."""
    # Create equipment
    equipment1 = Equipment(
        name='Pump A',
        model='PA-100',
        location='Factory Floor 1',
        maintenance_interval=30,
        last_service_date=date.today() - timedelta(days=25)
    )
    
    equipment2 = Equipment(
        name='Compressor B',
        model='CB-200',
        location='Factory Floor 2',
        maintenance_interval=60,
        last_service_date=date.today() - timedelta(days=50)
    )
    
    db.session.add_all([equipment1, equipment2])
    
    # Create spare parts
    bearing = SparePart(
        part_number='BRG-001',
        name='Ball Bearing',
        category='Mechanical',
        unit_of_measure='piece',
        unit_cost=25.50,
        current_stock=15,
        minimum_stock=5,
        reorder_point=8
    )
    
    filter_part = SparePart(
        part_number='FLT-002',
        name='Air Filter',
        category='Filtration',
        unit_of_measure='piece',
        unit_cost=12.75,
        current_stock=3,  # Low stock
        minimum_stock=5,
        reorder_point=10
    )
    
    db.session.add_all([bearing, filter_part])
    db.session.commit()
    
    # Create maintenance schedules
    schedule1 = MaintenanceSchedule(
        equipment_id=equipment1.id,
        scheduled_date=date.today() + timedelta(days=5),
        maintenance_type='preventive',
        description='Routine pump maintenance',
        assigned_technician='John Doe'
    )
    
    schedule2 = MaintenanceSchedule(
        equipment_id=equipment2.id,
        scheduled_date=date.today() + timedelta(days=10),
        maintenance_type='corrective',
        description='Fix compressor leak',
        assigned_technician='Jane Smith'
    )
    
    db.session.add_all([schedule1, schedule2])
    
    # Create downtime logs
    downtime1 = DowntimeLog(
        equipment_id=equipment1.id,
        reason='Bearing failure',
        reason_type='failure',
        start_time=datetime.now() - timedelta(days=5, hours=2),
        end_time=datetime.now() - timedelta(days=5),
        impact='high',
        technician='John Doe'
    )
    
    downtime2 = DowntimeLog(
        equipment_id=equipment2.id,
        reason='Scheduled maintenance',
        reason_type='maintenance',
        start_time=datetime.now() - timedelta(days=2, hours=4),
        end_time=datetime.now() - timedelta(days=2),
        impact='low',
        technician='Jane Smith'
    )
    
    db.session.add_all([downtime1, downtime2])
    
    # Create spare part usage
    usage1 = SparePartUsage(
        spare_part_id=bearing.id,
        equipment_id=equipment1.id,
        maintenance_schedule_id=schedule1.id,
        quantity_used=2,
        technician='John Doe',
        notes='Replaced worn bearings'
    )
    
    db.session.add(usage1)
    
    # Update spare part stock
    bearing.current_stock -= 2
    
    # Create equipment-spare part links
    link1 = EquipmentSparePart(
        equipment_id=equipment1.id,
        spare_part_id=bearing.id,
        recommended_quantity=2,
        critical=True
    )
    
    link2 = EquipmentSparePart(
        equipment_id=equipment2.id,
        spare_part_id=filter_part.id,
        recommended_quantity=1,
        critical=False
    )
    
    db.session.add_all([link1, link2])
    
    # Create alerts
    alert1 = Alert(
        alert_type='maintenance_due',
        title='Maintenance Due: Pump A',
        message='Preventive maintenance is due for Pump A',
        priority='medium',
        equipment_id=equipment1.id,
        maintenance_schedule_id=schedule1.id
    )
    
    alert2 = Alert(
        alert_type='low_stock',
        title='Low Stock: Air Filter',
        message='Air Filter stock is below reorder point',
        priority='high',
        spare_part_id=filter_part.id
    )
    
    db.session.add_all([alert1, alert2])
    
    # Create notification settings
    notification1 = NotificationSettings(
        user_email='maintenance@company.com',
        alert_type='maintenance_due',
        email_enabled=True,
        in_app_enabled=True,
        priority_threshold='medium'
    )
    
    notification2 = NotificationSettings(
        user_email='inventory@company.com',
        alert_type='low_stock',
        email_enabled=True,
        in_app_enabled=True,
        priority_threshold='high'
    )
    
    db.session.add_all([notification1, notification2])
    db.session.commit()
    
    return {
        'equipment': [equipment1, equipment2],
        'spare_parts': [bearing, filter_part],
        'schedules': [schedule1, schedule2],
        'downtime': [downtime1, downtime2],
        'alerts': [alert1, alert2]
    }

class TestEquipmentWorkflow:
    """Test complete equipment management workflow."""
    
    def test_equipment_lifecycle(self, client, sample_data):
        """Test complete equipment lifecycle from creation to deletion."""
        # 1. Create new equipment
        equipment_data = {
            'name': 'Test Motor',
            'model': 'TM-300',
            'location': 'Test Area',
            'maintenance_interval': 90,
            'last_service_date': '2024-01-01'
        }
        
        response = client.post('/api/equipment/', 
                             json=equipment_data)
        assert response.status_code == 201
        equipment_id = response.json['data']['id']
        
        # 2. Verify equipment appears in list
        response = client.get('/api/equipment/')
        assert response.status_code == 200
        equipment_names = [eq['name'] for eq in response.json['data']]
        assert 'Test Motor' in equipment_names
        
        # 3. Update equipment
        update_data = {'maintenance_interval': 120}
        response = client.put(f'/api/equipment/{equipment_id}', json=update_data)
        assert response.status_code == 200
        assert response.json['data']['maintenance_interval'] == 120
        
        # 4. Check maintenance due status
        response = client.get('/api/equipment/maintenance-due')
        assert response.status_code == 200
        
        # 5. Delete equipment
        response = client.delete(f'/api/equipment/{equipment_id}')
        assert response.status_code == 200
        
        # 6. Verify equipment is deleted
        response = client.get(f'/api/equipment/{equipment_id}')
        assert response.status_code == 404

class TestMaintenanceWorkflow:
    """Test complete maintenance management workflow."""
    
    def test_maintenance_scheduling_workflow(self, client, sample_data):
        """Test maintenance scheduling from creation to completion."""
        equipment_id = sample_data['equipment'][0].id
        
        # 1. Create maintenance schedule
        schedule_data = {
            'equipment_id': equipment_id,
            'scheduled_date': (date.today() + timedelta(days=14)).isoformat(),
            'maintenance_type': 'preventive',
            'description': 'Quarterly maintenance',
            'assigned_technician': 'Bob Wilson',
            'estimated_duration': 240
        }
        
        response = client.post('/api/maintenance/schedules', json=schedule_data)
        assert response.status_code == 201
        schedule_id = response.json['data']['id']
        
        # 2. Verify schedule appears in upcoming maintenance
        response = client.get('/api/maintenance/upcoming')
        assert response.status_code == 200
        schedule_descriptions = [s['description'] for s in response.json['data']]
        assert 'Quarterly maintenance' in schedule_descriptions
        
        # 3. Update schedule status to in_progress
        update_data = {
            'status': 'in_progress',
            'notes': 'Started maintenance work'
        }
        response = client.put(f'/api/maintenance/schedules/{schedule_id}', json=update_data)
        assert response.status_code == 200
        assert response.json['data']['status'] == 'in_progress'
        
        # 4. Complete maintenance
        complete_data = {
            'status': 'completed',
            'actual_duration': 210,
            'notes': 'Maintenance completed successfully'
        }
        response = client.put(f'/api/maintenance/schedules/{schedule_id}', json=complete_data)
        assert response.status_code == 200
        assert response.json['data']['status'] == 'completed'
        
        # 5. Verify equipment last service date is updated
        response = client.get(f'/api/equipment/{equipment_id}')
        assert response.status_code == 200
        # Last service date should be updated when maintenance is completed

class TestDowntimeWorkflow:
    """Test complete downtime logging and reporting workflow."""
    
    def test_downtime_logging_and_reporting(self, client, sample_data):
        """Test downtime logging from incident to resolution."""
        equipment_id = sample_data['equipment'][0].id
        
        # 1. Log new downtime incident
        downtime_data = {
            'equipment_id': equipment_id,
            'reason': 'Motor overheating',
            'reason_type': 'failure',
            'start_time': (datetime.now() - timedelta(hours=3)).strftime('%Y-%m-%d %H:%M:%S'),
            'impact': 'critical',
            'impact_description': 'Production line stopped',
            'production_loss': 5000.0,
            'technician': 'Emergency Team'
        }
        
        response = client.post('/api/downtime/logs', json=downtime_data)
        assert response.status_code == 201
        log_id = response.json['data']['id']
        
        # 2. Verify downtime appears in ongoing incidents
        response = client.get('/api/downtime/ongoing')
        assert response.status_code == 200
        ongoing_reasons = [log['reason'] for log in response.json['data']]
        assert 'Motor overheating' in ongoing_reasons
        
        # 3. Update downtime with resolution
        resolution_data = {
            'end_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'resolution': 'Replaced faulty motor cooling fan'
        }
        response = client.put(f'/api/downtime/logs/{log_id}', json=resolution_data)
        assert response.status_code == 200
        
        # 4. Generate MTBF report
        response = client.get(f'/api/downtime/reports/mtbf?equipment_id={equipment_id}')
        assert response.status_code == 200
        assert len(response.json['data']) == 1
        assert response.json['data'][0]['equipment_id'] == equipment_id
        
        # 5. Get downtime summary
        response = client.get('/api/downtime/reports/summary')
        assert response.status_code == 200
        summary = response.json['data']
        assert summary['total_incidents'] >= 1
        assert 'reason_type_breakdown' in summary
        assert 'impact_level_breakdown' in summary

class TestSparePartsWorkflow:
    """Test complete spare parts management workflow."""
    
    def test_spare_parts_inventory_workflow(self, client, sample_data):
        """Test spare parts from creation to usage and restocking."""
        equipment_id = sample_data['equipment'][0].id
        
        # 1. Create new spare part
        part_data = {
            'part_number': 'TEST-001',
            'name': 'Test Gasket',
            'category': 'Sealing',
            'unit_of_measure': 'piece',
            'unit_cost': 8.50,
            'current_stock': 25,
            'minimum_stock': 10,
            'reorder_point': 15,
            'supplier': 'Test Supplier'
        }
        
        response = client.post('/api/spare-parts/', json=part_data)
        assert response.status_code == 201
        part_id = response.json['data']['id']
        
        # 2. Link part to equipment
        link_data = {
            'equipment_id': equipment_id,
            'spare_part_id': part_id,
            'recommended_quantity': 2,
            'critical': True
        }
        response = client.post('/api/spare-parts/equipment-parts', json=link_data)
        assert response.status_code == 201
        
        # 3. Record usage
        usage_data = {
            'spare_part_id': part_id,
            'equipment_id': equipment_id,
            'quantity_used': 12,
            'usage_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'technician': 'Test Tech',
            'notes': 'Replaced during maintenance'
        }
        response = client.post('/api/spare-parts/usage', json=usage_data)
        assert response.status_code == 201
        
        # 4. Verify stock was decremented and low stock alert created
        response = client.get(f'/api/spare-parts/{part_id}')
        assert response.status_code == 200
        assert response.json['data']['current_stock'] == 13  # 25 - 12
        
        # 5. Check low stock parts
        response = client.get('/api/spare-parts/low-stock')
        assert response.status_code == 200
        low_stock_parts = [p['part_number'] for p in response.json['data']]
        assert 'TEST-001' in low_stock_parts
        
        # 6. Restock part
        restock_data = {
            'spare_part_id': part_id,
            'quantity': 20
        }
        response = client.post('/api/spare-parts/restock', json=restock_data)
        assert response.status_code == 200
        assert response.json['data']['current_stock'] == 33  # 13 + 20

class TestAlertWorkflow:
    """Test complete alert management workflow."""
    
    def test_alert_lifecycle(self, client, sample_data):
        """Test alert from creation to resolution."""
        equipment_id = sample_data['equipment'][0].id
        
        # 1. Create alert
        alert_data = {
            'alert_type': 'equipment_failure',
            'title': 'Critical Equipment Failure',
            'message': 'Equipment has experienced a critical failure requiring immediate attention',
            'priority': 'critical',
            'equipment_id': equipment_id
        }
        
        response = client.post('/api/alerts/', json=alert_data)
        assert response.status_code == 201
        alert_id = response.json['data']['id']
        
        # 2. Verify alert appears in summary
        response = client.get('/api/alerts/summary')
        assert response.status_code == 200
        summary = response.json['data']
        assert summary['priority_breakdown']['critical'] >= 1
        
        # 3. Mark alert as read
        response = client.post(f'/api/alerts/{alert_id}/read')
        assert response.status_code == 200
        assert response.json['data']['in_app_read'] == True
        
        # 4. Resolve alert
        resolve_data = {
            'resolved_by': 'Maintenance Manager'
        }
        response = client.post(f'/api/alerts/{alert_id}/resolve', json=resolve_data)
        assert response.status_code == 200
        assert response.json['data']['status'] == 'resolved'
        
        # 5. Verify alert no longer appears in active alerts
        response = client.get('/api/alerts/?status=active')
        assert response.status_code == 200
        active_alert_ids = [a['id'] for a in response.json['data']]
        assert alert_id not in active_alert_ids

class TestIntegratedWorkflow:
    """Test integrated workflows across multiple modules."""
    
    def test_complete_maintenance_cycle(self, client, sample_data):
        """Test complete maintenance cycle with spare parts usage and alerts."""
        equipment_id = sample_data['equipment'][0].id
        spare_part_id = sample_data['spare_parts'][0].id
        
        # 1. Generate preventive maintenance schedules
        response = client.post('/api/maintenance/generate-preventive', 
                             json={'months_ahead': 3})
        assert response.status_code == 200
        
        # 2. Get upcoming maintenance
        response = client.get('/api/maintenance/upcoming')
        assert response.status_code == 200
        schedules = response.json['data']
        
        if schedules:
            schedule_id = schedules[0]['id']
            
            # 3. Start maintenance work
            response = client.put(f'/api/maintenance/schedules/{schedule_id}',
                                json={'status': 'in_progress'})
            assert response.status_code == 200
            
            # 4. Record spare part usage during maintenance
            usage_data = {
                'spare_part_id': spare_part_id,
                'equipment_id': equipment_id,
                'maintenance_schedule_id': schedule_id,
                'quantity_used': 1,
                'technician': 'Maintenance Tech'
            }
            response = client.post('/api/spare-parts/usage', json=usage_data)
            assert response.status_code == 201
            
            # 5. Complete maintenance
            response = client.put(f'/api/maintenance/schedules/{schedule_id}',
                                json={
                                    'status': 'completed',
                                    'actual_duration': 180,
                                    'notes': 'Maintenance completed with spare part replacement'
                                })
            assert response.status_code == 200
    
    def test_failure_to_resolution_workflow(self, client, sample_data):
        """Test workflow from equipment failure to resolution."""
        equipment_id = sample_data['equipment'][0].id
        
        # 1. Log equipment failure
        downtime_data = {
            'equipment_id': equipment_id,
            'reason': 'Hydraulic system failure',
            'reason_type': 'failure',
            'start_time': (datetime.now() - timedelta(hours=1)).strftime('%Y-%m-%d %H:%M:%S'),
            'impact': 'critical',
            'technician': 'Emergency Response'
        }
        response = client.post('/api/downtime/logs', json=downtime_data)
        assert response.status_code == 201
        downtime_id = response.json['data']['id']
        
        # 2. Create emergency maintenance schedule
        schedule_data = {
            'equipment_id': equipment_id,
            'scheduled_date': date.today().isoformat(),
            'maintenance_type': 'emergency',
            'description': 'Emergency repair for hydraulic failure',
            'assigned_technician': 'Emergency Team'
        }
        response = client.post('/api/maintenance/schedules', json=schedule_data)
        assert response.status_code == 201
        schedule_id = response.json['data']['id']
        
        # 3. Complete emergency maintenance
        response = client.put(f'/api/maintenance/schedules/{schedule_id}',
                            json={
                                'status': 'completed',
                                'actual_duration': 300,
                                'notes': 'Hydraulic system repaired and tested'
                            })
        assert response.status_code == 200
        
        # 4. Close downtime incident
        response = client.put(f'/api/downtime/logs/{downtime_id}',
                            json={
                                'end_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                                'resolution': 'Hydraulic system repaired, equipment operational'
                            })
        assert response.status_code == 200
        
        # 5. Verify MTBF calculation includes new failure
        response = client.get(f'/api/downtime/reports/mtbf?equipment_id={equipment_id}')
        assert response.status_code == 200
        mtbf_data = response.json['data'][0]
        assert mtbf_data['total_failures'] >= 1

class TestDataConsistency:
    """Test data consistency across the system."""
    
    def test_equipment_deletion_cascade(self, client, sample_data):
        """Test that deleting equipment properly cascades to related records."""
        equipment_id = sample_data['equipment'][0].id
        
        # Verify related records exist
        response = client.get(f'/api/maintenance/schedules?equipment_id={equipment_id}')
        assert len(response.json['data']) > 0
        
        response = client.get(f'/api/downtime/logs?equipment_id={equipment_id}')
        assert len(response.json['data']) > 0
        
        # Delete equipment
        response = client.delete(f'/api/equipment/{equipment_id}')
        assert response.status_code == 200
        
        # Verify related records are also deleted
        response = client.get(f'/api/maintenance/schedules?equipment_id={equipment_id}')
        assert len(response.json['data']) == 0
        
        response = client.get(f'/api/downtime/logs?equipment_id={equipment_id}')
        assert len(response.json['data']) == 0
    
    def test_spare_part_stock_consistency(self, client, sample_data):
        """Test that spare part stock remains consistent across operations."""
        spare_part_id = sample_data['spare_parts'][0].id
        equipment_id = sample_data['equipment'][0].id
        
        # Get initial stock
        response = client.get(f'/api/spare-parts/{spare_part_id}')
        initial_stock = response.json['data']['current_stock']
        
        # Record usage
        usage_data = {
            'spare_part_id': spare_part_id,
            'equipment_id': equipment_id,
            'quantity_used': 3
        }
        response = client.post('/api/spare-parts/usage', json=usage_data)
        assert response.status_code == 201
        
        # Verify stock decreased
        response = client.get(f'/api/spare-parts/{spare_part_id}')
        new_stock = response.json['data']['current_stock']
        assert new_stock == initial_stock - 3
        
        # Restock
        response = client.post('/api/spare-parts/restock',
                             json={'spare_part_id': spare_part_id, 'quantity': 5})
        assert response.status_code == 200
        
        # Verify stock increased
        response = client.get(f'/api/spare-parts/{spare_part_id}')
        final_stock = response.json['data']['current_stock']
        assert final_stock == new_stock + 5

