#!/usr/bin/env python3
"""
Sample data generator for CMMS module
Creates realistic test data for equipment, maintenance schedules, downtime logs, spare parts, and alerts
"""

import sys
import os
from datetime import datetime, date, timedelta
import random

# Add the src directory to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from src.main import app
from src.models.equipment import db, Equipment, MaintenanceSchedule
from src.models.downtime import DowntimeLog
from src.models.spare_parts import SparePart, SparePartUsage, EquipmentSparePart
from src.models.alerts import Alert, NotificationSettings

def create_sample_equipment():
    """Create sample equipment data."""
    equipment_data = [
        {
            'name': 'Hydraulic Press A',
            'model': 'HP-2000',
            'location': 'Production Line 1',
            'maintenance_interval': 30,
            'last_service_date': date.today() - timedelta(days=20)
        },
        {
            'name': 'CNC Machine B',
            'model': 'CNC-500X',
            'location': 'Machining Center',
            'maintenance_interval': 45,
            'last_service_date': date.today() - timedelta(days=35)
        },
        {
            'name': 'Conveyor Belt C',
            'model': 'CB-1500',
            'location': 'Assembly Line',
            'maintenance_interval': 60,
            'last_service_date': date.today() - timedelta(days=45)
        },
        {
            'name': 'Air Compressor D',
            'model': 'AC-750',
            'location': 'Utility Room',
            'maintenance_interval': 90,
            'last_service_date': date.today() - timedelta(days=75)
        },
        {
            'name': 'Packaging Machine E',
            'model': 'PM-300',
            'location': 'Packaging Area',
            'maintenance_interval': 30,
            'last_service_date': date.today() - timedelta(days=25)
        },
        {
            'name': 'Welding Robot F',
            'model': 'WR-400',
            'location': 'Welding Station',
            'maintenance_interval': 60,
            'last_service_date': date.today() - timedelta(days=50)
        },
        {
            'name': 'Cooling Tower G',
            'model': 'CT-1000',
            'location': 'Roof Level',
            'maintenance_interval': 120,
            'last_service_date': date.today() - timedelta(days=100)
        },
        {
            'name': 'Forklift H',
            'model': 'FL-25',
            'location': 'Warehouse',
            'maintenance_interval': 30,
            'last_service_date': date.today() - timedelta(days=28)
        }
    ]
    
    equipment_list = []
    for data in equipment_data:
        equipment = Equipment(**data)
        db.session.add(equipment)
        equipment_list.append(equipment)
    
    db.session.commit()
    print(f"Created {len(equipment_list)} equipment records")
    return equipment_list

def create_sample_spare_parts():
    """Create sample spare parts data."""
    spare_parts_data = [
        {
            'part_number': 'BRG-001',
            'name': 'Ball Bearing 6205',
            'category': 'Mechanical',
            'unit_of_measure': 'piece',
            'unit_cost': 25.50,
            'current_stock': 15,
            'minimum_stock': 5,
            'reorder_point': 8,
            'supplier': 'Bearing Solutions Inc.'
        },
        {
            'part_number': 'FLT-002',
            'name': 'Hydraulic Filter',
            'category': 'Filtration',
            'unit_of_measure': 'piece',
            'unit_cost': 45.75,
            'current_stock': 8,
            'minimum_stock': 3,
            'reorder_point': 5,
            'supplier': 'Filter Tech Ltd.'
        },
        {
            'part_number': 'GSK-003',
            'name': 'Rubber Gasket Set',
            'category': 'Sealing',
            'unit_of_measure': 'set',
            'unit_cost': 12.25,
            'current_stock': 25,
            'minimum_stock': 10,
            'reorder_point': 15,
            'supplier': 'Seal Masters'
        },
        {
            'part_number': 'BLT-004',
            'name': 'Drive Belt V-Type',
            'category': 'Power Transmission',
            'unit_of_measure': 'piece',
            'unit_cost': 35.00,
            'current_stock': 6,
            'minimum_stock': 4,
            'reorder_point': 8,
            'supplier': 'Belt Dynamics'
        },
        {
            'part_number': 'OIL-005',
            'name': 'Hydraulic Oil ISO 46',
            'category': 'Lubricants',
            'unit_of_measure': 'liter',
            'unit_cost': 8.50,
            'current_stock': 200,
            'minimum_stock': 50,
            'reorder_point': 100,
            'supplier': 'Lubricant Supply Co.'
        },
        {
            'part_number': 'SEN-006',
            'name': 'Proximity Sensor',
            'category': 'Electronics',
            'unit_of_measure': 'piece',
            'unit_cost': 85.00,
            'current_stock': 4,
            'minimum_stock': 2,
            'reorder_point': 6,
            'supplier': 'Sensor Technologies'
        },
        {
            'part_number': 'VAL-007',
            'name': 'Pneumatic Valve',
            'category': 'Pneumatics',
            'unit_of_measure': 'piece',
            'unit_cost': 125.00,
            'current_stock': 3,
            'minimum_stock': 2,
            'reorder_point': 4,
            'supplier': 'Pneumatic Systems Inc.'
        },
        {
            'part_number': 'WIR-008',
            'name': 'Control Cable 16AWG',
            'category': 'Electrical',
            'unit_of_measure': 'meter',
            'unit_cost': 2.75,
            'current_stock': 150,
            'minimum_stock': 50,
            'reorder_point': 100,
            'supplier': 'Electric Wire Co.'
        }
    ]
    
    spare_parts_list = []
    for data in spare_parts_data:
        part = SparePart(**data)
        db.session.add(part)
        spare_parts_list.append(part)
    
    db.session.commit()
    print(f"Created {len(spare_parts_list)} spare parts records")
    return spare_parts_list

def create_maintenance_schedules(equipment_list):
    """Create sample maintenance schedules."""
    maintenance_types = ['preventive', 'corrective', 'emergency']
    technicians = ['John Smith', 'Jane Doe', 'Mike Johnson', 'Sarah Wilson', 'Bob Anderson']
    
    schedules = []
    
    for equipment in equipment_list:
        # Create past maintenance
        for i in range(random.randint(2, 5)):
            past_date = date.today() - timedelta(days=random.randint(30, 365))
            schedule = MaintenanceSchedule(
                equipment_id=equipment.id,
                scheduled_date=past_date,
                maintenance_type=random.choice(maintenance_types),
                description=f'Routine maintenance for {equipment.name}',
                status='completed',
                assigned_technician=random.choice(technicians),
                estimated_duration=random.randint(60, 480),
                actual_duration=random.randint(60, 480),
                completed_date=datetime.combine(past_date, datetime.min.time()) + timedelta(hours=random.randint(1, 8))
            )
            schedules.append(schedule)
        
        # Create upcoming maintenance
        next_service = equipment.get_next_service_date()
        if next_service <= date.today() + timedelta(days=90):
            schedule = MaintenanceSchedule(
                equipment_id=equipment.id,
                scheduled_date=next_service,
                maintenance_type='preventive',
                description=f'Scheduled preventive maintenance for {equipment.name}',
                status='scheduled',
                assigned_technician=random.choice(technicians),
                estimated_duration=random.randint(120, 360)
            )
            schedules.append(schedule)
    
    for schedule in schedules:
        db.session.add(schedule)
    
    db.session.commit()
    print(f"Created {len(schedules)} maintenance schedule records")
    return schedules

def create_downtime_logs(equipment_list):
    """Create sample downtime logs."""
    failure_reasons = [
        'Bearing failure', 'Motor overheating', 'Hydraulic leak', 'Belt breakage',
        'Sensor malfunction', 'Electrical fault', 'Mechanical wear', 'Lubrication issue'
    ]
    
    maintenance_reasons = [
        'Scheduled maintenance', 'Preventive service', 'Component replacement',
        'Calibration', 'Software update', 'Cleaning and inspection'
    ]
    
    impacts = ['low', 'medium', 'high', 'critical']
    technicians = ['John Smith', 'Jane Doe', 'Mike Johnson', 'Sarah Wilson', 'Bob Anderson']
    
    downtime_logs = []
    
    for equipment in equipment_list:
        # Create 3-8 downtime logs per equipment
        for i in range(random.randint(3, 8)):
            reason_type = random.choice(['failure', 'maintenance', 'setup'])
            
            if reason_type == 'failure':
                reason = random.choice(failure_reasons)
                impact = random.choice(['medium', 'high', 'critical'])
            elif reason_type == 'maintenance':
                reason = random.choice(maintenance_reasons)
                impact = random.choice(['low', 'medium'])
            else:
                reason = 'Equipment setup and configuration'
                impact = 'low'
            
            start_time = datetime.now() - timedelta(
                days=random.randint(1, 180),
                hours=random.randint(0, 23),
                minutes=random.randint(0, 59)
            )
            
            duration_hours = random.uniform(0.5, 24)
            end_time = start_time + timedelta(hours=duration_hours)
            
            log = DowntimeLog(
                equipment_id=equipment.id,
                reason=reason,
                reason_type=reason_type,
                start_time=start_time,
                end_time=end_time,
                impact=impact,
                impact_description=f'{impact.title()} impact on production',
                production_loss=random.uniform(100, 10000) if impact in ['high', 'critical'] else None,
                technician=random.choice(technicians),
                resolution=f'Resolved by {reason_type} completion'
            )
            downtime_logs.append(log)
    
    for log in downtime_logs:
        db.session.add(log)
    
    db.session.commit()
    print(f"Created {len(downtime_logs)} downtime log records")
    return downtime_logs

def create_spare_part_usage(equipment_list, spare_parts_list, schedules):
    """Create sample spare part usage records."""
    technicians = ['John Smith', 'Jane Doe', 'Mike Johnson', 'Sarah Wilson', 'Bob Anderson']
    
    usage_records = []
    
    # Create equipment-spare part relationships
    equipment_parts = []
    for equipment in equipment_list:
        # Each equipment uses 2-4 different spare parts
        used_parts = random.sample(spare_parts_list, random.randint(2, 4))
        for part in used_parts:
            link = EquipmentSparePart(
                equipment_id=equipment.id,
                spare_part_id=part.id,
                recommended_quantity=random.randint(1, 3),
                critical=random.choice([True, False])
            )
            equipment_parts.append(link)
    
    for link in equipment_parts:
        db.session.add(link)
    
    # Create usage records
    for equipment in equipment_list:
        equipment_parts_links = [ep for ep in equipment_parts if ep.equipment_id == equipment.id]
        
        for i in range(random.randint(5, 15)):
            if equipment_parts_links:
                link = random.choice(equipment_parts_links)
                part = next(p for p in spare_parts_list if p.id == link.spare_part_id)
                
                # Find a completed maintenance schedule for this equipment
                completed_schedules = [s for s in schedules if s.equipment_id == equipment.id and s.status == 'completed']
                maintenance_schedule_id = random.choice(completed_schedules).id if completed_schedules else None
                
                quantity_used = random.randint(1, link.recommended_quantity)
                
                # Only create usage if there's enough stock
                if part.current_stock >= quantity_used:
                    usage = SparePartUsage(
                        spare_part_id=part.id,
                        equipment_id=equipment.id,
                        maintenance_schedule_id=maintenance_schedule_id,
                        quantity_used=quantity_used,
                        usage_date=datetime.now() - timedelta(days=random.randint(1, 180)),
                        technician=random.choice(technicians),
                        notes=f'Used during maintenance of {equipment.name}'
                    )
                    usage_records.append(usage)
                    
                    # Update stock
                    part.current_stock -= quantity_used
    
    for usage in usage_records:
        db.session.add(usage)
    
    db.session.commit()
    print(f"Created {len(equipment_parts)} equipment-part links")
    print(f"Created {len(usage_records)} spare part usage records")
    return usage_records

def create_alerts(equipment_list, spare_parts_list):
    """Create sample alerts."""
    alerts = []
    
    # Maintenance due alerts
    for equipment in equipment_list:
        if equipment.is_maintenance_due(days_ahead=30):
            alert = Alert(
                alert_type='maintenance_due',
                title=f'Maintenance Due: {equipment.name}',
                message=f'Preventive maintenance is due for {equipment.name} in {equipment.location}',
                priority='medium' if equipment.is_maintenance_due(days_ahead=7) else 'low',
                equipment_id=equipment.id
            )
            alerts.append(alert)
    
    # Low stock alerts
    for part in spare_parts_list:
        if part.needs_reorder():
            priority = 'high' if part.current_stock <= 0 else 'medium'
            alert = Alert(
                alert_type='low_stock',
                title=f'Low Stock: {part.name}',
                message=f'Spare part {part.part_number} ({part.name}) is running low. Current stock: {part.current_stock}, Reorder point: {part.reorder_point}',
                priority=priority,
                spare_part_id=part.id
            )
            alerts.append(alert)
    
    # Equipment failure alerts (simulated)
    critical_equipment = random.sample(equipment_list, min(2, len(equipment_list)))
    for equipment in critical_equipment:
        alert = Alert(
            alert_type='equipment_failure',
            title=f'Equipment Alert: {equipment.name}',
            message=f'Unusual vibration detected in {equipment.name}. Inspection recommended.',
            priority='high',
            equipment_id=equipment.id
        )
        alerts.append(alert)
    
    for alert in alerts:
        db.session.add(alert)
    
    db.session.commit()
    print(f"Created {len(alerts)} alert records")
    return alerts

def create_notification_settings():
    """Create sample notification settings."""
    settings_data = [
        {
            'user_email': 'maintenance.manager@company.com',
            'alert_type': 'maintenance_due',
            'email_enabled': True,
            'in_app_enabled': True,
            'priority_threshold': 'medium'
        },
        {
            'user_email': 'maintenance.manager@company.com',
            'alert_type': 'equipment_failure',
            'email_enabled': True,
            'in_app_enabled': True,
            'priority_threshold': 'high'
        },
        {
            'user_email': 'inventory.manager@company.com',
            'alert_type': 'low_stock',
            'email_enabled': True,
            'in_app_enabled': True,
            'priority_threshold': 'medium'
        },
        {
            'user_email': 'operations.supervisor@company.com',
            'alert_type': 'equipment_failure',
            'email_enabled': True,
            'in_app_enabled': True,
            'priority_threshold': 'critical'
        }
    ]
    
    settings_list = []
    for data in settings_data:
        setting = NotificationSettings(**data)
        db.session.add(setting)
        settings_list.append(setting)
    
    db.session.commit()
    print(f"Created {len(settings_list)} notification settings")
    return settings_list

def main():
    """Generate all sample data."""
    print("Starting sample data generation...")
    
    with app.app_context():
        # Clear existing data
        db.drop_all()
        db.create_all()
        print("Database tables created")
        
        # Create sample data
        equipment_list = create_sample_equipment()
        spare_parts_list = create_sample_spare_parts()
        schedules = create_maintenance_schedules(equipment_list)
        downtime_logs = create_downtime_logs(equipment_list)
        usage_records = create_spare_part_usage(equipment_list, spare_parts_list, schedules)
        alerts = create_alerts(equipment_list, spare_parts_list)
        notification_settings = create_notification_settings()
        
        print("\nSample data generation completed!")
        print(f"Total records created:")
        print(f"  - Equipment: {len(equipment_list)}")
        print(f"  - Spare Parts: {len(spare_parts_list)}")
        print(f"  - Maintenance Schedules: {len(schedules)}")
        print(f"  - Downtime Logs: {len(downtime_logs)}")
        print(f"  - Spare Part Usage: {len(usage_records)}")
        print(f"  - Alerts: {len(alerts)}")
        print(f"  - Notification Settings: {len(notification_settings)}")

if __name__ == '__main__':
    main()

