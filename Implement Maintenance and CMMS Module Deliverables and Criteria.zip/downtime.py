from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from src.models.equipment import db

class DowntimeLog(db.Model):
    __tablename__ = 'downtime_log'
    
    id = db.Column(db.Integer, primary_key=True)
    equipment_id = db.Column(db.Integer, db.ForeignKey('equipment.id'), nullable=False)
    reason = db.Column(db.String(500), nullable=False)
    reason_type = db.Column(db.String(100), nullable=False)  # failure, maintenance, setup, other
    start_time = db.Column(db.DateTime, nullable=False)
    end_time = db.Column(db.DateTime, nullable=True)
    impact = db.Column(db.String(100), nullable=False)  # low, medium, high, critical
    impact_description = db.Column(db.Text)
    production_loss = db.Column(db.Float)  # units or monetary value
    technician = db.Column(db.String(255))
    resolution = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<DowntimeLog {self.equipment.name} - {self.start_time}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'equipment_id': self.equipment_id,
            'equipment_name': self.equipment.name if self.equipment else None,
            'reason': self.reason,
            'reason_type': self.reason_type,
            'start_time': self.start_time.isoformat(),
            'end_time': self.end_time.isoformat() if self.end_time else None,
            'impact': self.impact,
            'impact_description': self.impact_description,
            'production_loss': self.production_loss,
            'technician': self.technician,
            'resolution': self.resolution,
            'duration_hours': self.get_duration_hours(),
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }
    
    def get_duration_hours(self):
        """Calculate downtime duration in hours"""
        if self.end_time:
            duration = self.end_time - self.start_time
            return round(duration.total_seconds() / 3600, 2)
        else:
            # Ongoing downtime
            duration = datetime.utcnow() - self.start_time
            return round(duration.total_seconds() / 3600, 2)
    
    def is_ongoing(self):
        """Check if downtime is still ongoing"""
        return self.end_time is None

