import pytest
import json
import sys
import os
from datetime import datetime, date, timedelta

# Add the src directory to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from src.main import app
from src.models.equipment import db, Equipment, MaintenanceSchedule
from src.models.downtime import DowntimeLog
from src.models.spare_parts import SparePart, SparePartUsage, EquipmentSparePart
from src.models.alerts import Alert, NotificationSettings

@pytest.fixture
def client():
    """Create a test client for the Flask application."""
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    with app.test_client() as client:
        with app.app_context():
            db.create_all()
            yield client
            db.drop_all()

@pytest.fixture
def sample_data(client):
    """Create sample data for testing."""
    # Create equipment
    equipment = Equipment(
        name='Test Pump',
        model='TP-100',
        location='Factory Floor A',
        maintenance_interval=30,
        last_service_date=date.today() - timedelta(days=25)
    )
    db.session.add(equipment)
    
    # Create spare part
    spare_part = SparePart(
        part_number='SP-001',
        name='Test Bearing',
        category='Mechanical',
        unit_of_measure='piece',
        unit_cost=25.50,
        current_stock=10,
        minimum_stock=5,
        reorder_point=8
    )
    db.session.add(spare_part)
    
    db.session.commit()
    
    return {
        'equipment': equipment,
        'spare_part': spare_part
    }

class TestEquipmentAPI:
    """Test Equipment API endpoints."""
    
    def test_get_all_equipment(self, client, sample_data):
        """Test GET /api/equipment/"""
        response = client.get('/api/equipment/')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['success'] == True
        assert data['count'] == 1
        assert len(data['data']) == 1
        assert data['data'][0]['name'] == 'Test Pump'
    
    def test_get_equipment_by_id(self, client, sample_data):
        """Test GET /api/equipment/<id>"""
        equipment_id = sample_data['equipment'].id
        response = client.get(f'/api/equipment/{equipment_id}')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['success'] == True
        assert data['data']['name'] == 'Test Pump'
        assert 'next_service_date' in data['data']
        assert 'maintenance_due' in data['data']
    
    def test_create_equipment(self, client):
        """Test POST /api/equipment/"""
        equipment_data = {
            'name': 'New Equipment',
            'model': 'NE-001',
            'location': 'Test Location',
            'maintenance_interval': 45,
            'last_service_date': '2024-01-01'
        }
        
        response = client.post('/api/equipment/', 
                             data=json.dumps(equipment_data),
                             content_type='application/json')
        assert response.status_code == 201
        
        data = json.loads(response.data)
        assert data['success'] == True
        assert data['data']['name'] == 'New Equipment'
        assert data['data']['maintenance_interval'] == 45
    
    def test_update_equipment(self, client, sample_data):
        """Test PUT /api/equipment/<id>"""
        equipment_id = sample_data['equipment'].id
        update_data = {
            'name': 'Updated Pump',
            'maintenance_interval': 60
        }
        
        response = client.put(f'/api/equipment/{equipment_id}',
                            data=json.dumps(update_data),
                            content_type='application/json')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['success'] == True
        assert data['data']['name'] == 'Updated Pump'
        assert data['data']['maintenance_interval'] == 60
    
    def test_delete_equipment(self, client, sample_data):
        """Test DELETE /api/equipment/<id>"""
        equipment_id = sample_data['equipment'].id
        
        response = client.delete(f'/api/equipment/{equipment_id}')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['success'] == True
        
        # Verify equipment is deleted
        response = client.get(f'/api/equipment/{equipment_id}')
        assert response.status_code == 404
    
    def test_get_maintenance_due(self, client, sample_data):
        """Test GET /api/equipment/maintenance-due"""
        response = client.get('/api/equipment/maintenance-due?days_ahead=10')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['success'] == True
        # Equipment should be due for maintenance within 10 days

class TestMaintenanceAPI:
    """Test Maintenance API endpoints."""
    
    def test_get_maintenance_schedules(self, client, sample_data):
        """Test GET /api/maintenance/schedules"""
        # Create a maintenance schedule
        schedule = MaintenanceSchedule(
            equipment_id=sample_data['equipment'].id,
            scheduled_date=date.today() + timedelta(days=5),
            maintenance_type='preventive',
            description='Test maintenance'
        )
        db.session.add(schedule)
        db.session.commit()
        
        response = client.get('/api/maintenance/schedules')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['success'] == True
        assert data['count'] == 1
        assert data['data'][0]['maintenance_type'] == 'preventive'
    
    def test_create_maintenance_schedule(self, client, sample_data):
        """Test POST /api/maintenance/schedules"""
        schedule_data = {
            'equipment_id': sample_data['equipment'].id,
            'scheduled_date': (date.today() + timedelta(days=7)).isoformat(),
            'maintenance_type': 'corrective',
            'description': 'Fix pump issue',
            'assigned_technician': 'John Doe'
        }
        
        response = client.post('/api/maintenance/schedules',
                             data=json.dumps(schedule_data),
                             content_type='application/json')
        assert response.status_code == 201
        
        data = json.loads(response.data)
        assert data['success'] == True
        assert data['data']['maintenance_type'] == 'corrective'
        assert data['data']['assigned_technician'] == 'John Doe'
    
    def test_get_maintenance_calendar(self, client, sample_data):
        """Test GET /api/maintenance/calendar"""
        # Create a maintenance schedule for current month
        schedule = MaintenanceSchedule(
            equipment_id=sample_data['equipment'].id,
            scheduled_date=date.today().replace(day=15),
            maintenance_type='preventive',
            description='Monthly maintenance'
        )
        db.session.add(schedule)
        db.session.commit()
        
        current_date = date.today()
        response = client.get(f'/api/maintenance/calendar?month={current_date.month}&year={current_date.year}')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['success'] == True
        assert data['data']['month'] == current_date.month
        assert data['data']['year'] == current_date.year
    
    def test_generate_preventive_maintenance(self, client, sample_data):
        """Test POST /api/maintenance/generate-preventive"""
        generate_data = {
            'months_ahead': 3
        }
        
        response = client.post('/api/maintenance/generate-preventive',
                             data=json.dumps(generate_data),
                             content_type='application/json')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['success'] == True
        assert data['count'] >= 0  # Should generate at least some schedules

class TestDowntimeAPI:
    """Test Downtime API endpoints."""
    
    def test_get_downtime_logs(self, client, sample_data):
        """Test GET /api/downtime/logs"""
        # Create a downtime log
        log = DowntimeLog(
            equipment_id=sample_data['equipment'].id,
            reason='Pump failure',
            reason_type='failure',
            start_time=datetime.now() - timedelta(hours=2),
            end_time=datetime.now(),
            impact='high'
        )
        db.session.add(log)
        db.session.commit()
        
        response = client.get('/api/downtime/logs')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['success'] == True
        assert data['count'] == 1
        assert data['data'][0]['reason'] == 'Pump failure'
    
    def test_create_downtime_log(self, client, sample_data):
        """Test POST /api/downtime/logs"""
        log_data = {
            'equipment_id': sample_data['equipment'].id,
            'reason': 'Motor overheating',
            'reason_type': 'failure',
            'start_time': (datetime.now() - timedelta(hours=1)).strftime('%Y-%m-%d %H:%M:%S'),
            'end_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'impact': 'medium',
            'technician': 'Jane Smith'
        }
        
        response = client.post('/api/downtime/logs',
                             data=json.dumps(log_data),
                             content_type='application/json')
        assert response.status_code == 201
        
        data = json.loads(response.data)
        assert data['success'] == True
        assert data['data']['reason'] == 'Motor overheating'
        assert data['data']['technician'] == 'Jane Smith'
    
    def test_get_mtbf_report(self, client, sample_data):
        """Test GET /api/downtime/reports/mtbf"""
        # Create failure logs for MTBF calculation
        failure1 = DowntimeLog(
            equipment_id=sample_data['equipment'].id,
            reason='Bearing failure',
            reason_type='failure',
            start_time=datetime.now() - timedelta(days=10),
            end_time=datetime.now() - timedelta(days=10, hours=2),
            impact='high'
        )
        failure2 = DowntimeLog(
            equipment_id=sample_data['equipment'].id,
            reason='Motor failure',
            reason_type='failure',
            start_time=datetime.now() - timedelta(days=5),
            end_time=datetime.now() - timedelta(days=5, hours=1),
            impact='critical'
        )
        
        db.session.add_all([failure1, failure2])
        db.session.commit()
        
        response = client.get('/api/downtime/reports/mtbf')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['success'] == True
        assert len(data['data']) == 1
        assert data['data'][0]['equipment_name'] == 'Test Pump'
        assert data['data'][0]['total_failures'] == 2

class TestSparePartsAPI:
    """Test Spare Parts API endpoints."""
    
    def test_get_spare_parts(self, client, sample_data):
        """Test GET /api/spare-parts/"""
        response = client.get('/api/spare-parts/')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['success'] == True
        assert data['count'] == 1
        assert data['data'][0]['part_number'] == 'SP-001'
    
    def test_create_spare_part(self, client):
        """Test POST /api/spare-parts/"""
        part_data = {
            'part_number': 'SP-002',
            'name': 'Test Filter',
            'category': 'Filtration',
            'unit_of_measure': 'piece',
            'unit_cost': 15.75,
            'current_stock': 20,
            'reorder_point': 5
        }
        
        response = client.post('/api/spare-parts/',
                             data=json.dumps(part_data),
                             content_type='application/json')
        assert response.status_code == 201
        
        data = json.loads(response.data)
        assert data['success'] == True
        assert data['data']['part_number'] == 'SP-002'
        assert data['data']['name'] == 'Test Filter'
    
    def test_record_usage(self, client, sample_data):
        """Test POST /api/spare-parts/usage"""
        usage_data = {
            'spare_part_id': sample_data['spare_part'].id,
            'equipment_id': sample_data['equipment'].id,
            'quantity_used': 2,
            'usage_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'technician': 'Bob Wilson'
        }
        
        response = client.post('/api/spare-parts/usage',
                             data=json.dumps(usage_data),
                             content_type='application/json')
        assert response.status_code == 201
        
        data = json.loads(response.data)
        assert data['success'] == True
        assert data['data']['quantity_used'] == 2
        assert data['data']['technician'] == 'Bob Wilson'
        
        # Verify stock was decremented
        part_response = client.get(f'/api/spare-parts/{sample_data["spare_part"].id}')
        part_data = json.loads(part_response.data)
        assert part_data['data']['current_stock'] == 8  # 10 - 2
    
    def test_get_low_stock_parts(self, client, sample_data):
        """Test GET /api/spare-parts/low-stock"""
        # Update part to be low stock
        sample_data['spare_part'].current_stock = 5  # Below reorder point of 8
        db.session.commit()
        
        response = client.get('/api/spare-parts/low-stock')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['success'] == True
        assert data['count'] == 1
        assert data['data'][0]['part_number'] == 'SP-001'
    
    def test_restock_part(self, client, sample_data):
        """Test POST /api/spare-parts/restock"""
        restock_data = {
            'spare_part_id': sample_data['spare_part'].id,
            'quantity': 15
        }
        
        response = client.post('/api/spare-parts/restock',
                             data=json.dumps(restock_data),
                             content_type='application/json')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['success'] == True
        assert data['data']['current_stock'] == 25  # 10 + 15

class TestAlertsAPI:
    """Test Alerts API endpoints."""
    
    def test_get_alerts(self, client, sample_data):
        """Test GET /api/alerts/"""
        # Create an alert
        alert = Alert(
            alert_type='maintenance_due',
            title='Test Alert',
            message='Test alert message',
            priority='medium',
            equipment_id=sample_data['equipment'].id
        )
        db.session.add(alert)
        db.session.commit()
        
        response = client.get('/api/alerts/')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['success'] == True
        assert data['count'] == 1
        assert data['data'][0]['title'] == 'Test Alert'
    
    def test_create_alert(self, client, sample_data):
        """Test POST /api/alerts/"""
        alert_data = {
            'alert_type': 'equipment_failure',
            'title': 'Equipment Down',
            'message': 'Equipment has failed and needs immediate attention',
            'priority': 'critical',
            'equipment_id': sample_data['equipment'].id
        }
        
        response = client.post('/api/alerts/',
                             data=json.dumps(alert_data),
                             content_type='application/json')
        assert response.status_code == 201
        
        data = json.loads(response.data)
        assert data['success'] == True
        assert data['data']['title'] == 'Equipment Down'
        assert data['data']['priority'] == 'critical'
    
    def test_mark_alert_read(self, client, sample_data):
        """Test POST /api/alerts/<id>/read"""
        alert = Alert(
            alert_type='test',
            title='Test Alert',
            message='Test message',
            equipment_id=sample_data['equipment'].id
        )
        db.session.add(alert)
        db.session.commit()
        
        response = client.post(f'/api/alerts/{alert.id}/read')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['success'] == True
        assert data['data']['in_app_read'] == True
    
    def test_resolve_alert(self, client, sample_data):
        """Test POST /api/alerts/<id>/resolve"""
        alert = Alert(
            alert_type='test',
            title='Test Alert',
            message='Test message',
            equipment_id=sample_data['equipment'].id
        )
        db.session.add(alert)
        db.session.commit()
        
        resolve_data = {
            'resolved_by': 'Test User'
        }
        
        response = client.post(f'/api/alerts/{alert.id}/resolve',
                             data=json.dumps(resolve_data),
                             content_type='application/json')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['success'] == True
        assert data['data']['status'] == 'resolved'
        assert data['data']['resolved_by'] == 'Test User'
    
    def test_get_alert_summary(self, client, sample_data):
        """Test GET /api/alerts/summary"""
        # Create various alerts
        alerts = [
            Alert(alert_type='maintenance_due', title='Alert 1', message='Message 1', priority='high'),
            Alert(alert_type='low_stock', title='Alert 2', message='Message 2', priority='medium'),
            Alert(alert_type='equipment_failure', title='Alert 3', message='Message 3', priority='critical')
        ]
        
        for alert in alerts:
            db.session.add(alert)
        db.session.commit()
        
        response = client.get('/api/alerts/summary')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['success'] == True
        assert data['data']['total_active'] == 3
        assert data['data']['priority_breakdown']['critical'] == 1
        assert data['data']['priority_breakdown']['high'] == 1
        assert data['data']['priority_breakdown']['medium'] == 1

class TestNotificationSettingsAPI:
    """Test Notification Settings API endpoints."""
    
    def test_create_notification_setting(self, client):
        """Test POST /api/alerts/notifications/settings"""
        setting_data = {
            'user_email': 'test@example.com',
            'alert_type': 'maintenance_due',
            'email_enabled': True,
            'in_app_enabled': True,
            'priority_threshold': 'medium'
        }
        
        response = client.post('/api/alerts/notifications/settings',
                             data=json.dumps(setting_data),
                             content_type='application/json')
        assert response.status_code == 201
        
        data = json.loads(response.data)
        assert data['success'] == True
        assert data['data']['user_email'] == 'test@example.com'
        assert data['data']['alert_type'] == 'maintenance_due'
    
    def test_get_notification_settings(self, client):
        """Test GET /api/alerts/notifications/settings"""
        # Create a notification setting
        setting = NotificationSettings(
            user_email='test@example.com',
            alert_type='low_stock',
            email_enabled=False,
            in_app_enabled=True
        )
        db.session.add(setting)
        db.session.commit()
        
        response = client.get('/api/alerts/notifications/settings?user_email=test@example.com')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['success'] == True
        assert len(data['data']) == 1
        assert data['data'][0]['alert_type'] == 'low_stock'

