from flask import Blueprint, request, jsonify
from datetime import datetime, date, timedelta
from src.models.equipment import db, Equipment, MaintenanceSchedule
from src.models.alerts import Alert
from sqlalchemy import and_, or_
import calendar

maintenance_bp = Blueprint('maintenance', __name__)

@maintenance_bp.route('/schedules', methods=['GET'])
def get_maintenance_schedules():
    """Get maintenance schedules with optional filtering"""
    try:
        # Query parameters
        equipment_id = request.args.get('equipment_id', type=int)
        status = request.args.get('status')
        maintenance_type = request.args.get('maintenance_type')
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        query = MaintenanceSchedule.query
        
        # Apply filters
        if equipment_id:
            query = query.filter(MaintenanceSchedule.equipment_id == equipment_id)
        if status:
            query = query.filter(MaintenanceSchedule.status == status)
        if maintenance_type:
            query = query.filter(MaintenanceSchedule.maintenance_type == maintenance_type)
        if start_date:
            start_dt = datetime.strptime(start_date, '%Y-%m-%d').date()
            query = query.filter(MaintenanceSchedule.scheduled_date >= start_dt)
        if end_date:
            end_dt = datetime.strptime(end_date, '%Y-%m-%d').date()
            query = query.filter(MaintenanceSchedule.scheduled_date <= end_dt)
        
        schedules = query.order_by(MaintenanceSchedule.scheduled_date).all()
        
        return jsonify({
            'success': True,
            'data': [schedule.to_dict() for schedule in schedules],
            'count': len(schedules)
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@maintenance_bp.route('/schedules/<int:schedule_id>', methods=['GET'])
def get_maintenance_schedule(schedule_id):
    """Get specific maintenance schedule by ID"""
    try:
        schedule = MaintenanceSchedule.query.get_or_404(schedule_id)
        return jsonify({
            'success': True,
            'data': schedule.to_dict()
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@maintenance_bp.route('/schedules', methods=['POST'])
def create_maintenance_schedule():
    """Create new maintenance schedule"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['equipment_id', 'scheduled_date', 'maintenance_type']
        for field in required_fields:
            if field not in data:
                return jsonify({'success': False, 'error': f'Missing required field: {field}'}), 400
        
        # Verify equipment exists
        equipment = Equipment.query.get(data['equipment_id'])
        if not equipment:
            return jsonify({'success': False, 'error': 'Equipment not found'}), 404
        
        # Create new maintenance schedule
        schedule = MaintenanceSchedule(
            equipment_id=data['equipment_id'],
            scheduled_date=datetime.strptime(data['scheduled_date'], '%Y-%m-%d').date(),
            maintenance_type=data['maintenance_type'],
            description=data.get('description', ''),
            assigned_technician=data.get('assigned_technician'),
            estimated_duration=data.get('estimated_duration')
        )
        
        db.session.add(schedule)
        db.session.commit()
        
        # Create alert for new maintenance schedule
        _create_maintenance_alert(schedule)
        
        return jsonify({
            'success': True,
            'data': schedule.to_dict(),
            'message': 'Maintenance schedule created successfully'
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@maintenance_bp.route('/schedules/<int:schedule_id>', methods=['PUT'])
def update_maintenance_schedule(schedule_id):
    """Update existing maintenance schedule"""
    try:
        schedule = MaintenanceSchedule.query.get_or_404(schedule_id)
        data = request.get_json()
        
        # Update fields
        if 'scheduled_date' in data:
            schedule.scheduled_date = datetime.strptime(data['scheduled_date'], '%Y-%m-%d').date()
        if 'maintenance_type' in data:
            schedule.maintenance_type = data['maintenance_type']
        if 'description' in data:
            schedule.description = data['description']
        if 'status' in data:
            schedule.status = data['status']
            if data['status'] == 'completed':
                schedule.completed_date = datetime.utcnow()
                # Update equipment last service date
                schedule.equipment.last_service_date = schedule.scheduled_date
        if 'assigned_technician' in data:
            schedule.assigned_technician = data['assigned_technician']
        if 'estimated_duration' in data:
            schedule.estimated_duration = data['estimated_duration']
        if 'actual_duration' in data:
            schedule.actual_duration = data['actual_duration']
        if 'notes' in data:
            schedule.notes = data['notes']
        
        schedule.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': schedule.to_dict(),
            'message': 'Maintenance schedule updated successfully'
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@maintenance_bp.route('/schedules/<int:schedule_id>', methods=['DELETE'])
def delete_maintenance_schedule(schedule_id):
    """Delete maintenance schedule"""
    try:
        schedule = MaintenanceSchedule.query.get_or_404(schedule_id)
        
        db.session.delete(schedule)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Maintenance schedule deleted successfully'
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@maintenance_bp.route('/calendar', methods=['GET'])
def get_maintenance_calendar():
    """Get maintenance calendar view for a specific month/year"""
    try:
        # Query parameters
        year = request.args.get('year', default=datetime.now().year, type=int)
        month = request.args.get('month', default=datetime.now().month, type=int)
        
        # Get first and last day of the month
        first_day = date(year, month, 1)
        last_day = date(year, month, calendar.monthrange(year, month)[1])
        
        # Get all maintenance schedules for the month
        schedules = MaintenanceSchedule.query.filter(
            and_(
                MaintenanceSchedule.scheduled_date >= first_day,
                MaintenanceSchedule.scheduled_date <= last_day
            )
        ).order_by(MaintenanceSchedule.scheduled_date).all()
        
        # Group schedules by date
        calendar_data = {}
        for schedule in schedules:
            date_str = schedule.scheduled_date.isoformat()
            if date_str not in calendar_data:
                calendar_data[date_str] = []
            calendar_data[date_str].append(schedule.to_dict())
        
        return jsonify({
            'success': True,
            'data': {
                'year': year,
                'month': month,
                'calendar': calendar_data,
                'total_schedules': len(schedules)
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@maintenance_bp.route('/generate-preventive', methods=['POST'])
def generate_preventive_maintenance():
    """Generate preventive maintenance schedules for all equipment"""
    try:
        data = request.get_json()
        months_ahead = data.get('months_ahead', 6)  # Generate schedules for next 6 months
        
        equipment_list = Equipment.query.all()
        generated_schedules = []
        
        for equipment in equipment_list:
            schedules = _generate_preventive_schedules(equipment, months_ahead)
            generated_schedules.extend(schedules)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': [schedule.to_dict() for schedule in generated_schedules],
            'count': len(generated_schedules),
            'message': f'Generated {len(generated_schedules)} preventive maintenance schedules'
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@maintenance_bp.route('/upcoming', methods=['GET'])
def get_upcoming_maintenance():
    """Get upcoming maintenance schedules"""
    try:
        days_ahead = request.args.get('days_ahead', default=30, type=int)
        
        end_date = date.today() + timedelta(days=days_ahead)
        
        schedules = MaintenanceSchedule.query.filter(
            and_(
                MaintenanceSchedule.scheduled_date >= date.today(),
                MaintenanceSchedule.scheduled_date <= end_date,
                MaintenanceSchedule.status.in_(['scheduled', 'in_progress'])
            )
        ).order_by(MaintenanceSchedule.scheduled_date).all()
        
        return jsonify({
            'success': True,
            'data': [schedule.to_dict() for schedule in schedules],
            'count': len(schedules)
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

def _generate_preventive_schedules(equipment, months_ahead):
    """Generate preventive maintenance schedules for a specific equipment"""
    schedules = []
    
    # Start from next service date
    current_date = equipment.get_next_service_date()
    end_date = date.today() + timedelta(days=months_ahead * 30)
    
    while current_date <= end_date:
        # Check if schedule already exists for this date
        existing_schedule = MaintenanceSchedule.query.filter(
            and_(
                MaintenanceSchedule.equipment_id == equipment.id,
                MaintenanceSchedule.scheduled_date == current_date,
                MaintenanceSchedule.maintenance_type == 'preventive'
            )
        ).first()
        
        if not existing_schedule:
            schedule = MaintenanceSchedule(
                equipment_id=equipment.id,
                scheduled_date=current_date,
                maintenance_type='preventive',
                description=f'Scheduled preventive maintenance for {equipment.name}',
                status='scheduled'
            )
            
            db.session.add(schedule)
            schedules.append(schedule)
            
            # Create alert for upcoming maintenance
            _create_maintenance_alert(schedule)
        
        # Move to next maintenance date
        current_date += timedelta(days=equipment.maintenance_interval)
    
    return schedules

def _create_maintenance_alert(schedule):
    """Create alert for maintenance schedule"""
    try:
        # Calculate days until maintenance
        days_until = (schedule.scheduled_date - date.today()).days
        
        # Set priority based on urgency
        if days_until <= 1:
            priority = 'critical'
        elif days_until <= 7:
            priority = 'high'
        elif days_until <= 30:
            priority = 'medium'
        else:
            priority = 'low'
        
        alert = Alert(
            alert_type='maintenance_due',
            title=f'Maintenance Scheduled: {schedule.equipment.name}',
            message=f'{schedule.maintenance_type.title()} maintenance scheduled for {schedule.equipment.name} on {schedule.scheduled_date}',
            priority=priority,
            equipment_id=schedule.equipment_id,
            maintenance_schedule_id=schedule.id
        )
        
        db.session.add(alert)
        
    except Exception as e:
        # Don't fail the main operation if alert creation fails
        pass

