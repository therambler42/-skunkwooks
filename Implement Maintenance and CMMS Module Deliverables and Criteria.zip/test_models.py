import pytest
import sys
import os
from datetime import datetime, date, timedelta

# Add the src directory to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from src.main import app
from src.models.equipment import db, Equipment, MaintenanceSchedule
from src.models.downtime import DowntimeLog
from src.models.spare_parts import SparePart, SparePartUsage, EquipmentSparePart
from src.models.alerts import Alert, NotificationSettings

@pytest.fixture
def client():
    """Create a test client for the Flask application."""
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    with app.test_client() as client:
        with app.app_context():
            db.create_all()
            yield client
            db.drop_all()

@pytest.fixture
def sample_equipment():
    """Create sample equipment for testing."""
    equipment = Equipment(
        name='Test Pump',
        model='TP-100',
        location='Factory Floor A',
        maintenance_interval=30,
        last_service_date=date.today() - timedelta(days=25)
    )
    db.session.add(equipment)
    db.session.commit()
    return equipment

@pytest.fixture
def sample_spare_part():
    """Create sample spare part for testing."""
    part = SparePart(
        part_number='SP-001',
        name='Test Bearing',
        category='Mechanical',
        unit_of_measure='piece',
        unit_cost=25.50,
        current_stock=10,
        minimum_stock=5,
        reorder_point=8
    )
    db.session.add(part)
    db.session.commit()
    return part

class TestEquipmentModel:
    """Test Equipment model functionality."""
    
    def test_equipment_creation(self, client):
        """Test equipment creation."""
        equipment = Equipment(
            name='Test Equipment',
            model='TE-001',
            location='Test Location',
            maintenance_interval=60
        )
        db.session.add(equipment)
        db.session.commit()
        
        assert equipment.id is not None
        assert equipment.name == 'Test Equipment'
        assert equipment.maintenance_interval == 60
    
    def test_equipment_to_dict(self, client, sample_equipment):
        """Test equipment to_dict method."""
        data = sample_equipment.to_dict()
        
        assert data['name'] == 'Test Pump'
        assert data['model'] == 'TP-100'
        assert data['location'] == 'Factory Floor A'
        assert data['maintenance_interval'] == 30
    
    def test_get_next_service_date(self, client, sample_equipment):
        """Test next service date calculation."""
        next_service = sample_equipment.get_next_service_date()
        expected_date = sample_equipment.last_service_date + timedelta(days=30)
        
        assert next_service == expected_date
    
    def test_is_maintenance_due(self, client, sample_equipment):
        """Test maintenance due check."""
        # Equipment with last service 25 days ago and 30-day interval should be due soon
        assert sample_equipment.is_maintenance_due(days_ahead=10) == True
        assert sample_equipment.is_maintenance_due(days_ahead=2) == False
    
    def test_calculate_mtbf_no_failures(self, client, sample_equipment):
        """Test MTBF calculation with no failures."""
        mtbf = sample_equipment.calculate_mtbf()
        assert mtbf is None
    
    def test_calculate_mtbf_with_failures(self, client, sample_equipment):
        """Test MTBF calculation with failure logs."""
        # Create failure logs
        failure1 = DowntimeLog(
            equipment_id=sample_equipment.id,
            reason='Bearing failure',
            reason_type='failure',
            start_time=datetime.now() - timedelta(days=10),
            end_time=datetime.now() - timedelta(days=10, hours=2),
            impact='high'
        )
        failure2 = DowntimeLog(
            equipment_id=sample_equipment.id,
            reason='Motor failure',
            reason_type='failure',
            start_time=datetime.now() - timedelta(days=5),
            end_time=datetime.now() - timedelta(days=5, hours=1),
            impact='critical'
        )
        
        db.session.add_all([failure1, failure2])
        db.session.commit()
        
        mtbf = sample_equipment.calculate_mtbf()
        assert mtbf is not None
        assert mtbf > 0

class TestMaintenanceScheduleModel:
    """Test MaintenanceSchedule model functionality."""
    
    def test_maintenance_schedule_creation(self, client, sample_equipment):
        """Test maintenance schedule creation."""
        schedule = MaintenanceSchedule(
            equipment_id=sample_equipment.id,
            scheduled_date=date.today() + timedelta(days=5),
            maintenance_type='preventive',
            description='Routine maintenance'
        )
        db.session.add(schedule)
        db.session.commit()
        
        assert schedule.id is not None
        assert schedule.equipment_id == sample_equipment.id
        assert schedule.maintenance_type == 'preventive'
        assert schedule.status == 'scheduled'
    
    def test_maintenance_schedule_to_dict(self, client, sample_equipment):
        """Test maintenance schedule to_dict method."""
        schedule = MaintenanceSchedule(
            equipment_id=sample_equipment.id,
            scheduled_date=date.today() + timedelta(days=5),
            maintenance_type='preventive',
            description='Test maintenance'
        )
        db.session.add(schedule)
        db.session.commit()
        
        data = schedule.to_dict()
        
        assert data['equipment_id'] == sample_equipment.id
        assert data['equipment_name'] == sample_equipment.name
        assert data['maintenance_type'] == 'preventive'
        assert data['status'] == 'scheduled'

class TestDowntimeLogModel:
    """Test DowntimeLog model functionality."""
    
    def test_downtime_log_creation(self, client, sample_equipment):
        """Test downtime log creation."""
        log = DowntimeLog(
            equipment_id=sample_equipment.id,
            reason='Pump failure',
            reason_type='failure',
            start_time=datetime.now() - timedelta(hours=2),
            end_time=datetime.now(),
            impact='high'
        )
        db.session.add(log)
        db.session.commit()
        
        assert log.id is not None
        assert log.equipment_id == sample_equipment.id
        assert log.reason_type == 'failure'
        assert log.impact == 'high'
    
    def test_get_duration_hours(self, client, sample_equipment):
        """Test duration calculation."""
        start_time = datetime.now() - timedelta(hours=3)
        end_time = datetime.now()
        
        log = DowntimeLog(
            equipment_id=sample_equipment.id,
            reason='Test downtime',
            reason_type='maintenance',
            start_time=start_time,
            end_time=end_time,
            impact='low'
        )
        db.session.add(log)
        db.session.commit()
        
        duration = log.get_duration_hours()
        assert abs(duration - 3.0) < 0.1  # Allow small variance
    
    def test_is_ongoing(self, client, sample_equipment):
        """Test ongoing downtime check."""
        ongoing_log = DowntimeLog(
            equipment_id=sample_equipment.id,
            reason='Ongoing issue',
            reason_type='failure',
            start_time=datetime.now() - timedelta(hours=1),
            impact='medium'
        )
        
        completed_log = DowntimeLog(
            equipment_id=sample_equipment.id,
            reason='Completed issue',
            reason_type='failure',
            start_time=datetime.now() - timedelta(hours=2),
            end_time=datetime.now() - timedelta(hours=1),
            impact='low'
        )
        
        db.session.add_all([ongoing_log, completed_log])
        db.session.commit()
        
        assert ongoing_log.is_ongoing() == True
        assert completed_log.is_ongoing() == False

class TestSparePartModel:
    """Test SparePart model functionality."""
    
    def test_spare_part_creation(self, client):
        """Test spare part creation."""
        part = SparePart(
            part_number='TEST-001',
            name='Test Part',
            category='Test Category',
            unit_of_measure='piece',
            unit_cost=10.00,
            current_stock=20
        )
        db.session.add(part)
        db.session.commit()
        
        assert part.id is not None
        assert part.part_number == 'TEST-001'
        assert part.current_stock == 20
    
    def test_get_stock_status(self, client, sample_spare_part):
        """Test stock status calculation."""
        # Normal stock
        assert sample_spare_part.get_stock_status() == 'normal'
        
        # Low stock
        sample_spare_part.current_stock = 7
        assert sample_spare_part.get_stock_status() == 'low_stock'
        
        # Out of stock
        sample_spare_part.current_stock = 0
        assert sample_spare_part.get_stock_status() == 'out_of_stock'
    
    def test_needs_reorder(self, client, sample_spare_part):
        """Test reorder check."""
        # Above reorder point
        assert sample_spare_part.needs_reorder() == False
        
        # At reorder point
        sample_spare_part.current_stock = 8
        assert sample_spare_part.needs_reorder() == True
        
        # Below reorder point
        sample_spare_part.current_stock = 5
        assert sample_spare_part.needs_reorder() == True

class TestSparePartUsageModel:
    """Test SparePartUsage model functionality."""
    
    def test_spare_part_usage_creation(self, client, sample_equipment, sample_spare_part):
        """Test spare part usage creation."""
        usage = SparePartUsage(
            spare_part_id=sample_spare_part.id,
            equipment_id=sample_equipment.id,
            quantity_used=2,
            technician='John Doe'
        )
        db.session.add(usage)
        db.session.commit()
        
        assert usage.id is not None
        assert usage.spare_part_id == sample_spare_part.id
        assert usage.equipment_id == sample_equipment.id
        assert usage.quantity_used == 2

class TestAlertModel:
    """Test Alert model functionality."""
    
    def test_alert_creation(self, client, sample_equipment):
        """Test alert creation."""
        alert = Alert(
            alert_type='maintenance_due',
            title='Test Alert',
            message='Test alert message',
            priority='medium',
            equipment_id=sample_equipment.id
        )
        db.session.add(alert)
        db.session.commit()
        
        assert alert.id is not None
        assert alert.alert_type == 'maintenance_due'
        assert alert.priority == 'medium'
        assert alert.status == 'active'
    
    def test_mark_as_read(self, client, sample_equipment):
        """Test marking alert as read."""
        alert = Alert(
            alert_type='test',
            title='Test Alert',
            message='Test message',
            equipment_id=sample_equipment.id
        )
        db.session.add(alert)
        db.session.commit()
        
        assert alert.in_app_read == False
        
        alert.mark_as_read()
        assert alert.in_app_read == True
        assert alert.in_app_read_at is not None
    
    def test_resolve_alert(self, client, sample_equipment):
        """Test resolving alert."""
        alert = Alert(
            alert_type='test',
            title='Test Alert',
            message='Test message',
            equipment_id=sample_equipment.id
        )
        db.session.add(alert)
        db.session.commit()
        
        alert.resolve('Test User')
        
        assert alert.status == 'resolved'
        assert alert.resolved_at is not None
        assert alert.resolved_by == 'Test User'

class TestNotificationSettingsModel:
    """Test NotificationSettings model functionality."""
    
    def test_notification_settings_creation(self, client):
        """Test notification settings creation."""
        settings = NotificationSettings(
            user_email='test@example.com',
            alert_type='maintenance_due',
            email_enabled=True,
            in_app_enabled=True,
            priority_threshold='medium'
        )
        db.session.add(settings)
        db.session.commit()
        
        assert settings.id is not None
        assert settings.user_email == 'test@example.com'
        assert settings.alert_type == 'maintenance_due'
        assert settings.email_enabled == True

