from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta
from sqlalchemy import func

db = SQLAlchemy()

class Equipment(db.Model):
    __tablename__ = 'equipment'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    model = db.Column(db.String(255), nullable=False)
    location = db.Column(db.String(255), nullable=False)
    maintenance_interval = db.Column(db.Integer, nullable=False)  # days
    last_service_date = db.Column(db.Date, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    maintenance_schedules = db.relationship('MaintenanceSchedule', backref='equipment', lazy=True, cascade='all, delete-orphan')
    downtime_logs = db.relationship('DowntimeLog', backref='equipment', lazy=True, cascade='all, delete-orphan')
    spare_part_usages = db.relationship('SparePartUsage', backref='equipment', lazy=True, cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Equipment {self.name}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'model': self.model,
            'location': self.location,
            'maintenance_interval': self.maintenance_interval,
            'last_service_date': self.last_service_date.isoformat() if self.last_service_date else None,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }
    
    def get_next_service_date(self):
        """Calculate next service date based on last service date and maintenance interval"""
        if self.last_service_date:
            return self.last_service_date + timedelta(days=self.maintenance_interval)
        return datetime.now().date() + timedelta(days=self.maintenance_interval)
    
    def is_maintenance_due(self, days_ahead=7):
        """Check if maintenance is due within specified days"""
        next_service = self.get_next_service_date()
        return next_service <= (datetime.now().date() + timedelta(days=days_ahead))
    
    def calculate_mtbf(self):
        """Calculate Mean Time Between Failures based on downtime logs"""
        from src.models.downtime import DowntimeLog
        
        # Get all failure-related downtime logs
        failure_logs = DowntimeLog.query.filter_by(
            equipment_id=self.id,
            reason_type='failure'
        ).order_by(DowntimeLog.start_time).all()
        
        if len(failure_logs) < 2:
            return None
        
        # Calculate time between failures
        total_time = 0
        for i in range(1, len(failure_logs)):
            time_diff = failure_logs[i].start_time - failure_logs[i-1].end_time
            total_time += time_diff.total_seconds()
        
        # Return MTBF in hours
        return total_time / (len(failure_logs) - 1) / 3600


class MaintenanceSchedule(db.Model):
    __tablename__ = 'maintenance_schedule'
    
    id = db.Column(db.Integer, primary_key=True)
    equipment_id = db.Column(db.Integer, db.ForeignKey('equipment.id'), nullable=False)
    scheduled_date = db.Column(db.Date, nullable=False)
    maintenance_type = db.Column(db.String(100), nullable=False)  # preventive, corrective, emergency
    description = db.Column(db.Text)
    status = db.Column(db.String(50), default='scheduled')  # scheduled, in_progress, completed, cancelled
    assigned_technician = db.Column(db.String(255))
    estimated_duration = db.Column(db.Integer)  # minutes
    actual_duration = db.Column(db.Integer)  # minutes
    completed_date = db.Column(db.DateTime)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<MaintenanceSchedule {self.equipment.name} - {self.scheduled_date}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'equipment_id': self.equipment_id,
            'equipment_name': self.equipment.name if self.equipment else None,
            'scheduled_date': self.scheduled_date.isoformat(),
            'maintenance_type': self.maintenance_type,
            'description': self.description,
            'status': self.status,
            'assigned_technician': self.assigned_technician,
            'estimated_duration': self.estimated_duration,
            'actual_duration': self.actual_duration,
            'completed_date': self.completed_date.isoformat() if self.completed_date else None,
            'notes': self.notes,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }

