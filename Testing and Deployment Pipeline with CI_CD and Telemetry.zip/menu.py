from flask import Blueprint, request, jsonify
from src.models.restaurant import db, MenuItem

menu_bp = Blueprint('menu', __name__)

@menu_bp.route('/restaurant/<int:restaurant_id>', methods=['GET'])
def get_menu_items(restaurant_id):
    """Get all menu items for a restaurant"""
    try:
        menu_items = MenuItem.query.filter_by(restaurant_id=restaurant_id).all()
        return jsonify([item.to_dict() for item in menu_items])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@menu_bp.route('/<int:item_id>', methods=['GET'])
def get_menu_item(item_id):
    """Get a specific menu item"""
    try:
        item = MenuItem.query.get_or_404(item_id)
        return jsonify(item.to_dict())
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@menu_bp.route('/', methods=['POST'])
def create_menu_item():
    """Create a new menu item"""
    try:
        data = request.get_json()
        
        item = MenuItem(
            restaurant_id=data.get('restaurant_id'),
            name=data.get('name'),
            description=data.get('description'),
            price=data.get('price'),
            category=data.get('category'),
            is_available=data.get('is_available', True)
        )
        
        db.session.add(item)
        db.session.commit()
        
        return jsonify(item.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@menu_bp.route('/<int:item_id>', methods=['PUT'])
def update_menu_item(item_id):
    """Update a menu item"""
    try:
        item = MenuItem.query.get_or_404(item_id)
        data = request.get_json()
        
        item.name = data.get('name', item.name)
        item.description = data.get('description', item.description)
        item.price = data.get('price', item.price)
        item.category = data.get('category', item.category)
        item.is_available = data.get('is_available', item.is_available)
        
        db.session.commit()
        
        return jsonify(item.to_dict())
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@menu_bp.route('/<int:item_id>', methods=['DELETE'])
def delete_menu_item(item_id):
    """Delete a menu item"""
    try:
        item = MenuItem.query.get_or_404(item_id)
        db.session.delete(item)
        db.session.commit()
        
        return jsonify({'message': 'Menu item deleted successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

