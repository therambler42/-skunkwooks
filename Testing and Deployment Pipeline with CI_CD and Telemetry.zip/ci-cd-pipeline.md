# CI/CD Pipeline Documentation

## Overview

This repository implements a comprehensive CI/CD pipeline using GitHub Actions with the following key features:

- **Automated Testing**: Unit, integration, E2E, and performance tests
- **Security Scanning**: Vulnerability scanning and dependency audits
- **Multi-Environment Deployment**: Staging and production environments
- **Manual Approval Gates**: Production deployments require manual approval
- **Rollback Capabilities**: Automated rollback on deployment failures
- **Comprehensive Monitoring**: Test coverage, performance metrics, and health checks

## Workflows

### 1. CI/CD Pipeline (`ci-cd.yml`)

**Triggers**: Push to `main` or `develop`, Pull requests to `main`

**Jobs**:
- `test-backend`: Runs Python/Flask backend tests with MySQL
- `test-frontend`: Runs React frontend tests with coverage
- `lint-and-format`: Code quality checks (ESLint, Black, Flake8)
- `security-scan`: Trivy vulnerability scanning
- `build-backend`: Creates backend deployment package
- `build-frontend`: Builds React application for production

**Coverage Requirements**: 85% minimum for backend, configurable for frontend

### 2. Staging Deployment (`deploy-staging.yml`)

**Triggers**: Push to `develop` branch, successful CI/CD completion

**Jobs**:
- `deploy-staging`: Automated deployment to staging environment
- `run-e2e-tests`: Cypress E2E tests against staging
- `performance-tests`: k6 load testing against staging

**Environment**: `staging` with URL https://restaurant-staging.example.com

### 3. Production Deployment (`deploy-production.yml`)

**Triggers**: Push to `main` branch, manual workflow dispatch

**Jobs**:
- `approval-gate`: **Manual approval required** for production deployments
- `pre-deployment-checks`: Validates staging health and backup status
- `deploy-production`: Blue-green deployment to production
- `post-deployment`: Monitoring updates and stakeholder notifications
- `rollback`: Automatic rollback on deployment failure

**Environment**: `production` with URL https://restaurant-app.example.com

### 4. Nightly Tests (`nightly-tests.yml`)

**Triggers**: Daily at 2 AM UTC, manual dispatch

**Jobs**:
- `comprehensive-tests`: Full test suite with 90% coverage requirement
- `security-audit`: npm audit, safety, bandit, CodeQL analysis
- `dependency-updates`: Checks for outdated packages
- `performance-baseline`: Performance regression testing

### 5. Release (`release.yml`)

**Triggers**: Git tags matching `v*`, manual dispatch

**Jobs**:
- `create-release`: Generates changelog and GitHub release
- `build-and-package`: Creates release artifacts
- `deploy-release`: Deploys tagged release to production

## Environment Configuration

### Required Secrets

```yaml
# Database Configuration
STAGING_DB_HOST: staging-db.example.com
STAGING_DB_PASSWORD: <staging-db-password>
PRODUCTION_DB_HOST: production-db.example.com
PRODUCTION_DB_PASSWORD: <production-db-password>

# Deployment Credentials
STAGING_DEPLOY_KEY: <staging-ssh-key>
PRODUCTION_DEPLOY_KEY: <production-ssh-key>

# Notification Webhooks
SLACK_WEBHOOK_URL: <slack-webhook-url>
EMAIL_NOTIFICATION_TOKEN: <email-service-token>
```

### Environment Protection Rules

#### Staging Environment
- No protection rules (automatic deployment)
- Required status checks: CI/CD Pipeline

#### Production Environment
- Required reviewers: 2 team members
- Restrict pushes to specific branches: `main`
- Required status checks: All staging tests must pass

#### Production Approval Environment
- Required reviewers: 1 senior team member or tech lead
- Deployment window: Business hours only (9 AM - 5 PM UTC)

## Deployment Strategy

### Staging Deployment
1. **Automatic Trigger**: Every push to `develop` branch
2. **Process**: 
   - Deploy backend and frontend
   - Run database migrations
   - Execute smoke tests
   - Run E2E test suite
   - Perform load testing
3. **Rollback**: Automatic on test failures

### Production Deployment
1. **Manual Approval**: Required before deployment
2. **Pre-deployment Checks**:
   - Staging environment health verification
   - Database backup confirmation
   - Artifact validation
3. **Deployment Process**:
   - Create pre-deployment backup
   - Blue-green deployment
   - Database migrations with rollback capability
   - Application warm-up
   - Comprehensive health checks
4. **Post-deployment**:
   - Monitoring dashboard updates
   - Stakeholder notifications
   - Deployment tracking updates

## Testing Strategy

### Backend Testing
- **Framework**: pytest with coverage reporting
- **Database**: MySQL 8.0 test instance
- **Coverage Target**: 85% minimum
- **Test Types**: Unit, integration, API endpoint tests

### Frontend Testing
- **Framework**: Jest with React Testing Library
- **Coverage Target**: Configurable (recommended 80%+)
- **Test Types**: Component, integration, user interaction tests

### E2E Testing
- **Framework**: Cypress
- **Target Environment**: Staging
- **Scope**: Critical user journeys, form submissions, navigation

### Performance Testing
- **Framework**: k6
- **Metrics**: Response time, throughput, error rate
- **Thresholds**: 95% requests < 500ms, error rate < 10%

## Security Measures

### Vulnerability Scanning
- **Tool**: Trivy filesystem scanner
- **Frequency**: Every CI run
- **Integration**: GitHub Security tab

### Dependency Auditing
- **npm audit**: Frontend dependencies
- **safety**: Python dependencies
- **bandit**: Python security linting
- **CodeQL**: Static analysis security testing

### Code Quality
- **Frontend**: ESLint with security rules
- **Backend**: Black formatting, Flake8 linting, isort imports
- **Enforcement**: Required status checks

## Monitoring and Alerting

### Deployment Monitoring
- Health check endpoints
- Application performance metrics
- Database connection monitoring
- Error rate tracking

### Notification Channels
- Slack integration for deployment status
- Email notifications for failures
- GitHub issue creation for dependency updates

## Rollback Procedures

### Automatic Rollback Triggers
- Health check failures post-deployment
- Critical error rate thresholds exceeded
- Database migration failures

### Manual Rollback Process
1. Access production-rollback environment
2. Execute rollback workflow
3. Verify rollback success
4. Update incident tracking

## Best Practices

### Branch Strategy
- `main`: Production-ready code
- `develop`: Integration branch for staging
- Feature branches: Merge to `develop` via PR

### Commit Messages
- Follow conventional commits format
- Include issue references
- Clear, descriptive messages

### Pull Request Requirements
- All status checks must pass
- Code review from team member
- No merge conflicts
- Up-to-date with target branch

### Release Management
- Semantic versioning (v1.0.0)
- Comprehensive changelog
- Release notes with breaking changes
- Coordinated deployment communication

## Troubleshooting

### Common Issues

#### Test Failures
1. Check test logs in GitHub Actions
2. Verify database connectivity
3. Review code coverage reports
4. Run tests locally to reproduce

#### Deployment Failures
1. Check deployment logs
2. Verify environment secrets
3. Confirm artifact integrity
4. Review health check responses

#### Performance Issues
1. Analyze k6 test results
2. Check database query performance
3. Review application metrics
4. Compare with baseline performance

### Support Contacts
- **DevOps Team**: devops@restaurant-app.com
- **On-call Engineer**: +1-555-ONCALL
- **Incident Management**: incidents@restaurant-app.com

