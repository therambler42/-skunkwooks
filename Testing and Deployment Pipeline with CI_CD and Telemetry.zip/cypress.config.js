{
  "e2e": {
    "baseUrl": "http://localhost:3000",
    "supportFile": false,
    "specPattern": "tests/e2e/**/*.cy.{js,jsx,ts,tsx}",
    "video": false,
    "screenshotOnRunFailure": true,
    "viewportWidth": 1280,
    "viewportHeight": 720
  }
}

