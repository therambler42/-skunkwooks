import React, { createContext, useContext, useEffect } from 'react';
import telemetryService from '../services/telemetry';

const TelemetryContext = createContext();

export const useTelemetry = () => {
  const context = useContext(TelemetryContext);
  if (!context) {
    throw new Error('useTelemetry must be used within a TelemetryProvider');
  }
  return context;
};

export const TelemetryProvider = ({ children }) => {
  useEffect(() => {
    // Start session when app loads
    telemetryService.startSession();

    // Track page visibility changes
    const handleVisibilityChange = () => {
      if (document.hidden) {
        telemetryService.track('page_hidden');
      } else {
        telemetryService.track('page_visible');
      }
    };

    // Track unload events
    const handleBeforeUnload = () => {
      telemetryService.endSession();
    };

    // Track JavaScript errors
    const handleError = (event) => {
      telemetryService.trackJavaScriptError(event.error, {
        filename: event.filename,
        lineno: event.lineno,
        colno: event.colno,
      });
    };

    // Track unhandled promise rejections
    const handleUnhandledRejection = (event) => {
      telemetryService.trackError('unhandled_promise_rejection', event.reason?.message || 'Unknown error', {
        reason: event.reason,
      });
    };

    // Add event listeners
    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('beforeunload', handleBeforeUnload);
    window.addEventListener('error', handleError);
    window.addEventListener('unhandledrejection', handleUnhandledRejection);

    // Cleanup
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('beforeunload', handleBeforeUnload);
      window.removeEventListener('error', handleError);
      window.removeEventListener('unhandledrejection', handleUnhandledRejection);
    };
  }, []);

  const value = {
    // Expose telemetry service methods
    track: telemetryService.track.bind(telemetryService),
    identify: telemetryService.identify.bind(telemetryService),
    trackPageView: telemetryService.trackPageView.bind(telemetryService),
    trackRestaurantCreated: telemetryService.trackRestaurantCreated.bind(telemetryService),
    trackRestaurantViewed: telemetryService.trackRestaurantViewed.bind(telemetryService),
    trackRestaurantUpdated: telemetryService.trackRestaurantUpdated.bind(telemetryService),
    trackRestaurantDeleted: telemetryService.trackRestaurantDeleted.bind(telemetryService),
    trackMenuItemCreated: telemetryService.trackMenuItemCreated.bind(telemetryService),
    trackMenuItemUpdated: telemetryService.trackMenuItemUpdated.bind(telemetryService),
    trackOrderCreated: telemetryService.trackOrderCreated.bind(telemetryService),
    trackOrderStatusChanged: telemetryService.trackOrderStatusChanged.bind(telemetryService),
    trackDataImportStarted: telemetryService.trackDataImportStarted.bind(telemetryService),
    trackDataImportCompleted: telemetryService.trackDataImportCompleted.bind(telemetryService),
    trackFieldMappingChanged: telemetryService.trackFieldMappingChanged.bind(telemetryService),
    trackTemplateDownloaded: telemetryService.trackTemplateDownloaded.bind(telemetryService),
    trackAnalyticsViewed: telemetryService.trackAnalyticsViewed.bind(telemetryService),
    trackAnalyticsFilterChanged: telemetryService.trackAnalyticsFilterChanged.bind(telemetryService),
    trackFormError: telemetryService.trackFormError.bind(telemetryService),
    trackFormSubmitted: telemetryService.trackFormSubmitted.bind(telemetryService),
    trackNavigationClicked: telemetryService.trackNavigationClicked.bind(telemetryService),
    trackSearchPerformed: telemetryService.trackSearchPerformed.bind(telemetryService),
    trackFeatureUsed: telemetryService.trackFeatureUsed.bind(telemetryService),
    trackPerformanceMetric: telemetryService.trackPerformanceMetric.bind(telemetryService),
    trackAPICall: telemetryService.trackAPICall.bind(telemetryService),
    trackError: telemetryService.trackError.bind(telemetryService),
    trackTimeOnPage: telemetryService.trackTimeOnPage.bind(telemetryService),
    trackButtonClicked: telemetryService.trackButtonClicked.bind(telemetryService),
    getFeatureFlag: telemetryService.getFeatureFlag.bind(telemetryService),
    setUserProperty: telemetryService.setUserProperty.bind(telemetryService),
  };

  return (
    <TelemetryContext.Provider value={value}>
      {children}
    </TelemetryContext.Provider>
  );
};

