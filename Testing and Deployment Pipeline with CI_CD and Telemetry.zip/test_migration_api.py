import pytest
import json
import io
from src.models.restaurant import Restaurant, MenuItem, db

class TestMigrationAPI:
    """Test cases for Data Migration API endpoints."""
    
    def test_get_restaurant_template(self, client):
        """Test getting restaurant CSV template."""
        response = client.get('/api/migration/template/restaurants')
        assert response.status_code == 200
        data = response.json
        assert 'template' in data
        assert 'required_fields' in data
        assert 'optional_fields' in data
        assert 'name' in data['required_fields']
        assert 'address' in data['required_fields']
    
    def test_get_menu_template(self, client):
        """Test getting menu CSV template."""
        response = client.get('/api/migration/template/menu')
        assert response.status_code == 200
        data = response.json
        assert 'template' in data
        assert 'required_fields' in data
        assert 'optional_fields' in data
        assert 'restaurant_id' in data['required_fields']
        assert 'name' in data['required_fields']
        assert 'price' in data['required_fields']
    
    def test_import_restaurants_success(self, client):
        """Test successful restaurant CSV import."""
        csv_content = """name,address,phone,email,cuisine_type
Test Restaurant 1,123 Main St,555-1234,test1@example.com,Italian
Test Restaurant 2,456 Oak Ave,555-5678,test2@example.com,Mexican"""
        
        data = {
            'file': (io.BytesIO(csv_content.encode('utf-8')), 'restaurants.csv')
        }
        
        response = client.post('/api/migration/restaurants/import', 
                             data=data,
                             content_type='multipart/form-data')
        assert response.status_code == 200
        result = response.json
        assert result['success'] == True
        assert result['imported_count'] == 2
        assert len(result['errors']) == 0
        
        # Verify restaurants were created
        restaurants = client.get('/api/restaurants/').json
        assert len(restaurants) == 2
    
    def test_import_restaurants_missing_required_fields(self, client):
        """Test restaurant import with missing required fields."""
        csv_content = """name,phone,email
Test Restaurant,555-1234,test@example.com"""
        
        data = {
            'file': (io.BytesIO(csv_content.encode('utf-8')), 'restaurants.csv')
        }
        
        response = client.post('/api/migration/restaurants/import', 
                             data=data,
                             content_type='multipart/form-data')
        assert response.status_code == 200
        result = response.json
        assert result['success'] == False
        assert result['imported_count'] == 0
        assert len(result['errors']) > 0
        assert 'Missing required fields' in result['errors'][0]
    
    def test_import_menu_items_success(self, client, sample_restaurant_data):
        """Test successful menu items CSV import."""
        # First create a restaurant
        restaurant_response = client.post('/api/restaurants/', 
                                        data=json.dumps(sample_restaurant_data),
                                        content_type='application/json')
        restaurant_id = restaurant_response.json['id']
        
        csv_content = f"""restaurant_id,name,description,price,category,is_available
{restaurant_id},Pizza Margherita,Classic pizza with tomato and mozzarella,12.99,Pizza,true
{restaurant_id},Caesar Salad,Fresh romaine lettuce with caesar dressing,8.99,Salad,true"""
        
        data = {
            'file': (io.BytesIO(csv_content.encode('utf-8')), 'menu.csv')
        }
        
        response = client.post('/api/migration/menu/import', 
                             data=data,
                             content_type='multipart/form-data')
        assert response.status_code == 200
        result = response.json
        assert result['success'] == True
        assert result['imported_count'] == 2
        assert len(result['errors']) == 0
        
        # Verify menu items were created
        menu_items = client.get(f'/api/menu/restaurant/{restaurant_id}').json
        assert len(menu_items) == 2
    
    def test_import_menu_items_invalid_restaurant(self, client):
        """Test menu import with invalid restaurant ID."""
        csv_content = """restaurant_id,name,description,price,category
999,Pizza Margherita,Classic pizza,12.99,Pizza"""
        
        data = {
            'file': (io.BytesIO(csv_content.encode('utf-8')), 'menu.csv')
        }
        
        response = client.post('/api/migration/menu/import', 
                             data=data,
                             content_type='multipart/form-data')
        assert response.status_code == 200
        result = response.json
        assert result['success'] == False
        assert result['imported_count'] == 0
        assert len(result['errors']) > 0
        assert 'Restaurant with ID 999 not found' in result['errors'][0]
    
    def test_import_no_file_provided(self, client):
        """Test import with no file provided."""
        response = client.post('/api/migration/restaurants/import')
        assert response.status_code == 400
        assert 'No file provided' in response.json['error']
    
    def test_import_empty_file(self, client):
        """Test import with empty file."""
        data = {
            'file': (io.BytesIO(b''), 'empty.csv')
        }
        
        response = client.post('/api/migration/restaurants/import', 
                             data=data,
                             content_type='multipart/form-data')
        assert response.status_code == 400
        assert 'No file selected' in response.json['error']

