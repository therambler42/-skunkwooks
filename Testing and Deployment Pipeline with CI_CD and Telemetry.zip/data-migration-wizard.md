# Data Migration Wizard Documentation

## Overview

The Data Migration Wizard is a comprehensive tool for importing restaurant and menu data from CSV files into the Restaurant Management System. It provides a user-friendly interface with field mapping capabilities, validation, and error handling.

## Features

### Restaurant Import
- **CSV Upload**: Drag-and-drop or file selection interface
- **Template Download**: Pre-formatted CSV template with required fields
- **Field Mapping**: Interactive mapping of CSV columns to database fields
- **Data Preview**: Shows sample data before import
- **Validation**: Real-time validation of required fields
- **Error Handling**: Detailed error reporting with row-level feedback
- **Progress Tracking**: Visual progress indicators during import

### Menu Item Import
- **Restaurant Association**: Links menu items to existing restaurants
- **Category Management**: Organizes items by category
- **Price Validation**: Ensures proper price formatting
- **Availability Status**: Controls item availability

### Import History
- **Audit Trail**: Complete history of all import operations
- **Status Tracking**: Success/failure status for each import
- **Error Logs**: Detailed error information for troubleshooting

## Technical Implementation

### Backend API Endpoints

#### Restaurant Import
```
POST /api/migration/restaurants/import
- Accepts multipart/form-data with CSV file
- Returns import results with success count and errors
```

#### Menu Import
```
POST /api/migration/menu/import
- Accepts multipart/form-data with CSV file
- Validates restaurant associations
- Returns import results
```

#### Templates
```
GET /api/migration/template/restaurants
GET /api/migration/template/menu
- Returns CSV templates with field definitions
```

### Frontend Components

#### DataMigration.jsx
- Main component with tabbed interface
- Handles file uploads and processing
- Manages import workflow states

#### RestaurantImport Component
- Three-step wizard: Upload → Map → Import
- CSV parsing using Papa Parse library
- Field mapping with dropdown selectors
- Real-time validation feedback

### CSV Format Requirements

#### Restaurant CSV
**Required Fields:**
- name: Restaurant name
- address: Full address

**Optional Fields:**
- phone: Contact phone number
- email: Contact email address
- cuisine_type: Type of cuisine

**Sample Format:**
```csv
name,address,phone,email,cuisine_type
Bella Vista Italian,123 Main Street,555-0101,info@bellavista.com,Italian
Dragon Palace,456 Oak Avenue,555-0102,orders@dragonpalace.com,Chinese
```

#### Menu Items CSV
**Required Fields:**
- restaurant_id: ID of associated restaurant
- name: Menu item name
- price: Item price (decimal format)

**Optional Fields:**
- description: Item description
- category: Item category
- is_available: Availability status (true/false)

**Sample Format:**
```csv
restaurant_id,name,description,price,category,is_available
1,Margherita Pizza,Classic pizza with tomato sauce,12.99,Pizza,true
1,Caesar Salad,Fresh romaine lettuce with caesar dressing,8.99,Salad,true
```

## User Workflow

### Restaurant Import Process

1. **Upload CSV File**
   - User selects or drags CSV file
   - System parses file and validates format
   - Preview of data is displayed

2. **Map Fields**
   - System auto-detects common field names
   - User manually maps remaining fields
   - Required field validation prevents proceeding without mapping

3. **Import Data**
   - System processes mapped data
   - Validation occurs row-by-row
   - Results displayed with success/error counts

4. **Review Results**
   - Summary of imported records
   - Detailed error list for failed records
   - Option to import another file or view restaurants

### Error Handling

#### Common Validation Errors
- Missing required fields (name, address)
- Invalid email format
- Duplicate restaurant names
- Invalid data types

#### Error Reporting
- Row-level error identification
- Descriptive error messages
- Partial import support (successful rows are imported)

## Integration Points

### Database Integration
- Uses existing Restaurant and MenuItem models
- Maintains referential integrity
- Supports transaction rollback on critical errors

### API Integration
- RESTful endpoints for all operations
- Consistent error response format
- CORS support for frontend integration

### Frontend Integration
- React Router for navigation
- Shadcn/UI components for consistent styling
- Papa Parse for CSV processing
- Form validation and user feedback

## Testing

### Unit Tests
- CSV parsing validation
- Field mapping logic
- Error handling scenarios
- API endpoint testing

### Integration Tests
- End-to-end import workflow
- Database transaction testing
- File upload handling

### User Acceptance Tests
- Complete import workflows
- Error scenario handling
- UI responsiveness and feedback

## Security Considerations

### File Upload Security
- File type validation (CSV only)
- File size limits
- Content validation before processing

### Data Validation
- SQL injection prevention
- Input sanitization
- Type checking and format validation

### Access Control
- Authentication required for import operations
- Audit logging of all import activities
- Role-based access to import functionality

## Performance Optimization

### Large File Handling
- Streaming CSV processing
- Batch database operations
- Progress reporting for long operations

### Memory Management
- Efficient data structures
- Garbage collection optimization
- Resource cleanup after operations

## Monitoring and Logging

### Import Metrics
- Success/failure rates
- Processing times
- Error frequency analysis

### Audit Trail
- Complete import history
- User activity tracking
- Data lineage information

## Future Enhancements

### Planned Features
- Excel file support (.xlsx)
- Data transformation rules
- Scheduled imports
- API-based imports
- Advanced field mapping with transformations

### Scalability Improvements
- Asynchronous processing
- Queue-based import handling
- Distributed processing support

## Troubleshooting

### Common Issues

#### Import Failures
1. Check CSV format matches template
2. Verify required fields are mapped
3. Review error messages for specific issues
4. Ensure restaurant IDs exist for menu imports

#### Performance Issues
1. Reduce file size for large imports
2. Import in smaller batches
3. Check system resources during import

#### Data Quality Issues
1. Validate data before import
2. Use provided templates
3. Clean data in external tools if needed

### Support Resources
- Template downloads available in application
- Error message documentation
- Sample data files for testing
- API documentation for developers

