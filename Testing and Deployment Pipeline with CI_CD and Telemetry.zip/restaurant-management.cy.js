describe('Restaurant Management System E2E Tests', () => {
  beforeEach(() => {
    // Visit the application
    cy.visit('http://localhost:3000');
  });

  it('should load the homepage', () => {
    cy.contains('Restaurant Management System');
    cy.get('[data-testid="main-navigation"]').should('be.visible');
  });

  it('should navigate to restaurants page', () => {
    cy.get('[data-testid="nav-restaurants"]').click();
    cy.url().should('include', '/restaurants');
    cy.contains('Restaurants');
  });

  it('should create a new restaurant', () => {
    cy.get('[data-testid="nav-restaurants"]').click();
    cy.get('[data-testid="add-restaurant-btn"]').click();
    
    // Fill out the form
    cy.get('[data-testid="restaurant-name"]').type('Test Restaurant');
    cy.get('[data-testid="restaurant-address"]').type('123 Test Street');
    cy.get('[data-testid="restaurant-phone"]').type('555-1234');
    cy.get('[data-testid="restaurant-email"]').type('test@restaurant.com');
    cy.get('[data-testid="restaurant-cuisine"]').select('Italian');
    
    // Submit the form
    cy.get('[data-testid="submit-restaurant"]').click();
    
    // Verify success
    cy.contains('Restaurant created successfully');
    cy.contains('Test Restaurant');
  });

  it('should view restaurant details', () => {
    // First create a restaurant
    cy.get('[data-testid="nav-restaurants"]').click();
    cy.get('[data-testid="add-restaurant-btn"]').click();
    cy.get('[data-testid="restaurant-name"]').type('Detail Test Restaurant');
    cy.get('[data-testid="restaurant-address"]').type('456 Detail Street');
    cy.get('[data-testid="submit-restaurant"]').click();
    
    // Click on the restaurant to view details
    cy.contains('Detail Test Restaurant').click();
    cy.url().should('include', '/restaurants/');
    cy.contains('Detail Test Restaurant');
    cy.contains('456 Detail Street');
  });

  it('should add menu items to a restaurant', () => {
    // Create a restaurant first
    cy.get('[data-testid="nav-restaurants"]').click();
    cy.get('[data-testid="add-restaurant-btn"]').click();
    cy.get('[data-testid="restaurant-name"]').type('Menu Test Restaurant');
    cy.get('[data-testid="restaurant-address"]').type('789 Menu Street');
    cy.get('[data-testid="submit-restaurant"]').click();
    
    // Navigate to menu management
    cy.contains('Menu Test Restaurant').click();
    cy.get('[data-testid="manage-menu-btn"]').click();
    
    // Add a menu item
    cy.get('[data-testid="add-menu-item-btn"]').click();
    cy.get('[data-testid="menu-item-name"]').type('Test Pizza');
    cy.get('[data-testid="menu-item-description"]').type('Delicious test pizza');
    cy.get('[data-testid="menu-item-price"]').type('15.99');
    cy.get('[data-testid="menu-item-category"]').select('Pizza');
    cy.get('[data-testid="submit-menu-item"]').click();
    
    // Verify menu item was added
    cy.contains('Test Pizza');
    cy.contains('$15.99');
  });

  it('should create an order', () => {
    // Setup: Create restaurant and menu item
    cy.get('[data-testid="nav-restaurants"]').click();
    cy.get('[data-testid="add-restaurant-btn"]').click();
    cy.get('[data-testid="restaurant-name"]').type('Order Test Restaurant');
    cy.get('[data-testid="restaurant-address"]').type('321 Order Street');
    cy.get('[data-testid="submit-restaurant"]').click();
    
    cy.contains('Order Test Restaurant').click();
    cy.get('[data-testid="manage-menu-btn"]').click();
    cy.get('[data-testid="add-menu-item-btn"]').click();
    cy.get('[data-testid="menu-item-name"]').type('Order Pizza');
    cy.get('[data-testid="menu-item-price"]').type('12.99');
    cy.get('[data-testid="submit-menu-item"]').click();
    
    // Create an order
    cy.get('[data-testid="create-order-btn"]').click();
    cy.get('[data-testid="customer-name"]').type('John Doe');
    cy.get('[data-testid="customer-email"]').type('john@example.com');
    cy.get('[data-testid="customer-phone"]').type('555-9876');
    
    // Add item to order
    cy.get('[data-testid="add-item-to-order"]').click();
    cy.get('[data-testid="select-menu-item"]').select('Order Pizza');
    cy.get('[data-testid="item-quantity"]').clear().type('2');
    cy.get('[data-testid="add-item-confirm"]').click();
    
    // Submit order
    cy.get('[data-testid="submit-order"]').click();
    
    // Verify order was created
    cy.contains('Order created successfully');
    cy.contains('John Doe');
  });

  it('should view analytics dashboard', () => {
    cy.get('[data-testid="nav-analytics"]').click();
    cy.url().should('include', '/analytics');
    cy.contains('Analytics Dashboard');
    cy.get('[data-testid="total-orders"]').should('be.visible');
    cy.get('[data-testid="total-revenue"]').should('be.visible');
    cy.get('[data-testid="avg-order-value"]').should('be.visible');
  });

  it('should import restaurant data via CSV', () => {
    cy.get('[data-testid="nav-migration"]').click();
    cy.url().should('include', '/migration');
    
    // Upload CSV file
    const csvContent = 'name,address,phone,email,cuisine_type\\nTest CSV Restaurant,123 CSV St,555-0000,csv@test.com,Italian';
    cy.get('[data-testid="csv-upload"]').selectFile({
      contents: Cypress.Buffer.from(csvContent),
      fileName: 'restaurants.csv',
      mimeType: 'text/csv',
    });
    
    cy.get('[data-testid="import-btn"]').click();
    cy.contains('Import successful');
    cy.contains('1 restaurants imported');
  });

  it('should handle error states gracefully', () => {
    // Test invalid form submission
    cy.get('[data-testid="nav-restaurants"]').click();
    cy.get('[data-testid="add-restaurant-btn"]').click();
    cy.get('[data-testid="submit-restaurant"]').click();
    
    // Should show validation errors
    cy.contains('Name is required');
    cy.contains('Address is required');
  });
});

