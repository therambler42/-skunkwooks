import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Star, Quote } from 'lucide-react';

const Testimonials = () => {
  const testimonials = [
    {
      name: 'Sarah Chen',
      role: 'Owner',
      restaurant: 'Golden Dragon Restaurant',
      location: 'San Francisco, CA',
      rating: 5,
      image: '/api/placeholder/64/64',
      quote: 'RestaurantOS transformed our operations completely. We increased revenue by 35% in just 6 months while reducing food waste by 40%. The analytics are incredible.',
      metrics: {
        revenue: '+35%',
        efficiency: '+40%',
        satisfaction: '4.9★'
      }
    },
    {
      name: 'Marcus Rodriguez',
      role: 'General Manager',
      restaurant: 'Bella Vista Pizzeria',
      location: 'Austin, TX',
      rating: 5,
      image: '/api/placeholder/64/64',
      quote: 'The POS system is lightning fast and the staff picked it up immediately. Customer wait times dropped by 50% and our order accuracy is now 99.8%.',
      metrics: {
        speed: '+50%',
        accuracy: '99.8%',
        training: '2 hours'
      }
    },
    {
      name: 'Emily Thompson',
      role: 'Operations Director',
      restaurant: 'Fresh & Co. Chain',
      location: 'New York, NY',
      rating: 5,
      image: '/api/placeholder/64/64',
      quote: 'Managing 12 locations was a nightmare before RestaurantOS. Now I have real-time visibility across all stores and can make data-driven decisions instantly.',
      metrics: {
        locations: '12 stores',
        visibility: 'Real-time',
        decisions: 'Data-driven'
      }
    },
    {
      name: 'David Park',
      role: 'Chef & Owner',
      restaurant: 'Seoul Kitchen',
      location: 'Los Angeles, CA',
      rating: 5,
      image: '/api/placeholder/64/64',
      quote: 'The inventory management is a game-changer. We reduced food costs by 25% and never run out of ingredients during peak hours anymore.',
      metrics: {
        costs: '-25%',
        stockouts: '0%',
        waste: '-30%'
      }
    },
    {
      name: 'Lisa Johnson',
      role: 'Franchise Owner',
      restaurant: 'Healthy Bites',
      location: 'Miami, FL',
      rating: 5,
      image: '/api/placeholder/64/64',
      quote: 'The customer loyalty program built into RestaurantOS helped us increase repeat customers by 60%. The marketing tools are incredibly powerful.',
      metrics: {
        loyalty: '+60%',
        retention: '85%',
        growth: '+45%'
      }
    },
    {
      name: 'Tony Ricci',
      role: 'Owner',
      restaurant: 'Ricci\'s Italian',
      location: 'Chicago, IL',
      rating: 5,
      image: '/api/placeholder/64/64',
      quote: 'Best investment we ever made. The support team is amazing - they respond within minutes and actually understand restaurant operations.',
      metrics: {
        support: '< 15min',
        uptime: '99.9%',
        satisfaction: '5★'
      }
    }
  ];

  const stats = [
    { value: '10,000+', label: 'Restaurants Trust Us' },
    { value: '4.9/5', label: 'Average Rating' },
    { value: '99.9%', label: 'Uptime Guarantee' },
    { value: '24/7', label: 'Expert Support' }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <Badge className="mb-4 bg-gradient-to-r from-yellow-100 to-orange-100 text-orange-700 border-orange-200">
            Customer Success
          </Badge>
          <h2 className="text-3xl md:text-5xl font-bold text-gray-900 mb-6">
            Loved by{' '}
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Restaurant Owners
            </span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Join thousands of successful restaurants that have transformed their operations 
            and boosted their revenue with RestaurantOS.
          </p>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          viewport={{ once: true }}
          className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16"
        >
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.3 + index * 0.1 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">
                {stat.value}
              </div>
              <div className="text-gray-600">{stat.label}</div>
            </motion.div>
          ))}
        </motion.div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="h-full hover:shadow-xl transition-all duration-300 group border-0 shadow-lg">
                <CardContent className="p-6">
                  {/* Quote Icon */}
                  <div className="mb-4">
                    <Quote className="h-8 w-8 text-blue-500 opacity-50" />
                  </div>

                  {/* Rating */}
                  <div className="flex items-center mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                    ))}
                  </div>

                  {/* Quote */}
                  <blockquote className="text-gray-700 mb-6 leading-relaxed">
                    "{testimonial.quote}"
                  </blockquote>

                  {/* Metrics */}
                  <div className="grid grid-cols-3 gap-2 mb-6 p-3 bg-gray-50 rounded-lg">
                    {Object.entries(testimonial.metrics).map(([key, value]) => (
                      <div key={key} className="text-center">
                        <div className="text-sm font-bold text-blue-600">{value}</div>
                        <div className="text-xs text-gray-500 capitalize">{key}</div>
                      </div>
                    ))}
                  </div>

                  {/* Author */}
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white font-semibold">
                      {testimonial.name.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">{testimonial.name}</div>
                      <div className="text-sm text-gray-600">{testimonial.role}</div>
                      <div className="text-sm font-medium text-blue-600">{testimonial.restaurant}</div>
                      <div className="text-xs text-gray-500">{testimonial.location}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          viewport={{ once: true }}
          className="text-center mt-16"
        >
          <div className="bg-white rounded-2xl p-8 shadow-xl border border-gray-200">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Join These Successful Restaurants
            </h3>
            <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
              Start your 30-day free trial today and see why thousands of restaurant owners 
              choose RestaurantOS to grow their business.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-3 rounded-lg font-semibold shadow-lg hover:shadow-xl transition-all duration-200"
              >
                Start Free Trial
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="border-2 border-gray-300 text-gray-700 px-8 py-3 rounded-lg font-semibold hover:border-blue-500 hover:text-blue-600 transition-all duration-200"
              >
                Read More Reviews
              </motion.button>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Testimonials;

