# Quick Start Guide

## Deployed Applications - Ready to Use

### 🎯 Backend API
**URL**: https://r3dhkilc5gg5.manus.space

**Test the API**:
```bash
# Health check
curl https://r3dhkilc5gg5.manus.space/health

# Get restaurants
curl https://r3dhkilc5gg5.manus.space/api/restaurants

# Upload CSV for data migration
curl -X POST https://r3dhkilc5gg5.manus.space/api/migration/upload \
  -F "file=@sample-data/restaurants.csv"
```

### 🖥️ Frontend Dashboard
**URL**: https://zwqihzlz.manus.space

**Features Available**:
- Restaurant management interface
- Data migration wizard (upload CSV files)
- Analytics dashboard
- Real-time metrics

### 🌐 Marketing Site
**URL**: https://snyptjzt.manus.space

**Features Available**:
- Professional landing page
- Pricing information
- Webinar signup form
- Feature showcase

## Sample Data for Testing

Use these CSV files to test the data migration wizard:

### Restaurants CSV (`sample-data/restaurants.csv`)
```csv
name,address,phone,email,cuisine_type
Golden Dragon Restaurant,123 Main St,555-0101,info@goldendragon.com,Chinese
Bella Vista Pizzeria,456 Oak Ave,555-0102,hello@bellavista.com,Italian
Seoul Kitchen,789 Pine St,555-0103,contact@seoulkitchen.com,Korean
```

### Menu Items CSV (`sample-data/menu-items.csv`)
```csv
restaurant_id,name,description,price,category
1,Kung Pao Chicken,Spicy chicken with peanuts,12.99,Main Course
1,Spring Rolls,Fresh vegetable spring rolls,6.99,Appetizer
2,Margherita Pizza,Classic tomato and mozzarella,14.99,Pizza
```

## Testing the Complete Pipeline

### 1. Test Backend API
```bash
# Check health
curl https://r3dhkilc5gg5.manus.space/health

# Expected response:
# {"service":"restaurant-management-api","status":"healthy"}
```

### 2. Test Data Migration
1. Visit: https://zwqihzlz.manus.space
2. Navigate to "Data Migration" tab
3. Upload `sample-data/restaurants.csv`
4. Map fields and import data
5. Verify successful import

### 3. Test Analytics
1. Visit the Analytics tab in the frontend
2. View real-time metrics and charts
3. Verify telemetry data collection

### 4. Test Marketing Site
1. Visit: https://snyptjzt.manus.space
2. Navigate through all sections
3. Test webinar signup form
4. Verify responsive design

## CI/CD Pipeline

The GitHub Actions workflows are configured for:

- **Continuous Integration**: Automated testing on every commit
- **Staging Deployment**: Automatic deployment to staging environment
- **Production Deployment**: Manual approval required for production
- **Test Coverage**: Enforced 90%+ coverage requirements

## Documentation

Complete documentation is available in the `/docs/` directory:

- `ci-cd-pipeline.md` - CI/CD setup and workflows
- `data-migration-wizard.md` - Data migration guide
- `telemetry-integration.md` - Analytics and tracking
- `sla-support-documentation.md` - SLA and support information

## Support

For technical support or questions:
- Review documentation in `/docs/` directory
- Check deployment logs for troubleshooting
- All applications include health check endpoints
- Telemetry provides real-time monitoring

---

**Status**: ✅ All systems operational and ready for production use
**Last Updated**: June 8, 2025

