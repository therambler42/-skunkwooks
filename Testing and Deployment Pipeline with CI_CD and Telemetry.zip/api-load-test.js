import http from 'k6/http';
import { check, sleep } from 'k6';

export let options = {
  stages: [
    { duration: '30s', target: 10 },  // Ramp up to 10 users
    { duration: '1m', target: 20 },   // Stay at 20 users
    { duration: '30s', target: 0 },   // Ramp down to 0 users
  ],
  thresholds: {
    http_req_duration: ['p(95)<500'], // 95% of requests must complete below 500ms
    http_req_failed: ['rate<0.1'],    // Error rate must be below 10%
  },
};

const BASE_URL = 'http://localhost:5000';

export default function () {
  // Test restaurant endpoints
  let restaurantResponse = http.get(`${BASE_URL}/api/restaurants/`);
  check(restaurantResponse, {
    'get restaurants status is 200': (r) => r.status === 200,
    'get restaurants response time < 200ms': (r) => r.timings.duration < 200,
  });

  // Test health endpoint
  let healthResponse = http.get(`${BASE_URL}/health`);
  check(healthResponse, {
    'health check status is 200': (r) => r.status === 200,
    'health check response time < 100ms': (r) => r.timings.duration < 100,
  });

  // Create a restaurant
  let createPayload = JSON.stringify({
    name: `Test Restaurant ${Math.random()}`,
    address: '123 Test St',
    phone: '555-1234',
    email: 'test@example.com',
    cuisine_type: 'Test'
  });

  let createResponse = http.post(`${BASE_URL}/api/restaurants/`, createPayload, {
    headers: { 'Content-Type': 'application/json' },
  });

  check(createResponse, {
    'create restaurant status is 201': (r) => r.status === 201,
    'create restaurant response time < 300ms': (r) => r.timings.duration < 300,
  });

  if (createResponse.status === 201) {
    let restaurant = JSON.parse(createResponse.body);
    let restaurantId = restaurant.id;

    // Get the created restaurant
    let getResponse = http.get(`${BASE_URL}/api/restaurants/${restaurantId}`);
    check(getResponse, {
      'get restaurant status is 200': (r) => r.status === 200,
      'get restaurant response time < 200ms': (r) => r.timings.duration < 200,
    });

    // Get menu items for the restaurant
    let menuResponse = http.get(`${BASE_URL}/api/menu/restaurant/${restaurantId}`);
    check(menuResponse, {
      'get menu status is 200': (r) => r.status === 200,
      'get menu response time < 200ms': (r) => r.timings.duration < 200,
    });

    // Get orders for the restaurant
    let ordersResponse = http.get(`${BASE_URL}/api/orders/restaurant/${restaurantId}`);
    check(ordersResponse, {
      'get orders status is 200': (r) => r.status === 200,
      'get orders response time < 200ms': (r) => r.timings.duration < 200,
    });

    // Get analytics for the restaurant
    let analyticsResponse = http.get(`${BASE_URL}/api/analytics/restaurant/${restaurantId}/dashboard`);
    check(analyticsResponse, {
      'get analytics status is 200': (r) => r.status === 200,
      'get analytics response time < 300ms': (r) => r.timings.duration < 300,
    });
  }

  sleep(1);
}

