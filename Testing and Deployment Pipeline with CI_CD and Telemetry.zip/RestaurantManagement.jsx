import React, { useState, useEffect } from 'react';
import { Routes, Route, Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Plus, Edit, Trash2, Eye } from 'lucide-react';

const API_BASE_URL = 'http://localhost:5000/api';

function RestaurantManagement() {
  return (
    <Routes>
      <Route path="/" element={<RestaurantList />} />
      <Route path="/new" element={<RestaurantForm />} />
      <Route path="/edit/:id" element={<RestaurantForm />} />
      <Route path="/:id" element={<RestaurantDetails />} />
    </Routes>
  );
}

function RestaurantList() {
  const [restaurants, setRestaurants] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetchRestaurants();
  }, []);

  const fetchRestaurants = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/restaurants/`);
      const data = await response.json();
      setRestaurants(data);
    } catch (error) {
      console.error('Error fetching restaurants:', error);
    } finally {
      setLoading(false);
    }
  };

  const deleteRestaurant = async (id) => {
    if (window.confirm('Are you sure you want to delete this restaurant?')) {
      try {
        await fetch(`${API_BASE_URL}/restaurants/${id}`, {
          method: 'DELETE',
        });
        fetchRestaurants();
      } catch (error) {
        console.error('Error deleting restaurant:', error);
      }
    }
  };

  if (loading) {
    return <div className="text-center py-8">Loading restaurants...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Restaurants</h1>
        <Link to="/restaurants/new">
          <Button data-testid="add-restaurant-btn">
            <Plus className="h-4 w-4 mr-2" />
            Add Restaurant
          </Button>
        </Link>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Restaurant List</CardTitle>
        </CardHeader>
        <CardContent>
          {restaurants.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No restaurants found. Add your first restaurant to get started.
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Address</TableHead>
                  <TableHead>Cuisine Type</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {restaurants.map((restaurant) => (
                  <TableRow key={restaurant.id}>
                    <TableCell className="font-medium">{restaurant.name}</TableCell>
                    <TableCell>{restaurant.address}</TableCell>
                    <TableCell>{restaurant.cuisine_type || 'N/A'}</TableCell>
                    <TableCell>
                      <Badge variant={restaurant.status === 'active' ? 'default' : 'secondary'}>
                        {restaurant.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => navigate(`/restaurants/${restaurant.id}`)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => navigate(`/restaurants/edit/${restaurant.id}`)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => deleteRestaurant(restaurant.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function RestaurantForm() {
  const [formData, setFormData] = useState({
    name: '',
    address: '',
    phone: '',
    email: '',
    cuisine_type: ''
  });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrors({});

    // Validation
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Name is required';
    if (!formData.address.trim()) newErrors.address = 'Address is required';

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      setLoading(false);
      return;
    }

    try {
      const response = await fetch(`${API_BASE_URL}/restaurants/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        navigate('/restaurants');
      } else {
        const errorData = await response.json();
        setErrors({ submit: errorData.error || 'Failed to create restaurant' });
      }
    } catch (error) {
      setErrors({ submit: 'Network error. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center space-x-4">
        <Button variant="outline" onClick={() => navigate('/restaurants')}>
          ← Back
        </Button>
        <h1 className="text-3xl font-bold">Add New Restaurant</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Restaurant Information</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="name">Restaurant Name *</Label>
              <Input
                id="name"
                data-testid="restaurant-name"
                value={formData.name}
                onChange={(e) => handleChange('name', e.target.value)}
                className={errors.name ? 'border-red-500' : ''}
              />
              {errors.name && <p className="text-sm text-red-500 mt-1">{errors.name}</p>}
            </div>

            <div>
              <Label htmlFor="address">Address *</Label>
              <Input
                id="address"
                data-testid="restaurant-address"
                value={formData.address}
                onChange={(e) => handleChange('address', e.target.value)}
                className={errors.address ? 'border-red-500' : ''}
              />
              {errors.address && <p className="text-sm text-red-500 mt-1">{errors.address}</p>}
            </div>

            <div>
              <Label htmlFor="phone">Phone</Label>
              <Input
                id="phone"
                data-testid="restaurant-phone"
                value={formData.phone}
                onChange={(e) => handleChange('phone', e.target.value)}
              />
            </div>

            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                data-testid="restaurant-email"
                value={formData.email}
                onChange={(e) => handleChange('email', e.target.value)}
              />
            </div>

            <div>
              <Label htmlFor="cuisine_type">Cuisine Type</Label>
              <Select onValueChange={(value) => handleChange('cuisine_type', value)}>
                <SelectTrigger data-testid="restaurant-cuisine">
                  <SelectValue placeholder="Select cuisine type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Italian">Italian</SelectItem>
                  <SelectItem value="Mexican">Mexican</SelectItem>
                  <SelectItem value="Chinese">Chinese</SelectItem>
                  <SelectItem value="Indian">Indian</SelectItem>
                  <SelectItem value="American">American</SelectItem>
                  <SelectItem value="French">French</SelectItem>
                  <SelectItem value="Japanese">Japanese</SelectItem>
                  <SelectItem value="Thai">Thai</SelectItem>
                  <SelectItem value="Mediterranean">Mediterranean</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {errors.submit && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-md">
                <p className="text-sm text-red-600">{errors.submit}</p>
              </div>
            )}

            <div className="flex space-x-4">
              <Button
                type="submit"
                data-testid="submit-restaurant"
                disabled={loading}
                className="flex-1"
              >
                {loading ? 'Creating...' : 'Create Restaurant'}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate('/restaurants')}
                className="flex-1"
              >
                Cancel
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

function RestaurantDetails() {
  const [restaurant, setRestaurant] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  // This would use useParams to get the restaurant ID
  // For now, we'll use a placeholder

  useEffect(() => {
    // Fetch restaurant details
    setLoading(false);
    setRestaurant({
      id: 1,
      name: 'Sample Restaurant',
      address: '123 Main St',
      phone: '555-1234',
      email: 'sample@restaurant.com',
      cuisine_type: 'Italian',
      status: 'active'
    });
  }, []);

  if (loading) {
    return <div className="text-center py-8">Loading restaurant details...</div>;
  }

  if (!restaurant) {
    return <div className="text-center py-8">Restaurant not found</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button variant="outline" onClick={() => navigate('/restaurants')}>
            ← Back
          </Button>
          <h1 className="text-3xl font-bold">{restaurant.name}</h1>
        </div>
        <div className="flex space-x-2">
          <Button data-testid="manage-menu-btn">Manage Menu</Button>
          <Button data-testid="create-order-btn">Create Order</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Restaurant Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div>
              <strong>Address:</strong> {restaurant.address}
            </div>
            <div>
              <strong>Phone:</strong> {restaurant.phone || 'N/A'}
            </div>
            <div>
              <strong>Email:</strong> {restaurant.email || 'N/A'}
            </div>
            <div>
              <strong>Cuisine Type:</strong> {restaurant.cuisine_type || 'N/A'}
            </div>
            <div>
              <strong>Status:</strong>{' '}
              <Badge variant={restaurant.status === 'active' ? 'default' : 'secondary'}>
                {restaurant.status}
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Quick Stats</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div>
              <strong>Menu Items:</strong> 15
            </div>
            <div>
              <strong>Orders Today:</strong> 23
            </div>
            <div>
              <strong>Revenue Today:</strong> $1,245.50
            </div>
            <div>
              <strong>Average Rating:</strong> 4.5/5
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export default RestaurantManagement;

