import { useState, useEffect, useCallback } from 'react';
import { useTelemetry } from '../contexts/TelemetryContext';

// Hook for tracking page views
export const usePageTracking = (pageName) => {
  const { trackPageView } = useTelemetry();
  
  useEffect(() => {
    trackPageView(pageName);
  }, [pageName, trackPageView]);
};

// Hook for tracking time on page
export const useTimeTracking = (pageName) => {
  const { trackTimeOnPage } = useTelemetry();
  const [startTime] = useState(Date.now());

  useEffect(() => {
    return () => {
      const timeSpent = Math.round((Date.now() - startTime) / 1000);
      trackTimeOnPage(pageName, timeSpent);
    };
  }, [pageName, startTime, trackTimeOnPage]);
};

// Hook for tracking form interactions
export const useFormTracking = (formName) => {
  const { trackFormError, trackFormSubmitted } = useTelemetry();
  const [startTime] = useState(Date.now());

  const trackError = useCallback((fieldName, errorType) => {
    trackFormError(formName, fieldName, errorType);
  }, [formName, trackFormError]);

  const trackSubmit = useCallback((fieldCount) => {
    const timeToComplete = Date.now() - startTime;
    trackFormSubmitted(formName, fieldCount, timeToComplete);
  }, [formName, startTime, trackFormSubmitted]);

  return { trackError, trackSubmit };
};

// Hook for tracking API calls
export const useAPITracking = () => {
  const { trackAPICall, trackError } = useTelemetry();

  const trackCall = useCallback(async (apiCall, endpoint, method = 'GET') => {
    const startTime = Date.now();
    
    try {
      const response = await apiCall();
      const responseTime = Date.now() - startTime;
      
      trackAPICall(endpoint, method, responseTime, response.status || 200);
      
      return response;
    } catch (error) {
      const responseTime = Date.now() - startTime;
      
      trackAPICall(endpoint, method, responseTime, error.status || 500);
      trackError('api_error', error.message, { endpoint, method });
      
      throw error;
    }
  }, [trackAPICall, trackError]);

  return { trackCall };
};

// Hook for tracking feature usage
export const useFeatureTracking = () => {
  const { trackFeatureUsed, getFeatureFlag } = useTelemetry();

  const trackUsage = useCallback((featureName, context = {}) => {
    trackFeatureUsed(featureName, context);
  }, [trackFeatureUsed]);

  const isEnabled = useCallback((flagName, defaultValue = false) => {
    return getFeatureFlag(flagName, defaultValue);
  }, [getFeatureFlag]);

  return { trackUsage, isEnabled };
};

// Hook for tracking button clicks
export const useButtonTracking = () => {
  const { trackButtonClicked } = useTelemetry();

  const trackClick = useCallback((buttonName, context = {}) => {
    trackButtonClicked(buttonName, context);
  }, [trackButtonClicked]);

  return { trackClick };
};

// Hook for tracking navigation
export const useNavigationTracking = () => {
  const { trackNavigationClicked } = useTelemetry();

  const trackNavigation = useCallback((fromPage, toPage, navigationElement) => {
    trackNavigationClicked(fromPage, toPage, navigationElement);
  }, [trackNavigationClicked]);

  return { trackNavigation };
};

// Hook for tracking search
export const useSearchTracking = () => {
  const { trackSearchPerformed } = useTelemetry();

  const trackSearch = useCallback((searchTerm, resultCount, searchContext) => {
    trackSearchPerformed(searchTerm, resultCount, searchContext);
  }, [trackSearchPerformed]);

  return { trackSearch };
};

// Hook for tracking performance metrics
export const usePerformanceTracking = () => {
  const { trackPerformanceMetric } = useTelemetry();

  const trackMetric = useCallback((metricName, value, context = {}) => {
    trackPerformanceMetric(metricName, value, context);
  }, [trackPerformanceMetric]);

  // Track Core Web Vitals
  useEffect(() => {
    // Track Largest Contentful Paint (LCP)
    const observer = new PerformanceObserver((list) => {
      const entries = list.getEntries();
      const lastEntry = entries[entries.length - 1];
      trackMetric('largest_contentful_paint', lastEntry.startTime);
    });
    
    try {
      observer.observe({ entryTypes: ['largest-contentful-paint'] });
    } catch (e) {
      // LCP not supported
    }

    // Track First Input Delay (FID)
    const fidObserver = new PerformanceObserver((list) => {
      const entries = list.getEntries();
      entries.forEach((entry) => {
        trackMetric('first_input_delay', entry.processingStart - entry.startTime);
      });
    });

    try {
      fidObserver.observe({ entryTypes: ['first-input'] });
    } catch (e) {
      // FID not supported
    }

    // Track Cumulative Layout Shift (CLS)
    let clsValue = 0;
    const clsObserver = new PerformanceObserver((list) => {
      const entries = list.getEntries();
      entries.forEach((entry) => {
        if (!entry.hadRecentInput) {
          clsValue += entry.value;
        }
      });
    });

    try {
      clsObserver.observe({ entryTypes: ['layout-shift'] });
    } catch (e) {
      // CLS not supported
    }

    // Track CLS on page unload
    const handleBeforeUnload = () => {
      trackMetric('cumulative_layout_shift', clsValue);
    };

    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      observer.disconnect();
      fidObserver.disconnect();
      clsObserver.disconnect();
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [trackMetric]);

  return { trackMetric };
};

// Hook for tracking user engagement
export const useEngagementTracking = () => {
  const { track } = useTelemetry();

  const trackEngagement = useCallback((eventName, properties = {}) => {
    track(eventName, properties);
  }, [track]);

  // Track scroll depth
  useEffect(() => {
    let maxScrollDepth = 0;
    const trackScrollDepth = () => {
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      const windowHeight = window.innerHeight;
      const documentHeight = document.documentElement.scrollHeight;
      
      const scrollDepth = Math.round((scrollTop + windowHeight) / documentHeight * 100);
      
      if (scrollDepth > maxScrollDepth) {
        maxScrollDepth = scrollDepth;
        
        // Track milestone scroll depths
        if (scrollDepth >= 25 && maxScrollDepth < 25) {
          trackEngagement('scroll_depth_25');
        } else if (scrollDepth >= 50 && maxScrollDepth < 50) {
          trackEngagement('scroll_depth_50');
        } else if (scrollDepth >= 75 && maxScrollDepth < 75) {
          trackEngagement('scroll_depth_75');
        } else if (scrollDepth >= 100 && maxScrollDepth < 100) {
          trackEngagement('scroll_depth_100');
        }
      }
    };

    const throttledTrackScrollDepth = throttle(trackScrollDepth, 1000);
    window.addEventListener('scroll', throttledTrackScrollDepth);

    return () => {
      window.removeEventListener('scroll', throttledTrackScrollDepth);
    };
  }, [trackEngagement]);

  return { trackEngagement };
};

// Utility function for throttling
function throttle(func, limit) {
  let inThrottle;
  return function() {
    const args = arguments;
    const context = this;
    if (!inThrottle) {
      func.apply(context, args);
      inThrottle = true;
      setTimeout(() => inThrottle = false, limit);
    }
  };
}

