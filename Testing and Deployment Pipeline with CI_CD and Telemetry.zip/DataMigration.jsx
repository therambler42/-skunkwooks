import React, { useState, useRef } from 'react';
import Papa from 'papaparse';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Upload, Download, FileText, CheckCircle, XCircle, AlertTriangle } from 'lucide-react';

const API_BASE_URL = 'http://localhost:5000/api';

function DataMigration() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Data Migration</h1>
      </div>

      <Tabs defaultValue="restaurants" className="space-y-4">
        <TabsList>
          <TabsTrigger value="restaurants">Restaurant Import</TabsTrigger>
          <TabsTrigger value="menu">Menu Import</TabsTrigger>
          <TabsTrigger value="history">Import History</TabsTrigger>
        </TabsList>

        <TabsContent value="restaurants">
          <RestaurantImport />
        </TabsContent>

        <TabsContent value="menu">
          <MenuImport />
        </TabsContent>

        <TabsContent value="history">
          <ImportHistory />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function RestaurantImport() {
  const [csvData, setCsvData] = useState([]);
  const [mappings, setMappings] = useState({});
  const [step, setStep] = useState(1); // 1: Upload, 2: Map, 3: Import
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState(null);
  const [template, setTemplate] = useState(null);
  const fileInputRef = useRef(null);

  React.useEffect(() => {
    fetchTemplate();
  }, []);

  const fetchTemplate = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/migration/template/restaurants`);
      const data = await response.json();
      setTemplate(data);
    } catch (error) {
      console.error('Error fetching template:', error);
    }
  };

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (!file) return;

    Papa.parse(file, {
      complete: (results) => {
        if (results.data && results.data.length > 0) {
          setCsvData(results.data);
          setStep(2);
          // Auto-map common field names
          const headers = results.data[0];
          const autoMappings = {};
          headers.forEach((header, index) => {
            const lowerHeader = header.toLowerCase();
            if (lowerHeader.includes('name')) autoMappings.name = index;
            if (lowerHeader.includes('address')) autoMappings.address = index;
            if (lowerHeader.includes('phone')) autoMappings.phone = index;
            if (lowerHeader.includes('email')) autoMappings.email = index;
            if (lowerHeader.includes('cuisine')) autoMappings.cuisine_type = index;
          });
          setMappings(autoMappings);
        }
      },
      header: false,
      skipEmptyLines: true,
    });
  };

  const downloadTemplate = () => {
    if (!template) return;
    
    const csv = Papa.unparse(template.template);
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'restaurant-template.csv';
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const handleImport = async () => {
    setImporting(true);
    
    try {
      // Convert CSV data to mapped format
      const headers = csvData[0];
      const rows = csvData.slice(1);
      
      const mappedData = rows.map(row => {
        const item = {};
        Object.entries(mappings).forEach(([field, columnIndex]) => {
          if (columnIndex !== undefined && columnIndex !== '') {
            item[field] = row[columnIndex] || '';
          }
        });
        return item;
      });

      // Create CSV from mapped data
      const csvContent = Papa.unparse(mappedData);
      const blob = new Blob([csvContent], { type: 'text/csv' });
      
      const formData = new FormData();
      formData.append('file', blob, 'restaurants.csv');

      const response = await fetch(`${API_BASE_URL}/migration/restaurants/import`, {
        method: 'POST',
        body: formData,
      });

      const result = await response.json();
      setImportResult(result);
      setStep(3);
    } catch (error) {
      setImportResult({
        success: false,
        imported_count: 0,
        errors: ['Network error: ' + error.message]
      });
      setStep(3);
    } finally {
      setImporting(false);
    }
  };

  const resetImport = () => {
    setCsvData([]);
    setMappings({});
    setStep(1);
    setImportResult(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  if (step === 1) {
    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Upload className="h-5 w-5 mr-2" />
              Upload Restaurant Data
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center border-2 border-dashed border-gray-300 rounded-lg p-8">
              <Upload className="mx-auto h-12 w-12 text-gray-400" />
              <div className="mt-4">
                <Label htmlFor="csv-file" className="cursor-pointer">
                  <span className="text-lg font-medium">Upload CSV File</span>
                  <Input
                    id="csv-file"
                    ref={fileInputRef}
                    type="file"
                    accept=".csv"
                    onChange={handleFileUpload}
                    className="hidden"
                    data-testid="csv-upload"
                  />
                </Label>
                <p className="text-sm text-gray-500 mt-2">
                  Select a CSV file containing restaurant data
                </p>
              </div>
            </div>

            <div className="flex justify-center">
              <Button onClick={downloadTemplate} variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Download Template
              </Button>
            </div>

            {template && (
              <Alert>
                <FileText className="h-4 w-4" />
                <AlertDescription>
                  <strong>Required fields:</strong> {template.required_fields.join(', ')}
                  <br />
                  <strong>Optional fields:</strong> {template.optional_fields.join(', ')}
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  if (step === 2) {
    const headers = csvData[0] || [];
    const sampleRow = csvData[1] || [];

    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Map CSV Columns</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                Map your CSV columns to the restaurant fields. Required fields must be mapped.
              </AlertDescription>
            </Alert>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {template && template.required_fields.concat(template.optional_fields).map(field => (
                <div key={field} className="space-y-2">
                  <Label>
                    {field} {template.required_fields.includes(field) && <span className="text-red-500">*</span>}
                  </Label>
                  <Select
                    value={mappings[field]?.toString() || ''}
                    onValueChange={(value) => setMappings(prev => ({
                      ...prev,
                      [field]: value === '' ? undefined : parseInt(value)
                    }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select column" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">-- Not mapped --</SelectItem>
                      {headers.map((header, index) => (
                        <SelectItem key={index} value={index.toString()}>
                          {header} (Sample: {sampleRow[index] || 'N/A'})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              ))}
            </div>

            <div className="flex space-x-4">
              <Button onClick={resetImport} variant="outline">
                Back
              </Button>
              <Button 
                onClick={handleImport} 
                disabled={importing || !template?.required_fields.every(field => mappings[field] !== undefined)}
                data-testid="import-btn"
              >
                {importing ? 'Importing...' : 'Import Data'}
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Preview Data</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  {headers.map((header, index) => (
                    <TableHead key={index}>{header}</TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {csvData.slice(1, 6).map((row, rowIndex) => (
                  <TableRow key={rowIndex}>
                    {row.map((cell, cellIndex) => (
                      <TableCell key={cellIndex}>{cell}</TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            {csvData.length > 6 && (
              <p className="text-sm text-gray-500 mt-2">
                Showing first 5 rows of {csvData.length - 1} total rows
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  if (step === 3) {
    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              {importResult?.success ? (
                <CheckCircle className="h-5 w-5 mr-2 text-green-500" />
              ) : (
                <XCircle className="h-5 w-5 mr-2 text-red-500" />
              )}
              Import Results
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">
                  {importResult?.imported_count || 0}
                </div>
                <div className="text-sm text-gray-500">Imported</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-red-600">
                  {importResult?.errors?.length || 0}
                </div>
                <div className="text-sm text-gray-500">Errors</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">
                  {(csvData.length - 1) || 0}
                </div>
                <div className="text-sm text-gray-500">Total Rows</div>
              </div>
            </div>

            {importResult?.errors && importResult.errors.length > 0 && (
              <div className="space-y-2">
                <h4 className="font-medium text-red-600">Errors:</h4>
                <div className="bg-red-50 border border-red-200 rounded-md p-3 max-h-40 overflow-y-auto">
                  {importResult.errors.map((error, index) => (
                    <div key={index} className="text-sm text-red-600">
                      {error}
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex space-x-4">
              <Button onClick={resetImport}>
                Import Another File
              </Button>
              <Button variant="outline" onClick={() => window.location.href = '/restaurants'}>
                View Restaurants
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return null;
}

function MenuImport() {
  // Similar implementation to RestaurantImport but for menu items
  return (
    <Card>
      <CardHeader>
        <CardTitle>Menu Import</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-gray-500">Menu import functionality coming soon...</p>
      </CardContent>
    </Card>
  );
}

function ImportHistory() {
  const [history] = useState([
    {
      id: 1,
      type: 'restaurants',
      filename: 'restaurants_2024.csv',
      imported_count: 15,
      error_count: 2,
      status: 'completed',
      created_at: '2024-01-15T10:30:00Z'
    },
    {
      id: 2,
      type: 'menu',
      filename: 'menu_items.csv',
      imported_count: 0,
      error_count: 5,
      status: 'failed',
      created_at: '2024-01-14T15:45:00Z'
    }
  ]);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Import History</CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Type</TableHead>
              <TableHead>Filename</TableHead>
              <TableHead>Imported</TableHead>
              <TableHead>Errors</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Date</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {history.map((item) => (
              <TableRow key={item.id}>
                <TableCell className="capitalize">{item.type}</TableCell>
                <TableCell>{item.filename}</TableCell>
                <TableCell>{item.imported_count}</TableCell>
                <TableCell>{item.error_count}</TableCell>
                <TableCell>
                  <Badge variant={item.status === 'completed' ? 'default' : 'destructive'}>
                    {item.status}
                  </Badge>
                </TableCell>
                <TableCell>
                  {new Date(item.created_at).toLocaleDateString()}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}

export default DataMigration;

