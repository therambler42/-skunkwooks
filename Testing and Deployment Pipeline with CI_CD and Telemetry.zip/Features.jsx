import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  ShoppingCart, 
  BarChart3, 
  Users, 
  Calendar, 
  CreditCard, 
  Smartphone,
  Cloud,
  Shield,
  Zap,
  Globe,
  HeadphonesIcon,
  TrendingUp
} from 'lucide-react';

const Features = () => {
  const features = [
    {
      icon: ShoppingCart,
      title: 'Smart POS System',
      description: 'Lightning-fast point of sale with offline capabilities, custom menus, and seamless payment processing.',
      color: 'from-blue-500 to-blue-600',
      badge: 'Core'
    },
    {
      icon: BarChart3,
      title: 'Advanced Analytics',
      description: 'Real-time insights into sales, inventory, customer behavior, and performance metrics.',
      color: 'from-purple-500 to-purple-600',
      badge: 'Intelligence'
    },
    {
      icon: Users,
      title: 'Customer Management',
      description: 'Build lasting relationships with loyalty programs, personalized offers, and customer insights.',
      color: 'from-green-500 to-green-600',
      badge: 'Growth'
    },
    {
      icon: Calendar,
      title: 'Table Reservations',
      description: 'Streamlined booking system with automated confirmations and waitlist management.',
      color: 'from-orange-500 to-orange-600',
      badge: 'Service'
    },
    {
      icon: CreditCard,
      title: 'Payment Processing',
      description: 'Accept all payment methods with secure, PCI-compliant processing and instant settlements.',
      color: 'from-pink-500 to-pink-600',
      badge: 'Payments'
    },
    {
      icon: Smartphone,
      title: 'Mobile App',
      description: 'Manage your restaurant on-the-go with our native iOS and Android applications.',
      color: 'from-indigo-500 to-indigo-600',
      badge: 'Mobile'
    },
    {
      icon: Cloud,
      title: 'Cloud Infrastructure',
      description: '99.9% uptime with automatic backups, real-time sync, and enterprise-grade security.',
      color: 'from-cyan-500 to-cyan-600',
      badge: 'Reliability'
    },
    {
      icon: Shield,
      title: 'Data Security',
      description: 'SOC 2 certified with end-to-end encryption, GDPR compliance, and regular security audits.',
      color: 'from-red-500 to-red-600',
      badge: 'Security'
    },
    {
      icon: Zap,
      title: 'API Integration',
      description: 'Connect with 100+ third-party services including delivery platforms and accounting software.',
      color: 'from-yellow-500 to-yellow-600',
      badge: 'Integration'
    },
    {
      icon: Globe,
      title: 'Multi-Location',
      description: 'Centralized management for restaurant chains with location-specific customization.',
      color: 'from-teal-500 to-teal-600',
      badge: 'Scale'
    },
    {
      icon: HeadphonesIcon,
      title: '24/7 Support',
      description: 'Round-the-clock expert support with 15-minute response time for critical issues.',
      color: 'from-violet-500 to-violet-600',
      badge: 'Support'
    },
    {
      icon: TrendingUp,
      title: 'Growth Tools',
      description: 'Marketing automation, promotional campaigns, and business intelligence to drive growth.',
      color: 'from-emerald-500 to-emerald-600',
      badge: 'Marketing'
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <section id="features" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <Badge className="mb-4 bg-gradient-to-r from-blue-100 to-purple-100 text-blue-700 border-blue-200">
            Complete Solution
          </Badge>
          <h2 className="text-3xl md:text-5xl font-bold text-gray-900 mb-6">
            Everything You Need to{' '}
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Succeed
            </span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            From point of sale to advanced analytics, our comprehensive platform provides 
            all the tools modern restaurants need to thrive in today's competitive market.
          </p>
        </motion.div>

        {/* Features Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {features.map((feature, index) => (
            <motion.div key={feature.title} variants={itemVariants}>
              <Card className="h-full group hover:shadow-xl transition-all duration-300 border-0 shadow-lg hover:-translate-y-2">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4">
                    <div className={`p-3 rounded-xl bg-gradient-to-r ${feature.color} shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                      <feature.icon className="h-6 w-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="text-lg font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">
                          {feature.title}
                        </h3>
                        <Badge variant="secondary" className="text-xs">
                          {feature.badge}
                        </Badge>
                      </div>
                      <p className="text-gray-600 leading-relaxed">
                        {feature.description}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          viewport={{ once: true }}
          className="text-center mt-16"
        >
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-8 border border-blue-100">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Ready to Transform Your Restaurant?
            </h3>
            <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
              Join thousands of successful restaurants already using RestaurantOS to 
              streamline operations and boost revenue.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-3 rounded-lg font-semibold shadow-lg hover:shadow-xl transition-all duration-200"
              >
                Start Free Trial
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="border-2 border-gray-300 text-gray-700 px-8 py-3 rounded-lg font-semibold hover:border-blue-500 hover:text-blue-600 transition-all duration-200"
              >
                Schedule Demo
              </motion.button>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Features;

