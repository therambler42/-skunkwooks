import pytest
import json
from src.models.restaurant import Restaurant, MenuItem, db

class TestMenuAPI:
    """Test cases for Menu API endpoints."""
    
    def setup_method(self):
        """Set up test data before each test."""
        pass
    
    def create_test_restaurant(self, client, sample_restaurant_data):
        """Helper method to create a test restaurant."""
        response = client.post('/api/restaurants/', 
                             data=json.dumps(sample_restaurant_data),
                             content_type='application/json')
        return response.json['id']
    
    def test_get_menu_items_empty(self, client, sample_restaurant_data):
        """Test getting menu items when none exist."""
        restaurant_id = self.create_test_restaurant(client, sample_restaurant_data)
        response = client.get(f'/api/menu/restaurant/{restaurant_id}')
        assert response.status_code == 200
        assert response.json == []
    
    def test_create_menu_item(self, client, sample_restaurant_data, sample_menu_item_data):
        """Test creating a new menu item."""
        restaurant_id = self.create_test_restaurant(client, sample_restaurant_data)
        sample_menu_item_data['restaurant_id'] = restaurant_id
        
        response = client.post('/api/menu/', 
                             data=json.dumps(sample_menu_item_data),
                             content_type='application/json')
        assert response.status_code == 201
        data = response.json
        assert data['name'] == sample_menu_item_data['name']
        assert data['price'] == sample_menu_item_data['price']
        assert data['restaurant_id'] == restaurant_id
    
    def test_get_menu_item_by_id(self, client, sample_restaurant_data, sample_menu_item_data):
        """Test getting a specific menu item by ID."""
        restaurant_id = self.create_test_restaurant(client, sample_restaurant_data)
        sample_menu_item_data['restaurant_id'] = restaurant_id
        
        # Create menu item
        create_response = client.post('/api/menu/', 
                                    data=json.dumps(sample_menu_item_data),
                                    content_type='application/json')
        item_id = create_response.json['id']
        
        # Get menu item by ID
        response = client.get(f'/api/menu/{item_id}')
        assert response.status_code == 200
        data = response.json
        assert data['id'] == item_id
        assert data['name'] == sample_menu_item_data['name']
    
    def test_update_menu_item(self, client, sample_restaurant_data, sample_menu_item_data):
        """Test updating a menu item."""
        restaurant_id = self.create_test_restaurant(client, sample_restaurant_data)
        sample_menu_item_data['restaurant_id'] = restaurant_id
        
        # Create menu item
        create_response = client.post('/api/menu/', 
                                    data=json.dumps(sample_menu_item_data),
                                    content_type='application/json')
        item_id = create_response.json['id']
        
        # Update menu item
        update_data = {'name': 'Updated Pizza', 'price': 18.99}
        response = client.put(f'/api/menu/{item_id}',
                            data=json.dumps(update_data),
                            content_type='application/json')
        assert response.status_code == 200
        data = response.json
        assert data['name'] == 'Updated Pizza'
        assert data['price'] == 18.99
    
    def test_delete_menu_item(self, client, sample_restaurant_data, sample_menu_item_data):
        """Test deleting a menu item."""
        restaurant_id = self.create_test_restaurant(client, sample_restaurant_data)
        sample_menu_item_data['restaurant_id'] = restaurant_id
        
        # Create menu item
        create_response = client.post('/api/menu/', 
                                    data=json.dumps(sample_menu_item_data),
                                    content_type='application/json')
        item_id = create_response.json['id']
        
        # Delete menu item
        response = client.delete(f'/api/menu/{item_id}')
        assert response.status_code == 200
        assert 'message' in response.json
        
        # Verify it's deleted
        get_response = client.get(f'/api/menu/{item_id}')
        assert get_response.status_code == 404
    
    def test_get_menu_items_by_restaurant(self, client, sample_restaurant_data, sample_menu_item_data):
        """Test getting all menu items for a restaurant."""
        restaurant_id = self.create_test_restaurant(client, sample_restaurant_data)
        
        # Create multiple menu items
        item1 = sample_menu_item_data.copy()
        item1['restaurant_id'] = restaurant_id
        item2 = sample_menu_item_data.copy()
        item2['restaurant_id'] = restaurant_id
        item2['name'] = 'Test Pasta'
        item2['category'] = 'Pasta'
        
        client.post('/api/menu/', 
                   data=json.dumps(item1),
                   content_type='application/json')
        client.post('/api/menu/', 
                   data=json.dumps(item2),
                   content_type='application/json')
        
        # Get all menu items for restaurant
        response = client.get(f'/api/menu/restaurant/{restaurant_id}')
        assert response.status_code == 200
        data = response.json
        assert len(data) == 2
        assert any(item['name'] == 'Test Pizza' for item in data)
        assert any(item['name'] == 'Test Pasta' for item in data)
    
    def test_menu_item_availability(self, client, sample_restaurant_data, sample_menu_item_data):
        """Test menu item availability toggle."""
        restaurant_id = self.create_test_restaurant(client, sample_restaurant_data)
        sample_menu_item_data['restaurant_id'] = restaurant_id
        
        # Create menu item
        create_response = client.post('/api/menu/', 
                                    data=json.dumps(sample_menu_item_data),
                                    content_type='application/json')
        item_id = create_response.json['id']
        
        # Update availability
        update_data = {'is_available': False}
        response = client.put(f'/api/menu/{item_id}',
                            data=json.dumps(update_data),
                            content_type='application/json')
        assert response.status_code == 200
        data = response.json
        assert data['is_available'] == False

