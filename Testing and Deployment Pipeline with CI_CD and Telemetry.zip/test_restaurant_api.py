import pytest
import json
from src.models.restaurant import Restaurant, db

class TestRestaurantAPI:
    """Test cases for Restaurant API endpoints."""
    
    def test_get_restaurants_empty(self, client):
        """Test getting restaurants when none exist."""
        response = client.get('/api/restaurants/')
        assert response.status_code == 200
        assert response.json == []
    
    def test_create_restaurant(self, client, sample_restaurant_data):
        """Test creating a new restaurant."""
        response = client.post('/api/restaurants/', 
                             data=json.dumps(sample_restaurant_data),
                             content_type='application/json')
        assert response.status_code == 201
        data = response.json
        assert data['name'] == sample_restaurant_data['name']
        assert data['address'] == sample_restaurant_data['address']
        assert data['id'] is not None
    
    def test_create_restaurant_missing_data(self, client):
        """Test creating restaurant with missing required data."""
        incomplete_data = {'name': 'Test Restaurant'}
        response = client.post('/api/restaurants/', 
                             data=json.dumps(incomplete_data),
                             content_type='application/json')
        assert response.status_code == 500  # Should fail due to missing address
    
    def test_get_restaurant_by_id(self, client, sample_restaurant_data):
        """Test getting a specific restaurant by ID."""
        # First create a restaurant
        create_response = client.post('/api/restaurants/', 
                                    data=json.dumps(sample_restaurant_data),
                                    content_type='application/json')
        restaurant_id = create_response.json['id']
        
        # Then get it by ID
        response = client.get(f'/api/restaurants/{restaurant_id}')
        assert response.status_code == 200
        data = response.json
        assert data['id'] == restaurant_id
        assert data['name'] == sample_restaurant_data['name']
    
    def test_get_nonexistent_restaurant(self, client):
        """Test getting a restaurant that doesn't exist."""
        response = client.get('/api/restaurants/999')
        assert response.status_code == 404
    
    def test_update_restaurant(self, client, sample_restaurant_data):
        """Test updating a restaurant."""
        # First create a restaurant
        create_response = client.post('/api/restaurants/', 
                                    data=json.dumps(sample_restaurant_data),
                                    content_type='application/json')
        restaurant_id = create_response.json['id']
        
        # Update the restaurant
        update_data = {'name': 'Updated Restaurant Name'}
        response = client.put(f'/api/restaurants/{restaurant_id}',
                            data=json.dumps(update_data),
                            content_type='application/json')
        assert response.status_code == 200
        data = response.json
        assert data['name'] == 'Updated Restaurant Name'
        assert data['address'] == sample_restaurant_data['address']  # Should remain unchanged
    
    def test_delete_restaurant(self, client, sample_restaurant_data):
        """Test deleting a restaurant."""
        # First create a restaurant
        create_response = client.post('/api/restaurants/', 
                                    data=json.dumps(sample_restaurant_data),
                                    content_type='application/json')
        restaurant_id = create_response.json['id']
        
        # Delete the restaurant
        response = client.delete(f'/api/restaurants/{restaurant_id}')
        assert response.status_code == 200
        assert 'message' in response.json
        
        # Verify it's deleted
        get_response = client.get(f'/api/restaurants/{restaurant_id}')
        assert get_response.status_code == 404
    
    def test_get_all_restaurants(self, client, sample_restaurant_data):
        """Test getting all restaurants."""
        # Create multiple restaurants
        restaurant1 = sample_restaurant_data.copy()
        restaurant2 = sample_restaurant_data.copy()
        restaurant2['name'] = 'Second Restaurant'
        restaurant2['address'] = '456 Second St'
        
        client.post('/api/restaurants/', 
                   data=json.dumps(restaurant1),
                   content_type='application/json')
        client.post('/api/restaurants/', 
                   data=json.dumps(restaurant2),
                   content_type='application/json')
        
        # Get all restaurants
        response = client.get('/api/restaurants/')
        assert response.status_code == 200
        data = response.json
        assert len(data) == 2
        assert any(r['name'] == 'Test Restaurant' for r in data)
        assert any(r['name'] == 'Second Restaurant' for r in data)

