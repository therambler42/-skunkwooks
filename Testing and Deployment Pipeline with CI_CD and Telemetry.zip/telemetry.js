import posthog from 'posthog-js';

class TelemetryService {
  constructor() {
    this.isInitialized = false;
    this.init();
  }

  init() {
    if (typeof window !== 'undefined' && !this.isInitialized) {
      // Initialize PostHog
      posthog.init(
        process.env.REACT_APP_POSTHOG_KEY || 'phc_test_key_placeholder',
        {
          api_host: process.env.REACT_APP_POSTHOG_HOST || 'https://app.posthog.com',
          // Enable session recording for UX analysis
          session_recording: {
            maskAllInputs: false,
            maskInputOptions: {
              password: true,
              email: false,
            },
          },
          // Capture pageviews automatically
          capture_pageview: true,
          // Enable feature flags
          bootstrap: {
            featureFlags: {},
          },
          // Privacy settings
          respect_dnt: true,
          opt_out_capturing_by_default: false,
        }
      );
      this.isInitialized = true;
    }
  }

  // User identification
  identify(userId, properties = {}) {
    if (this.isInitialized) {
      posthog.identify(userId, {
        ...properties,
        $set: {
          ...properties,
          last_seen: new Date().toISOString(),
        },
      });
    }
  }

  // Track page views
  trackPageView(pageName, properties = {}) {
    if (this.isInitialized) {
      posthog.capture('$pageview', {
        $current_url: window.location.href,
        page_name: pageName,
        ...properties,
      });
    }
  }

  // Restaurant management events
  trackRestaurantCreated(restaurantData) {
    this.track('restaurant_created', {
      restaurant_id: restaurantData.id,
      restaurant_name: restaurantData.name,
      cuisine_type: restaurantData.cuisine_type,
      has_phone: !!restaurantData.phone,
      has_email: !!restaurantData.email,
    });
  }

  trackRestaurantViewed(restaurantId) {
    this.track('restaurant_viewed', {
      restaurant_id: restaurantId,
    });
  }

  trackRestaurantUpdated(restaurantId, updatedFields) {
    this.track('restaurant_updated', {
      restaurant_id: restaurantId,
      updated_fields: updatedFields,
      field_count: Object.keys(updatedFields).length,
    });
  }

  trackRestaurantDeleted(restaurantId) {
    this.track('restaurant_deleted', {
      restaurant_id: restaurantId,
    });
  }

  // Menu management events
  trackMenuItemCreated(menuItemData) {
    this.track('menu_item_created', {
      restaurant_id: menuItemData.restaurant_id,
      menu_item_id: menuItemData.id,
      category: menuItemData.category,
      price: menuItemData.price,
      has_description: !!menuItemData.description,
    });
  }

  trackMenuItemUpdated(menuItemId, updatedFields) {
    this.track('menu_item_updated', {
      menu_item_id: menuItemId,
      updated_fields: updatedFields,
    });
  }

  // Order management events
  trackOrderCreated(orderData) {
    this.track('order_created', {
      restaurant_id: orderData.restaurant_id,
      order_id: orderData.id,
      order_type: orderData.order_type,
      total_amount: orderData.total_amount,
      item_count: orderData.items?.length || 0,
    });
  }

  trackOrderStatusChanged(orderId, oldStatus, newStatus) {
    this.track('order_status_changed', {
      order_id: orderId,
      old_status: oldStatus,
      new_status: newStatus,
    });
  }

  // Data migration events
  trackDataImportStarted(importType, fileName, rowCount) {
    this.track('data_import_started', {
      import_type: importType,
      file_name: fileName,
      row_count: rowCount,
    });
  }

  trackDataImportCompleted(importType, successCount, errorCount, duration) {
    this.track('data_import_completed', {
      import_type: importType,
      success_count: successCount,
      error_count: errorCount,
      duration_ms: duration,
      success_rate: successCount / (successCount + errorCount),
    });
  }

  trackFieldMappingChanged(importType, fieldName, columnIndex) {
    this.track('field_mapping_changed', {
      import_type: importType,
      field_name: fieldName,
      column_index: columnIndex,
    });
  }

  trackTemplateDownloaded(templateType) {
    this.track('template_downloaded', {
      template_type: templateType,
    });
  }

  // Analytics events
  trackAnalyticsViewed(restaurantId, timeRange) {
    this.track('analytics_viewed', {
      restaurant_id: restaurantId,
      time_range: timeRange,
    });
  }

  trackAnalyticsFilterChanged(filterType, filterValue) {
    this.track('analytics_filter_changed', {
      filter_type: filterType,
      filter_value: filterValue,
    });
  }

  // User experience events
  trackFormError(formName, fieldName, errorType) {
    this.track('form_error', {
      form_name: formName,
      field_name: fieldName,
      error_type: errorType,
    });
  }

  trackFormSubmitted(formName, fieldCount, timeToComplete) {
    this.track('form_submitted', {
      form_name: formName,
      field_count: fieldCount,
      time_to_complete_ms: timeToComplete,
    });
  }

  trackNavigationClicked(fromPage, toPage, navigationElement) {
    this.track('navigation_clicked', {
      from_page: fromPage,
      to_page: toPage,
      navigation_element: navigationElement,
    });
  }

  trackSearchPerformed(searchTerm, resultCount, searchContext) {
    this.track('search_performed', {
      search_term: searchTerm,
      result_count: resultCount,
      search_context: searchContext,
    });
  }

  trackFeatureUsed(featureName, context = {}) {
    this.track('feature_used', {
      feature_name: featureName,
      ...context,
    });
  }

  // Performance tracking
  trackPerformanceMetric(metricName, value, context = {}) {
    this.track('performance_metric', {
      metric_name: metricName,
      metric_value: value,
      ...context,
    });
  }

  trackAPICall(endpoint, method, responseTime, statusCode) {
    this.track('api_call', {
      endpoint,
      method,
      response_time_ms: responseTime,
      status_code: statusCode,
      success: statusCode >= 200 && statusCode < 300,
    });
  }

  // Error tracking
  trackError(errorType, errorMessage, context = {}) {
    this.track('error_occurred', {
      error_type: errorType,
      error_message: errorMessage,
      ...context,
    });
  }

  trackJavaScriptError(error, errorInfo) {
    this.track('javascript_error', {
      error_message: error.message,
      error_stack: error.stack,
      component_stack: errorInfo?.componentStack,
    });
  }

  // User engagement
  trackTimeOnPage(pageName, timeSpent) {
    this.track('time_on_page', {
      page_name: pageName,
      time_spent_seconds: timeSpent,
    });
  }

  trackButtonClicked(buttonName, context = {}) {
    this.track('button_clicked', {
      button_name: buttonName,
      ...context,
    });
  }

  // A/B testing support
  getFeatureFlag(flagName, defaultValue = false) {
    if (this.isInitialized) {
      return posthog.isFeatureEnabled(flagName) ?? defaultValue;
    }
    return defaultValue;
  }

  // User properties
  setUserProperty(key, value) {
    if (this.isInitialized) {
      posthog.people.set({ [key]: value });
    }
  }

  // Session management
  startSession() {
    this.track('session_started', {
      timestamp: new Date().toISOString(),
      user_agent: navigator.userAgent,
      screen_resolution: `${screen.width}x${screen.height}`,
      viewport_size: `${window.innerWidth}x${window.innerHeight}`,
    });
  }

  endSession() {
    this.track('session_ended', {
      timestamp: new Date().toISOString(),
    });
  }

  // Generic event tracking
  track(eventName, properties = {}) {
    if (this.isInitialized) {
      posthog.capture(eventName, {
        ...properties,
        timestamp: new Date().toISOString(),
        page_url: window.location.href,
        page_title: document.title,
      });
    }
  }

  // Utility methods
  reset() {
    if (this.isInitialized) {
      posthog.reset();
    }
  }

  optOut() {
    if (this.isInitialized) {
      posthog.opt_out_capturing();
    }
  }

  optIn() {
    if (this.isInitialized) {
      posthog.opt_in_capturing();
    }
  }
}

// Create singleton instance
const telemetryService = new TelemetryService();

export default telemetryService;

