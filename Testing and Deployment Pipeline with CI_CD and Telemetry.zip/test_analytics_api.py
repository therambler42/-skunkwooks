import pytest
import json
from src.models.restaurant import Restaurant, MenuItem, Order, OrderItem, db
from datetime import datetime, timedelta

class TestAnalyticsAPI:
    """Test cases for Analytics API endpoints."""
    
    def create_test_data(self, client):
        """Helper method to create test data for analytics."""
        # Create restaurant
        restaurant_data = {
            'name': 'Analytics Test Restaurant',
            'address': '123 Analytics St',
            'phone': '555-1234',
            'email': 'analytics@test.com',
            'cuisine_type': 'Test'
        }
        restaurant_response = client.post('/api/restaurants/', 
                                        data=json.dumps(restaurant_data),
                                        content_type='application/json')
        restaurant_id = restaurant_response.json['id']
        
        # Create menu items
        menu_item1 = {
            'restaurant_id': restaurant_id,
            'name': 'Test Pizza',
            'price': 15.99,
            'category': 'Pizza'
        }
        menu_item2 = {
            'restaurant_id': restaurant_id,
            'name': 'Test Salad',
            'price': 9.99,
            'category': 'Salad'
        }
        
        menu1_response = client.post('/api/menu/', 
                                   data=json.dumps(menu_item1),
                                   content_type='application/json')
        menu2_response = client.post('/api/menu/', 
                                   data=json.dumps(menu_item2),
                                   content_type='application/json')
        
        menu_item1_id = menu1_response.json['id']
        menu_item2_id = menu2_response.json['id']
        
        # Create orders
        order1 = {
            'restaurant_id': restaurant_id,
            'customer_name': 'Customer 1',
            'total_amount': 31.98,
            'status': 'delivered',
            'items': [
                {'menu_item_id': menu_item1_id, 'quantity': 2, 'unit_price': 15.99}
            ]
        }
        
        order2 = {
            'restaurant_id': restaurant_id,
            'customer_name': 'Customer 2',
            'total_amount': 25.98,
            'status': 'delivered',
            'items': [
                {'menu_item_id': menu_item1_id, 'quantity': 1, 'unit_price': 15.99},
                {'menu_item_id': menu_item2_id, 'quantity': 1, 'unit_price': 9.99}
            ]
        }
        
        order3 = {
            'restaurant_id': restaurant_id,
            'customer_name': 'Customer 3',
            'total_amount': 15.99,
            'status': 'cancelled',
            'items': [
                {'menu_item_id': menu_item1_id, 'quantity': 1, 'unit_price': 15.99}
            ]
        }
        
        client.post('/api/orders/', data=json.dumps(order1), content_type='application/json')
        client.post('/api/orders/', data=json.dumps(order2), content_type='application/json')
        client.post('/api/orders/', data=json.dumps(order3), content_type='application/json')
        
        return restaurant_id
    
    def test_get_dashboard_analytics(self, client):
        """Test getting dashboard analytics."""
        restaurant_id = self.create_test_data(client)
        
        response = client.get(f'/api/analytics/restaurant/{restaurant_id}/dashboard')
        assert response.status_code == 200
        data = response.json
        
        # Check required fields
        assert 'total_orders' in data
        assert 'total_revenue' in data
        assert 'avg_order_value' in data
        assert 'orders_by_status' in data
        assert 'popular_items' in data
        assert 'daily_revenue' in data
        
        # Verify calculations
        assert data['total_orders'] == 3
        assert data['total_revenue'] == 57.96  # Only delivered orders
        assert data['avg_order_value'] == 28.98  # 57.96 / 2 delivered orders
    
    def test_get_dashboard_analytics_with_date_filter(self, client):
        """Test getting dashboard analytics with date filter."""
        restaurant_id = self.create_test_data(client)
        
        response = client.get(f'/api/analytics/restaurant/{restaurant_id}/dashboard?days=7')
        assert response.status_code == 200
        data = response.json
        
        # Should still return data since test orders are recent
        assert data['total_orders'] >= 0
        assert 'total_revenue' in data
    
    def test_get_performance_metrics(self, client):
        """Test getting performance metrics."""
        restaurant_id = self.create_test_data(client)
        
        response = client.get(f'/api/analytics/restaurant/{restaurant_id}/performance')
        assert response.status_code == 200
        data = response.json
        
        # Check required fields
        assert 'fulfillment_rate' in data
        assert 'avg_preparation_time' in data
        assert 'customer_satisfaction' in data
        assert 'total_orders' in data
        assert 'completed_orders' in data
        
        # Verify calculations
        assert data['total_orders'] == 3
        assert data['completed_orders'] == 2  # Only delivered orders
        assert data['fulfillment_rate'] == 66.67  # 2/3 * 100
    
    def test_get_performance_metrics_with_date_filter(self, client):
        """Test getting performance metrics with date filter."""
        restaurant_id = self.create_test_data(client)
        
        response = client.get(f'/api/analytics/restaurant/{restaurant_id}/performance?days=1')
        assert response.status_code == 200
        data = response.json
        
        # Should return metrics even with short date range
        assert 'fulfillment_rate' in data
        assert 'total_orders' in data
    
    def test_analytics_empty_restaurant(self, client, sample_restaurant_data):
        """Test analytics for restaurant with no orders."""
        # Create restaurant without orders
        restaurant_response = client.post('/api/restaurants/', 
                                        data=json.dumps(sample_restaurant_data),
                                        content_type='application/json')
        restaurant_id = restaurant_response.json['id']
        
        # Test dashboard analytics
        response = client.get(f'/api/analytics/restaurant/{restaurant_id}/dashboard')
        assert response.status_code == 200
        data = response.json
        assert data['total_orders'] == 0
        assert data['total_revenue'] == 0
        assert data['avg_order_value'] == 0
        
        # Test performance metrics
        response = client.get(f'/api/analytics/restaurant/{restaurant_id}/performance')
        assert response.status_code == 200
        data = response.json
        assert data['total_orders'] == 0
        assert data['completed_orders'] == 0
        assert data['fulfillment_rate'] == 0
    
    def test_analytics_nonexistent_restaurant(self, client):
        """Test analytics for nonexistent restaurant."""
        response = client.get('/api/analytics/restaurant/999/dashboard')
        assert response.status_code == 200  # Should not fail, just return empty data
        
        response = client.get('/api/analytics/restaurant/999/performance')
        assert response.status_code == 200  # Should not fail, just return empty data

