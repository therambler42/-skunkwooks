from flask import Blueprint, request, jsonify
import csv
import io
from src.models.restaurant import db, Restaurant, MenuItem

migration_bp = Blueprint('migration', __name__)

@migration_bp.route('/restaurants/import', methods=['POST'])
def import_restaurants():
    """Import restaurants from CSV"""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        # Read CSV content
        stream = io.StringIO(file.stream.read().decode("UTF8"), newline=None)
        csv_input = csv.DictReader(stream)
        
        imported_count = 0
        errors = []
        
        for row_num, row in enumerate(csv_input, start=2):
            try:
                # Validate required fields
                if not row.get('name') or not row.get('address'):
                    errors.append(f"Row {row_num}: Missing required fields (name, address)")
                    continue
                
                restaurant = Restaurant(
                    name=row.get('name'),
                    address=row.get('address'),
                    phone=row.get('phone'),
                    email=row.get('email'),
                    cuisine_type=row.get('cuisine_type')
                )
                
                db.session.add(restaurant)
                imported_count += 1
                
            except Exception as e:
                errors.append(f"Row {row_num}: {str(e)}")
        
        if imported_count > 0:
            db.session.commit()
        else:
            db.session.rollback()
        
        return jsonify({
            'imported_count': imported_count,
            'errors': errors,
            'success': imported_count > 0
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@migration_bp.route('/menu/import', methods=['POST'])
def import_menu_items():
    """Import menu items from CSV"""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        # Read CSV content
        stream = io.StringIO(file.stream.read().decode("UTF8"), newline=None)
        csv_input = csv.DictReader(stream)
        
        imported_count = 0
        errors = []
        
        for row_num, row in enumerate(csv_input, start=2):
            try:
                # Validate required fields
                if not row.get('restaurant_id') or not row.get('name') or not row.get('price'):
                    errors.append(f"Row {row_num}: Missing required fields (restaurant_id, name, price)")
                    continue
                
                # Check if restaurant exists
                restaurant_id = int(row.get('restaurant_id'))
                restaurant = Restaurant.query.get(restaurant_id)
                if not restaurant:
                    errors.append(f"Row {row_num}: Restaurant with ID {restaurant_id} not found")
                    continue
                
                menu_item = MenuItem(
                    restaurant_id=restaurant_id,
                    name=row.get('name'),
                    description=row.get('description'),
                    price=float(row.get('price')),
                    category=row.get('category'),
                    is_available=row.get('is_available', 'true').lower() == 'true'
                )
                
                db.session.add(menu_item)
                imported_count += 1
                
            except Exception as e:
                errors.append(f"Row {row_num}: {str(e)}")
        
        if imported_count > 0:
            db.session.commit()
        else:
            db.session.rollback()
        
        return jsonify({
            'imported_count': imported_count,
            'errors': errors,
            'success': imported_count > 0
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@migration_bp.route('/template/restaurants', methods=['GET'])
def get_restaurant_template():
    """Get CSV template for restaurant import"""
    template_data = [
        {
            'name': 'Sample Restaurant',
            'address': '123 Main St, City, State 12345',
            'phone': '+1-555-123-4567',
            'email': 'contact@samplerestaurant.com',
            'cuisine_type': 'Italian'
        }
    ]
    
    return jsonify({
        'template': template_data,
        'required_fields': ['name', 'address'],
        'optional_fields': ['phone', 'email', 'cuisine_type']
    })

@migration_bp.route('/template/menu', methods=['GET'])
def get_menu_template():
    """Get CSV template for menu import"""
    template_data = [
        {
            'restaurant_id': '1',
            'name': 'Margherita Pizza',
            'description': 'Classic pizza with tomato sauce, mozzarella, and basil',
            'price': '12.99',
            'category': 'Pizza',
            'is_available': 'true'
        }
    ]
    
    return jsonify({
        'template': template_data,
        'required_fields': ['restaurant_id', 'name', 'price'],
        'optional_fields': ['description', 'category', 'is_available']
    })

