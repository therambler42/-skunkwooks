import os
import posthog
from datetime import datetime
from functools import wraps
import time
import traceback

class TelemetryService:
    def __init__(self):
        self.posthog_key = os.getenv('POSTHOG_KEY', 'phc_test_key_placeholder')
        self.posthog_host = os.getenv('POSTHOG_HOST', 'https://app.posthog.com')
        self.is_enabled = os.getenv('TELEMETRY_ENABLED', 'true').lower() == 'true'
        
        if self.is_enabled:
            posthog.api_key = self.posthog_key
            posthog.host = self.posthog_host

    def track(self, user_id, event_name, properties=None):
        """Track an event with PostHog"""
        if not self.is_enabled:
            return
            
        if properties is None:
            properties = {}
            
        # Add common properties
        properties.update({
            'timestamp': datetime.utcnow().isoformat(),
            'environment': os.getenv('ENVIRONMENT', 'development'),
            'service': 'restaurant-management-backend'
        })
        
        try:
            posthog.capture(
                distinct_id=user_id or 'anonymous',
                event=event_name,
                properties=properties
            )
        except Exception as e:
            # Don't let telemetry errors break the application
            print(f"Telemetry error: {e}")

    def identify(self, user_id, properties=None):
        """Identify a user with PostHog"""
        if not self.is_enabled:
            return
            
        if properties is None:
            properties = {}
            
        try:
            posthog.identify(
                distinct_id=user_id,
                properties=properties
            )
        except Exception as e:
            print(f"Telemetry identify error: {e}")

    # Restaurant events
    def track_restaurant_created(self, user_id, restaurant_data):
        self.track(user_id, 'restaurant_created_backend', {
            'restaurant_id': restaurant_data.get('id'),
            'restaurant_name': restaurant_data.get('name'),
            'cuisine_type': restaurant_data.get('cuisine_type'),
            'has_phone': bool(restaurant_data.get('phone')),
            'has_email': bool(restaurant_data.get('email')),
        })

    def track_restaurant_updated(self, user_id, restaurant_id, updated_fields):
        self.track(user_id, 'restaurant_updated_backend', {
            'restaurant_id': restaurant_id,
            'updated_fields': list(updated_fields.keys()),
            'field_count': len(updated_fields),
        })

    def track_restaurant_deleted(self, user_id, restaurant_id):
        self.track(user_id, 'restaurant_deleted_backend', {
            'restaurant_id': restaurant_id,
        })

    # Menu events
    def track_menu_item_created(self, user_id, menu_item_data):
        self.track(user_id, 'menu_item_created_backend', {
            'restaurant_id': menu_item_data.get('restaurant_id'),
            'menu_item_id': menu_item_data.get('id'),
            'category': menu_item_data.get('category'),
            'price': float(menu_item_data.get('price', 0)),
            'has_description': bool(menu_item_data.get('description')),
        })

    def track_menu_item_updated(self, user_id, menu_item_id, updated_fields):
        self.track(user_id, 'menu_item_updated_backend', {
            'menu_item_id': menu_item_id,
            'updated_fields': list(updated_fields.keys()),
        })

    # Order events
    def track_order_created(self, user_id, order_data):
        self.track(user_id, 'order_created_backend', {
            'restaurant_id': order_data.get('restaurant_id'),
            'order_id': order_data.get('id'),
            'order_type': order_data.get('order_type'),
            'total_amount': float(order_data.get('total_amount', 0)),
            'item_count': len(order_data.get('items', [])),
        })

    def track_order_status_changed(self, user_id, order_id, old_status, new_status):
        self.track(user_id, 'order_status_changed_backend', {
            'order_id': order_id,
            'old_status': old_status,
            'new_status': new_status,
        })

    # Data migration events
    def track_data_import_started(self, user_id, import_type, file_name, row_count):
        self.track(user_id, 'data_import_started_backend', {
            'import_type': import_type,
            'file_name': file_name,
            'row_count': row_count,
        })

    def track_data_import_completed(self, user_id, import_type, success_count, error_count, duration):
        self.track(user_id, 'data_import_completed_backend', {
            'import_type': import_type,
            'success_count': success_count,
            'error_count': error_count,
            'duration_ms': duration,
            'success_rate': success_count / (success_count + error_count) if (success_count + error_count) > 0 else 0,
        })

    # API events
    def track_api_request(self, user_id, endpoint, method, status_code, response_time):
        self.track(user_id, 'api_request', {
            'endpoint': endpoint,
            'method': method,
            'status_code': status_code,
            'response_time_ms': response_time,
            'success': 200 <= status_code < 300,
        })

    def track_api_error(self, user_id, endpoint, method, error_type, error_message):
        self.track(user_id, 'api_error', {
            'endpoint': endpoint,
            'method': method,
            'error_type': error_type,
            'error_message': error_message,
        })

    # Analytics events
    def track_analytics_query(self, user_id, restaurant_id, query_type, time_range):
        self.track(user_id, 'analytics_query_backend', {
            'restaurant_id': restaurant_id,
            'query_type': query_type,
            'time_range': time_range,
        })

    # Database events
    def track_database_operation(self, user_id, operation, table, record_count, duration):
        self.track(user_id, 'database_operation', {
            'operation': operation,
            'table': table,
            'record_count': record_count,
            'duration_ms': duration,
        })

    # Performance events
    def track_performance_metric(self, user_id, metric_name, value, context=None):
        properties = {
            'metric_name': metric_name,
            'metric_value': value,
        }
        if context:
            properties.update(context)
        
        self.track(user_id, 'performance_metric_backend', properties)

    # Error tracking
    def track_error(self, user_id, error_type, error_message, context=None):
        properties = {
            'error_type': error_type,
            'error_message': error_message,
            'traceback': traceback.format_exc(),
        }
        if context:
            properties.update(context)
        
        self.track(user_id, 'error_backend', properties)

# Create singleton instance
telemetry_service = TelemetryService()

# Decorator for tracking API endpoints
def track_api_call(endpoint_name=None):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            start_time = time.time()
            user_id = kwargs.get('user_id', 'anonymous')
            endpoint = endpoint_name or func.__name__
            
            try:
                result = func(*args, **kwargs)
                response_time = (time.time() - start_time) * 1000
                
                # Determine status code from result
                status_code = 200
                if hasattr(result, 'status_code'):
                    status_code = result.status_code
                elif isinstance(result, tuple) and len(result) == 2:
                    status_code = result[1]
                
                telemetry_service.track_api_request(
                    user_id, endpoint, 'POST', status_code, response_time
                )
                
                return result
                
            except Exception as e:
                response_time = (time.time() - start_time) * 1000
                telemetry_service.track_api_error(
                    user_id, endpoint, 'POST', type(e).__name__, str(e)
                )
                telemetry_service.track_api_request(
                    user_id, endpoint, 'POST', 500, response_time
                )
                raise
                
        return wrapper
    return decorator

# Decorator for tracking database operations
def track_db_operation(operation_name, table_name):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            start_time = time.time()
            user_id = kwargs.get('user_id', 'anonymous')
            
            try:
                result = func(*args, **kwargs)
                duration = (time.time() - start_time) * 1000
                
                # Try to determine record count
                record_count = 1
                if hasattr(result, '__len__'):
                    record_count = len(result)
                elif hasattr(result, 'rowcount'):
                    record_count = result.rowcount
                
                telemetry_service.track_database_operation(
                    user_id, operation_name, table_name, record_count, duration
                )
                
                return result
                
            except Exception as e:
                duration = (time.time() - start_time) * 1000
                telemetry_service.track_error(
                    user_id, 'database_error', str(e), {
                        'operation': operation_name,
                        'table': table_name,
                        'duration_ms': duration,
                    }
                )
                raise
                
        return wrapper
    return decorator

