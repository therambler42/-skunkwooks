from flask import Blueprint, request, jsonify
from sqlalchemy import func, desc
from src.models.restaurant import db, Restaurant, Order, MenuItem, OrderItem
from datetime import datetime, timedelta

analytics_bp = Blueprint('analytics', __name__)

@analytics_bp.route('/restaurant/<int:restaurant_id>/dashboard', methods=['GET'])
def get_dashboard_analytics(restaurant_id):
    """Get dashboard analytics for a restaurant"""
    try:
        # Get date range from query params
        days = request.args.get('days', 30, type=int)
        start_date = datetime.now() - timedelta(days=days)
        
        # Total orders
        total_orders = Order.query.filter(
            Order.restaurant_id == restaurant_id,
            Order.created_at >= start_date
        ).count()
        
        # Total revenue
        total_revenue = db.session.query(func.sum(Order.total_amount)).filter(
            Order.restaurant_id == restaurant_id,
            Order.created_at >= start_date,
            Order.status != 'cancelled'
        ).scalar() or 0
        
        # Average order value
        avg_order_value = (total_revenue / total_orders) if total_orders > 0 else 0
        
        # Orders by status
        orders_by_status = db.session.query(
            Order.status,
            func.count(Order.id).label('count')
        ).filter(
            Order.restaurant_id == restaurant_id,
            Order.created_at >= start_date
        ).group_by(Order.status).all()
        
        # Popular menu items
        popular_items = db.session.query(
            MenuItem.name,
            func.sum(OrderItem.quantity).label('total_quantity')
        ).join(
            OrderItem, MenuItem.id == OrderItem.menu_item_id
        ).join(
            Order, Order.id == OrderItem.order_id
        ).filter(
            MenuItem.restaurant_id == restaurant_id,
            Order.created_at >= start_date,
            Order.status != 'cancelled'
        ).group_by(MenuItem.name).order_by(desc('total_quantity')).limit(10).all()
        
        # Daily revenue trend
        daily_revenue = db.session.query(
            func.date(Order.created_at).label('date'),
            func.sum(Order.total_amount).label('revenue')
        ).filter(
            Order.restaurant_id == restaurant_id,
            Order.created_at >= start_date,
            Order.status != 'cancelled'
        ).group_by(func.date(Order.created_at)).order_by('date').all()
        
        return jsonify({
            'total_orders': total_orders,
            'total_revenue': float(total_revenue),
            'avg_order_value': float(avg_order_value),
            'orders_by_status': [{'status': status, 'count': count} for status, count in orders_by_status],
            'popular_items': [{'name': name, 'quantity': int(quantity)} for name, quantity in popular_items],
            'daily_revenue': [{'date': date.isoformat(), 'revenue': float(revenue)} for date, revenue in daily_revenue]
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@analytics_bp.route('/restaurant/<int:restaurant_id>/performance', methods=['GET'])
def get_performance_metrics(restaurant_id):
    """Get performance metrics for a restaurant"""
    try:
        # Get date range from query params
        days = request.args.get('days', 30, type=int)
        start_date = datetime.now() - timedelta(days=days)
        
        # Order fulfillment rate
        total_orders = Order.query.filter(
            Order.restaurant_id == restaurant_id,
            Order.created_at >= start_date
        ).count()
        
        completed_orders = Order.query.filter(
            Order.restaurant_id == restaurant_id,
            Order.created_at >= start_date,
            Order.status == 'delivered'
        ).count()
        
        fulfillment_rate = (completed_orders / total_orders * 100) if total_orders > 0 else 0
        
        # Average preparation time (mock data for now)
        avg_prep_time = 25  # minutes
        
        # Customer satisfaction (mock data for now)
        customer_satisfaction = 4.2  # out of 5
        
        return jsonify({
            'fulfillment_rate': round(fulfillment_rate, 2),
            'avg_preparation_time': avg_prep_time,
            'customer_satisfaction': customer_satisfaction,
            'total_orders': total_orders,
            'completed_orders': completed_orders
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

