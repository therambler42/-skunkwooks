from flask import Blueprint, request, jsonify
from src.models.restaurant import db, Order, OrderItem

order_bp = Blueprint('order', __name__)

@order_bp.route('/restaurant/<int:restaurant_id>', methods=['GET'])
def get_orders(restaurant_id):
    """Get all orders for a restaurant"""
    try:
        orders = Order.query.filter_by(restaurant_id=restaurant_id).all()
        return jsonify([order.to_dict() for order in orders])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@order_bp.route('/<int:order_id>', methods=['GET'])
def get_order(order_id):
    """Get a specific order"""
    try:
        order = Order.query.get_or_404(order_id)
        return jsonify(order.to_dict())
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@order_bp.route('/', methods=['POST'])
def create_order():
    """Create a new order"""
    try:
        data = request.get_json()
        
        order = Order(
            restaurant_id=data.get('restaurant_id'),
            customer_name=data.get('customer_name'),
            customer_email=data.get('customer_email'),
            customer_phone=data.get('customer_phone'),
            total_amount=data.get('total_amount'),
            order_type=data.get('order_type', 'dine_in')
        )
        
        db.session.add(order)
        db.session.flush()  # Get the order ID
        
        # Add order items
        for item_data in data.get('items', []):
            order_item = OrderItem(
                order_id=order.id,
                menu_item_id=item_data.get('menu_item_id'),
                quantity=item_data.get('quantity'),
                unit_price=item_data.get('unit_price'),
                special_instructions=item_data.get('special_instructions')
            )
            db.session.add(order_item)
        
        db.session.commit()
        
        return jsonify(order.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@order_bp.route('/<int:order_id>', methods=['PUT'])
def update_order(order_id):
    """Update an order"""
    try:
        order = Order.query.get_or_404(order_id)
        data = request.get_json()
        
        order.status = data.get('status', order.status)
        order.customer_name = data.get('customer_name', order.customer_name)
        order.customer_email = data.get('customer_email', order.customer_email)
        order.customer_phone = data.get('customer_phone', order.customer_phone)
        
        db.session.commit()
        
        return jsonify(order.to_dict())
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@order_bp.route('/<int:order_id>/status', methods=['PUT'])
def update_order_status(order_id):
    """Update order status"""
    try:
        order = Order.query.get_or_404(order_id)
        data = request.get_json()
        
        order.status = data.get('status')
        db.session.commit()
        
        return jsonify(order.to_dict())
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

