import pytest
import json
from src.models.restaurant import Restaurant, MenuItem, Order, OrderItem, db

class TestOrderAPI:
    """Test cases for Order API endpoints."""
    
    def create_test_restaurant_and_menu(self, client, sample_restaurant_data, sample_menu_item_data):
        """Helper method to create test restaurant and menu item."""
        # Create restaurant
        restaurant_response = client.post('/api/restaurants/', 
                                        data=json.dumps(sample_restaurant_data),
                                        content_type='application/json')
        restaurant_id = restaurant_response.json['id']
        
        # Create menu item
        sample_menu_item_data['restaurant_id'] = restaurant_id
        menu_response = client.post('/api/menu/', 
                                  data=json.dumps(sample_menu_item_data),
                                  content_type='application/json')
        menu_item_id = menu_response.json['id']
        
        return restaurant_id, menu_item_id
    
    def test_get_orders_empty(self, client, sample_restaurant_data, sample_menu_item_data):
        """Test getting orders when none exist."""
        restaurant_id, _ = self.create_test_restaurant_and_menu(client, sample_restaurant_data, sample_menu_item_data)
        response = client.get(f'/api/orders/restaurant/{restaurant_id}')
        assert response.status_code == 200
        assert response.json == []
    
    def test_create_order(self, client, sample_restaurant_data, sample_menu_item_data, sample_order_data):
        """Test creating a new order."""
        restaurant_id, menu_item_id = self.create_test_restaurant_and_menu(client, sample_restaurant_data, sample_menu_item_data)
        
        # Update sample order data with correct IDs
        sample_order_data['restaurant_id'] = restaurant_id
        sample_order_data['items'][0]['menu_item_id'] = menu_item_id
        
        response = client.post('/api/orders/', 
                             data=json.dumps(sample_order_data),
                             content_type='application/json')
        assert response.status_code == 201
        data = response.json
        assert data['customer_name'] == sample_order_data['customer_name']
        assert data['total_amount'] == sample_order_data['total_amount']
        assert data['restaurant_id'] == restaurant_id
        assert len(data['items']) == 1
    
    def test_get_order_by_id(self, client, sample_restaurant_data, sample_menu_item_data, sample_order_data):
        """Test getting a specific order by ID."""
        restaurant_id, menu_item_id = self.create_test_restaurant_and_menu(client, sample_restaurant_data, sample_menu_item_data)
        
        # Update sample order data
        sample_order_data['restaurant_id'] = restaurant_id
        sample_order_data['items'][0]['menu_item_id'] = menu_item_id
        
        # Create order
        create_response = client.post('/api/orders/', 
                                    data=json.dumps(sample_order_data),
                                    content_type='application/json')
        order_id = create_response.json['id']
        
        # Get order by ID
        response = client.get(f'/api/orders/{order_id}')
        assert response.status_code == 200
        data = response.json
        assert data['id'] == order_id
        assert data['customer_name'] == sample_order_data['customer_name']
    
    def test_update_order_status(self, client, sample_restaurant_data, sample_menu_item_data, sample_order_data):
        """Test updating order status."""
        restaurant_id, menu_item_id = self.create_test_restaurant_and_menu(client, sample_restaurant_data, sample_menu_item_data)
        
        # Update sample order data
        sample_order_data['restaurant_id'] = restaurant_id
        sample_order_data['items'][0]['menu_item_id'] = menu_item_id
        
        # Create order
        create_response = client.post('/api/orders/', 
                                    data=json.dumps(sample_order_data),
                                    content_type='application/json')
        order_id = create_response.json['id']
        
        # Update order status
        status_data = {'status': 'confirmed'}
        response = client.put(f'/api/orders/{order_id}/status',
                            data=json.dumps(status_data),
                            content_type='application/json')
        assert response.status_code == 200
        data = response.json
        assert data['status'] == 'confirmed'
    
    def test_update_order(self, client, sample_restaurant_data, sample_menu_item_data, sample_order_data):
        """Test updating order details."""
        restaurant_id, menu_item_id = self.create_test_restaurant_and_menu(client, sample_restaurant_data, sample_menu_item_data)
        
        # Update sample order data
        sample_order_data['restaurant_id'] = restaurant_id
        sample_order_data['items'][0]['menu_item_id'] = menu_item_id
        
        # Create order
        create_response = client.post('/api/orders/', 
                                    data=json.dumps(sample_order_data),
                                    content_type='application/json')
        order_id = create_response.json['id']
        
        # Update order
        update_data = {'customer_name': 'Jane Doe', 'status': 'preparing'}
        response = client.put(f'/api/orders/{order_id}',
                            data=json.dumps(update_data),
                            content_type='application/json')
        assert response.status_code == 200
        data = response.json
        assert data['customer_name'] == 'Jane Doe'
        assert data['status'] == 'preparing'
    
    def test_get_orders_by_restaurant(self, client, sample_restaurant_data, sample_menu_item_data, sample_order_data):
        """Test getting all orders for a restaurant."""
        restaurant_id, menu_item_id = self.create_test_restaurant_and_menu(client, sample_restaurant_data, sample_menu_item_data)
        
        # Create multiple orders
        order1 = sample_order_data.copy()
        order1['restaurant_id'] = restaurant_id
        order1['items'][0]['menu_item_id'] = menu_item_id
        
        order2 = sample_order_data.copy()
        order2['restaurant_id'] = restaurant_id
        order2['customer_name'] = 'Jane Smith'
        order2['items'][0]['menu_item_id'] = menu_item_id
        
        client.post('/api/orders/', 
                   data=json.dumps(order1),
                   content_type='application/json')
        client.post('/api/orders/', 
                   data=json.dumps(order2),
                   content_type='application/json')
        
        # Get all orders for restaurant
        response = client.get(f'/api/orders/restaurant/{restaurant_id}')
        assert response.status_code == 200
        data = response.json
        assert len(data) == 2
        assert any(order['customer_name'] == 'John Doe' for order in data)
        assert any(order['customer_name'] == 'Jane Smith' for order in data)
    
    def test_order_with_multiple_items(self, client, sample_restaurant_data, sample_menu_item_data):
        """Test creating an order with multiple items."""
        restaurant_id, menu_item_id = self.create_test_restaurant_and_menu(client, sample_restaurant_data, sample_menu_item_data)
        
        # Create another menu item
        item2_data = sample_menu_item_data.copy()
        item2_data['name'] = 'Test Salad'
        item2_data['price'] = 8.99
        item2_data['category'] = 'Salad'
        menu2_response = client.post('/api/menu/', 
                                   data=json.dumps(item2_data),
                                   content_type='application/json')
        menu_item_id2 = menu2_response.json['id']
        
        # Create order with multiple items
        order_data = {
            'restaurant_id': restaurant_id,
            'customer_name': 'Multi Item Customer',
            'customer_email': 'multi@example.com',
            'total_amount': 33.97,
            'order_type': 'takeout',
            'items': [
                {
                    'menu_item_id': menu_item_id,
                    'quantity': 2,
                    'unit_price': 12.99,
                    'special_instructions': 'Extra cheese'
                },
                {
                    'menu_item_id': menu_item_id2,
                    'quantity': 1,
                    'unit_price': 8.99,
                    'special_instructions': 'Dressing on the side'
                }
            ]
        }
        
        response = client.post('/api/orders/', 
                             data=json.dumps(order_data),
                             content_type='application/json')
        assert response.status_code == 201
        data = response.json
        assert len(data['items']) == 2
        assert data['total_amount'] == 33.97

