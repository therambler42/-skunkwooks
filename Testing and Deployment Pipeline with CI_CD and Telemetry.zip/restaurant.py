from flask import Blueprint, request, jsonify
from src.models.restaurant import db, Restaurant

restaurant_bp = Blueprint('restaurant', __name__)

@restaurant_bp.route('/', methods=['GET'])
def get_restaurants():
    """Get all restaurants"""
    try:
        restaurants = Restaurant.query.all()
        return jsonify([restaurant.to_dict() for restaurant in restaurants])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@restaurant_bp.route('/<int:restaurant_id>', methods=['GET'])
def get_restaurant(restaurant_id):
    """Get a specific restaurant"""
    try:
        restaurant = Restaurant.query.get_or_404(restaurant_id)
        return jsonify(restaurant.to_dict())
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@restaurant_bp.route('/', methods=['POST'])
def create_restaurant():
    """Create a new restaurant"""
    try:
        data = request.get_json()
        
        restaurant = Restaurant(
            name=data.get('name'),
            address=data.get('address'),
            phone=data.get('phone'),
            email=data.get('email'),
            cuisine_type=data.get('cuisine_type')
        )
        
        db.session.add(restaurant)
        db.session.commit()
        
        return jsonify(restaurant.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@restaurant_bp.route('/<int:restaurant_id>', methods=['PUT'])
def update_restaurant(restaurant_id):
    """Update a restaurant"""
    try:
        restaurant = Restaurant.query.get_or_404(restaurant_id)
        data = request.get_json()
        
        restaurant.name = data.get('name', restaurant.name)
        restaurant.address = data.get('address', restaurant.address)
        restaurant.phone = data.get('phone', restaurant.phone)
        restaurant.email = data.get('email', restaurant.email)
        restaurant.cuisine_type = data.get('cuisine_type', restaurant.cuisine_type)
        restaurant.status = data.get('status', restaurant.status)
        
        db.session.commit()
        
        return jsonify(restaurant.to_dict())
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@restaurant_bp.route('/<int:restaurant_id>', methods=['DELETE'])
def delete_restaurant(restaurant_id):
    """Delete a restaurant"""
    try:
        restaurant = Restaurant.query.get_or_404(restaurant_id)
        db.session.delete(restaurant)
        db.session.commit()
        
        return jsonify({'message': 'Restaurant deleted successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

