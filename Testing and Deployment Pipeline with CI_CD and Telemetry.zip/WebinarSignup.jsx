import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Calendar, 
  Clock, 
  Users, 
  Video, 
  Gift, 
  CheckCircle,
  ArrowRight,
  Star,
  Play,
  TrendingUp,
  BarChart3
} from 'lucide-react';

const WebinarSignup = ({ fullPage = false }) => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    restaurant: '',
    phone: '',
    role: '',
    locations: ''
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Simulate form submission
    setTimeout(() => {
      setIsSubmitted(true);
    }, 1000);
  };

  const webinarDetails = {
    title: 'Restaurant Success Masterclass',
    subtitle: 'Transform Your Restaurant Operations in 2024',
    date: 'January 25, 2024',
    time: '2:00 PM EST',
    duration: '60 minutes',
    attendees: '2,847 registered'
  };

  const benefits = [
    {
      icon: TrendingUp,
      title: 'Increase Revenue by 35%',
      description: 'Learn proven strategies to boost sales and optimize pricing'
    },
    {
      icon: Clock,
      title: 'Save 20+ Hours Weekly',
      description: 'Automate operations and streamline your workflow'
    },
    {
      icon: Users,
      title: 'Improve Customer Satisfaction',
      description: 'Enhance service quality and build customer loyalty'
    },
    {
      icon: BarChart3,
      title: 'Data-Driven Decisions',
      description: 'Use analytics to make smarter business choices'
    }
  ];

  const agenda = [
    { time: '2:00 PM', topic: 'Welcome & Restaurant Industry Trends' },
    { time: '2:15 PM', topic: 'The 5 Pillars of Restaurant Success' },
    { time: '2:30 PM', topic: 'Technology Solutions That Actually Work' },
    { time: '2:45 PM', topic: 'Live Demo: RestaurantOS in Action' },
    { time: '3:00 PM', topic: 'Q&A Session with Industry Experts' }
  ];

  const speakers = [
    {
      name: 'Chef Michael Torres',
      role: 'Restaurant Consultant',
      experience: '20+ years',
      restaurants: '50+ successful launches'
    },
    {
      name: 'Sarah Kim',
      role: 'Operations Expert',
      experience: '15+ years',
      restaurants: 'Multi-location specialist'
    }
  ];

  if (isSubmitted) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        className={`${fullPage ? 'min-h-screen flex items-center' : 'py-20'} bg-gradient-to-br from-green-50 to-blue-50`}
      >
        <div className="max-w-2xl mx-auto px-4 text-center">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: 'spring' }}
            className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6"
          >
            <CheckCircle className="w-10 h-10 text-white" />
          </motion.div>
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            You're All Set! 🎉
          </h2>
          <p className="text-xl text-gray-600 mb-6">
            Thank you for registering for our Restaurant Success Masterclass. 
            We've sent a confirmation email with your calendar invite.
          </p>
          <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-200 mb-6">
            <h3 className="font-semibold text-gray-900 mb-2">What's Next?</h3>
            <ul className="text-left space-y-2 text-gray-600">
              <li className="flex items-center">
                <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                Check your email for the calendar invite
              </li>
              <li className="flex items-center">
                <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                Download our free Restaurant Success Guide
              </li>
              <li className="flex items-center">
                <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                Join 15 minutes early for networking
              </li>
            </ul>
          </div>
          <Button className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-3">
            Download Success Guide
          </Button>
        </div>
      </motion.div>
    );
  }

  return (
    <section className={`${fullPage ? 'min-h-screen pt-20' : 'py-20'} bg-gradient-to-br from-blue-50 via-white to-purple-50`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <Badge className="mb-4 bg-gradient-to-r from-red-100 to-orange-100 text-red-700 border-red-200">
            🔥 Limited Seats Available
          </Badge>
          <h2 className="text-3xl md:text-5xl font-bold text-gray-900 mb-6">
            {webinarDetails.title}
          </h2>
          <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-3xl mx-auto">
            {webinarDetails.subtitle}
          </p>
          
          {/* Webinar Details */}
          <div className="flex flex-wrap justify-center gap-6 mb-8">
            <div className="flex items-center space-x-2 bg-white px-4 py-2 rounded-lg shadow-md">
              <Calendar className="h-5 w-5 text-blue-600" />
              <span className="font-medium">{webinarDetails.date}</span>
            </div>
            <div className="flex items-center space-x-2 bg-white px-4 py-2 rounded-lg shadow-md">
              <Clock className="h-5 w-5 text-blue-600" />
              <span className="font-medium">{webinarDetails.time}</span>
            </div>
            <div className="flex items-center space-x-2 bg-white px-4 py-2 rounded-lg shadow-md">
              <Video className="h-5 w-5 text-blue-600" />
              <span className="font-medium">{webinarDetails.duration}</span>
            </div>
            <div className="flex items-center space-x-2 bg-white px-4 py-2 rounded-lg shadow-md">
              <Users className="h-5 w-5 text-blue-600" />
              <span className="font-medium">{webinarDetails.attendees}</span>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          {/* Left Column - Benefits & Agenda */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            {/* What You'll Learn */}
            <Card className="shadow-xl border-0">
              <CardHeader>
                <h3 className="text-2xl font-bold text-gray-900 flex items-center">
                  <Gift className="h-6 w-6 text-blue-600 mr-2" />
                  What You'll Learn
                </h3>
              </CardHeader>
              <CardContent className="space-y-4">
                {benefits.map((benefit, index) => (
                  <motion.div
                    key={benefit.title}
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    viewport={{ once: true }}
                    className="flex items-start space-x-3 p-3 rounded-lg hover:bg-blue-50 transition-colors"
                  >
                    <div className="p-2 bg-blue-100 rounded-lg">
                      <benefit.icon className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">{benefit.title}</h4>
                      <p className="text-gray-600 text-sm">{benefit.description}</p>
                    </div>
                  </motion.div>
                ))}
              </CardContent>
            </Card>

            {/* Agenda */}
            <Card className="shadow-xl border-0">
              <CardHeader>
                <h3 className="text-2xl font-bold text-gray-900">Agenda</h3>
              </CardHeader>
              <CardContent className="space-y-3">
                {agenda.map((item, index) => (
                  <div key={index} className="flex items-center space-x-3 p-2">
                    <div className="bg-blue-100 text-blue-700 px-3 py-1 rounded-lg text-sm font-medium">
                      {item.time}
                    </div>
                    <div className="text-gray-700">{item.topic}</div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Speakers */}
            <Card className="shadow-xl border-0">
              <CardHeader>
                <h3 className="text-2xl font-bold text-gray-900">Expert Speakers</h3>
              </CardHeader>
              <CardContent className="space-y-4">
                {speakers.map((speaker, index) => (
                  <div key={index} className="flex items-center space-x-4 p-3 bg-gray-50 rounded-lg">
                    <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white font-semibold">
                      {speaker.name.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">{speaker.name}</h4>
                      <p className="text-sm text-gray-600">{speaker.role}</p>
                      <p className="text-xs text-blue-600">{speaker.experience} • {speaker.restaurants}</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </motion.div>

          {/* Right Column - Registration Form */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <Card className="shadow-2xl border-0 sticky top-8">
              <CardHeader className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-t-lg">
                <div className="text-center">
                  <h3 className="text-2xl font-bold mb-2">Reserve Your Seat</h3>
                  <p className="opacity-90">Free Registration • Limited Spots</p>
                  <div className="mt-4 flex items-center justify-center space-x-2">
                    <Star className="h-4 w-4 fill-current" />
                    <span className="text-sm">4.9/5 from 1,200+ attendees</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <Input
                      name="firstName"
                      placeholder="First Name"
                      value={formData.firstName}
                      onChange={handleInputChange}
                      required
                      className="border-gray-300 focus:border-blue-500"
                    />
                    <Input
                      name="lastName"
                      placeholder="Last Name"
                      value={formData.lastName}
                      onChange={handleInputChange}
                      required
                      className="border-gray-300 focus:border-blue-500"
                    />
                  </div>
                  <Input
                    name="email"
                    type="email"
                    placeholder="Email Address"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                    className="border-gray-300 focus:border-blue-500"
                  />
                  <Input
                    name="restaurant"
                    placeholder="Restaurant Name"
                    value={formData.restaurant}
                    onChange={handleInputChange}
                    required
                    className="border-gray-300 focus:border-blue-500"
                  />
                  <Input
                    name="phone"
                    placeholder="Phone Number"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className="border-gray-300 focus:border-blue-500"
                  />
                  <select
                    name="role"
                    value={formData.role}
                    onChange={handleInputChange}
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:border-blue-500 focus:outline-none"
                  >
                    <option value="">Select Your Role</option>
                    <option value="owner">Owner</option>
                    <option value="manager">Manager</option>
                    <option value="chef">Chef</option>
                    <option value="other">Other</option>
                  </select>
                  <select
                    name="locations"
                    value={formData.locations}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:border-blue-500 focus:outline-none"
                  >
                    <option value="">Number of Locations</option>
                    <option value="1">1 Location</option>
                    <option value="2-5">2-5 Locations</option>
                    <option value="6-10">6-10 Locations</option>
                    <option value="10+">10+ Locations</option>
                  </select>
                  
                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white py-3 text-lg font-semibold shadow-lg hover:shadow-xl transition-all duration-200 group"
                  >
                    Reserve My Free Seat
                    <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </form>

                <div className="mt-6 text-center">
                  <p className="text-sm text-gray-600 mb-4">
                    🎁 <strong>Bonus:</strong> All attendees receive our exclusive 
                    "Restaurant Success Toolkit" (Value: $297)
                  </p>
                  <div className="flex items-center justify-center space-x-4 text-xs text-gray-500">
                    <span>✓ No spam, ever</span>
                    <span>✓ Unsubscribe anytime</span>
                    <span>✓ 100% free</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default WebinarSignup;

