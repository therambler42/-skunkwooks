import pytest
import sys
import os

# Add the src directory to the Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from src.main import app
from src.models.restaurant import db

@pytest.fixture
def client():
    """Create a test client for the Flask application."""
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    with app.test_client() as client:
        with app.app_context():
            db.create_all()
            yield client
            db.drop_all()

@pytest.fixture
def sample_restaurant_data():
    """Sample restaurant data for testing."""
    return {
        'name': 'Test Restaurant',
        'address': '123 Test St, Test City, TC 12345',
        'phone': '+1-555-123-4567',
        'email': 'test@testrestaurant.com',
        'cuisine_type': 'Italian'
    }

@pytest.fixture
def sample_menu_item_data():
    """Sample menu item data for testing."""
    return {
        'restaurant_id': 1,
        'name': 'Test Pizza',
        'description': 'A delicious test pizza',
        'price': 15.99,
        'category': 'Pizza',
        'is_available': True
    }

@pytest.fixture
def sample_order_data():
    """Sample order data for testing."""
    return {
        'restaurant_id': 1,
        'customer_name': 'John Doe',
        'customer_email': 'john@example.com',
        'customer_phone': '+1-555-987-6543',
        'total_amount': 25.99,
        'order_type': 'dine_in',
        'items': [
            {
                'menu_item_id': 1,
                'quantity': 2,
                'unit_price': 12.99,
                'special_instructions': 'Extra cheese'
            }
        ]
    }

