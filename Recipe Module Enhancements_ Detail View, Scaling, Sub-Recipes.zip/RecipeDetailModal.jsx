import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Clock, 
  Users, 
  DollarSign, 
  Scale, 
  GripVertical, 
  Plus, 
  Trash2,
  Edit,
  Save,
  X
} from 'lucide-react';
import IngredientBuilder from './IngredientBuilder';
import NutritionLabel from './NutritionLabel';

const API_BASE_URL = 'http://localhost:5000/api';

const RecipeDetailModal = ({ recipe, isOpen, onClose, onUpdate }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedRecipe, setEditedRecipe] = useState(recipe);
  const [scaledServings, setScaledServings] = useState(recipe.servings);
  const [scaledData, setScaledData] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setEditedRecipe(recipe);
    setScaledServings(recipe.servings);
    setScaledData(null);
  }, [recipe]);

  const handleSave = async () => {
    setLoading(true);
    try {
      const response = await fetch(`${API_BASE_URL}/recipes/${recipe.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...editedRecipe,
          updated_by: 'user'
        }),
      });

      if (response.ok) {
        setIsEditing(false);
        onUpdate();
      } else {
        console.error('Failed to update recipe');
      }
    } catch (error) {
      console.error('Error updating recipe:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleScale = async () => {
    if (scaledServings === recipe.servings) {
      setScaledData(null);
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`${API_BASE_URL}/recipes/${recipe.id}/scale`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ servings: scaledServings }),
      });

      if (response.ok) {
        const data = await response.json();
        setScaledData(data.scaled_recipe);
      } else {
        console.error('Failed to scale recipe');
      }
    } catch (error) {
      console.error('Error scaling recipe:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatTime = (minutes) => {
    if (!minutes) return 'N/A';
    if (minutes < 60) return `${minutes}m`;
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
  };

  const currentData = scaledData || recipe;
  const currentServings = scaledData ? scaledServings : recipe.servings;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex justify-between items-start">
            <div className="flex-1">
              {isEditing ? (
                <Input
                  value={editedRecipe.name}
                  onChange={(e) => setEditedRecipe({ ...editedRecipe, name: e.target.value })}
                  className="text-xl font-bold"
                />
              ) : (
                <DialogTitle className="text-2xl font-bold">{recipe.name}</DialogTitle>
              )}
              {recipe.is_sub_recipe && (
                <Badge variant="secondary" className="mt-2">Sub-recipe</Badge>
              )}
            </div>
            <div className="flex items-center space-x-2">
              {isEditing ? (
                <>
                  <Button size="sm" onClick={handleSave} disabled={loading}>
                    <Save className="h-4 w-4 mr-1" />
                    Save
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => setIsEditing(false)}>
                    <X className="h-4 w-4 mr-1" />
                    Cancel
                  </Button>
                </>
              ) : (
                <Button size="sm" variant="outline" onClick={() => setIsEditing(true)}>
                  <Edit className="h-4 w-4 mr-1" />
                  Edit
                </Button>
              )}
            </div>
          </div>
        </DialogHeader>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="ingredients">Ingredients</TabsTrigger>
            <TabsTrigger value="nutrition">Nutrition</TabsTrigger>
            <TabsTrigger value="scaling">Scaling</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <Users className="h-5 w-5 text-blue-600" />
                    <div>
                      <p className="text-sm text-gray-600">Servings</p>
                      <p className="text-lg font-semibold">{currentServings}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <Clock className="h-5 w-5 text-green-600" />
                    <div>
                      <p className="text-sm text-gray-600">Total Time</p>
                      <p className="text-lg font-semibold">
                        {formatTime((recipe.prep_time || 0) + (recipe.cook_time || 0))}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <DollarSign className="h-5 w-5 text-yellow-600" />
                    <div>
                      <p className="text-sm text-gray-600">Cost</p>
                      <p className="text-lg font-semibold">${currentData.cost?.toFixed(2) || '0.00'}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <span className="text-red-600 font-bold">Cal</span>
                    <div>
                      <p className="text-sm text-gray-600">Calories</p>
                      <p className="text-lg font-semibold">
                        {currentData.nutrition?.calories?.toFixed(0) || 0}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="space-y-4">
              <div>
                <Label htmlFor="description">Description</Label>
                {isEditing ? (
                  <Textarea
                    id="description"
                    value={editedRecipe.description || ''}
                    onChange={(e) => setEditedRecipe({ ...editedRecipe, description: e.target.value })}
                    className="mt-1"
                    rows={3}
                  />
                ) : (
                  <p className="mt-1 text-gray-700">{recipe.description || 'No description available'}</p>
                )}
              </div>

              <div>
                <Label htmlFor="instructions">Instructions</Label>
                {isEditing ? (
                  <Textarea
                    id="instructions"
                    value={editedRecipe.instructions || ''}
                    onChange={(e) => setEditedRecipe({ ...editedRecipe, instructions: e.target.value })}
                    className="mt-1"
                    rows={6}
                  />
                ) : (
                  <div className="mt-1 text-gray-700 whitespace-pre-wrap">
                    {recipe.instructions || 'No instructions available'}
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="prep-time">Prep Time (minutes)</Label>
                  {isEditing ? (
                    <Input
                      id="prep-time"
                      type="number"
                      value={editedRecipe.prep_time || ''}
                      onChange={(e) => setEditedRecipe({ ...editedRecipe, prep_time: parseInt(e.target.value) || 0 })}
                      className="mt-1"
                    />
                  ) : (
                    <p className="mt-1 text-gray-700">{recipe.prep_time || 0} minutes</p>
                  )}
                </div>

                <div>
                  <Label htmlFor="cook-time">Cook Time (minutes)</Label>
                  {isEditing ? (
                    <Input
                      id="cook-time"
                      type="number"
                      value={editedRecipe.cook_time || ''}
                      onChange={(e) => setEditedRecipe({ ...editedRecipe, cook_time: parseInt(e.target.value) || 0 })}
                      className="mt-1"
                    />
                  ) : (
                    <p className="mt-1 text-gray-700">{recipe.cook_time || 0} minutes</p>
                  )}
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="ingredients" className="space-y-4">
            {isEditing ? (
              <IngredientBuilder
                ingredients={editedRecipe.ingredients || []}
                onChange={(ingredients) => setEditedRecipe({ ...editedRecipe, ingredients })}
              />
            ) : (
              <div className="space-y-2">
                <h3 className="text-lg font-semibold">Ingredients</h3>
                {scaledData && (
                  <p className="text-sm text-blue-600">
                    Scaled for {scaledServings} servings (original: {recipe.servings})
                  </p>
                )}
                <div className="space-y-2">
                  {(scaledData?.ingredients || recipe.ingredients || []).map((ingredient, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <span className="text-sm text-gray-500">#{index + 1}</span>
                        <div>
                          <p className="font-medium">
                            {ingredient.ingredient?.name || ingredient.sub_recipe?.name}
                          </p>
                          {ingredient.notes && (
                            <p className="text-sm text-gray-600">{ingredient.notes}</p>
                          )}
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">
                          {ingredient.quantity} {ingredient.unit}
                        </p>
                        {ingredient.ingredient?.cost_per_unit && (
                          <p className="text-sm text-gray-600">
                            ${(ingredient.quantity * ingredient.ingredient.cost_per_unit).toFixed(2)}
                          </p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="nutrition" className="space-y-4">
            <NutritionLabel 
              nutrition={currentData.nutrition} 
              servings={currentServings}
              format="US"
            />
          </TabsContent>

          <TabsContent value="scaling" className="space-y-4">
            <div className="space-y-4">
              <div>
                <Label htmlFor="scaled-servings">Scale to servings:</Label>
                <div className="flex items-center space-x-2 mt-1">
                  <Input
                    id="scaled-servings"
                    type="number"
                    min="1"
                    value={scaledServings}
                    onChange={(e) => setScaledServings(parseInt(e.target.value) || 1)}
                    className="w-24"
                  />
                  <Button onClick={handleScale} disabled={loading}>
                    <Scale className="h-4 w-4 mr-1" />
                    Scale Recipe
                  </Button>
                  {scaledData && (
                    <Button 
                      variant="outline" 
                      onClick={() => {
                        setScaledServings(recipe.servings);
                        setScaledData(null);
                      }}
                    >
                      Reset
                    </Button>
                  )}
                </div>
              </div>

              {scaledData && (
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-blue-900 mb-2">Scaled Recipe Preview</h4>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <p className="text-blue-700">Servings</p>
                      <p className="font-medium">{scaledData.servings}</p>
                    </div>
                    <div>
                      <p className="text-blue-700">Cost</p>
                      <p className="font-medium">${scaledData.cost?.toFixed(2)}</p>
                    </div>
                    <div>
                      <p className="text-blue-700">Calories</p>
                      <p className="font-medium">{scaledData.nutrition?.calories?.toFixed(0)}</p>
                    </div>
                    <div>
                      <p className="text-blue-700">Per Serving</p>
                      <p className="font-medium">
                        {(scaledData.nutrition?.calories / scaledData.servings)?.toFixed(0)} cal
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};

export default RecipeDetailModal;

