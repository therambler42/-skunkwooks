from flask import Blueprint, request, jsonify
from src.models.recipe import db, Ingredient
import json

ingredients_bp = Blueprint('ingredients', __name__)

@ingredients_bp.route('/ingredients', methods=['GET'])
def get_ingredients():
    """Get all ingredients with optional filtering"""
    try:
        # Query parameters
        search = request.args.get('search', '')
        category = request.args.get('category')
        
        query = Ingredient.query
        
        # Apply filters
        if search:
            query = query.filter(Ingredient.name.contains(search))
        
        if category:
            query = query.filter(Ingredient.category == category)
        
        ingredients = query.order_by(Ingredient.name).all()
        
        return jsonify({
            'success': True,
            'ingredients': [ingredient.to_dict() for ingredient in ingredients]
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@ingredients_bp.route('/ingredients', methods=['POST'])
def create_ingredient():
    """Create a new ingredient"""
    try:
        data = request.get_json()
        
        if not data or not data.get('name'):
            return jsonify({
                'success': False,
                'error': 'Ingredient name is required'
            }), 400
        
        # Validate nutrition data if provided
        nutrition_data = data.get('nutrition_per_100g', {})
        if nutrition_data and not isinstance(nutrition_data, dict):
            return jsonify({
                'success': False,
                'error': 'nutrition_per_100g must be a valid object'
            }), 400
        
        # Validate allergens data if provided
        allergens_data = data.get('allergens', [])
        if allergens_data and not isinstance(allergens_data, list):
            return jsonify({
                'success': False,
                'error': 'allergens must be a valid array'
            }), 400
        
        # Create new ingredient
        ingredient = Ingredient(
            name=data['name'],
            category=data.get('category', ''),
            unit=data.get('unit', 'g'),
            cost_per_unit=data.get('cost_per_unit', 0.0),
            nutrition_per_100g=json.dumps(nutrition_data) if nutrition_data else None,
            allergens=json.dumps(allergens_data) if allergens_data else None
        )
        
        db.session.add(ingredient)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'ingredient': ingredient.to_dict()
        }), 201
    
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@ingredients_bp.route('/ingredients/<int:ingredient_id>', methods=['GET'])
def get_ingredient(ingredient_id):
    """Get a specific ingredient by ID"""
    try:
        ingredient = Ingredient.query.get_or_404(ingredient_id)
        return jsonify({
            'success': True,
            'ingredient': ingredient.to_dict()
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@ingredients_bp.route('/ingredients/<int:ingredient_id>', methods=['PUT'])
def update_ingredient(ingredient_id):
    """Update an ingredient"""
    try:
        ingredient = Ingredient.query.get_or_404(ingredient_id)
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        # Update ingredient fields
        if 'name' in data:
            ingredient.name = data['name']
        if 'category' in data:
            ingredient.category = data['category']
        if 'unit' in data:
            ingredient.unit = data['unit']
        if 'cost_per_unit' in data:
            ingredient.cost_per_unit = data['cost_per_unit']
        
        # Update nutrition data
        if 'nutrition_per_100g' in data:
            nutrition_data = data['nutrition_per_100g']
            if nutrition_data and not isinstance(nutrition_data, dict):
                return jsonify({
                    'success': False,
                    'error': 'nutrition_per_100g must be a valid object'
                }), 400
            ingredient.nutrition_per_100g = json.dumps(nutrition_data) if nutrition_data else None
        
        # Update allergens data
        if 'allergens' in data:
            allergens_data = data['allergens']
            if allergens_data and not isinstance(allergens_data, list):
                return jsonify({
                    'success': False,
                    'error': 'allergens must be a valid array'
                }), 400
            ingredient.allergens = json.dumps(allergens_data) if allergens_data else None
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'ingredient': ingredient.to_dict()
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@ingredients_bp.route('/ingredients/<int:ingredient_id>', methods=['DELETE'])
def delete_ingredient(ingredient_id):
    """Delete an ingredient"""
    try:
        ingredient = Ingredient.query.get_or_404(ingredient_id)
        
        # Check if ingredient is used in any recipes
        from src.models.recipe import RecipeIngredient
        used_in_recipes = RecipeIngredient.query.filter_by(ingredient_id=ingredient_id).all()
        if used_in_recipes:
            recipe_names = [ri.recipe.name for ri in used_in_recipes]
            return jsonify({
                'success': False,
                'error': f'Cannot delete ingredient. It is used in recipes: {", ".join(recipe_names)}'
            }), 400
        
        db.session.delete(ingredient)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Ingredient deleted successfully'
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@ingredients_bp.route('/ingredients/categories', methods=['GET'])
def get_ingredient_categories():
    """Get all unique ingredient categories"""
    try:
        categories = db.session.query(Ingredient.category).distinct().filter(
            Ingredient.category.isnot(None),
            Ingredient.category != ''
        ).all()
        
        category_list = [cat[0] for cat in categories if cat[0]]
        
        return jsonify({
            'success': True,
            'categories': sorted(category_list)
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@ingredients_bp.route('/ingredients/bulk', methods=['POST'])
def create_bulk_ingredients():
    """Create multiple ingredients at once"""
    try:
        data = request.get_json()
        
        if not data or 'ingredients' not in data:
            return jsonify({
                'success': False,
                'error': 'ingredients array is required'
            }), 400
        
        ingredients_data = data['ingredients']
        if not isinstance(ingredients_data, list):
            return jsonify({
                'success': False,
                'error': 'ingredients must be an array'
            }), 400
        
        created_ingredients = []
        errors = []
        
        for idx, ingredient_data in enumerate(ingredients_data):
            try:
                if not ingredient_data.get('name'):
                    errors.append(f'Ingredient {idx + 1}: name is required')
                    continue
                
                # Validate nutrition data
                nutrition_data = ingredient_data.get('nutrition_per_100g', {})
                if nutrition_data and not isinstance(nutrition_data, dict):
                    errors.append(f'Ingredient {idx + 1}: nutrition_per_100g must be a valid object')
                    continue
                
                # Validate allergens data
                allergens_data = ingredient_data.get('allergens', [])
                if allergens_data and not isinstance(allergens_data, list):
                    errors.append(f'Ingredient {idx + 1}: allergens must be a valid array')
                    continue
                
                ingredient = Ingredient(
                    name=ingredient_data['name'],
                    category=ingredient_data.get('category', ''),
                    unit=ingredient_data.get('unit', 'g'),
                    cost_per_unit=ingredient_data.get('cost_per_unit', 0.0),
                    nutrition_per_100g=json.dumps(nutrition_data) if nutrition_data else None,
                    allergens=json.dumps(allergens_data) if allergens_data else None
                )
                
                db.session.add(ingredient)
                created_ingredients.append(ingredient)
                
            except Exception as e:
                errors.append(f'Ingredient {idx + 1}: {str(e)}')
        
        if errors:
            db.session.rollback()
            return jsonify({
                'success': False,
                'errors': errors
            }), 400
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'ingredients': [ingredient.to_dict() for ingredient in created_ingredients],
            'count': len(created_ingredients)
        }), 201
    
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

