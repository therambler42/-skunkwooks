from flask import Blueprint, request, jsonify
from src.models.recipe import db, Recipe, RecipeIngredient
import json

scaling_bp = Blueprint('scaling', __name__)

# Unit conversion factors to grams/ml
UNIT_CONVERSIONS = {
    # Weight units
    'g': 1,
    'kg': 1000,
    'oz': 28.3495,
    'lb': 453.592,
    'mg': 0.001,
    
    # Volume units (assuming 1ml = 1g for most ingredients)
    'ml': 1,
    'l': 1000,
    'fl oz': 29.5735,
    'cup': 240,
    'tbsp': 15,
    'tsp': 5,
    'pint': 473.176,
    'quart': 946.353,
    'gallon': 3785.41,
    
    # Count units
    'piece': 50,  # Average weight assumption
    'item': 50,
    'unit': 50,
    'portion': 100,  # For sub-recipes
    
    # Special units
    'pinch': 0.5,
    'dash': 1,
    'handful': 30,
    'clove': 3,  # garlic clove
    'slice': 25,
    'stick': 113,  # butter stick
}

@scaling_bp.route('/recipes/<int:recipe_id>/scale-advanced', methods=['POST'])
def scale_recipe_advanced(recipe_id):
    """Advanced recipe scaling with precise unit conversion and rounding"""
    try:
        recipe = Recipe.query.get_or_404(recipe_id)
        data = request.get_json()
        
        if not data or 'servings' not in data:
            return jsonify({
                'success': False,
                'error': 'New servings amount is required'
            }), 400
        
        new_servings = data['servings']
        if new_servings <= 0:
            return jsonify({
                'success': False,
                'error': 'Servings must be greater than 0'
            }), 400
        
        precision = data.get('precision', 'normal')  # 'high', 'normal', 'low'
        round_to_nice_numbers = data.get('round_to_nice_numbers', True)
        
        if recipe.servings == 0:
            return jsonify({
                'success': False,
                'error': 'Cannot scale recipe with 0 servings'
            }), 400
        
        scale_factor = new_servings / recipe.servings
        
        # Scale ingredients with advanced logic
        scaled_ingredients = []
        for recipe_ingredient in recipe.recipe_ingredients:
            original_quantity = recipe_ingredient.quantity
            scaled_quantity = original_quantity * scale_factor
            
            # Apply rounding based on precision and unit type
            final_quantity = apply_smart_rounding(
                scaled_quantity, 
                recipe_ingredient.unit, 
                precision, 
                round_to_nice_numbers
            )
            
            scaled_ingredients.append({
                'id': recipe_ingredient.id,
                'ingredient_id': recipe_ingredient.ingredient_id,
                'sub_recipe_id': recipe_ingredient.sub_recipe_id,
                'quantity': final_quantity,
                'original_quantity': original_quantity,
                'scale_factor': scale_factor,
                'unit': recipe_ingredient.unit,
                'notes': recipe_ingredient.notes,
                'ingredient': recipe_ingredient.ingredient.to_dict() if recipe_ingredient.ingredient else None,
                'sub_recipe': {
                    'id': recipe_ingredient.sub_recipe.id,
                    'name': recipe_ingredient.sub_recipe.name,
                    'servings': recipe_ingredient.sub_recipe.servings
                } if recipe_ingredient.sub_recipe else None
            })
        
        # Calculate scaled nutrition (including nested)
        scaled_nutrition = calculate_scaled_nutrition_with_nesting(recipe, scale_factor)
        
        # Calculate scaled cost (including nested)
        scaled_cost = calculate_scaled_cost_with_nesting(recipe, scale_factor)
        
        # Calculate accuracy metrics
        accuracy_metrics = calculate_scaling_accuracy(recipe, scale_factor, scaled_ingredients)
        
        return jsonify({
            'success': True,
            'scaled_recipe': {
                'servings': new_servings,
                'original_servings': recipe.servings,
                'scale_factor': scale_factor,
                'ingredients': scaled_ingredients,
                'nutrition': scaled_nutrition,
                'cost': round(scaled_cost, 2),
                'accuracy_metrics': accuracy_metrics
            }
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

def apply_smart_rounding(quantity, unit, precision, round_to_nice_numbers):
    """Apply intelligent rounding based on quantity, unit, and precision settings"""
    
    if precision == 'high':
        decimal_places = 2
    elif precision == 'normal':
        decimal_places = 1
    else:  # low
        decimal_places = 0
    
    # Adjust decimal places based on unit type
    if unit in ['g', 'ml', 'oz']:
        if quantity < 1:
            decimal_places = max(decimal_places, 1)
        elif quantity < 10:
            decimal_places = max(decimal_places, 1)
    elif unit in ['kg', 'l']:
        decimal_places = max(decimal_places, 2)
    elif unit in ['tsp', 'tbsp']:
        if quantity < 1:
            decimal_places = max(decimal_places, 2)
        else:
            decimal_places = max(decimal_places, 1)
    elif unit in ['piece', 'item', 'unit']:
        decimal_places = 0  # Always whole numbers for countable items
    
    # Round to specified decimal places
    rounded_quantity = round(quantity, decimal_places)
    
    # Apply nice number rounding if requested
    if round_to_nice_numbers and decimal_places > 0:
        rounded_quantity = round_to_nice_number(rounded_quantity, unit)
    
    return rounded_quantity

def round_to_nice_number(quantity, unit):
    """Round to 'nice' numbers that are easier to measure"""
    
    # For very small quantities, use fractions
    if quantity < 1:
        nice_fractions = [0.125, 0.25, 0.33, 0.5, 0.67, 0.75]
        return min(nice_fractions, key=lambda x: abs(x - quantity))
    
    # For larger quantities, round to quarters or halves
    if quantity < 10:
        return round(quantity * 4) / 4  # Round to nearest quarter
    elif quantity < 50:
        return round(quantity * 2) / 2  # Round to nearest half
    else:
        return round(quantity)  # Round to nearest whole number

def calculate_scaled_nutrition_with_nesting(recipe, scale_factor):
    """Calculate nutrition for scaled recipe including sub-recipe contributions"""
    
    def calculate_nutrition_recursive(recipe_obj, multiplier=1):
        total_nutrition = {
            'calories': 0, 'protein': 0, 'carbs': 0, 'fat': 0,
            'fiber': 0, 'sugar': 0, 'sodium': 0
        }
        
        for recipe_ingredient in recipe_obj.recipe_ingredients:
            ingredient_multiplier = recipe_ingredient.quantity * multiplier
            
            if recipe_ingredient.ingredient:
                # Regular ingredient
                ingredient = recipe_ingredient.ingredient
                if ingredient.nutrition_per_100g:
                    nutrition_data = json.loads(ingredient.nutrition_per_100g)
                    
                    # Convert to grams for calculation
                    quantity_in_grams = convert_to_grams(
                        ingredient_multiplier,
                        recipe_ingredient.unit,
                        ingredient
                    )
                    
                    for key in total_nutrition:
                        if key in nutrition_data:
                            total_nutrition[key] += (nutrition_data[key] / 100) * quantity_in_grams
            
            elif recipe_ingredient.sub_recipe:
                # Sub-recipe - recursively calculate
                sub_nutrition = calculate_nutrition_recursive(
                    recipe_ingredient.sub_recipe,
                    ingredient_multiplier
                )
                
                for key in total_nutrition:
                    total_nutrition[key] += sub_nutrition[key]
        
        return total_nutrition
    
    base_nutrition = calculate_nutrition_recursive(recipe, scale_factor)
    
    # Round nutrition values appropriately
    return {
        key: round(value, 1) if value < 100 else round(value)
        for key, value in base_nutrition.items()
    }

def calculate_scaled_cost_with_nesting(recipe, scale_factor):
    """Calculate cost for scaled recipe including sub-recipe contributions"""
    
    def calculate_cost_recursive(recipe_obj, multiplier=1):
        total_cost = 0
        
        for recipe_ingredient in recipe_obj.recipe_ingredients:
            ingredient_multiplier = recipe_ingredient.quantity * multiplier
            
            if recipe_ingredient.ingredient:
                # Regular ingredient
                ingredient = recipe_ingredient.ingredient
                if ingredient.cost_per_unit:
                    quantity_in_base_unit = convert_to_base_unit(
                        ingredient_multiplier,
                        recipe_ingredient.unit,
                        ingredient
                    )
                    total_cost += ingredient.cost_per_unit * quantity_in_base_unit
            
            elif recipe_ingredient.sub_recipe:
                # Sub-recipe - recursively calculate
                sub_cost = calculate_cost_recursive(
                    recipe_ingredient.sub_recipe,
                    ingredient_multiplier
                )
                total_cost += sub_cost
        
        return total_cost
    
    return calculate_cost_recursive(recipe, scale_factor)

def convert_to_grams(quantity, unit, ingredient):
    """Convert quantity to grams for nutrition calculation"""
    conversion_factor = UNIT_CONVERSIONS.get(unit.lower(), 1)
    return quantity * conversion_factor

def convert_to_base_unit(quantity, unit, ingredient):
    """Convert quantity to ingredient's base unit for cost calculation"""
    # For now, assume all ingredients are priced per gram
    return convert_to_grams(quantity, unit, ingredient)

def calculate_scaling_accuracy(recipe, scale_factor, scaled_ingredients):
    """Calculate accuracy metrics for the scaling operation"""
    
    total_error = 0
    max_error = 0
    ingredient_count = len(scaled_ingredients)
    
    for ingredient in scaled_ingredients:
        expected_quantity = ingredient['original_quantity'] * scale_factor
        actual_quantity = ingredient['quantity']
        
        if expected_quantity > 0:
            error_percentage = abs(actual_quantity - expected_quantity) / expected_quantity * 100
            total_error += error_percentage
            max_error = max(max_error, error_percentage)
    
    average_error = total_error / ingredient_count if ingredient_count > 0 else 0
    
    return {
        'average_error_percentage': round(average_error, 2),
        'max_error_percentage': round(max_error, 2),
        'meets_1_percent_accuracy': max_error <= 1.0,
        'ingredient_count': ingredient_count
    }

@scaling_bp.route('/recipes/<int:recipe_id>/unit-conversions', methods=['GET'])
def get_unit_conversions(recipe_id):
    """Get available unit conversions for recipe ingredients"""
    try:
        recipe = Recipe.query.get_or_404(recipe_id)
        
        # Group units by category
        unit_categories = {
            'weight': ['g', 'kg', 'oz', 'lb', 'mg'],
            'volume': ['ml', 'l', 'fl oz', 'cup', 'tbsp', 'tsp', 'pint', 'quart'],
            'count': ['piece', 'item', 'unit', 'portion'],
            'special': ['pinch', 'dash', 'handful', 'clove', 'slice', 'stick']
        }
        
        # Get current units used in recipe
        current_units = list(set(ri.unit for ri in recipe.recipe_ingredients))
        
        return jsonify({
            'success': True,
            'unit_categories': unit_categories,
            'current_units': current_units,
            'conversion_factors': UNIT_CONVERSIONS
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

