import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const NutritionLabel = ({ nutrition = {}, servings = 1, format = 'US' }) => {
  const {
    calories = 0,
    protein = 0,
    carbs = 0,
    fat = 0,
    fiber = 0,
    sugar = 0,
    sodium = 0
  } = nutrition;

  // Calculate per serving values
  const perServing = {
    calories: Math.round(calories / servings),
    protein: Math.round((protein / servings) * 10) / 10,
    carbs: Math.round((carbs / servings) * 10) / 10,
    fat: Math.round((fat / servings) * 10) / 10,
    fiber: Math.round((fiber / servings) * 10) / 10,
    sugar: Math.round((sugar / servings) * 10) / 10,
    sodium: Math.round(sodium / servings)
  };

  // Daily Value percentages (based on 2000 calorie diet)
  const dailyValues = {
    fat: Math.round((perServing.fat / 65) * 100),
    carbs: Math.round((perServing.carbs / 300) * 100),
    fiber: Math.round((perServing.fiber / 25) * 100),
    protein: Math.round((perServing.protein / 50) * 100),
    sodium: Math.round((perServing.sodium / 2300) * 100)
  };

  if (format === 'EU') {
    return (
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-lg">Nutrition Information</CardTitle>
          <p className="text-sm text-gray-600">Per serving ({servings} servings total)</p>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="border-b pb-2">
            <div className="flex justify-between items-center">
              <span className="font-semibold">Energy</span>
              <span className="font-semibold">{perServing.calories} kcal</span>
            </div>
          </div>
          
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span>Fat</span>
              <span>{perServing.fat}g</span>
            </div>
            <div className="flex justify-between">
              <span>Carbohydrates</span>
              <span>{perServing.carbs}g</span>
            </div>
            <div className="flex justify-between pl-4">
              <span>of which sugars</span>
              <span>{perServing.sugar}g</span>
            </div>
            <div className="flex justify-between">
              <span>Fibre</span>
              <span>{perServing.fiber}g</span>
            </div>
            <div className="flex justify-between">
              <span>Protein</span>
              <span>{perServing.protein}g</span>
            </div>
            <div className="flex justify-between">
              <span>Salt</span>
              <span>{Math.round((perServing.sodium / 1000) * 2.5 * 10) / 10}g</span>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  // US Format (FDA style)
  return (
    <Card className="w-full max-w-md">
      <CardContent className="p-0">
        <div className="bg-black text-white p-3">
          <h3 className="text-xl font-bold">Nutrition Facts</h3>
          <p className="text-sm">Per serving ({servings} servings total)</p>
        </div>
        
        <div className="p-4 space-y-1">
          <div className="border-b-8 border-black pb-1">
            <div className="flex justify-between items-baseline">
              <span className="text-2xl font-bold">Calories</span>
              <span className="text-2xl font-bold">{perServing.calories}</span>
            </div>
          </div>
          
          <div className="text-right text-sm font-semibold border-b border-gray-300 pb-1">
            % Daily Value*
          </div>
          
          <div className="space-y-1 text-sm">
            <div className="flex justify-between border-b border-gray-300 pb-1">
              <span><strong>Total Fat</strong> {perServing.fat}g</span>
              <span className="font-bold">{dailyValues.fat}%</span>
            </div>
            
            <div className="flex justify-between border-b border-gray-300 pb-1">
              <span><strong>Total Carbohydrate</strong> {perServing.carbs}g</span>
              <span className="font-bold">{dailyValues.carbs}%</span>
            </div>
            
            <div className="flex justify-between pl-4 border-b border-gray-300 pb-1">
              <span>Total Sugars {perServing.sugar}g</span>
              <span></span>
            </div>
            
            <div className="flex justify-between border-b border-gray-300 pb-1">
              <span><strong>Dietary Fiber</strong> {perServing.fiber}g</span>
              <span className="font-bold">{dailyValues.fiber}%</span>
            </div>
            
            <div className="flex justify-between border-b border-gray-300 pb-1">
              <span><strong>Protein</strong> {perServing.protein}g</span>
              <span className="font-bold">{dailyValues.protein}%</span>
            </div>
            
            <div className="flex justify-between border-b-4 border-black pb-1">
              <span><strong>Sodium</strong> {perServing.sodium}mg</span>
              <span className="font-bold">{dailyValues.sodium}%</span>
            </div>
          </div>
          
          <div className="text-xs text-gray-600 pt-2">
            <p>* The % Daily Value (DV) tells you how much a nutrient in a serving of food contributes to a daily diet. 2,000 calories a day is used for general nutrition advice.</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default NutritionLabel;

