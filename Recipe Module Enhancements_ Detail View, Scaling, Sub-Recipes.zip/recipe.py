from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json

db = SQLAlchemy()

class Recipe(db.Model):
    __tablename__ = 'recipes'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text)
    servings = db.Column(db.Integer, default=1)
    prep_time = db.Column(db.Integer)  # in minutes
    cook_time = db.Column(db.Integer)  # in minutes
    instructions = db.Column(db.Text)
    is_sub_recipe = db.Column(db.Boolean, default=False)
    version = db.Column(db.Integer, default=1)  # Version tracking
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    recipe_ingredients = db.relationship('RecipeIngredient', back_populates='recipe', cascade='all, delete-orphan', foreign_keys='RecipeIngredient.recipe_id')
    versions = db.relationship('RecipeVersion', back_populates='recipe', cascade='all, delete-orphan')
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'servings': self.servings,
            'prep_time': self.prep_time,
            'cook_time': self.cook_time,
            'instructions': self.instructions,
            'is_sub_recipe': self.is_sub_recipe,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'ingredients': [ri.to_dict() for ri in self.recipe_ingredients],
            'nutrition': self.calculate_nutrition(),
            'cost': self.calculate_cost()
        }
    
    def calculate_nutrition(self):
        """Calculate total nutrition for the recipe"""
        total_nutrition = {
            'calories': 0,
            'protein': 0,
            'carbs': 0,
            'fat': 0,
            'fiber': 0,
            'sugar': 0,
            'sodium': 0
        }
        
        for recipe_ingredient in self.recipe_ingredients:
            ingredient = recipe_ingredient.ingredient
            if ingredient:
                # Convert quantity to grams for calculation
                quantity_in_grams = self._convert_to_grams(
                    recipe_ingredient.quantity, 
                    recipe_ingredient.unit,
                    ingredient
                )
                
                # Calculate nutrition per gram and multiply by quantity
                if ingredient.nutrition_per_100g:
                    nutrition_data = json.loads(ingredient.nutrition_per_100g)
                    for key in total_nutrition:
                        if key in nutrition_data:
                            total_nutrition[key] += (nutrition_data[key] / 100) * quantity_in_grams
        
        return total_nutrition
    
    def calculate_cost(self):
        """Calculate total cost for the recipe"""
        total_cost = 0
        
        for recipe_ingredient in self.recipe_ingredients:
            ingredient = recipe_ingredient.ingredient
            if ingredient and ingredient.cost_per_unit:
                # Convert quantity to the ingredient's base unit for cost calculation
                quantity_in_base_unit = self._convert_to_base_unit(
                    recipe_ingredient.quantity,
                    recipe_ingredient.unit,
                    ingredient
                )
                total_cost += ingredient.cost_per_unit * quantity_in_base_unit
        
        return round(total_cost, 2)
    
    def _convert_to_grams(self, quantity, unit, ingredient):
        """Convert quantity to grams for nutrition calculation"""
        # Basic unit conversions - can be expanded
        conversions = {
            'g': 1,
            'kg': 1000,
            'oz': 28.35,
            'lb': 453.59,
            'ml': 1,  # Assuming 1ml = 1g for liquids (approximation)
            'l': 1000,
            'cup': 240,  # Approximate
            'tbsp': 15,
            'tsp': 5
        }
        
        return quantity * conversions.get(unit.lower(), 1)
    
    def _convert_to_base_unit(self, quantity, unit, ingredient):
        """Convert quantity to ingredient's base unit for cost calculation"""
        # This would need to be more sophisticated in a real application
        # For now, assume all ingredients are priced per gram
        return self._convert_to_grams(quantity, unit, ingredient)
    
    def scale_recipe(self, new_servings):
        """Scale recipe to new serving size"""
        if self.servings == 0:
            return None
            
        scale_factor = new_servings / self.servings
        
        scaled_ingredients = []
        for recipe_ingredient in self.recipe_ingredients:
            scaled_quantity = recipe_ingredient.quantity * scale_factor
            scaled_ingredients.append({
                'ingredient_id': recipe_ingredient.ingredient_id,
                'quantity': round(scaled_quantity, 2),
                'unit': recipe_ingredient.unit,
                'notes': recipe_ingredient.notes
            })
        
        return {
            'servings': new_servings,
            'ingredients': scaled_ingredients,
            'nutrition': self._calculate_scaled_nutrition(scale_factor),
            'cost': self.calculate_cost() * scale_factor
        }
    
    def _calculate_scaled_nutrition(self, scale_factor):
        """Calculate nutrition for scaled recipe"""
        base_nutrition = self.calculate_nutrition()
        return {key: round(value * scale_factor, 2) for key, value in base_nutrition.items()}


class Ingredient(db.Model):
    __tablename__ = 'ingredients'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    category = db.Column(db.String(100))
    unit = db.Column(db.String(50))  # base unit (g, ml, etc.)
    cost_per_unit = db.Column(db.Float)  # cost per base unit
    nutrition_per_100g = db.Column(db.Text)  # JSON string with nutrition data
    allergens = db.Column(db.Text)  # JSON string with allergen flags
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    recipe_ingredients = db.relationship('RecipeIngredient', back_populates='ingredient')
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'category': self.category,
            'unit': self.unit,
            'cost_per_unit': self.cost_per_unit,
            'nutrition_per_100g': json.loads(self.nutrition_per_100g) if self.nutrition_per_100g else {},
            'allergens': json.loads(self.allergens) if self.allergens else [],
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class RecipeIngredient(db.Model):
    __tablename__ = 'recipe_ingredients'
    
    id = db.Column(db.Integer, primary_key=True)
    recipe_id = db.Column(db.Integer, db.ForeignKey('recipes.id'), nullable=False)
    ingredient_id = db.Column(db.Integer, db.ForeignKey('ingredients.id'), nullable=True)
    sub_recipe_id = db.Column(db.Integer, db.ForeignKey('recipes.id'), nullable=True)
    quantity = db.Column(db.Float, nullable=False)
    unit = db.Column(db.String(50), nullable=False)
    notes = db.Column(db.Text)
    order_index = db.Column(db.Integer, default=0)
    
    # Relationships
    recipe = db.relationship('Recipe', back_populates='recipe_ingredients', foreign_keys=[recipe_id])
    ingredient = db.relationship('Ingredient', back_populates='recipe_ingredients')
    sub_recipe = db.relationship('Recipe', foreign_keys=[sub_recipe_id])
    
    def to_dict(self):
        result = {
            'id': self.id,
            'recipe_id': self.recipe_id,
            'quantity': self.quantity,
            'unit': self.unit,
            'notes': self.notes,
            'order_index': self.order_index
        }
        
        if self.ingredient:
            result['ingredient'] = self.ingredient.to_dict()
            result['type'] = 'ingredient'
        elif self.sub_recipe:
            result['sub_recipe'] = {
                'id': self.sub_recipe.id,
                'name': self.sub_recipe.name,
                'servings': self.sub_recipe.servings
            }
            result['type'] = 'sub_recipe'
        
        return result


class RecipeVersion(db.Model):
    __tablename__ = 'recipe_versions'
    
    id = db.Column(db.Integer, primary_key=True)
    recipe_id = db.Column(db.Integer, db.ForeignKey('recipes.id'), nullable=False)
    version_number = db.Column(db.Integer, nullable=False)
    changes_summary = db.Column(db.Text)
    recipe_data = db.Column(db.Text)  # JSON snapshot of recipe at this version
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    created_by = db.Column(db.String(255))  # User identifier
    
    # Relationships
    recipe = db.relationship('Recipe', back_populates='versions')
    
    def to_dict(self):
        return {
            'id': self.id,
            'recipe_id': self.recipe_id,
            'version_number': self.version_number,
            'changes_summary': self.changes_summary,
            'recipe_data': json.loads(self.recipe_data) if self.recipe_data else {},
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'created_by': self.created_by
        }

