import unittest
import json
from src.main import app
from src.models.recipe import db, Recipe, Ingredient, RecipeIngredient

class TestScalingMath(unittest.TestCase):
    """Test scaling calculations and accuracy"""
    
    def setUp(self):
        """Set up test environment"""
        self.app = app
        self.app.config['TESTING'] = True
        self.app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        self.client = self.app.test_client()
        
        with self.app.app_context():
            db.create_all()
            self.create_test_data()
    
    def tearDown(self):
        """Clean up after tests"""
        with self.app.app_context():
            db.session.remove()
            db.drop_all()
    
    def create_test_data(self):
        """Create test ingredients and recipe"""
        # Create test ingredients
        flour = Ingredient(
            name='Test Flour',
            category='Baking',
            unit='g',
            cost_per_unit=0.002,
            nutrition_per_100g=json.dumps({
                'calories': 364,
                'protein': 10.3,
                'carbs': 76.3,
                'fat': 1.0,
                'fiber': 2.7,
                'sugar': 0.3,
                'sodium': 2
            }),
            allergens=json.dumps(['gluten'])
        )
        
        sugar = Ingredient(
            name='Test Sugar',
            category='Baking',
            unit='g',
            cost_per_unit=0.001,
            nutrition_per_100g=json.dumps({
                'calories': 387,
                'protein': 0,
                'carbs': 99.8,
                'fat': 0,
                'fiber': 0,
                'sugar': 99.8,
                'sodium': 0
            }),
            allergens=json.dumps([])
        )
        
        db.session.add(flour)
        db.session.add(sugar)
        db.session.commit()
        
        # Create test recipe
        recipe = Recipe(
            name='Test Recipe',
            description='Test recipe for scaling',
            servings=4,
            prep_time=10,
            cook_time=15,
            instructions='Test instructions',
            version=1
        )
        
        db.session.add(recipe)
        db.session.commit()
        
        # Add ingredients to recipe
        recipe_ingredient1 = RecipeIngredient(
            recipe_id=recipe.id,
            ingredient_id=flour.id,
            quantity=200,
            unit='g',
            notes='Test flour',
            order_index=0
        )
        
        recipe_ingredient2 = RecipeIngredient(
            recipe_id=recipe.id,
            ingredient_id=sugar.id,
            quantity=50,
            unit='g',
            notes='Test sugar',
            order_index=1
        )
        
        db.session.add(recipe_ingredient1)
        db.session.add(recipe_ingredient2)
        db.session.commit()
        
        self.recipe_id = recipe.id
        self.flour_id = flour.id
        self.sugar_id = sugar.id
    
    def test_basic_scaling_accuracy(self):
        """Test basic scaling accuracy meets ±1% requirement"""
        # Scale recipe from 4 to 6 servings (1.5x)
        response = self.client.post(f'/api/recipes/{self.recipe_id}/scale-advanced', 
                                  json={
                                      'servings': 6,
                                      'precision': 'normal',
                                      'round_to_nice_numbers': False
                                  })
        
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        
        # Check accuracy metrics
        accuracy = data['scaled_recipe']['accuracy_metrics']
        self.assertTrue(accuracy['meets_1_percent_accuracy'])
        self.assertLessEqual(accuracy['max_error_percentage'], 1.0)
        
        # Check scaling factor
        self.assertEqual(data['scaled_recipe']['scale_factor'], 1.5)
        
        # Check ingredient scaling
        ingredients = data['scaled_recipe']['ingredients']
        flour_ingredient = next(i for i in ingredients if i['ingredient']['name'] == 'Test Flour')
        sugar_ingredient = next(i for i in ingredients if i['ingredient']['name'] == 'Test Sugar')
        
        # Flour: 200g * 1.5 = 300g
        self.assertEqual(flour_ingredient['quantity'], 300)
        # Sugar: 50g * 1.5 = 75g
        self.assertEqual(sugar_ingredient['quantity'], 75)
    
    def test_extreme_scaling_accuracy(self):
        """Test scaling accuracy with extreme ratios"""
        # Scale recipe from 4 to 1 serving (0.25x)
        response = self.client.post(f'/api/recipes/{self.recipe_id}/scale-advanced', 
                                  json={
                                      'servings': 1,
                                      'precision': 'high',
                                      'round_to_nice_numbers': False
                                  })
        
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        
        # Check accuracy metrics
        accuracy = data['scaled_recipe']['accuracy_metrics']
        self.assertLessEqual(accuracy['max_error_percentage'], 1.0)
        
        # Check ingredient scaling
        ingredients = data['scaled_recipe']['ingredients']
        flour_ingredient = next(i for i in ingredients if i['ingredient']['name'] == 'Test Flour')
        sugar_ingredient = next(i for i in ingredients if i['ingredient']['name'] == 'Test Sugar')
        
        # Flour: 200g * 0.25 = 50g
        self.assertEqual(flour_ingredient['quantity'], 50)
        # Sugar: 50g * 0.25 = 12.5g
        self.assertEqual(sugar_ingredient['quantity'], 12.5)
    
    def test_nutrition_scaling(self):
        """Test nutrition scaling accuracy"""
        # Scale recipe from 4 to 8 servings (2x)
        response = self.client.post(f'/api/recipes/{self.recipe_id}/scale-advanced', 
                                  json={
                                      'servings': 8,
                                      'precision': 'normal',
                                      'round_to_nice_numbers': False
                                  })
        
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        
        nutrition = data['scaled_recipe']['nutrition']
        
        # Calculate expected nutrition (2x scaling)
        # Flour: 200g -> 400g = 4 * 100g portions
        # Sugar: 50g -> 100g = 1 * 100g portion
        expected_calories = (4 * 364) + (1 * 387)  # 1456 + 387 = 1843
        
        # Allow for small rounding differences
        self.assertAlmostEqual(nutrition['calories'], expected_calories, delta=10)
    
    def test_cost_scaling(self):
        """Test cost scaling accuracy"""
        # Scale recipe from 4 to 6 servings (1.5x)
        response = self.client.post(f'/api/recipes/{self.recipe_id}/scale-advanced', 
                                  json={
                                      'servings': 6,
                                      'precision': 'normal',
                                      'round_to_nice_numbers': False
                                  })
        
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        
        scaled_cost = data['scaled_recipe']['cost']
        
        # Calculate expected cost (1.5x scaling)
        # Flour: 200g * 1.5 = 300g * 0.002 = 0.6
        # Sugar: 50g * 1.5 = 75g * 0.001 = 0.075
        expected_cost = 0.6 + 0.075  # 0.675
        
        self.assertAlmostEqual(scaled_cost, expected_cost, places=2)
    
    def test_unit_conversions(self):
        """Test unit conversion functionality"""
        response = self.client.get(f'/api/recipes/{self.recipe_id}/unit-conversions')
        
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        
        # Check conversion factors are present
        conversions = data['conversion_factors']
        self.assertIn('g', conversions)
        self.assertIn('kg', conversions)
        self.assertIn('ml', conversions)
        self.assertIn('cup', conversions)
        
        # Check specific conversions
        self.assertEqual(conversions['g'], 1)
        self.assertEqual(conversions['kg'], 1000)
        self.assertEqual(conversions['cup'], 240)
    
    def test_precision_levels(self):
        """Test different precision levels"""
        for precision in ['high', 'normal', 'low']:
            response = self.client.post(f'/api/recipes/{self.recipe_id}/scale-advanced', 
                                      json={
                                          'servings': 3,
                                          'precision': precision,
                                          'round_to_nice_numbers': True
                                      })
            
            self.assertEqual(response.status_code, 200)
            data = response.get_json()
            
            # All precision levels should meet accuracy requirement
            accuracy = data['scaled_recipe']['accuracy_metrics']
            self.assertTrue(accuracy['meets_1_percent_accuracy'])

if __name__ == '__main__':
    unittest.main()

