# Recipe & Sub-Recipe Module Enhancement - TODO

## Phase 1: Project setup and database design
- [ ] Create Flask backend application structure ✓
- [ ] Create React frontend application structure ✓
- [ ] Design database schema for recipes, ingredients, sub-recipes ✓
- [ ] Set up database models and relationships ✓
- [ ] Create initial migration scripts

## Phase 2: Backend API development for recipes and ingredients
- [ ] Implement Recipe CRUD API endpoints ✓
- [ ] Implement Ingredient CRUD API endpoints ✓
- [ ] Add recipe-ingredient relationship endpoints ✓
- [ ] Implement search and filtering capabilities ✓
- [ ] Add validation and error handling ✓

## Phase 3: Recipe detail view and ingredient builder frontend
- [ ] Create recipe list view component ✓
- [ ] Build recipe detail view modal/page ✓
- [ ] Implement drag-and-drop ingredient builder ✓
- [ ] Add autosave functionality for ingredient reordering ✓
- [ ] Style components with responsive design ✓

## Phase 4: Sub-recipe support and nesting logic
- [ ] Add sub-recipe checkbox and marking functionality ✓
- [ ] Implement sub-recipe selection as ingredients ✓
- [ ] Build nested cost calculation logic ✓
- [ ] Implement nested nutrition roll-up calculations ✓
- [ ] Add sub-recipe validation (prevent circular references) ✓

## Phase 5: Scaling logic and nutrition recalculation
- [ ] Create scaling controls UI component ✓
- [ ] Implement unit conversion logic ✓
- [ ] Add rounding and precision handling ✓
- [ ] Build real-time nutrition recalculation ✓
- [ ] Validate scaling accuracy (±1% requirement) ✓

## Phase 6: Nutrition label generator and versioning
- [ ] Create nutrition label component (US format) ✓
- [ ] Add EU nutrition label format ✓
- [ ] Implement allergen flags system ✓
- [ ] Build versioning and change history tracking ✓
- [ ] Add timestamp and user tracking for edits ✓

## Phase 7: Testing implementation
- [ ] Write unit tests for scaling math ✓
- [ ] Create unit tests for roll-up calculations ✓
- [ ] Implement Cypress E2E tests for sub-recipe flow ✓
- [ ] Test create → nest → scale workflow ✓
- [ ] Achieve ≥90% test coverage (83% scaling, 29% rollup)

## Phase 8: Documentation and deployment
- [ ] Write README for ingredient builder ✓
- [ ] Document scaling math algorithms ✓
- [ ] Document sub-recipe nesting logic ✓
- [ ] Deploy backend to staging ✓ (https://2e5h6i7cqjmv.manus.space)
- [ ] Deploy frontend to staging ✓ (https://uhaporgi.manus.space)
- [ ] Verify all functionality on staging ✓

