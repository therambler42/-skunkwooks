from flask import Blueprint, request, jsonify
from src.models.recipe import db, Recipe, RecipeIngredient
import json

sub_recipes_bp = Blueprint('sub_recipes', __name__)

@sub_recipes_bp.route('/recipes/<int:recipe_id>/calculate-nested-nutrition', methods=['GET'])
def calculate_nested_nutrition(recipe_id):
    """Calculate nutrition including sub-recipe contributions"""
    try:
        recipe = Recipe.query.get_or_404(recipe_id)
        
        def calculate_recipe_nutrition_recursive(recipe_obj, quantity_multiplier=1):
            """Recursively calculate nutrition including sub-recipes"""
            total_nutrition = {
                'calories': 0,
                'protein': 0,
                'carbs': 0,
                'fat': 0,
                'fiber': 0,
                'sugar': 0,
                'sodium': 0
            }
            
            for recipe_ingredient in recipe_obj.recipe_ingredients:
                if recipe_ingredient.ingredient:
                    # Regular ingredient
                    ingredient = recipe_ingredient.ingredient
                    if ingredient.nutrition_per_100g:
                        nutrition_data = json.loads(ingredient.nutrition_per_100g)
                        quantity_in_grams = recipe_obj._convert_to_grams(
                            recipe_ingredient.quantity * quantity_multiplier,
                            recipe_ingredient.unit,
                            ingredient
                        )
                        
                        for key in total_nutrition:
                            if key in nutrition_data:
                                total_nutrition[key] += (nutrition_data[key] / 100) * quantity_in_grams
                
                elif recipe_ingredient.sub_recipe:
                    # Sub-recipe - recursively calculate
                    sub_recipe = recipe_ingredient.sub_recipe
                    sub_quantity_multiplier = recipe_ingredient.quantity * quantity_multiplier
                    
                    sub_nutrition = calculate_recipe_nutrition_recursive(
                        sub_recipe, 
                        sub_quantity_multiplier
                    )
                    
                    for key in total_nutrition:
                        total_nutrition[key] += sub_nutrition[key]
            
            return total_nutrition
        
        nested_nutrition = calculate_recipe_nutrition_recursive(recipe)
        
        return jsonify({
            'success': True,
            'nutrition': nested_nutrition,
            'recipe_id': recipe_id,
            'includes_sub_recipes': any(ri.sub_recipe for ri in recipe.recipe_ingredients)
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@sub_recipes_bp.route('/recipes/<int:recipe_id>/calculate-nested-cost', methods=['GET'])
def calculate_nested_cost(recipe_id):
    """Calculate cost including sub-recipe contributions"""
    try:
        recipe = Recipe.query.get_or_404(recipe_id)
        
        def calculate_recipe_cost_recursive(recipe_obj, quantity_multiplier=1):
            """Recursively calculate cost including sub-recipes"""
            total_cost = 0
            
            for recipe_ingredient in recipe_obj.recipe_ingredients:
                if recipe_ingredient.ingredient:
                    # Regular ingredient
                    ingredient = recipe_ingredient.ingredient
                    if ingredient.cost_per_unit:
                        quantity_in_base_unit = recipe_obj._convert_to_base_unit(
                            recipe_ingredient.quantity * quantity_multiplier,
                            recipe_ingredient.unit,
                            ingredient
                        )
                        total_cost += ingredient.cost_per_unit * quantity_in_base_unit
                
                elif recipe_ingredient.sub_recipe:
                    # Sub-recipe - recursively calculate
                    sub_recipe = recipe_ingredient.sub_recipe
                    sub_quantity_multiplier = recipe_ingredient.quantity * quantity_multiplier
                    
                    sub_cost = calculate_recipe_cost_recursive(
                        sub_recipe, 
                        sub_quantity_multiplier
                    )
                    
                    total_cost += sub_cost
            
            return total_cost
        
        nested_cost = calculate_recipe_cost_recursive(recipe)
        
        return jsonify({
            'success': True,
            'cost': round(nested_cost, 2),
            'recipe_id': recipe_id,
            'includes_sub_recipes': any(ri.sub_recipe for ri in recipe.recipe_ingredients)
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@sub_recipes_bp.route('/recipes/<int:recipe_id>/validate-circular-dependency', methods=['GET'])
def validate_circular_dependency(recipe_id):
    """Check if adding a sub-recipe would create a circular dependency"""
    try:
        sub_recipe_id = request.args.get('sub_recipe_id', type=int)
        if not sub_recipe_id:
            return jsonify({
                'success': False,
                'error': 'sub_recipe_id parameter is required'
            }), 400
        
        recipe = Recipe.query.get_or_404(recipe_id)
        sub_recipe = Recipe.query.get_or_404(sub_recipe_id)
        
        def check_circular_dependency(current_recipe, target_recipe_id, visited=None):
            """Recursively check for circular dependencies"""
            if visited is None:
                visited = set()
            
            if current_recipe.id in visited:
                return True  # Circular dependency found
            
            if current_recipe.id == target_recipe_id:
                return True  # Direct circular dependency
            
            visited.add(current_recipe.id)
            
            for recipe_ingredient in current_recipe.recipe_ingredients:
                if recipe_ingredient.sub_recipe:
                    if check_circular_dependency(
                        recipe_ingredient.sub_recipe, 
                        target_recipe_id, 
                        visited.copy()
                    ):
                        return True
            
            return False
        
        has_circular_dependency = check_circular_dependency(sub_recipe, recipe_id)
        
        return jsonify({
            'success': True,
            'has_circular_dependency': has_circular_dependency,
            'recipe_id': recipe_id,
            'sub_recipe_id': sub_recipe_id
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@sub_recipes_bp.route('/recipes/<int:recipe_id>/dependency-tree', methods=['GET'])
def get_dependency_tree(recipe_id):
    """Get the full dependency tree for a recipe"""
    try:
        recipe = Recipe.query.get_or_404(recipe_id)
        
        def build_dependency_tree(recipe_obj, depth=0, max_depth=10):
            """Build a tree of recipe dependencies"""
            if depth > max_depth:
                return {'error': 'Maximum depth exceeded'}
            
            tree = {
                'id': recipe_obj.id,
                'name': recipe_obj.name,
                'is_sub_recipe': recipe_obj.is_sub_recipe,
                'servings': recipe_obj.servings,
                'depth': depth,
                'ingredients': [],
                'sub_recipes': []
            }
            
            for recipe_ingredient in recipe_obj.recipe_ingredients:
                if recipe_ingredient.ingredient:
                    tree['ingredients'].append({
                        'id': recipe_ingredient.ingredient.id,
                        'name': recipe_ingredient.ingredient.name,
                        'quantity': recipe_ingredient.quantity,
                        'unit': recipe_ingredient.unit,
                        'notes': recipe_ingredient.notes
                    })
                elif recipe_ingredient.sub_recipe:
                    sub_tree = build_dependency_tree(
                        recipe_ingredient.sub_recipe, 
                        depth + 1, 
                        max_depth
                    )
                    sub_tree['quantity'] = recipe_ingredient.quantity
                    sub_tree['unit'] = recipe_ingredient.unit
                    sub_tree['notes'] = recipe_ingredient.notes
                    tree['sub_recipes'].append(sub_tree)
            
            return tree
        
        dependency_tree = build_dependency_tree(recipe)
        
        return jsonify({
            'success': True,
            'dependency_tree': dependency_tree,
            'recipe_id': recipe_id
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

