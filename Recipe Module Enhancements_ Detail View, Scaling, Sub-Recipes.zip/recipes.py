from flask import Blueprint, request, jsonify
from src.models.recipe import db, Recipe, RecipeIngredient, RecipeVersion
import json
from datetime import datetime

recipes_bp = Blueprint('recipes', __name__)

@recipes_bp.route('/recipes', methods=['GET'])
def get_recipes():
    """Get all recipes with optional filtering"""
    try:
        # Query parameters
        is_sub_recipe = request.args.get('is_sub_recipe')
        search = request.args.get('search', '')
        category = request.args.get('category')
        
        query = Recipe.query
        
        # Apply filters
        if is_sub_recipe is not None:
            query = query.filter(Recipe.is_sub_recipe == (is_sub_recipe.lower() == 'true'))
        
        if search:
            query = query.filter(Recipe.name.contains(search))
        
        recipes = query.order_by(Recipe.name).all()
        
        return jsonify({
            'success': True,
            'recipes': [recipe.to_dict() for recipe in recipes]
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@recipes_bp.route('/recipes', methods=['POST'])
def create_recipe():
    """Create a new recipe"""
    try:
        data = request.get_json()
        
        if not data or not data.get('name'):
            return jsonify({
                'success': False,
                'error': 'Recipe name is required'
            }), 400
        
        # Create new recipe
        recipe = Recipe(
            name=data['name'],
            description=data.get('description', ''),
            servings=data.get('servings', 1),
            prep_time=data.get('prep_time'),
            cook_time=data.get('cook_time'),
            instructions=data.get('instructions', ''),
            is_sub_recipe=data.get('is_sub_recipe', False)
        )
        
        db.session.add(recipe)
        db.session.flush()  # Get the recipe ID
        
        # Add ingredients if provided
        if 'ingredients' in data:
            for idx, ingredient_data in enumerate(data['ingredients']):
                recipe_ingredient = RecipeIngredient(
                    recipe_id=recipe.id,
                    ingredient_id=ingredient_data.get('ingredient_id'),
                    sub_recipe_id=ingredient_data.get('sub_recipe_id'),
                    quantity=ingredient_data['quantity'],
                    unit=ingredient_data['unit'],
                    notes=ingredient_data.get('notes', ''),
                    order_index=idx
                )
                db.session.add(recipe_ingredient)
        
        # Create initial version
        version = RecipeVersion(
            recipe_id=recipe.id,
            version_number=1,
            changes_summary='Initial recipe creation',
            recipe_data=json.dumps(data),
            created_by=data.get('created_by', 'system')
        )
        db.session.add(version)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'recipe': recipe.to_dict()
        }), 201
    
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@recipes_bp.route('/recipes/<int:recipe_id>', methods=['GET'])
def get_recipe(recipe_id):
    """Get a specific recipe by ID"""
    try:
        recipe = Recipe.query.get_or_404(recipe_id)
        return jsonify({
            'success': True,
            'recipe': recipe.to_dict()
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@recipes_bp.route('/recipes/<int:recipe_id>', methods=['PUT'])
def update_recipe(recipe_id):
    """Update a recipe"""
    try:
        recipe = Recipe.query.get_or_404(recipe_id)
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        # Store old data for version tracking
        old_data = recipe.to_dict()
        
        # Update recipe fields
        if 'name' in data:
            recipe.name = data['name']
        if 'description' in data:
            recipe.description = data['description']
        if 'servings' in data:
            recipe.servings = data['servings']
        if 'prep_time' in data:
            recipe.prep_time = data['prep_time']
        if 'cook_time' in data:
            recipe.cook_time = data['cook_time']
        if 'instructions' in data:
            recipe.instructions = data['instructions']
        if 'is_sub_recipe' in data:
            recipe.is_sub_recipe = data['is_sub_recipe']
        
        recipe.updated_at = datetime.utcnow()
        
        # Update ingredients if provided
        if 'ingredients' in data:
            # Remove existing ingredients
            RecipeIngredient.query.filter_by(recipe_id=recipe.id).delete()
            
            # Add new ingredients
            for idx, ingredient_data in enumerate(data['ingredients']):
                recipe_ingredient = RecipeIngredient(
                    recipe_id=recipe.id,
                    ingredient_id=ingredient_data.get('ingredient_id'),
                    sub_recipe_id=ingredient_data.get('sub_recipe_id'),
                    quantity=ingredient_data['quantity'],
                    unit=ingredient_data['unit'],
                    notes=ingredient_data.get('notes', ''),
                    order_index=idx
                )
                db.session.add(recipe_ingredient)
        
        # Create new version
        latest_version = RecipeVersion.query.filter_by(recipe_id=recipe.id).order_by(RecipeVersion.version_number.desc()).first()
        new_version_number = (latest_version.version_number + 1) if latest_version else 1
        
        version = RecipeVersion(
            recipe_id=recipe.id,
            version_number=new_version_number,
            changes_summary=data.get('changes_summary', 'Recipe updated'),
            recipe_data=json.dumps(data),
            created_by=data.get('updated_by', 'system')
        )
        db.session.add(version)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'recipe': recipe.to_dict()
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@recipes_bp.route('/recipes/<int:recipe_id>', methods=['DELETE'])
def delete_recipe(recipe_id):
    """Delete a recipe"""
    try:
        recipe = Recipe.query.get_or_404(recipe_id)
        
        # Check if recipe is used as sub-recipe in other recipes
        used_in_recipes = RecipeIngredient.query.filter_by(sub_recipe_id=recipe_id).all()
        if used_in_recipes:
            recipe_names = [ri.recipe.name for ri in used_in_recipes]
            return jsonify({
                'success': False,
                'error': f'Cannot delete recipe. It is used as a sub-recipe in: {", ".join(recipe_names)}'
            }), 400
        
        db.session.delete(recipe)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Recipe deleted successfully'
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@recipes_bp.route('/recipes/<int:recipe_id>/scale', methods=['POST'])
def scale_recipe(recipe_id):
    """Scale a recipe to a new serving size"""
    try:
        recipe = Recipe.query.get_or_404(recipe_id)
        data = request.get_json()
        
        if not data or 'servings' not in data:
            return jsonify({
                'success': False,
                'error': 'New servings amount is required'
            }), 400
        
        new_servings = data['servings']
        if new_servings <= 0:
            return jsonify({
                'success': False,
                'error': 'Servings must be greater than 0'
            }), 400
        
        scaled_recipe = recipe.scale_recipe(new_servings)
        
        if scaled_recipe is None:
            return jsonify({
                'success': False,
                'error': 'Cannot scale recipe with 0 servings'
            }), 400
        
        return jsonify({
            'success': True,
            'scaled_recipe': scaled_recipe,
            'original_servings': recipe.servings
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@recipes_bp.route('/recipes/<int:recipe_id>/ingredients/reorder', methods=['PUT'])
def reorder_ingredients(recipe_id):
    """Reorder ingredients in a recipe (for drag-and-drop)"""
    try:
        recipe = Recipe.query.get_or_404(recipe_id)
        data = request.get_json()
        
        if not data or 'ingredient_ids' not in data:
            return jsonify({
                'success': False,
                'error': 'ingredient_ids array is required'
            }), 400
        
        ingredient_ids = data['ingredient_ids']
        
        # Update order_index for each ingredient
        for idx, ingredient_id in enumerate(ingredient_ids):
            recipe_ingredient = RecipeIngredient.query.filter_by(
                recipe_id=recipe_id,
                id=ingredient_id
            ).first()
            
            if recipe_ingredient:
                recipe_ingredient.order_index = idx
        
        recipe.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Ingredients reordered successfully'
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@recipes_bp.route('/recipes/<int:recipe_id>/versions', methods=['GET'])
def get_recipe_versions(recipe_id):
    """Get version history for a recipe"""
    try:
        recipe = Recipe.query.get_or_404(recipe_id)
        versions = RecipeVersion.query.filter_by(recipe_id=recipe_id).order_by(RecipeVersion.version_number.desc()).all()
        
        return jsonify({
            'success': True,
            'versions': [version.to_dict() for version in versions]
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@recipes_bp.route('/recipes/<int:recipe_id>/nutrition', methods=['GET'])
def get_recipe_nutrition(recipe_id):
    """Get detailed nutrition information for a recipe"""
    try:
        recipe = Recipe.query.get_or_404(recipe_id)
        servings = request.args.get('servings', recipe.servings, type=int)
        
        if servings <= 0:
            return jsonify({
                'success': False,
                'error': 'Servings must be greater than 0'
            }), 400
        
        # Calculate nutrition for specified servings
        base_nutrition = recipe.calculate_nutrition()
        scale_factor = servings / recipe.servings if recipe.servings > 0 else 1
        
        scaled_nutrition = {
            key: round(value * scale_factor, 2) 
            for key, value in base_nutrition.items()
        }
        
        # Add per-serving nutrition
        per_serving_nutrition = {
            key: round(value / servings, 2) if servings > 0 else 0
            for key, value in scaled_nutrition.items()
        }
        
        return jsonify({
            'success': True,
            'nutrition': {
                'total': scaled_nutrition,
                'per_serving': per_serving_nutrition,
                'servings': servings
            }
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

