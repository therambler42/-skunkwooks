describe('Recipe Management E2E Tests', () => {
  beforeEach(() => {
    // Visit the application
    cy.visit('http://localhost:5173')
    
    // Wait for the page to load
    cy.get('[data-testid="recipe-list"]', { timeout: 10000 }).should('be.visible')
  })

  it('should display recipe list on load', () => {
    // Check that recipes are displayed
    cy.get('[data-testid="recipe-card"]').should('have.length.at.least', 1)
    
    // Check that recipe names are visible
    cy.contains('Simple Pancakes').should('be.visible')
  })

  it('should open recipe detail modal when clicking View Details', () => {
    // Click on the first View Details button
    cy.get('[data-testid="view-details-btn"]').first().click()
    
    // Check that modal opens
    cy.get('[data-testid="recipe-detail-modal"]').should('be.visible')
    
    // Check that recipe name is displayed in modal
    cy.get('[data-testid="recipe-name"]').should('contain.text', 'Simple Pancakes')
    
    // Check that tabs are present
    cy.get('[data-testid="tab-overview"]').should('be.visible')
    cy.get('[data-testid="tab-ingredients"]').should('be.visible')
    cy.get('[data-testid="tab-nutrition"]').should('be.visible')
    cy.get('[data-testid="tab-scaling"]').should('be.visible')
  })

  it('should display ingredients in detail view', () => {
    // Open recipe detail
    cy.get('[data-testid="view-details-btn"]').first().click()
    
    // Click on Ingredients tab
    cy.get('[data-testid="tab-ingredients"]').click()
    
    // Check that ingredients are displayed
    cy.get('[data-testid="ingredient-item"]').should('have.length.at.least', 3)
    
    // Check for specific ingredients
    cy.contains('Flour').should('be.visible')
    cy.contains('Sugar').should('be.visible')
    cy.contains('Eggs').should('be.visible')
  })

  it('should display nutrition label', () => {
    // Open recipe detail
    cy.get('[data-testid="view-details-btn"]').first().click()
    
    // Click on Nutrition tab
    cy.get('[data-testid="tab-nutrition"]').click()
    
    // Check that nutrition label is displayed
    cy.get('[data-testid="nutrition-label"]').should('be.visible')
    
    // Check for nutrition facts
    cy.contains('Calories').should('be.visible')
    cy.contains('Total Fat').should('be.visible')
    cy.contains('Total Carbohydrate').should('be.visible')
    cy.contains('Protein').should('be.visible')
  })

  it('should scale recipe correctly', () => {
    // Open recipe detail
    cy.get('[data-testid="view-details-btn"]').first().click()
    
    // Click on Scaling tab
    cy.get('[data-testid="tab-scaling"]').click()
    
    // Get original cost and calories
    cy.get('[data-testid="original-cost"]').invoke('text').as('originalCost')
    cy.get('[data-testid="original-calories"]').invoke('text').as('originalCalories')
    
    // Change servings to 8
    cy.get('[data-testid="servings-input"]').clear().type('8')
    
    // Click scale button
    cy.get('[data-testid="scale-btn"]').click()
    
    // Wait for scaling to complete
    cy.get('[data-testid="scaled-preview"]', { timeout: 5000 }).should('be.visible')
    
    // Check that scaled values are different and higher
    cy.get('[data-testid="scaled-cost"]').should('not.contain', '@originalCost')
    cy.get('[data-testid="scaled-calories"]').should('not.contain', '@originalCalories')
    
    // Verify scaling factor is 2x (4 servings -> 8 servings)
    cy.get('[data-testid="scale-factor"]').should('contain', '2')
  })

  it('should create and use sub-recipe workflow', () => {
    // This test would require the ability to create recipes
    // For now, we'll test viewing existing sub-recipes
    
    // Look for sub-recipe badge
    cy.get('[data-testid="sub-recipe-badge"]').should('exist')
    
    // Open a recipe that uses sub-recipes
    cy.contains('Advanced Pancakes').parent().find('[data-testid="view-details-btn"]').click()
    
    // Check ingredients tab for sub-recipe ingredient
    cy.get('[data-testid="tab-ingredients"]').click()
    
    // Look for sub-recipe in ingredient list
    cy.get('[data-testid="ingredient-item"]').should('contain', 'Pancake Batter')
  })

  it('should show accurate cost and nutrition for nested recipes', () => {
    // Open recipe with sub-recipe
    cy.contains('Advanced Pancakes').parent().find('[data-testid="view-details-btn"]').click()
    
    // Check overview tab shows calculated values
    cy.get('[data-testid="recipe-cost"]').should('be.visible')
    cy.get('[data-testid="recipe-calories"]').should('be.visible')
    
    // Values should be higher than simple recipe due to nesting
    cy.get('[data-testid="recipe-calories"]').invoke('text').then((calories) => {
      const calorieValue = parseInt(calories.replace(/[^\d]/g, ''))
      expect(calorieValue).to.be.greaterThan(2000) // Should be higher due to sub-recipe
    })
  })

  it('should handle edit mode and ingredient builder', () => {
    // Open recipe detail
    cy.get('[data-testid="view-details-btn"]').first().click()
    
    // Click edit button
    cy.get('[data-testid="edit-btn"]').click()
    
    // Check that edit mode is active
    cy.get('[data-testid="edit-mode"]').should('be.visible')
    
    // Go to ingredients tab
    cy.get('[data-testid="tab-ingredients"]').click()
    
    // Check that ingredient builder is visible
    cy.get('[data-testid="ingredient-builder"]').should('be.visible')
    
    // Check for drag handles (indicating drag-and-drop capability)
    cy.get('[data-testid="drag-handle"]').should('have.length.at.least', 3)
  })

  it('should validate scaling accuracy within 1% tolerance', () => {
    // Open recipe detail
    cy.get('[data-testid="view-details-btn"]').first().click()
    
    // Go to scaling tab
    cy.get('[data-testid="tab-scaling"]').click()
    
    // Test multiple scaling factors
    const scalingTests = [
      { servings: 2, expectedFactor: 0.5 },
      { servings: 6, expectedFactor: 1.5 },
      { servings: 12, expectedFactor: 3.0 }
    ]
    
    scalingTests.forEach(({ servings, expectedFactor }) => {
      // Set servings
      cy.get('[data-testid="servings-input"]').clear().type(servings.toString())
      
      // Scale recipe
      cy.get('[data-testid="scale-btn"]').click()
      
      // Wait for results
      cy.get('[data-testid="scaled-preview"]', { timeout: 5000 }).should('be.visible')
      
      // Check accuracy indicator
      cy.get('[data-testid="accuracy-indicator"]').should('contain', '✓')
      cy.get('[data-testid="accuracy-percentage"]').invoke('text').then((accuracy) => {
        const accuracyValue = parseFloat(accuracy.replace(/[^\d.]/g, ''))
        expect(accuracyValue).to.be.lessThan(1.0) // Should be within 1% tolerance
      })
    })
  })

  it('should close modal when clicking close button', () => {
    // Open recipe detail
    cy.get('[data-testid="view-details-btn"]').first().click()
    
    // Check modal is open
    cy.get('[data-testid="recipe-detail-modal"]').should('be.visible')
    
    // Click close button
    cy.get('[data-testid="close-modal-btn"]').click()
    
    // Check modal is closed
    cy.get('[data-testid="recipe-detail-modal"]').should('not.exist')
  })

  it('should handle responsive design on mobile viewport', () => {
    // Set mobile viewport
    cy.viewport(375, 667)
    
    // Check that recipe cards stack properly
    cy.get('[data-testid="recipe-card"]').should('be.visible')
    
    // Open recipe detail
    cy.get('[data-testid="view-details-btn"]').first().click()
    
    // Check that modal is responsive
    cy.get('[data-testid="recipe-detail-modal"]').should('be.visible')
    
    // Check that tabs are accessible on mobile
    cy.get('[data-testid="tab-ingredients"]').should('be.visible').click()
    cy.get('[data-testid="ingredient-item"]').should('be.visible')
  })
})

