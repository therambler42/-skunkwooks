# Sample data for testing the recipe management system

import requests
import json

BASE_URL = "http://localhost:5000/api"

# Sample ingredients data
sample_ingredients = [
    {
        "name": "Flour",
        "category": "Baking",
        "unit": "g",
        "cost_per_unit": 0.002,
        "nutrition_per_100g": {
            "calories": 364,
            "protein": 10.3,
            "carbs": 76.3,
            "fat": 1.0,
            "fiber": 2.7,
            "sugar": 0.3,
            "sodium": 2
        },
        "allergens": ["gluten"]
    },
    {
        "name": "Sugar",
        "category": "Baking",
        "unit": "g",
        "cost_per_unit": 0.001,
        "nutrition_per_100g": {
            "calories": 387,
            "protein": 0,
            "carbs": 99.8,
            "fat": 0,
            "fiber": 0,
            "sugar": 99.8,
            "sodium": 0
        },
        "allergens": []
    },
    {
        "name": "Eggs",
        "category": "Dairy",
        "unit": "piece",
        "cost_per_unit": 0.25,
        "nutrition_per_100g": {
            "calories": 155,
            "protein": 13,
            "carbs": 1.1,
            "fat": 11,
            "fiber": 0,
            "sugar": 1.1,
            "sodium": 124
        },
        "allergens": ["eggs"]
    },
    {
        "name": "Butter",
        "category": "Dairy",
        "unit": "g",
        "cost_per_unit": 0.008,
        "nutrition_per_100g": {
            "calories": 717,
            "protein": 0.9,
            "carbs": 0.1,
            "fat": 81,
            "fiber": 0,
            "sugar": 0.1,
            "sodium": 11
        },
        "allergens": ["dairy"]
    },
    {
        "name": "Milk",
        "category": "Dairy",
        "unit": "ml",
        "cost_per_unit": 0.001,
        "nutrition_per_100g": {
            "calories": 42,
            "protein": 3.4,
            "carbs": 5,
            "fat": 1,
            "fiber": 0,
            "sugar": 5,
            "sodium": 44
        },
        "allergens": ["dairy"]
    }
]

def create_sample_data():
    """Create sample ingredients and recipes for testing"""
    
    print("Creating sample ingredients...")
    
    # Create ingredients
    ingredient_ids = {}
    for ingredient_data in sample_ingredients:
        response = requests.post(f"{BASE_URL}/ingredients", json=ingredient_data)
        if response.status_code == 201:
            result = response.json()
            ingredient_ids[ingredient_data["name"]] = result["ingredient"]["id"]
            print(f"Created ingredient: {ingredient_data['name']}")
        else:
            print(f"Failed to create ingredient {ingredient_data['name']}: {response.text}")
    
    print(f"\nCreated {len(ingredient_ids)} ingredients")
    
    # Create a sample recipe
    print("\nCreating sample recipe...")
    
    sample_recipe = {
        "name": "Simple Pancakes",
        "description": "Easy and delicious pancakes for breakfast",
        "servings": 4,
        "prep_time": 10,
        "cook_time": 15,
        "instructions": "1. Mix dry ingredients\n2. Add wet ingredients\n3. Cook on griddle until golden",
        "is_sub_recipe": False,
        "ingredients": [
            {
                "ingredient_id": ingredient_ids.get("Flour"),
                "quantity": 200,
                "unit": "g",
                "notes": "All-purpose flour"
            },
            {
                "ingredient_id": ingredient_ids.get("Sugar"),
                "quantity": 30,
                "unit": "g",
                "notes": "Granulated sugar"
            },
            {
                "ingredient_id": ingredient_ids.get("Eggs"),
                "quantity": 2,
                "unit": "piece",
                "notes": "Large eggs"
            },
            {
                "ingredient_id": ingredient_ids.get("Milk"),
                "quantity": 300,
                "unit": "ml",
                "notes": "Whole milk"
            },
            {
                "ingredient_id": ingredient_ids.get("Butter"),
                "quantity": 50,
                "unit": "g",
                "notes": "Melted butter"
            }
        ]
    }
    
    response = requests.post(f"{BASE_URL}/recipes", json=sample_recipe)
    if response.status_code == 201:
        result = response.json()
        recipe_id = result["recipe"]["id"]
        print(f"Created recipe: {sample_recipe['name']} (ID: {recipe_id})")
        
        # Test scaling
        print(f"\nTesting recipe scaling...")
        scale_response = requests.post(f"{BASE_URL}/recipes/{recipe_id}/scale", json={"servings": 6})
        if scale_response.status_code == 200:
            scaled_result = scale_response.json()
            print(f"Scaled recipe to 6 servings successfully")
            print(f"Original cost: ${result['recipe']['cost']:.2f}")
            print(f"Scaled cost: ${scaled_result['scaled_recipe']['cost']:.2f}")
        else:
            print(f"Failed to scale recipe: {scale_response.text}")
    else:
        print(f"Failed to create recipe: {response.text}")

if __name__ == "__main__":
    create_sample_data()

