from flask import Blueprint, request, jsonify
from src.models.recipe import db, Recipe, RecipeVersion
from datetime import datetime
import json

versioning_bp = Blueprint('versioning', __name__)

@versioning_bp.route('/recipes/<int:recipe_id>/versions', methods=['GET'])
def get_recipe_versions(recipe_id):
    """Get all versions of a recipe"""
    try:
        recipe = Recipe.query.get_or_404(recipe_id)
        versions = RecipeVersion.query.filter_by(recipe_id=recipe_id).order_by(RecipeVersion.created_at.desc()).all()
        
        version_list = []
        for version in versions:
            version_data = {
                'id': version.id,
                'version_number': version.version_number,
                'created_at': version.created_at.isoformat(),
                'user_id': version.user_id,
                'change_summary': version.change_summary,
                'changes': json.loads(version.changes) if version.changes else {},
                'recipe_data': json.loads(version.recipe_data) if version.recipe_data else {}
            }
            version_list.append(version_data)
        
        return jsonify({
            'success': True,
            'recipe_id': recipe_id,
            'current_version': recipe.version,
            'versions': version_list,
            'total_versions': len(version_list)
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@versioning_bp.route('/recipes/<int:recipe_id>/create-version', methods=['POST'])
def create_recipe_version(recipe_id):
    """Create a new version of a recipe"""
    try:
        recipe = Recipe.query.get_or_404(recipe_id)
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'Request data is required'
            }), 400
        
        # Get change summary and user info
        change_summary = data.get('change_summary', 'Recipe updated')
        user_id = data.get('user_id', 1)  # Default user for now
        changes = data.get('changes', {})
        
        # Create snapshot of current recipe state
        recipe_snapshot = {
            'name': recipe.name,
            'description': recipe.description,
            'servings': recipe.servings,
            'prep_time': recipe.prep_time,
            'cook_time': recipe.cook_time,
            'instructions': recipe.instructions,
            'is_sub_recipe': recipe.is_sub_recipe,
            'calculated_cost': recipe.calculate_cost(),
            'calculated_nutrition': recipe.calculate_nutrition(),
            'ingredients': []
        }
        
        # Add ingredients to snapshot
        for ri in recipe.recipe_ingredients:
            ingredient_data = {
                'ingredient_id': ri.ingredient_id,
                'sub_recipe_id': ri.sub_recipe_id,
                'quantity': ri.quantity,
                'unit': ri.unit,
                'notes': ri.notes,
                'order_index': ri.order_index,
                'type': getattr(ri, 'type', 'ingredient')  # Default to 'ingredient' if type doesn't exist
            }
            recipe_snapshot['ingredients'].append(ingredient_data)
        
        # Increment version number
        new_version_number = (recipe.version or 0) + 1
        
        # Create new version record
        new_version = RecipeVersion(
            recipe_id=recipe_id,
            version_number=new_version_number,
            created_by=str(user_id),  # Use created_by instead of user_id
            changes_summary=change_summary,  # Use changes_summary instead of change_summary
            recipe_data=json.dumps(recipe_snapshot),
            created_at=datetime.utcnow()
        )
        
        # Update recipe version
        recipe.version = new_version_number
        recipe.updated_at = datetime.utcnow()
        
        db.session.add(new_version)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'version': {
                'id': new_version.id,
                'version_number': new_version.version_number,
                'created_at': new_version.created_at.isoformat(),
                'changes_summary': new_version.changes_summary,
                'changes': changes
            },
            'recipe_id': recipe_id,
            'new_version_number': new_version_number
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@versioning_bp.route('/recipes/<int:recipe_id>/versions/<int:version_id>/restore', methods=['POST'])
def restore_recipe_version(recipe_id, version_id):
    """Restore a recipe to a previous version"""
    try:
        recipe = Recipe.query.get_or_404(recipe_id)
        version = RecipeVersion.query.filter_by(recipe_id=recipe_id, id=version_id).first_or_404()
        
        if not version.recipe_data:
            return jsonify({
                'success': False,
                'error': 'Version data not available'
            }), 400
        
        # Parse version data
        version_data = json.loads(version.recipe_data)
        
        # Create a new version before restoring (backup current state)
        backup_data = {
            'change_summary': f'Backup before restoring to version {version.version_number}',
            'user_id': request.get_json().get('user_id', 1) if request.get_json() else 1,
            'changes': {
                'action': 'backup_before_restore',
                'restored_from_version': version.version_number
            }
        }
        
        # Create backup version
        create_recipe_version(recipe_id)
        
        # Restore recipe data
        recipe.name = version_data.get('name', recipe.name)
        recipe.description = version_data.get('description', recipe.description)
        recipe.servings = version_data.get('servings', recipe.servings)
        recipe.prep_time = version_data.get('prep_time', recipe.prep_time)
        recipe.cook_time = version_data.get('cook_time', recipe.cook_time)
        recipe.instructions = version_data.get('instructions', recipe.instructions)
        recipe.is_sub_recipe = version_data.get('is_sub_recipe', recipe.is_sub_recipe)
        recipe.updated_at = datetime.utcnow()
        
        # Clear existing ingredients
        for ri in recipe.recipe_ingredients:
            db.session.delete(ri)
        
        # Restore ingredients
        from src.models.recipe import RecipeIngredient
        for ingredient_data in version_data.get('ingredients', []):
            new_ri = RecipeIngredient(
                recipe_id=recipe_id,
                ingredient_id=ingredient_data.get('ingredient_id'),
                sub_recipe_id=ingredient_data.get('sub_recipe_id'),
                quantity=ingredient_data.get('quantity'),
                unit=ingredient_data.get('unit'),
                notes=ingredient_data.get('notes'),
                order_index=ingredient_data.get('order_index'),
                type=ingredient_data.get('type', 'ingredient')
            )
            db.session.add(new_ri)
        
        # Recalculate cost and nutrition (methods exist in model)
        # recipe.calculate_cost()
        # recipe.calculate_nutrition()
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'Recipe restored to version {version.version_number}',
            'restored_version': version.version_number,
            'recipe_id': recipe_id
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@versioning_bp.route('/recipes/<int:recipe_id>/versions/<int:version_id>/compare', methods=['GET'])
def compare_recipe_versions(recipe_id, version_id):
    """Compare a version with the current recipe"""
    try:
        recipe = Recipe.query.get_or_404(recipe_id)
        version = RecipeVersion.query.filter_by(recipe_id=recipe_id, id=version_id).first_or_404()
        
        if not version.recipe_data:
            return jsonify({
                'success': False,
                'error': 'Version data not available'
            }), 400
        
        # Get current recipe state
        current_state = {
            'name': recipe.name,
            'description': recipe.description,
            'servings': recipe.servings,
            'prep_time': recipe.prep_time,
            'cook_time': recipe.cook_time,
            'instructions': recipe.instructions,
            'is_sub_recipe': recipe.is_sub_recipe,
            'ingredient_count': len(recipe.recipe_ingredients)
        }
        
        # Get version state
        version_data = json.loads(version.recipe_data)
        version_state = {
            'name': version_data.get('name'),
            'description': version_data.get('description'),
            'servings': version_data.get('servings'),
            'prep_time': version_data.get('prep_time'),
            'cook_time': version_data.get('cook_time'),
            'instructions': version_data.get('instructions'),
            'is_sub_recipe': version_data.get('is_sub_recipe'),
            'ingredient_count': len(version_data.get('ingredients', []))
        }
        
        # Calculate differences
        differences = {}
        for key in current_state:
            if current_state[key] != version_state[key]:
                differences[key] = {
                    'current': current_state[key],
                    'version': version_state[key]
                }
        
        return jsonify({
            'success': True,
            'recipe_id': recipe_id,
            'version_id': version_id,
            'version_number': version.version_number,
            'current_state': current_state,
            'version_state': version_state,
            'differences': differences,
            'has_differences': len(differences) > 0
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@versioning_bp.route('/recipes/<int:recipe_id>/change-history', methods=['GET'])
def get_change_history(recipe_id):
    """Get detailed change history for a recipe"""
    try:
        recipe = Recipe.query.get_or_404(recipe_id)
        
        # Get all versions with change details
        versions = RecipeVersion.query.filter_by(recipe_id=recipe_id).order_by(RecipeVersion.created_at.desc()).all()
        
        change_history = []
        for version in versions:
            # Since we don't have a changes field, create a simple change entry
            changes = {
                'action': 'update',
                'fields': {}
            }
            
            history_entry = {
                'version_number': version.version_number,
                'created_at': version.created_at.isoformat(),
                'created_by': version.created_by,
                'changes_summary': version.changes_summary,
                'changes': changes,
                'change_type': 'update',
                'fields_changed': []
            }
            change_history.append(history_entry)
        
        return jsonify({
            'success': True,
            'recipe_id': recipe_id,
            'recipe_name': recipe.name,
            'current_version': recipe.version,
            'change_history': change_history,
            'total_changes': len(change_history)
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

