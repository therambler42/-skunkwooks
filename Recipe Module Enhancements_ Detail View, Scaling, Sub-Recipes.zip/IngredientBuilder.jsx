import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { GripVertical, Plus, Trash2, Search } from 'lucide-react';

const API_BASE_URL = 'http://localhost:5000/api';

const IngredientBuilder = ({ ingredients = [], onChange }) => {
  const [availableIngredients, setAvailableIngredients] = useState([]);
  const [availableSubRecipes, setAvailableSubRecipes] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [draggedIndex, setDraggedIndex] = useState(null);

  useEffect(() => {
    fetchAvailableIngredients();
    fetchAvailableSubRecipes();
  }, []);

  const fetchAvailableIngredients = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/ingredients`);
      const data = await response.json();
      if (data.success) {
        setAvailableIngredients(data.ingredients);
      }
    } catch (error) {
      console.error('Error fetching ingredients:', error);
    }
  };

  const fetchAvailableSubRecipes = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/recipes?is_sub_recipe=true`);
      const data = await response.json();
      if (data.success) {
        setAvailableSubRecipes(data.recipes);
      }
    } catch (error) {
      console.error('Error fetching sub-recipes:', error);
    }
  };

  const addIngredient = () => {
    const newIngredient = {
      id: Date.now(), // Temporary ID for new ingredients
      ingredient_id: null,
      sub_recipe_id: null,
      quantity: 1,
      unit: 'g',
      notes: '',
      order_index: ingredients.length,
      type: 'ingredient'
    };
    onChange([...ingredients, newIngredient]);
  };

  const removeIngredient = (index) => {
    const updated = ingredients.filter((_, i) => i !== index);
    onChange(updated.map((ing, i) => ({ ...ing, order_index: i })));
  };

  const updateIngredient = (index, field, value) => {
    const updated = [...ingredients];
    updated[index] = { ...updated[index], [field]: value };
    
    // If changing from ingredient to sub-recipe or vice versa
    if (field === 'type') {
      updated[index].ingredient_id = null;
      updated[index].sub_recipe_id = null;
      updated[index].ingredient = null;
      updated[index].sub_recipe = null;
    }
    
    onChange(updated);
  };

  const handleDragStart = (e, index) => {
    setDraggedIndex(index);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (e, dropIndex) => {
    e.preventDefault();
    
    if (draggedIndex === null || draggedIndex === dropIndex) {
      setDraggedIndex(null);
      return;
    }

    const updated = [...ingredients];
    const draggedItem = updated[draggedIndex];
    
    // Remove dragged item
    updated.splice(draggedIndex, 1);
    
    // Insert at new position
    const insertIndex = draggedIndex < dropIndex ? dropIndex - 1 : dropIndex;
    updated.splice(insertIndex, 0, draggedItem);
    
    // Update order indices
    const reordered = updated.map((ing, i) => ({ ...ing, order_index: i }));
    
    onChange(reordered);
    setDraggedIndex(null);
  };

  const filteredIngredients = availableIngredients.filter(ing =>
    ing.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredSubRecipes = availableSubRecipes.filter(recipe =>
    recipe.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Recipe Ingredients</h3>
        <Button onClick={addIngredient} size="sm">
          <Plus className="h-4 w-4 mr-1" />
          Add Ingredient
        </Button>
      </div>

      <div className="space-y-3">
        {ingredients.map((ingredient, index) => (
          <Card
            key={ingredient.id || index}
            className={`transition-all ${draggedIndex === index ? 'opacity-50' : ''}`}
            draggable
            onDragStart={(e) => handleDragStart(e, index)}
            onDragOver={handleDragOver}
            onDrop={(e) => handleDrop(e, index)}
          >
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <div className="cursor-move">
                  <GripVertical className="h-5 w-5 text-gray-400" />
                </div>
                
                <div className="flex-1 grid grid-cols-1 md:grid-cols-6 gap-3">
                  {/* Type Selection */}
                  <div>
                    <Label className="text-xs">Type</Label>
                    <Select
                      value={ingredient.type || 'ingredient'}
                      onValueChange={(value) => updateIngredient(index, 'type', value)}
                    >
                      <SelectTrigger className="h-8">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ingredient">Ingredient</SelectItem>
                        <SelectItem value="sub_recipe">Sub-recipe</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Ingredient/Sub-recipe Selection */}
                  <div className="md:col-span-2">
                    <Label className="text-xs">
                      {ingredient.type === 'sub_recipe' ? 'Sub-recipe' : 'Ingredient'}
                    </Label>
                    <Select
                      value={ingredient.ingredient_id || ingredient.sub_recipe_id || ''}
                      onValueChange={(value) => {
                        if (ingredient.type === 'sub_recipe') {
                          updateIngredient(index, 'sub_recipe_id', parseInt(value));
                          updateIngredient(index, 'ingredient_id', null);
                        } else {
                          updateIngredient(index, 'ingredient_id', parseInt(value));
                          updateIngredient(index, 'sub_recipe_id', null);
                        }
                      }}
                    >
                      <SelectTrigger className="h-8">
                        <SelectValue placeholder="Select..." />
                      </SelectTrigger>
                      <SelectContent>
                        {ingredient.type === 'sub_recipe' 
                          ? filteredSubRecipes.map((recipe) => (
                              <SelectItem key={recipe.id} value={recipe.id.toString()}>
                                {recipe.name}
                              </SelectItem>
                            ))
                          : filteredIngredients.map((ing) => (
                              <SelectItem key={ing.id} value={ing.id.toString()}>
                                {ing.name}
                              </SelectItem>
                            ))
                        }
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Quantity */}
                  <div>
                    <Label className="text-xs">Quantity</Label>
                    <Input
                      type="number"
                      step="0.1"
                      min="0"
                      value={ingredient.quantity || ''}
                      onChange={(e) => updateIngredient(index, 'quantity', parseFloat(e.target.value) || 0)}
                      className="h-8"
                    />
                  </div>

                  {/* Unit */}
                  <div>
                    <Label className="text-xs">Unit</Label>
                    <Select
                      value={ingredient.unit || 'g'}
                      onValueChange={(value) => updateIngredient(index, 'unit', value)}
                    >
                      <SelectTrigger className="h-8">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="g">g</SelectItem>
                        <SelectItem value="kg">kg</SelectItem>
                        <SelectItem value="ml">ml</SelectItem>
                        <SelectItem value="l">l</SelectItem>
                        <SelectItem value="cup">cup</SelectItem>
                        <SelectItem value="tbsp">tbsp</SelectItem>
                        <SelectItem value="tsp">tsp</SelectItem>
                        <SelectItem value="piece">piece</SelectItem>
                        <SelectItem value="oz">oz</SelectItem>
                        <SelectItem value="lb">lb</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Notes */}
                  <div>
                    <Label className="text-xs">Notes</Label>
                    <Input
                      value={ingredient.notes || ''}
                      onChange={(e) => updateIngredient(index, 'notes', e.target.value)}
                      placeholder="Optional notes"
                      className="h-8"
                    />
                  </div>
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => removeIngredient(index)}
                  className="text-red-600 hover:text-red-700"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {ingredients.length === 0 && (
        <div className="text-center py-8 text-gray-500">
          <p>No ingredients added yet.</p>
          <p className="text-sm">Click "Add Ingredient" to get started.</p>
        </div>
      )}

      <div className="text-xs text-gray-500 mt-4">
        <p>💡 Tip: Drag ingredients by the grip handle to reorder them</p>
        <p>💡 Changes are automatically saved when you save the recipe</p>
      </div>
    </div>
  );
};

export default IngredientBuilder;

