# CI/CD Pipeline for SLA Documentation Publishing

This directory contains the CI/CD automation for automatically publishing SLA documentation to the `/docs/sla` endpoint when changes are merged to the main branch.

## Overview

The CI pipeline automatically:
1. Builds documentation from Markdown sources
2. Generates static HTML pages with navigation
3. Deploys to the `/docs/sla` endpoint
4. Validates links and accessibility
5. Notifies teams of successful deployment

## Pipeline Components

- **GitHub Actions Workflow**: `.github/workflows/deploy-sla-docs.yml`
- **Docker Configuration**: `Dockerfile` and `docker-compose.yml`
- **Build Scripts**: `scripts/build-docs.sh` and `scripts/deploy.sh`
- **Documentation Configuration**: `docs-config.json`
- **Nginx Configuration**: `nginx/sla-docs.conf`

