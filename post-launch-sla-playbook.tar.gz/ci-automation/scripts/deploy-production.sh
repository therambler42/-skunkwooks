#!/bin/bash

# Production deployment script for SLA Documentation
# Deploys built documentation to production server

set -e

echo "🚀 Deploying SLA Documentation to Production..."

# Configuration
PROD_SERVER="${PROD_SERVER:-your-prod-server.com}"
PROD_USER="${PROD_USER:-deploy}"
DEPLOY_PATH="/var/www/html/docs/sla"
BACKUP_PATH="/var/backups/sla-docs"
LOCAL_BUILD_DIR="dist/docs/sla"

# Validate environment variables
if [ -z "$PROD_SERVER" ] || [ -z "$PROD_USER" ]; then
    echo "❌ Error: PROD_SERVER and PROD_USER environment variables must be set"
    exit 1
fi

# Validate build directory exists
if [ ! -d "$LOCAL_BUILD_DIR" ]; then
    echo "❌ Error: Build directory $LOCAL_BUILD_DIR not found"
    echo "Please run build-docs.sh first"
    exit 1
fi

# Setup SSH key if provided
if [ -n "$PROD_KEY" ]; then
    echo "🔑 Setting up SSH key..."
    mkdir -p ~/.ssh
    echo "$PROD_KEY" > ~/.ssh/deploy_key
    chmod 600 ~/.ssh/deploy_key
    SSH_OPTS="-i ~/.ssh/deploy_key -o StrictHostKeyChecking=no"
else
    SSH_OPTS="-o StrictHostKeyChecking=no"
fi

# Function to run remote commands
run_remote() {
    ssh $SSH_OPTS "$PROD_USER@$PROD_SERVER" "$1"
}

# Function to copy files to remote server
copy_to_remote() {
    rsync -avz --delete -e "ssh $SSH_OPTS" "$1" "$PROD_USER@$PROD_SERVER:$2"
}

echo "📋 Pre-deployment checks..."

# Check if server is accessible
if ! run_remote "echo 'Server accessible'"; then
    echo "❌ Error: Cannot connect to production server"
    exit 1
fi

# Check if deployment directory exists
run_remote "sudo mkdir -p $DEPLOY_PATH"
run_remote "sudo mkdir -p $BACKUP_PATH"

echo "💾 Creating backup of current documentation..."

# Create timestamped backup
BACKUP_TIMESTAMP=$(date +%Y%m%d_%H%M%S)
run_remote "sudo cp -r $DEPLOY_PATH $BACKUP_PATH/sla-docs-$BACKUP_TIMESTAMP 2>/dev/null || true"

# Keep only last 5 backups
run_remote "cd $BACKUP_PATH && sudo ls -t | tail -n +6 | sudo xargs rm -rf"

echo "📤 Uploading new documentation..."

# Create temporary directory on server
TEMP_DIR="/tmp/sla-docs-deploy-$$"
run_remote "mkdir -p $TEMP_DIR"

# Upload files to temporary directory
copy_to_remote "$LOCAL_BUILD_DIR/" "$TEMP_DIR/"

echo "🔄 Deploying documentation..."

# Atomic deployment: move from temp to final location
run_remote "sudo rm -rf $DEPLOY_PATH.old"
run_remote "sudo mv $DEPLOY_PATH $DEPLOY_PATH.old 2>/dev/null || true"
run_remote "sudo mv $TEMP_DIR $DEPLOY_PATH"

# Set proper permissions
run_remote "sudo chown -R www-data:www-data $DEPLOY_PATH"
run_remote "sudo chmod -R 755 $DEPLOY_PATH"
run_remote "sudo find $DEPLOY_PATH -type f -name '*.html' -exec chmod 644 {} \;"
run_remote "sudo find $DEPLOY_PATH -type f -name '*.css' -exec chmod 644 {} \;"
run_remote "sudo find $DEPLOY_PATH -type f -name '*.js' -exec chmod 644 {} \;"
run_remote "sudo find $DEPLOY_PATH -type f -name '*.pdf' -exec chmod 644 {} \;"

echo "🔍 Validating deployment..."

# Test if main pages are accessible
VALIDATION_URLS=(
    "https://$PROD_SERVER/docs/sla/"
    "https://$PROD_SERVER/docs/sla/sla-document.html"
    "https://$PROD_SERVER/docs/sla/support-workflow.html"
    "https://$PROD_SERVER/docs/sla/incident-response-runbook.html"
)

VALIDATION_FAILED=false

for url in "${VALIDATION_URLS[@]}"; do
    echo "Testing $url..."
    if curl -f -s -o /dev/null "$url"; then
        echo "✅ $url - OK"
    else
        echo "❌ $url - FAILED"
        VALIDATION_FAILED=true
    fi
done

if [ "$VALIDATION_FAILED" = true ]; then
    echo "⚠️  Some validation checks failed. Rolling back deployment..."
    run_remote "sudo mv $DEPLOY_PATH $DEPLOY_PATH.failed"
    run_remote "sudo mv $DEPLOY_PATH.old $DEPLOY_PATH 2>/dev/null || true"
    echo "❌ Deployment rolled back due to validation failures"
    exit 1
fi

# Cleanup old deployment
run_remote "sudo rm -rf $DEPLOY_PATH.old"

echo "🧹 Cleaning up..."

# Remove SSH key
if [ -n "$PROD_KEY" ]; then
    rm -f ~/.ssh/deploy_key
fi

echo "✅ Production deployment completed successfully!"
echo "🌐 Documentation available at: https://$PROD_SERVER/docs/sla/"

# Log deployment
echo "📝 Logging deployment..."
DEPLOY_LOG="Deployment completed at $(date -u '+%Y-%m-%d %H:%M:%S UTC') by $USER"
run_remote "echo '$DEPLOY_LOG' | sudo tee -a $DEPLOY_PATH/deployment.log"

# Update last deployment timestamp
run_remote "echo '$(date -u +%s)' | sudo tee $DEPLOY_PATH/.last-deploy"

echo ""
echo "📊 Deployment Summary:"
echo "======================"
echo "Server: $PROD_SERVER"
echo "Path: $DEPLOY_PATH"
echo "Backup: $BACKUP_PATH/sla-docs-$BACKUP_TIMESTAMP"
echo "Status: ✅ SUCCESS"
echo "Time: $(date)"

# Send deployment notification
if [ -n "$SLACK_WEBHOOK" ]; then
    curl -X POST -H 'Content-type: application/json' \
        --data "{\"text\":\"📚 SLA Documentation deployed to production: https://$PROD_SERVER/docs/sla/\"}" \
        "$SLACK_WEBHOOK" || true
fi

