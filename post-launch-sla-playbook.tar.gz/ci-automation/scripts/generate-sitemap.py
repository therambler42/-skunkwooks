#!/usr/bin/env python3

"""
Sitemap generation script for SLA Documentation
Generates XML sitemap for search engine optimization
"""

import os
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path

def generate_sitemap():
    """Generate XML sitemap for the documentation"""
    
    # Configuration
    base_url = "https://your-domain.com/docs/sla"
    output_dir = Path("dist/docs/sla")
    
    # Create sitemap root element
    urlset = ET.Element("urlset")
    urlset.set("xmlns", "http://www.sitemaps.org/schemas/sitemap/0.9")
    
    # Current date for lastmod
    current_date = datetime.now().strftime("%Y-%m-%d")
    
    # Define pages with their priorities and change frequencies
    pages = [
        {
            "url": f"{base_url}/",
            "priority": "1.0",
            "changefreq": "monthly",
            "lastmod": current_date
        },
        {
            "url": f"{base_url}/sla-document.html",
            "priority": "0.9",
            "changefreq": "monthly",
            "lastmod": current_date
        },
        {
            "url": f"{base_url}/support-workflow.html",
            "priority": "0.9",
            "changefreq": "monthly",
            "lastmod": current_date
        },
        {
            "url": f"{base_url}/incident-response-runbook.html",
            "priority": "0.9",
            "changefreq": "monthly",
            "lastmod": current_date
        },
        {
            "url": f"{base_url}/status-page-config.html",
            "priority": "0.8",
            "changefreq": "monthly",
            "lastmod": current_date
        },
        {
            "url": f"{base_url}/downloads.html",
            "priority": "0.7",
            "changefreq": "weekly",
            "lastmod": current_date
        }
    ]
    
    # Add each page to sitemap
    for page in pages:
        url_element = ET.SubElement(urlset, "url")
        
        loc = ET.SubElement(url_element, "loc")
        loc.text = page["url"]
        
        lastmod = ET.SubElement(url_element, "lastmod")
        lastmod.text = page["lastmod"]
        
        changefreq = ET.SubElement(url_element, "changefreq")
        changefreq.text = page["changefreq"]
        
        priority = ET.SubElement(url_element, "priority")
        priority.text = page["priority"]
    
    # Create the tree and write to file
    tree = ET.ElementTree(urlset)
    ET.indent(tree, space="  ", level=0)
    
    # Ensure output directory exists
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Write sitemap
    sitemap_path = output_dir / "sitemap.xml"
    tree.write(sitemap_path, encoding="utf-8", xml_declaration=True)
    
    print(f"✅ Sitemap generated: {sitemap_path}")
    print(f"📄 Pages included: {len(pages)}")
    
    return sitemap_path

def generate_robots_txt():
    """Generate robots.txt file"""
    
    output_dir = Path("dist/docs/sla")
    output_dir.mkdir(parents=True, exist_ok=True)
    
    robots_content = """User-agent: *
Allow: /

# Sitemap location
Sitemap: https://your-domain.com/docs/sla/sitemap.xml

# Crawl delay (optional)
Crawl-delay: 1

# Disallow certain file types
Disallow: /*.pdf$
Disallow: /assets/
"""
    
    robots_path = output_dir / "robots.txt"
    with open(robots_path, 'w', encoding='utf-8') as f:
        f.write(robots_content)
    
    print(f"✅ Robots.txt generated: {robots_path}")
    
    return robots_path

def validate_sitemap(sitemap_path):
    """Validate the generated sitemap"""
    
    try:
        tree = ET.parse(sitemap_path)
        root = tree.getroot()
        
        # Check namespace
        if root.tag != "{http://www.sitemaps.org/schemas/sitemap/0.9}urlset":
            print("❌ Invalid sitemap namespace")
            return False
        
        # Count URLs
        urls = root.findall(".//{http://www.sitemaps.org/schemas/sitemap/0.9}url")
        print(f"📊 Sitemap contains {len(urls)} URLs")
        
        # Validate each URL
        for url in urls:
            loc = url.find("{http://www.sitemaps.org/schemas/sitemap/0.9}loc")
            if loc is None or not loc.text:
                print("❌ URL missing location")
                return False
            
            # Check if URL is properly formatted
            if not loc.text.startswith("http"):
                print(f"❌ Invalid URL format: {loc.text}")
                return False
        
        print("✅ Sitemap validation passed")
        return True
        
    except ET.ParseError as e:
        print(f"❌ Sitemap XML parsing error: {e}")
        return False
    except Exception as e:
        print(f"❌ Sitemap validation error: {e}")
        return False

def main():
    """Main function"""
    
    print("🗺️  Generating sitemap for SLA Documentation...")
    print("=" * 50)
    
    try:
        # Generate sitemap
        sitemap_path = generate_sitemap()
        
        # Generate robots.txt
        robots_path = generate_robots_txt()
        
        # Validate sitemap
        if validate_sitemap(sitemap_path):
            print("\n✅ Sitemap generation completed successfully!")
        else:
            print("\n❌ Sitemap validation failed!")
            return 1
        
        print(f"\n📊 Generated files:")
        print(f"  - {sitemap_path}")
        print(f"  - {robots_path}")
        
        return 0
        
    except Exception as e:
        print(f"\n❌ Error generating sitemap: {e}")
        return 1

if __name__ == "__main__":
    exit(main())

