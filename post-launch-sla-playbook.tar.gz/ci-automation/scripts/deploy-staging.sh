#!/bin/bash

# Staging deployment script for SLA Documentation
# Deploys built documentation to staging server for testing

set -e

echo "🚀 Deploying SLA Documentation to Staging..."

# Configuration
STAGING_SERVER="${STAGING_SERVER:-staging.your-domain.com}"
STAGING_USER="${STAGING_USER:-deploy}"
DEPLOY_PATH="/var/www/html/docs/sla"
LOCAL_BUILD_DIR="dist/docs/sla"

# Validate environment variables
if [ -z "$STAGING_SERVER" ] || [ -z "$STAGING_USER" ]; then
    echo "❌ Error: STAGING_SERVER and STAGING_USER environment variables must be set"
    exit 1
fi

# Validate build directory exists
if [ ! -d "$LOCAL_BUILD_DIR" ]; then
    echo "❌ Error: Build directory $LOCAL_BUILD_DIR not found"
    echo "Please run build-docs.sh first"
    exit 1
fi

# Setup SSH key if provided
if [ -n "$STAGING_KEY" ]; then
    echo "🔑 Setting up SSH key..."
    mkdir -p ~/.ssh
    echo "$STAGING_KEY" > ~/.ssh/staging_key
    chmod 600 ~/.ssh/staging_key
    SSH_OPTS="-i ~/.ssh/staging_key -o StrictHostKeyChecking=no"
else
    SSH_OPTS="-o StrictHostKeyChecking=no"
fi

# Function to run remote commands
run_remote() {
    ssh $SSH_OPTS "$STAGING_USER@$STAGING_SERVER" "$1"
}

# Function to copy files to remote server
copy_to_remote() {
    rsync -avz --delete -e "ssh $SSH_OPTS" "$1" "$STAGING_USER@$STAGING_SERVER:$2"
}

echo "📋 Pre-deployment checks..."

# Check if server is accessible
if ! run_remote "echo 'Staging server accessible'"; then
    echo "❌ Error: Cannot connect to staging server"
    exit 1
fi

# Ensure deployment directory exists
run_remote "sudo mkdir -p $DEPLOY_PATH"

echo "📤 Uploading documentation to staging..."

# Upload files directly to staging (no backup needed for staging)
copy_to_remote "$LOCAL_BUILD_DIR/" "$DEPLOY_PATH/"

# Set proper permissions
run_remote "sudo chown -R www-data:www-data $DEPLOY_PATH"
run_remote "sudo chmod -R 755 $DEPLOY_PATH"

# Add staging banner to indicate this is not production
echo "🏷️  Adding staging banner..."
STAGING_BANNER='<div style="background: #ff6b35; color: white; padding: 10px; text-align: center; font-weight: bold; position: fixed; top: 0; left: 0; right: 0; z-index: 9999;">⚠️ STAGING ENVIRONMENT - NOT FOR PRODUCTION USE ⚠️</div><div style="height: 50px;"></div>'

run_remote "find $DEPLOY_PATH -name '*.html' -exec sudo sed -i 's|<body>|<body>$STAGING_BANNER|g' {} \;"

echo "🔍 Validating staging deployment..."

# Test if main pages are accessible
sleep 5  # Give server time to update

VALIDATION_URLS=(
    "https://$STAGING_SERVER/docs/sla/"
    "https://$STAGING_SERVER/docs/sla/sla-document.html"
)

for url in "${VALIDATION_URLS[@]}"; do
    echo "Testing $url..."
    if curl -f -s -o /dev/null "$url"; then
        echo "✅ $url - OK"
    else
        echo "⚠️  $url - May need more time to propagate"
    fi
done

# Cleanup
if [ -n "$STAGING_KEY" ]; then
    rm -f ~/.ssh/staging_key
fi

echo "✅ Staging deployment completed!"
echo "🌐 Staging URL: https://$STAGING_SERVER/docs/sla/"
echo "⏰ Deployment time: $(date)"

# Log staging deployment
DEPLOY_LOG="Staging deployment at $(date -u '+%Y-%m-%d %H:%M:%S UTC')"
run_remote "echo '$DEPLOY_LOG' | sudo tee -a $DEPLOY_PATH/staging-deployment.log"

