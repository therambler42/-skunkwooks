# CI/CD Setup Guide for SLA Documentation

This guide provides step-by-step instructions for setting up the automated CI/CD pipeline for SLA documentation publishing.

## Prerequisites

- GitHub repository with admin access
- Production server with SSH access
- Staging server with SSH access (optional)
- Docker and Docker Compose installed locally
- Node.js 18+ installed locally

## Quick Start

1. **Copy CI files to your repository:**
   ```bash
   cp -r ci-automation/* /path/to/your/repo/
   ```

2. **Install dependencies:**
   ```bash
   cd /path/to/your/repo
   npm install
   ```

3. **Configure environment variables in GitHub:**
   - Go to Settings > Secrets and variables > Actions
   - Add the required secrets (see Configuration section)

4. **Place your documentation files:**
   ```
   docs/sla/
   ├── sla-document.md
   ├── support-workflow.md
   ├── incident-response-runbook.md
   └── status-page-config.md
   ```

5. **Commit and push to trigger the pipeline:**
   ```bash
   git add .
   git commit -m "Add SLA documentation and CI pipeline"
   git push origin main
   ```

## Configuration

### Required GitHub Secrets

Add these secrets in your GitHub repository settings:

#### Production Deployment
- `PROD_SERVER`: Production server hostname
- `PROD_USER`: SSH username for production
- `PROD_SSH_KEY`: SSH private key for production access

#### Staging Deployment (Optional)
- `STAGING_SERVER`: Staging server hostname
- `STAGING_USER`: SSH username for staging
- `STAGING_SSH_KEY`: SSH private key for staging access

#### Notifications
- `SLACK_WEBHOOK`: Slack webhook URL for notifications
- `TEAMS_WEBHOOK`: Microsoft Teams webhook URL
- `EMAIL_RECIPIENTS`: Email addresses for notifications

#### External Services (Optional)
- `SEARCH_INDEX_WEBHOOK`: Search service webhook for reindexing
- `SEARCH_API_KEY`: API key for search service
- `STATUS_DASHBOARD_API`: Status dashboard API endpoint
- `STATUS_API_KEY`: API key for status dashboard

### Server Setup

#### Production Server Requirements
- Nginx or Apache web server
- SSH access for deployment user
- Write permissions to `/var/www/html/docs/sla/`

#### Nginx Configuration
```nginx
server {
    listen 80;
    server_name your-domain.com;
    
    location /docs/sla/ {
        root /var/www/html;
        try_files $uri $uri/ $uri.html =404;
    }
}
```

#### User Permissions
```bash
# Create deployment user
sudo useradd -m -s /bin/bash deploy

# Add to web server group
sudo usermod -a -G www-data deploy

# Set up SSH key
sudo mkdir -p /home/deploy/.ssh
sudo cp your-public-key.pub /home/deploy/.ssh/authorized_keys
sudo chown -R deploy:deploy /home/deploy/.ssh
sudo chmod 700 /home/deploy/.ssh
sudo chmod 600 /home/deploy/.ssh/authorized_keys

# Grant permissions to web directory
sudo chown -R www-data:www-data /var/www/html/docs
sudo chmod -R 755 /var/www/html/docs
```

## Pipeline Overview

The CI/CD pipeline consists of the following stages:

### 1. Validation
- Markdown syntax validation
- Link checking
- Document structure validation
- Content quality checks

### 2. Build
- Convert Markdown to HTML
- Generate PDF versions
- Create navigation and index pages
- Optimize assets

### 3. Test
- Accessibility testing with pa11y
- Link validation with broken-link-checker
- Performance testing with Lighthouse
- Security scanning

### 4. Deploy
- **Staging**: Deploy to staging environment for PR previews
- **Production**: Deploy to production on main branch merge

### 5. Notify
- Send notifications to Slack/Teams
- Update status dashboards
- Create deployment records

## Local Development

### Build Documentation Locally
```bash
# Install dependencies
npm install

# Build documentation
npm run build

# Generate PDFs
npm run build:pdf

# Run local server
npm run dev
```

### Test with Docker
```bash
# Build and run locally
docker-compose up --build

# Run tests
docker-compose -f docker-compose.test.yml up --abort-on-container-exit

# Run specific test profiles
docker-compose -f docker-compose.test.yml --profile accessibility up
docker-compose -f docker-compose.test.yml --profile linkcheck up
docker-compose -f docker-compose.test.yml --profile performance up
```

### Manual Deployment
```bash
# Deploy to staging
npm run deploy:staging

# Deploy to production
npm run deploy:production
```

## Customization

### Modify Build Process
Edit `scripts/build-docs.sh` to customize:
- HTML template
- CSS styling
- Navigation structure
- Asset processing

### Add New Document Types
1. Add new Markdown files to the repository
2. Update `scripts/build-docs.sh` to include new files
3. Update navigation in the build script
4. Add new URLs to sitemap generation

### Customize Notifications
Edit `scripts/notify-deployment.sh` to:
- Add new notification channels
- Customize message formats
- Add deployment tracking

### Modify Testing
Update `.github/workflows/deploy-sla-docs.yml` to:
- Add new test steps
- Modify validation criteria
- Change deployment conditions

## Troubleshooting

### Common Issues

#### Build Failures
- Check Markdown syntax with `npm run test:lint`
- Validate links with `npm run test:links`
- Review build logs in GitHub Actions

#### Deployment Failures
- Verify SSH connectivity to servers
- Check file permissions on target directories
- Validate server configuration

#### Test Failures
- Review accessibility issues with pa11y reports
- Check broken links in test output
- Examine Lighthouse performance reports

### Debug Commands
```bash
# Validate documents locally
python3 scripts/validate-docs.py

# Test build process
./scripts/build-docs.sh

# Check generated files
ls -la dist/docs/sla/

# Test Docker build
docker build -t sla-docs .
docker run -p 8080:80 sla-docs
```

## Maintenance

### Regular Tasks
- Review and update documentation quarterly
- Monitor build performance and optimize as needed
- Update dependencies and security patches
- Review and rotate SSH keys annually

### Monitoring
- Set up alerts for build failures
- Monitor deployment success rates
- Track documentation usage analytics
- Review security scan results

## Support

For issues with the CI/CD pipeline:
1. Check GitHub Actions logs
2. Review server logs
3. Validate configuration settings
4. Test locally with Docker

For documentation content issues:
1. Run validation scripts
2. Check Markdown syntax
3. Validate internal links
4. Review content structure

## Security Considerations

- Rotate SSH keys regularly
- Use least-privilege access for deployment users
- Monitor deployment logs for suspicious activity
- Keep dependencies updated
- Use secrets management for sensitive data
- Enable security scanning in the pipeline

## Performance Optimization

- Enable compression in web server
- Set appropriate cache headers
- Optimize images and assets
- Use CDN for global distribution
- Monitor page load times
- Implement lazy loading for large documents

