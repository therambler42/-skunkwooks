from flask import Blueprint, request, jsonify, current_app
from src.models.database import db, Batch, Inventory, Location, Material
from sqlalchemy import func
import json

inventory_bp = Blueprint('inventory', __name__)

def get_cache_key(prefix, **kwargs):
    """Generate cache key from parameters"""
    key_parts = [prefix]
    for k, v in sorted(kwargs.items()):
        if v is not None:
            key_parts.append(f"{k}:{v}")
    return ":".join(key_parts)

def get_from_cache(key):
    """Get data from Redis cache"""
    redis_client = current_app.config.get('REDIS_CLIENT')
    if redis_client:
        try:
            cached_data = redis_client.get(key)
            if cached_data:
                return json.loads(cached_data)
        except Exception:
            pass
    return None

def set_cache(key, data, ttl=300):
    """Set data in Redis cache with TTL"""
    redis_client = current_app.config.get('REDIS_CLIENT')
    if redis_client:
        try:
            redis_client.setex(key, ttl, json.dumps(data, default=str))
        except Exception:
            pass

@inventory_bp.route('/summary', methods=['GET'])
def get_inventory_summary():
    """Get inventory summary with optional filtering"""
    try:
        # Get query parameters
        product_id = request.args.get('product_id', type=int)
        location_id = request.args.get('location_id', type=int)
        
        # Check cache first
        cache_key = get_cache_key('inventory_summary', product_id=product_id, location_id=location_id)
        cached_result = get_from_cache(cache_key)
        if cached_result:
            return jsonify(cached_result), 200
        
        # Build query
        query = db.session.query(
            Inventory.batch_id,
            Batch.batch_code,
            Batch.manufacturing_date,
            Batch.expiration_date,
            Batch.product_id,
            Material.material_code,
            Material.material_name,
            Inventory.location_id,
            Location.location_name,
            func.sum(Inventory.quantity_on_hand).label('total_quantity'),
            func.sum(Inventory.quantity_available).label('available_quantity'),
            func.sum(Inventory.quantity_allocated).label('allocated_quantity')
        ).join(Batch, Inventory.batch_id == Batch.id)\
         .join(Material, Batch.product_id == Material.id)\
         .join(Location, Inventory.location_id == Location.id)
        
        if product_id:
            query = query.filter(Batch.product_id == product_id)
        if location_id:
            query = query.filter(Inventory.location_id == location_id)
        
        # Group by batch and location
        query = query.group_by(
            Inventory.batch_id,
            Batch.batch_code,
            Batch.manufacturing_date,
            Batch.expiration_date,
            Batch.product_id,
            Material.material_code,
            Material.material_name,
            Inventory.location_id,
            Location.location_name
        ).order_by(Batch.manufacturing_date.desc())
        
        results = query.all()
        
        # Aggregate by product and location
        summary = {}
        batches = []
        
        for row in results:
            # Add to batches list
            batches.append({
                'batch_id': row.batch_id,
                'batch_code': row.batch_code,
                'quantity_on_hand': float(row.total_quantity),
                'manufacturing_date': row.manufacturing_date.isoformat() if row.manufacturing_date else None,
                'expiration_date': row.expiration_date.isoformat() if row.expiration_date else None,
                'location': {
                    'id': row.location_id,
                    'name': row.location_name
                }
            })
            
            # Aggregate totals
            key = f"{row.product_id}_{row.location_id}"
            if key not in summary:
                summary[key] = {
                    'product_id': row.product_id,
                    'product_code': row.material_code,
                    'product_name': row.material_name,
                    'location_id': row.location_id,
                    'location_name': row.location_name,
                    'total_quantity': 0.0,
                    'available_quantity': 0.0,
                    'allocated_quantity': 0.0
                }
            
            summary[key]['total_quantity'] += float(row.total_quantity)
            summary[key]['available_quantity'] += float(row.available_quantity)
            summary[key]['allocated_quantity'] += float(row.allocated_quantity)
        
        result = {
            'summary': list(summary.values()),
            'batches': batches
        }
        
        # Cache the result
        set_cache(cache_key, result, ttl=300)  # 5 minutes
        
        return jsonify(result), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@inventory_bp.route('/batches/<int:batch_id>', methods=['GET'])
def get_batch_details(batch_id):
    """Get detailed batch information"""
    try:
        # Check cache first
        cache_key = get_cache_key('batch_details', batch_id=batch_id)
        cached_result = get_from_cache(cache_key)
        if cached_result:
            return jsonify(cached_result), 200
        
        # Get batch with related data
        batch = Batch.query.get(batch_id)
        if not batch:
            return jsonify({'error': 'Batch not found'}), 404
        
        # Get inventory locations for this batch
        inventory_locations = []
        for inv in batch.inventory_records:
            inventory_locations.append({
                'location_id': inv.location.id,
                'location_name': inv.location.location_name,
                'quantity_on_hand': inv.quantity_on_hand,
                'quantity_allocated': inv.quantity_allocated,
                'quantity_available': inv.quantity_available,
                'last_transaction_date': inv.last_transaction_date.isoformat() if inv.last_transaction_date else None
            })
        
        result = {
            'id': batch.id,
            'batch_code': batch.batch_code,
            'lot_number': batch.lot_number,
            'work_order': {
                'id': batch.work_order.id,
                'work_order_number': batch.work_order.work_order_number
            } if batch.work_order else None,
            'product': {
                'id': batch.product.id,
                'material_code': batch.product.material_code,
                'material_name': batch.product.material_name,
                'unit_of_measure': batch.product.unit_of_measure
            },
            'quantity': batch.quantity,
            'manufacturing_date': batch.manufacturing_date.isoformat() if batch.manufacturing_date else None,
            'expiration_date': batch.expiration_date.isoformat() if batch.expiration_date else None,
            'status': batch.status,
            'quality_status': batch.quality_status,
            'inventory_locations': inventory_locations,
            'created_at': batch.created_at.isoformat(),
            'updated_at': batch.updated_at.isoformat()
        }
        
        # Cache the result
        set_cache(cache_key, result, ttl=1800)  # 30 minutes
        
        return jsonify(result), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@inventory_bp.route('/batches', methods=['GET'])
def list_batches():
    """List batches with optional filtering"""
    try:
        # Get query parameters
        product_id = request.args.get('product_id', type=int)
        location_id = request.args.get('location_id', type=int)
        status = request.args.get('status')
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        # Build query
        query = db.session.query(Batch).join(Inventory, Batch.id == Inventory.batch_id)
        
        if product_id:
            query = query.filter(Batch.product_id == product_id)
        if location_id:
            query = query.filter(Inventory.location_id == location_id)
        if status:
            query = query.filter(Batch.status == status)
        
        # Order by manufacturing date (newest first)
        query = query.order_by(Batch.manufacturing_date.desc())
        
        # Remove duplicates and paginate
        query = query.distinct()
        pagination = query.paginate(page=page, per_page=per_page, error_out=False)
        batches = pagination.items
        
        result = []
        for batch in batches:
            # Get total inventory for this batch
            total_inventory = db.session.query(func.sum(Inventory.quantity_on_hand))\
                .filter(Inventory.batch_id == batch.id).scalar() or 0
            
            result.append({
                'id': batch.id,
                'batch_code': batch.batch_code,
                'lot_number': batch.lot_number,
                'product': {
                    'id': batch.product.id,
                    'material_code': batch.product.material_code,
                    'material_name': batch.product.material_name
                },
                'quantity': batch.quantity,
                'quantity_on_hand': float(total_inventory),
                'manufacturing_date': batch.manufacturing_date.isoformat() if batch.manufacturing_date else None,
                'expiration_date': batch.expiration_date.isoformat() if batch.expiration_date else None,
                'status': batch.status,
                'quality_status': batch.quality_status
            })
        
        return jsonify({
            'batches': result,
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': pagination.total,
                'pages': pagination.pages,
                'has_next': pagination.has_next,
                'has_prev': pagination.has_prev
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@inventory_bp.route('/transactions', methods=['POST'])
def create_inventory_transaction():
    """Create an inventory transaction (movement, adjustment, etc.)"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['batch_id', 'location_id', 'transaction_type', 'quantity']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        batch_id = data['batch_id']
        location_id = data['location_id']
        transaction_type = data['transaction_type']  # RECEIPT, SHIPMENT, TRANSFER, ADJUSTMENT
        quantity = data['quantity']
        
        # Get or create inventory record
        inventory = Inventory.query.filter_by(batch_id=batch_id, location_id=location_id).first()
        
        if not inventory:
            if transaction_type in ['SHIPMENT', 'TRANSFER']:
                return jsonify({'error': 'No inventory available for shipment/transfer'}), 400
            
            # Create new inventory record for receipts
            inventory = Inventory(
                batch_id=batch_id,
                location_id=location_id,
                quantity_on_hand=0.0,
                quantity_allocated=0.0,
                quantity_available=0.0
            )
            db.session.add(inventory)
        
        # Update quantities based on transaction type
        if transaction_type == 'RECEIPT':
            inventory.quantity_on_hand += quantity
            inventory.quantity_available += quantity
        elif transaction_type in ['SHIPMENT', 'TRANSFER']:
            if inventory.quantity_available < quantity:
                return jsonify({'error': 'Insufficient available quantity'}), 400
            inventory.quantity_on_hand -= quantity
            inventory.quantity_available -= quantity
        elif transaction_type == 'ADJUSTMENT':
            # Adjustment can be positive or negative
            inventory.quantity_on_hand += quantity
            inventory.quantity_available += quantity
        
        # Ensure quantities don't go negative
        if inventory.quantity_on_hand < 0:
            inventory.quantity_on_hand = 0
        if inventory.quantity_available < 0:
            inventory.quantity_available = 0
        
        inventory.last_transaction_date = datetime.utcnow()
        
        db.session.commit()
        
        # Clear related caches
        redis_client = current_app.config.get('REDIS_CLIENT')
        if redis_client:
            try:
                # Clear batch details cache
                batch_cache_key = get_cache_key('batch_details', batch_id=batch_id)
                redis_client.delete(batch_cache_key)
                
                # Clear inventory summary caches (this is a simplified approach)
                keys = redis_client.keys('inventory_summary:*')
                if keys:
                    redis_client.delete(*keys)
            except Exception:
                pass
        
        return jsonify({
            'id': inventory.id,
            'batch_id': inventory.batch_id,
            'location_id': inventory.location_id,
            'quantity_on_hand': inventory.quantity_on_hand,
            'quantity_allocated': inventory.quantity_allocated,
            'quantity_available': inventory.quantity_available,
            'transaction_type': transaction_type,
            'transaction_quantity': quantity,
            'last_transaction_date': inventory.last_transaction_date.isoformat()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

