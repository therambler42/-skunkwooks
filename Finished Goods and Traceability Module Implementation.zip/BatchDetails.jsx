import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ArrowLeft, Package, Calendar, MapPin, Factory, Users, ArrowRight } from 'lucide-react'
import axios from 'axios'

const BatchDetails = ({ apiBaseUrl }) => {
  const { batchId } = useParams()
  const navigate = useNavigate()
  const [batch, setBatch] = useState(null)
  const [genealogy, setGenealogy] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchBatchDetails()
  }, [batchId])

  const fetchBatchDetails = async () => {
    try {
      setLoading(true)
      
      // Fetch batch details
      const batchResponse = await axios.get(`${apiBaseUrl}/inventory/batches/${batchId}`)
      setBatch(batchResponse.data)
      
      // Fetch genealogy if batch code is available
      if (batchResponse.data.batch_code) {
        try {
          const genealogyResponse = await axios.get(`${apiBaseUrl}/traceability/batch-genealogy/${batchResponse.data.batch_code}`)
          setGenealogy(genealogyResponse.data)
        } catch (error) {
          console.log('Genealogy not available:', error)
        }
      }
      
    } catch (error) {
      console.error('Error fetching batch details:', error)
    } finally {
      setLoading(false)
    }
  }

  const getStatusBadgeColor = (status) => {
    switch (status) {
      case 'RELEASED': return 'bg-green-100 text-green-800'
      case 'QUARANTINE': return 'bg-red-100 text-red-800'
      case 'ACTIVE': return 'bg-blue-100 text-blue-800'
      case 'PASSED': return 'bg-green-100 text-green-800'
      case 'FAILED': return 'bg-red-100 text-red-800'
      case 'PENDING': return 'bg-yellow-100 text-yellow-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center space-x-4">
          <Button variant="outline" onClick={() => navigate('/inventory')}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Inventory
          </Button>
          <h1 className="text-3xl font-bold text-gray-900">Batch Details</h1>
        </div>
        <div className="text-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-2 text-gray-600">Loading batch details...</p>
        </div>
      </div>
    )
  }

  if (!batch) {
    return (
      <div className="space-y-6">
        <div className="flex items-center space-x-4">
          <Button variant="outline" onClick={() => navigate('/inventory')}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Inventory
          </Button>
          <h1 className="text-3xl font-bold text-gray-900">Batch Details</h1>
        </div>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center py-8">
              <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">Batch not found</p>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-4">
        <Button variant="outline" onClick={() => navigate('/inventory')}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Inventory
        </Button>
        <h1 className="text-3xl font-bold text-gray-900">Batch Details</h1>
      </div>

      {/* Batch Overview */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center space-x-2">
              <Package className="h-6 w-6" />
              <span>{batch.batch_code}</span>
            </CardTitle>
            <div className="flex space-x-2">
              <Badge className={getStatusBadgeColor(batch.status)}>
                {batch.status}
              </Badge>
              <Badge className={getStatusBadgeColor(batch.quality_status)}>
                Quality: {batch.quality_status}
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Product Information</h4>
              <div className="space-y-1 text-sm">
                <p><span className="text-gray-500">Code:</span> {batch.product.material_code}</p>
                <p><span className="text-gray-500">Name:</span> {batch.product.material_name}</p>
                <p><span className="text-gray-500">UOM:</span> {batch.product.unit_of_measure}</p>
              </div>
            </div>
            
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Batch Information</h4>
              <div className="space-y-1 text-sm">
                <p><span className="text-gray-500">Lot Number:</span> {batch.lot_number}</p>
                <p><span className="text-gray-500">Quantity:</span> {batch.quantity?.toLocaleString()}</p>
                {batch.work_order && (
                  <p><span className="text-gray-500">Work Order:</span> {batch.work_order.work_order_number}</p>
                )}
              </div>
            </div>
            
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Dates</h4>
              <div className="space-y-1 text-sm">
                <p className="flex items-center">
                  <Calendar className="h-3 w-3 mr-1 text-gray-400" />
                  <span className="text-gray-500">Manufactured:</span>
                  <span className="ml-1">
                    {batch.manufacturing_date ? new Date(batch.manufacturing_date).toLocaleDateString() : 'N/A'}
                  </span>
                </p>
                <p className="flex items-center">
                  <Calendar className="h-3 w-3 mr-1 text-gray-400" />
                  <span className="text-gray-500">Expires:</span>
                  <span className="ml-1">
                    {batch.expiration_date ? new Date(batch.expiration_date).toLocaleDateString() : 'N/A'}
                  </span>
                </p>
                <p className="flex items-center">
                  <Calendar className="h-3 w-3 mr-1 text-gray-400" />
                  <span className="text-gray-500">Created:</span>
                  <span className="ml-1">
                    {new Date(batch.created_at).toLocaleDateString()}
                  </span>
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Inventory Locations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <MapPin className="h-5 w-5" />
            <span>Inventory Locations</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {batch.inventory_locations && batch.inventory_locations.length > 0 ? (
            <div className="space-y-3">
              {batch.inventory_locations.map((location, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <MapPin className="h-4 w-4 text-gray-400" />
                    <div>
                      <p className="font-medium text-gray-900">{location.location_name}</p>
                      <p className="text-sm text-gray-600">Location ID: {location.location_id}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-gray-900">
                      {location.quantity_on_hand?.toLocaleString()} on hand
                    </p>
                    <p className="text-sm text-gray-600">
                      {location.quantity_available?.toLocaleString()} available
                    </p>
                    {location.quantity_allocated > 0 && (
                      <p className="text-sm text-orange-600">
                        {location.quantity_allocated?.toLocaleString()} allocated
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-4 text-gray-600">
              No inventory locations found
            </div>
          )}
        </CardContent>
      </Card>

      {/* Genealogy */}
      {genealogy && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Parent Materials */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <ArrowLeft className="h-5 w-5" />
                <span>Source Materials (Parents)</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {genealogy.parents && genealogy.parents.length > 0 ? (
                <div className="space-y-3">
                  {genealogy.parents.map((parent, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <p className="font-medium text-gray-900">{parent.batch_code}</p>
                        <p className="text-sm text-gray-600">{parent.material_name}</p>
                        {parent.work_order_number && (
                          <p className="text-xs text-gray-500">WO: {parent.work_order_number}</p>
                        )}
                      </div>
                      <div className="text-right text-sm">
                        <p className="font-medium">
                          {parent.quantity_consumed?.toLocaleString()} consumed
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-4 text-gray-600">
                  No parent materials found
                </div>
              )}
            </CardContent>
          </Card>

          {/* Child Products */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <ArrowRight className="h-5 w-5" />
                <span>Derived Products (Children)</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {genealogy.children && genealogy.children.length > 0 ? (
                <div className="space-y-3">
                  {genealogy.children.map((child, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <p className="font-medium text-gray-900">{child.batch_code}</p>
                        <p className="text-sm text-gray-600">{child.material_name}</p>
                        {child.work_order_number && (
                          <p className="text-xs text-gray-500">WO: {child.work_order_number}</p>
                        )}
                      </div>
                      <div className="text-right text-sm">
                        <p className="font-medium">
                          {child.quantity_consumed?.toLocaleString()} used
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-4 text-gray-600">
                  No child products found
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-3">
            <Button 
              variant="outline"
              onClick={() => navigate(`/traceability?batch=${batch.batch_code}&type=forward`)}
            >
              <ArrowRight className="h-4 w-4 mr-2" />
              Forward Trace
            </Button>
            <Button 
              variant="outline"
              onClick={() => navigate(`/traceability?batch=${batch.batch_code}&type=backward`)}
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Backward Trace
            </Button>
            <Button variant="outline">
              <Factory className="h-4 w-4 mr-2" />
              View Work Order
            </Button>
            <Button variant="outline">
              <Users className="h-4 w-4 mr-2" />
              Quality Records
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default BatchDetails

