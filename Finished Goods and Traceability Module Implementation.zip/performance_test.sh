#!/bin/bash

# Performance Testing Script for Traceability API
# Tests the <2s requirement for recall queries

echo "=== Traceability API Performance Testing ==="
echo "Testing recall query performance requirements (<2s for 10k lots)"
echo ""

API_BASE="http://localhost:5002/api"

# Test 1: Forward Traceability Performance
echo "Test 1: Forward Traceability Query"
echo "Testing with multiple source batches..."

for i in {1..5}; do
    echo -n "  Run $i: "
    response_time=$(curl -X POST $API_BASE/traceability/forward \
        -H "Content-Type: application/json" \
        -d '{"source_batch_codes": ["RM-PLASTIC-0001", "RM-STEEL-0002"], "include_indirect": true, "max_levels": 10}' \
        -w "%{time_total}" \
        -s -o /dev/null)
    
    # Convert to milliseconds
    response_ms=$(echo "$response_time * 1000" | bc)
    echo "${response_ms}ms"
    
    if (( $(echo "$response_time < 2.0" | bc -l) )); then
        echo "    ✓ PASS - Under 2s requirement"
    else
        echo "    ✗ FAIL - Exceeds 2s requirement"
    fi
done

echo ""

# Test 2: Backward Traceability Performance
echo "Test 2: Backward Traceability Query"
echo "Testing with multiple target batches..."

for i in {1..5}; do
    echo -n "  Run $i: "
    response_time=$(curl -X POST $API_BASE/traceability/backward \
        -H "Content-Type: application/json" \
        -d '{"target_batch_codes": ["BATCH-20250411-0001", "BATCH-20250111-0002"], "include_indirect": true, "max_levels": 10}' \
        -w "%{time_total}" \
        -s -o /dev/null)
    
    response_ms=$(echo "$response_time * 1000" | bc)
    echo "${response_ms}ms"
    
    if (( $(echo "$response_time < 2.0" | bc -l) )); then
        echo "    ✓ PASS - Under 2s requirement"
    else
        echo "    ✗ FAIL - Exceeds 2s requirement"
    fi
done

echo ""

# Test 3: Recall Analysis Performance (Most Complex)
echo "Test 3: Recall Analysis Query (Most Complex)"
echo "Testing comprehensive recall impact analysis..."

for i in {1..5}; do
    echo -n "  Run $i: "
    response_time=$(curl -X POST $API_BASE/traceability/recall-analysis \
        -H "Content-Type: application/json" \
        -d '{"affected_batches": ["RM-PLASTIC-0001"], "recall_type": "FORWARD", "severity": "HIGH"}' \
        -w "%{time_total}" \
        -s -o /dev/null)
    
    response_ms=$(echo "$response_time * 1000" | bc)
    echo "${response_ms}ms"
    
    if (( $(echo "$response_time < 2.0" | bc -l) )); then
        echo "    ✓ PASS - Under 2s requirement"
    else
        echo "    ✗ FAIL - Exceeds 2s requirement"
    fi
done

echo ""

# Test 4: Concurrent Load Test
echo "Test 4: Concurrent Load Test"
echo "Testing with multiple simultaneous requests..."

echo "  Starting 10 concurrent forward trace requests..."
for i in {1..10}; do
    (
        response_time=$(curl -X POST $API_BASE/traceability/forward \
            -H "Content-Type: application/json" \
            -d '{"source_batch_codes": ["RM-COMPONENT-0005"], "include_indirect": true, "max_levels": 5}' \
            -w "%{time_total}" \
            -s -o /dev/null)
        response_ms=$(echo "$response_time * 1000" | bc)
        echo "    Concurrent request $i: ${response_ms}ms"
    ) &
done

wait

echo ""

# Test 5: Database Query Performance
echo "Test 5: Database Query Performance"
echo "Testing inventory and batch queries..."

echo -n "  Inventory Summary: "
response_time=$(curl -s $API_BASE/inventory/summary -w "%{time_total}" -o /dev/null)
response_ms=$(echo "$response_time * 1000" | bc)
echo "${response_ms}ms"

echo -n "  Work Orders List: "
response_time=$(curl -s "$API_BASE/workorders/?per_page=50" -w "%{time_total}" -o /dev/null)
response_ms=$(echo "$response_time * 1000" | bc)
echo "${response_ms}ms"

echo ""
echo "=== Performance Testing Complete ==="
echo ""
echo "Summary:"
echo "- All traceability queries should complete in <2000ms"
echo "- System should handle concurrent requests efficiently"
echo "- Database queries should be optimized with proper indexing"
echo ""
echo "Note: Performance may vary based on data volume and system resources."

