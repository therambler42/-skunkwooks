import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { useState } from 'react'
import Navigation from './components/Navigation'
import Dashboard from './components/Dashboard'
import WorkOrders from './components/WorkOrders'
import Inventory from './components/Inventory'
import Traceability from './components/Traceability'
import BatchDetails from './components/BatchDetails'
import './App.css'

function App() {
  const [apiBaseUrl] = useState(import.meta.env.VITE_API_BASE_URL || 'http://localhost:5002/api')

  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <main className="container mx-auto px-4 py-8">
          <Routes>
            <Route path="/" element={<Dashboard apiBaseUrl={apiBaseUrl} />} />
            <Route path="/workorders" element={<WorkOrders apiBaseUrl={apiBaseUrl} />} />
            <Route path="/inventory" element={<Inventory apiBaseUrl={apiBaseUrl} />} />
            <Route path="/traceability" element={<Traceability apiBaseUrl={apiBaseUrl} />} />
            <Route path="/batch/:batchId" element={<BatchDetails apiBaseUrl={apiBaseUrl} />} />
          </Routes>
        </main>
      </div>
    </Router>
  )
}

export default App

