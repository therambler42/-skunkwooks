# API Specifications and Data Models

## Data Models

### Work Order Model

```python
class WorkOrder:
    id: int                    # Primary key
    work_order_number: str     # Unique work order identifier
    product_id: int           # Foreign key to Product
    planned_quantity: float   # Planned production quantity
    actual_quantity: float    # Actual production quantity
    status: str              # CREATED, IN_PROGRESS, COMPLETED, CANCELLED
    start_date: datetime     # Production start date
    completion_date: datetime # Production completion date
    created_at: datetime     # Record creation timestamp
    updated_at: datetime     # Last update timestamp
    created_by: int          # User who created the work order
    completed_by: int        # User who completed the work order
```

### Batch Model

```python
class Batch:
    id: int                  # Primary key
    batch_code: str          # Unique batch identifier
    lot_number: str          # Lot number for traceability
    work_order_id: int       # Foreign key to WorkOrder
    product_id: int          # Foreign key to Product
    quantity: float          # Batch quantity
    manufacturing_date: date # Date of manufacture
    expiration_date: date    # Product expiration date
    status: str              # ACTIVE, QUARANTINE, RELEASED, RECALLED
    quality_status: str      # PENDING, PASSED, FAILED
    created_at: datetime     # Record creation timestamp
    updated_at: datetime     # Last update timestamp
```

### Inventory Model

```python
class Inventory:
    id: int                  # Primary key
    batch_id: int            # Foreign key to Batch
    location_id: int         # Foreign key to Location
    quantity_on_hand: float  # Current quantity available
    quantity_allocated: float # Quantity allocated to orders
    quantity_available: float # Available quantity (on_hand - allocated)
    last_transaction_date: datetime # Last inventory movement
    created_at: datetime     # Record creation timestamp
    updated_at: datetime     # Last update timestamp
```

### Traceability Link Model

```python
class TraceabilityLink:
    id: int                  # Primary key
    parent_batch_id: int     # Source batch (raw material)
    child_batch_id: int      # Destination batch (finished good)
    work_order_id: int       # Work order that created the link
    quantity_consumed: float # Quantity of parent used
    link_type: str           # DIRECT, REWORK, BLEND
    created_at: datetime     # Link creation timestamp
```

### Material Model

```python
class Material:
    id: int                  # Primary key
    material_code: str       # Unique material identifier
    material_name: str       # Material description
    material_type: str       # RAW_MATERIAL, FINISHED_GOOD, INTERMEDIATE
    unit_of_measure: str     # UOM (kg, liters, pieces, etc.)
    shelf_life_days: int     # Shelf life in days
    requires_lot_tracking: bool # Whether lot tracking is required
    created_at: datetime     # Record creation timestamp
    updated_at: datetime     # Last update timestamp
```

## API Endpoints Specification

### Work Order Management APIs

#### Create Work Order
```
POST /api/workorders/
Content-Type: application/json

Request Body:
{
    "work_order_number": "WO-2024-001",
    "product_id": 123,
    "planned_quantity": 1000.0,
    "start_date": "2024-01-15T08:00:00Z"
}

Response:
{
    "id": 456,
    "work_order_number": "WO-2024-001",
    "product_id": 123,
    "planned_quantity": 1000.0,
    "actual_quantity": null,
    "status": "CREATED",
    "start_date": "2024-01-15T08:00:00Z",
    "completion_date": null,
    "created_at": "2024-01-15T07:30:00Z",
    "updated_at": "2024-01-15T07:30:00Z"
}
```

#### Complete Work Order
```
POST /api/workorders/{id}/complete
Content-Type: application/json

Request Body:
{
    "actual_quantity": 950.0,
    "completion_date": "2024-01-15T16:00:00Z",
    "quality_notes": "Production completed successfully"
}

Response:
{
    "work_order": {
        "id": 456,
        "status": "COMPLETED",
        "actual_quantity": 950.0,
        "completion_date": "2024-01-15T16:00:00Z"
    },
    "batch": {
        "id": 789,
        "batch_code": "BATCH-2024-001",
        "lot_number": "LOT-456-001",
        "quantity": 950.0,
        "manufacturing_date": "2024-01-15"
    },
    "inventory": {
        "id": 101,
        "quantity_on_hand": 950.0,
        "location_id": 1
    }
}
```

#### Get Work Order Details
```
GET /api/workorders/{id}

Response:
{
    "id": 456,
    "work_order_number": "WO-2024-001",
    "product": {
        "id": 123,
        "material_code": "FG-WIDGET-001",
        "material_name": "Premium Widget"
    },
    "planned_quantity": 1000.0,
    "actual_quantity": 950.0,
    "status": "COMPLETED",
    "start_date": "2024-01-15T08:00:00Z",
    "completion_date": "2024-01-15T16:00:00Z",
    "batches": [
        {
            "id": 789,
            "batch_code": "BATCH-2024-001",
            "quantity": 950.0
        }
    ]
}
```

### Inventory Management APIs

#### Get Inventory Summary
```
GET /api/inventory/summary?product_id=123&location_id=1

Response:
{
    "product_id": 123,
    "location_id": 1,
    "total_quantity": 2850.0,
    "available_quantity": 2650.0,
    "allocated_quantity": 200.0,
    "batches": [
        {
            "batch_id": 789,
            "batch_code": "BATCH-2024-001",
            "quantity_on_hand": 950.0,
            "manufacturing_date": "2024-01-15",
            "expiration_date": "2024-07-15"
        },
        {
            "batch_id": 790,
            "batch_code": "BATCH-2024-002",
            "quantity_on_hand": 1900.0,
            "manufacturing_date": "2024-01-16",
            "expiration_date": "2024-07-16"
        }
    ]
}
```

#### Get Batch Details
```
GET /api/inventory/batches/{batch_id}

Response:
{
    "id": 789,
    "batch_code": "BATCH-2024-001",
    "lot_number": "LOT-456-001",
    "work_order": {
        "id": 456,
        "work_order_number": "WO-2024-001"
    },
    "product": {
        "id": 123,
        "material_code": "FG-WIDGET-001",
        "material_name": "Premium Widget"
    },
    "quantity": 950.0,
    "manufacturing_date": "2024-01-15",
    "expiration_date": "2024-07-15",
    "status": "RELEASED",
    "quality_status": "PASSED",
    "inventory_locations": [
        {
            "location_id": 1,
            "location_name": "Main Warehouse",
            "quantity_on_hand": 950.0
        }
    ]
}
```

### Traceability and Recall APIs

#### Forward Traceability Query
```
POST /api/traceability/forward
Content-Type: application/json

Request Body:
{
    "source_batch_codes": ["RM-BATCH-001", "RM-BATCH-002"],
    "date_range": {
        "start_date": "2024-01-01",
        "end_date": "2024-01-31"
    },
    "include_indirect": true
}

Response:
{
    "query_id": "TQ-2024-001",
    "execution_time_ms": 1250,
    "total_affected_batches": 45,
    "results": [
        {
            "source_batch_code": "RM-BATCH-001",
            "affected_products": [
                {
                    "batch_code": "BATCH-2024-001",
                    "product_code": "FG-WIDGET-001",
                    "quantity_affected": 950.0,
                    "manufacturing_date": "2024-01-15",
                    "trace_path": [
                        {
                            "work_order": "WO-2024-001",
                            "quantity_consumed": 50.0
                        }
                    ]
                }
            ]
        }
    ]
}
```

#### Backward Traceability Query
```
POST /api/traceability/backward
Content-Type: application/json

Request Body:
{
    "target_batch_codes": ["BATCH-2024-001"],
    "include_indirect": true,
    "max_levels": 5
}

Response:
{
    "query_id": "TQ-2024-002",
    "execution_time_ms": 890,
    "results": [
        {
            "target_batch_code": "BATCH-2024-001",
            "source_materials": [
                {
                    "batch_code": "RM-BATCH-001",
                    "material_code": "RM-COMPONENT-A",
                    "quantity_consumed": 50.0,
                    "supplier": "Supplier ABC",
                    "received_date": "2024-01-10"
                },
                {
                    "batch_code": "RM-BATCH-002",
                    "material_code": "RM-COMPONENT-B",
                    "quantity_consumed": 25.0,
                    "supplier": "Supplier XYZ",
                    "received_date": "2024-01-12"
                }
            ]
        }
    ]
}
```

#### Recall Impact Analysis
```
POST /api/traceability/recall-analysis
Content-Type: application/json

Request Body:
{
    "affected_batches": ["RM-BATCH-001"],
    "recall_type": "FORWARD",
    "severity": "HIGH",
    "analysis_date": "2024-01-20"
}

Response:
{
    "recall_id": "RC-2024-001",
    "analysis_summary": {
        "total_affected_batches": 45,
        "total_affected_quantity": 42500.0,
        "estimated_value": 850000.0,
        "customers_affected": 12,
        "locations_affected": 8
    },
    "affected_products": [
        {
            "product_code": "FG-WIDGET-001",
            "batches_affected": 15,
            "quantity_affected": 14250.0,
            "inventory_on_hand": 8500.0,
            "shipped_quantity": 5750.0
        }
    ],
    "recommended_actions": [
        "Quarantine all affected inventory",
        "Issue customer notifications",
        "Coordinate with quality assurance team"
    ]
}
```

## Performance Optimization Specifications

### Database Indexing Strategy

```sql
-- Primary indexes for core tables
CREATE INDEX idx_workorder_number ON work_orders(work_order_number);
CREATE INDEX idx_workorder_status ON work_orders(status);
CREATE INDEX idx_workorder_dates ON work_orders(start_date, completion_date);

-- Batch tracking indexes
CREATE INDEX idx_batch_code ON batches(batch_code);
CREATE INDEX idx_batch_lot ON batches(lot_number);
CREATE INDEX idx_batch_workorder ON batches(work_order_id);
CREATE INDEX idx_batch_product ON batches(product_id);
CREATE INDEX idx_batch_dates ON batches(manufacturing_date, expiration_date);

-- Inventory performance indexes
CREATE INDEX idx_inventory_batch ON inventory(batch_id);
CREATE INDEX idx_inventory_location ON inventory(location_id);
CREATE INDEX idx_inventory_composite ON inventory(batch_id, location_id);

-- Critical traceability indexes for <2s performance
CREATE INDEX idx_trace_parent ON traceability_links(parent_batch_id);
CREATE INDEX idx_trace_child ON traceability_links(child_batch_id);
CREATE INDEX idx_trace_workorder ON traceability_links(work_order_id);
CREATE INDEX idx_trace_forward ON traceability_links(parent_batch_id, child_batch_id);
CREATE INDEX idx_trace_backward ON traceability_links(child_batch_id, parent_batch_id);

-- Composite indexes for complex queries
CREATE INDEX idx_batch_product_date ON batches(product_id, manufacturing_date);
CREATE INDEX idx_inventory_product_location ON inventory(batch_id, location_id, quantity_on_hand);
```

### Query Optimization Patterns

```sql
-- Optimized forward traceability query
WITH RECURSIVE forward_trace AS (
    -- Base case: direct children of source batches
    SELECT 
        tl.parent_batch_id,
        tl.child_batch_id,
        tl.quantity_consumed,
        1 as level,
        ARRAY[tl.parent_batch_id] as path
    FROM traceability_links tl
    WHERE tl.parent_batch_id IN (SELECT id FROM batches WHERE batch_code = ANY($1))
    
    UNION ALL
    
    -- Recursive case: children of children
    SELECT 
        ft.parent_batch_id,
        tl.child_batch_id,
        tl.quantity_consumed,
        ft.level + 1,
        ft.path || tl.parent_batch_id
    FROM forward_trace ft
    JOIN traceability_links tl ON ft.child_batch_id = tl.parent_batch_id
    WHERE ft.level < 10 AND NOT (tl.parent_batch_id = ANY(ft.path))
)
SELECT 
    b_parent.batch_code as source_batch,
    b_child.batch_code as affected_batch,
    p.material_code as product_code,
    ft.quantity_consumed,
    b_child.manufacturing_date,
    ft.level
FROM forward_trace ft
JOIN batches b_parent ON ft.parent_batch_id = b_parent.id
JOIN batches b_child ON ft.child_batch_id = b_child.id
JOIN materials p ON b_child.product_id = p.id
ORDER BY ft.level, b_child.manufacturing_date;
```

### Caching Strategy

```python
# Redis caching configuration for high-performance queries
CACHE_CONFIG = {
    'traceability_queries': {
        'ttl': 3600,  # 1 hour cache for traceability results
        'key_pattern': 'trace:{query_type}:{hash}',
        'max_size': '100MB'
    },
    'batch_details': {
        'ttl': 1800,  # 30 minutes for batch information
        'key_pattern': 'batch:{batch_id}',
        'max_size': '50MB'
    },
    'inventory_summary': {
        'ttl': 300,   # 5 minutes for inventory data
        'key_pattern': 'inventory:{product_id}:{location_id}',
        'max_size': '25MB'
    }
}
```

This comprehensive API specification provides the foundation for implementing all required functionality while ensuring optimal performance for the critical recall query requirements.

