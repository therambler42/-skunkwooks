import os
import sys
import random
from datetime import datetime, date, timedelta

# Add the src directory to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from src.main import app
from src.models.database import db, Material, WorkOrder, Batch, Location, Inventory, TraceabilityLink

def create_sample_data():
    """Create comprehensive sample data for testing and demonstration"""
    
    with app.app_context():
        # Clear existing data
        db.drop_all()
        db.create_all()
        
        print("Creating sample materials...")
        
        # Create raw materials
        raw_materials = [
            Material(material_code='RM-STEEL-001', material_name='Steel Alloy Grade A', material_type='RAW_MATERIAL', unit_of_measure='KG', shelf_life_days=None),
            Material(material_code='RM-PLASTIC-001', material_name='High-Grade Plastic Resin', material_type='RAW_MATERIAL', unit_of_measure='KG', shelf_life_days=365),
            Material(material_code='RM-COMPONENT-001', material_name='Electronic Component A', material_type='RAW_MATERIAL', unit_of_measure='EA', shelf_life_days=730),
            Material(material_code='RM-COMPONENT-002', material_name='Electronic Component B', material_type='RAW_MATERIAL', unit_of_measure='EA', shelf_life_days=730),
            Material(material_code='RM-CHEMICAL-001', material_name='Industrial Chemical X', material_type='RAW_MATERIAL', unit_of_measure='L', shelf_life_days=180),
        ]
        
        # Create finished goods
        finished_goods = [
            Material(material_code='FG-WIDGET-001', material_name='Premium Widget Model A', material_type='FINISHED_GOOD', unit_of_measure='EA', shelf_life_days=365),
            Material(material_code='FG-GADGET-001', material_name='Advanced Gadget Pro', material_type='FINISHED_GOOD', unit_of_measure='EA', shelf_life_days=730),
            Material(material_code='FG-DEVICE-001', material_name='Smart Device Ultra', material_type='FINISHED_GOOD', unit_of_measure='EA', shelf_life_days=1095),
            Material(material_code='FG-ASSEMBLY-001', material_name='Complex Assembly Unit', material_type='FINISHED_GOOD', unit_of_measure='EA', shelf_life_days=545),
            Material(material_code='FG-MODULE-001', material_name='Precision Module System', material_type='FINISHED_GOOD', unit_of_measure='EA', shelf_life_days=365),
        ]
        
        all_materials = raw_materials + finished_goods
        db.session.add_all(all_materials)
        db.session.flush()
        
        print("Creating sample locations...")
        
        # Create locations
        locations = [
            Location(location_code='WH-MAIN', location_name='Main Warehouse', location_type='WAREHOUSE'),
            Location(location_code='WH-COLD', location_name='Cold Storage Warehouse', location_type='WAREHOUSE'),
            Location(location_code='PROD-LINE-1', location_name='Production Line 1', location_type='PRODUCTION'),
            Location(location_code='PROD-LINE-2', location_name='Production Line 2', location_type='PRODUCTION'),
            Location(location_code='QC-LAB', location_name='Quality Control Lab', location_type='QUARANTINE'),
        ]
        
        db.session.add_all(locations)
        db.session.flush()
        
        print("Creating sample work orders and batches...")
        
        # Create work orders and batches
        work_orders = []
        batches = []
        
        # Generate data for the past 6 months
        start_date = datetime.now() - timedelta(days=180)
        
        for i in range(100):  # Create 100 work orders
            wo_date = start_date + timedelta(days=random.randint(0, 180))
            completion_date = wo_date + timedelta(days=random.randint(1, 7))
            
            # Select random finished good
            product = random.choice(finished_goods)
            planned_qty = random.randint(50, 1000)
            actual_qty = planned_qty + random.randint(-50, 50)
            
            work_order = WorkOrder(
                work_order_number=f'WO-2024-{i+1:04d}',
                product_id=product.id,
                planned_quantity=planned_qty,
                actual_quantity=actual_qty,
                status='COMPLETED',
                start_date=wo_date,
                completion_date=completion_date,
                created_by=1,
                completed_by=1
            )
            
            work_orders.append(work_order)
            db.session.add(work_order)
            db.session.flush()
            
            # Create batch for this work order
            manufacturing_date = completion_date.date()
            expiration_date = None
            if product.shelf_life_days:
                expiration_date = manufacturing_date + timedelta(days=product.shelf_life_days)
            
            batch = Batch(
                batch_code=f'BATCH-{manufacturing_date.strftime("%Y%m%d")}-{i+1:04d}',
                lot_number=f'LOT-{work_order.id}-001',
                work_order_id=work_order.id,
                product_id=product.id,
                quantity=actual_qty,
                manufacturing_date=manufacturing_date,
                expiration_date=expiration_date,
                status='RELEASED',
                quality_status='PASSED'
            )
            
            batches.append(batch)
            db.session.add(batch)
            db.session.flush()
            
            # Create inventory for this batch
            location = random.choice(locations[:2])  # Use warehouse locations
            remaining_qty = actual_qty * random.uniform(0.3, 0.9)  # Some inventory consumed
            
            inventory = Inventory(
                batch_id=batch.id,
                location_id=location.id,
                quantity_on_hand=remaining_qty,
                quantity_allocated=remaining_qty * random.uniform(0, 0.2),
                quantity_available=remaining_qty * random.uniform(0.8, 1.0)
            )
            
            db.session.add(inventory)
        
        print("Creating raw material batches...")
        
        # Create raw material batches
        rm_batches = []
        for i in range(200):  # Create 200 raw material batches
            rm_date = start_date + timedelta(days=random.randint(0, 180))
            
            # Select random raw material
            material = random.choice(raw_materials)
            quantity = random.randint(100, 5000)
            
            rm_batch = Batch(
                batch_code=f'RM-{material.material_code.split("-")[1]}-{i+1:04d}',
                lot_number=f'RM-LOT-{i+1:04d}',
                work_order_id=None,  # Raw materials don't have work orders
                product_id=material.id,
                quantity=quantity,
                manufacturing_date=rm_date.date(),
                expiration_date=rm_date.date() + timedelta(days=material.shelf_life_days) if material.shelf_life_days else None,
                status='RELEASED',
                quality_status='PASSED'
            )
            
            rm_batches.append(rm_batch)
            db.session.add(rm_batch)
            db.session.flush()
            
            # Create inventory for raw material
            location = random.choice(locations[:2])
            remaining_qty = quantity * random.uniform(0.1, 0.8)
            
            inventory = Inventory(
                batch_id=rm_batch.id,
                location_id=location.id,
                quantity_on_hand=remaining_qty,
                quantity_allocated=0,
                quantity_available=remaining_qty
            )
            
            db.session.add(inventory)
        
        print("Creating traceability links...")
        
        # Create traceability links between raw materials and finished goods
        traceability_links = []
        
        for batch in batches:
            # Each finished good batch uses 2-4 raw material batches
            num_rm_batches = random.randint(2, 4)
            selected_rm_batches = random.sample(rm_batches, num_rm_batches)
            
            for rm_batch in selected_rm_batches:
                # Ensure we don't create links with incompatible materials
                if rm_batch.product.material_type == 'RAW_MATERIAL':
                    consumed_qty = random.uniform(10, 100)
                    
                    link = TraceabilityLink(
                        parent_batch_id=rm_batch.id,
                        child_batch_id=batch.id,
                        work_order_id=batch.work_order_id,
                        quantity_consumed=consumed_qty,
                        link_type='DIRECT'
                    )
                    
                    traceability_links.append(link)
                    db.session.add(link)
        
        # Create some multi-level traceability (intermediate products)
        print("Creating multi-level traceability...")
        
        # Create some intermediate batches that use finished goods as inputs
        for i in range(20):
            # Select a finished good as input
            input_batch = random.choice(batches)
            output_product = random.choice(finished_goods)
            
            # Create intermediate work order
            wo_date = input_batch.manufacturing_date + timedelta(days=random.randint(1, 30))
            
            intermediate_wo = WorkOrder(
                work_order_number=f'WO-INT-2024-{i+1:03d}',
                product_id=output_product.id,
                planned_quantity=random.randint(20, 200),
                actual_quantity=random.randint(15, 200),
                status='COMPLETED',
                start_date=wo_date,
                completion_date=wo_date + timedelta(days=random.randint(1, 3)),
                created_by=1,
                completed_by=1
            )
            
            db.session.add(intermediate_wo)
            db.session.flush()
            
            # Create intermediate batch
            intermediate_batch = Batch(
                batch_code=f'INT-BATCH-{wo_date.strftime("%Y%m%d")}-{i+1:03d}',
                lot_number=f'INT-LOT-{intermediate_wo.id}-001',
                work_order_id=intermediate_wo.id,
                product_id=output_product.id,
                quantity=intermediate_wo.actual_quantity,
                manufacturing_date=wo_date,
                expiration_date=wo_date + timedelta(days=output_product.shelf_life_days) if output_product.shelf_life_days else None,
                status='RELEASED',
                quality_status='PASSED'
            )
            
            db.session.add(intermediate_batch)
            db.session.flush()
            
            # Create traceability link
            link = TraceabilityLink(
                parent_batch_id=input_batch.id,
                child_batch_id=intermediate_batch.id,
                work_order_id=intermediate_wo.id,
                quantity_consumed=random.uniform(5, 50),
                link_type='DIRECT'
            )
            
            db.session.add(link)
            
            # Create inventory for intermediate batch
            location = random.choice(locations[:2])
            remaining_qty = intermediate_batch.quantity * random.uniform(0.5, 0.9)
            
            inventory = Inventory(
                batch_id=intermediate_batch.id,
                location_id=location.id,
                quantity_on_hand=remaining_qty,
                quantity_allocated=0,
                quantity_available=remaining_qty
            )
            
            db.session.add(inventory)
        
        print("Committing data to database...")
        db.session.commit()
        
        # Print summary
        print(f"\nSample data created successfully!")
        print(f"Materials: {len(all_materials)}")
        print(f"Locations: {len(locations)}")
        print(f"Work Orders: {len(work_orders) + 20}")  # +20 for intermediate work orders
        print(f"Batches: {len(batches) + len(rm_batches) + 20}")  # +20 for intermediate batches
        print(f"Traceability Links: {len(traceability_links) + 20}")  # +20 for intermediate links
        print(f"Inventory Records: {len(batches) + len(rm_batches) + 20}")
        
        # Print some sample batch codes for testing
        print(f"\nSample batch codes for testing:")
        print(f"Raw Material Batches: {[b.batch_code for b in rm_batches[:5]]}")
        print(f"Finished Good Batches: {[b.batch_code for b in batches[:5]]}")

if __name__ == '__main__':
    print("Creating sample data for Traceability API...")
    create_sample_data()
    print("Sample data creation completed!")

