from flask import Blueprint, request, jsonify, current_app
from src.models.database import db, Batch, TraceabilityLink, Material, WorkOrder, Inventory
from sqlalchemy import text, func
import json
import time
import hashlib

traceability_bp = Blueprint('traceability', __name__)

def get_cache_key(prefix, **kwargs):
    """Generate cache key from parameters"""
    key_parts = [prefix]
    for k, v in sorted(kwargs.items()):
        if v is not None:
            key_parts.append(f"{k}:{v}")
    key_string = ":".join(key_parts)
    # Hash long keys to avoid Redis key length limits
    if len(key_string) > 200:
        key_hash = hashlib.md5(key_string.encode()).hexdigest()
        return f"{prefix}:hash:{key_hash}"
    return key_string

def get_from_cache(key):
    """Get data from Redis cache"""
    redis_client = current_app.config.get('REDIS_CLIENT')
    if redis_client:
        try:
            cached_data = redis_client.get(key)
            if cached_data:
                return json.loads(cached_data)
        except Exception:
            pass
    return None

def set_cache(key, data, ttl=3600):
    """Set data in Redis cache with TTL"""
    redis_client = current_app.config.get('REDIS_CLIENT')
    if redis_client:
        try:
            redis_client.setex(key, ttl, json.dumps(data, default=str))
        except Exception:
            pass

@traceability_bp.route('/forward', methods=['POST'])
def forward_traceability():
    """Perform forward traceability query - find all products made from source materials"""
    start_time = time.time()
    
    try:
        data = request.get_json()
        
        if 'source_batch_codes' not in data:
            return jsonify({'error': 'Missing source_batch_codes'}), 400
        
        source_batch_codes = data['source_batch_codes']
        include_indirect = data.get('include_indirect', True)
        max_levels = data.get('max_levels', 10)
        
        # Generate cache key
        cache_key = get_cache_key(
            'forward_trace',
            batch_codes=','.join(sorted(source_batch_codes)),
            indirect=include_indirect,
            levels=max_levels
        )
        
        # Check cache first
        cached_result = get_from_cache(cache_key)
        if cached_result:
            cached_result['execution_time_ms'] = int((time.time() - start_time) * 1000)
            cached_result['from_cache'] = True
            return jsonify(cached_result), 200
        
        # Get source batch IDs
        source_batches = Batch.query.filter(Batch.batch_code.in_(source_batch_codes)).all()
        if not source_batches:
            return jsonify({'error': 'No source batches found'}), 404
        
        source_batch_ids = [b.id for b in source_batches]
        
        if include_indirect:
            # Use recursive CTE for multi-level traceability
            forward_trace_sql = text("""
                WITH RECURSIVE forward_trace AS (
                    -- Base case: direct children of source batches
                    SELECT 
                        tl.parent_batch_id,
                        tl.child_batch_id,
                        tl.quantity_consumed,
                        tl.work_order_id,
                        1 as level,
                        CAST(tl.parent_batch_id AS CHAR(1000)) as path
                    FROM traceability_links tl
                    WHERE tl.parent_batch_id IN :source_batch_ids
                    
                    UNION ALL
                    
                    -- Recursive case: children of children
                    SELECT 
                        ft.parent_batch_id,
                        tl.child_batch_id,
                        tl.quantity_consumed,
                        tl.work_order_id,
                        ft.level + 1,
                        CONCAT(ft.path, ',', tl.parent_batch_id)
                    FROM forward_trace ft
                    JOIN traceability_links tl ON ft.child_batch_id = tl.parent_batch_id
                    WHERE ft.level < :max_levels 
                    AND NOT FIND_IN_SET(tl.parent_batch_id, ft.path)
                )
                SELECT DISTINCT
                    b_source.batch_code as source_batch_code,
                    b_child.batch_code as affected_batch_code,
                    b_child.id as affected_batch_id,
                    m.material_code as product_code,
                    m.material_name as product_name,
                    b_child.quantity as batch_quantity,
                    ft.quantity_consumed,
                    b_child.manufacturing_date,
                    wo.work_order_number,
                    ft.level
                FROM forward_trace ft
                JOIN batches b_source ON ft.parent_batch_id = b_source.id
                JOIN batches b_child ON ft.child_batch_id = b_child.id
                JOIN materials m ON b_child.product_id = m.id
                LEFT JOIN work_orders wo ON ft.work_order_id = wo.id
                ORDER BY ft.level, b_child.manufacturing_date
            """)
            
            results = db.session.execute(forward_trace_sql, {
                'source_batch_ids': source_batch_ids,
                'max_levels': max_levels
            }).fetchall()
        else:
            # Direct children only
            direct_trace_sql = text("""
                SELECT DISTINCT
                    b_source.batch_code as source_batch_code,
                    b_child.batch_code as affected_batch_code,
                    b_child.id as affected_batch_id,
                    m.material_code as product_code,
                    m.material_name as product_name,
                    b_child.quantity as batch_quantity,
                    tl.quantity_consumed,
                    b_child.manufacturing_date,
                    wo.work_order_number,
                    1 as level
                FROM traceability_links tl
                JOIN batches b_source ON tl.parent_batch_id = b_source.id
                JOIN batches b_child ON tl.child_batch_id = b_child.id
                JOIN materials m ON b_child.product_id = m.id
                LEFT JOIN work_orders wo ON tl.work_order_id = wo.id
                WHERE tl.parent_batch_id IN :source_batch_ids
                ORDER BY b_child.manufacturing_date
            """)
            
            results = db.session.execute(direct_trace_sql, {
                'source_batch_ids': source_batch_ids
            }).fetchall()
        
        # Organize results by source batch
        trace_results = {}
        total_affected_batches = 0
        
        for row in results:
            source_code = row.source_batch_code
            if source_code not in trace_results:
                trace_results[source_code] = {
                    'source_batch_code': source_code,
                    'affected_products': []
                }
            
            trace_results[source_code]['affected_products'].append({
                'batch_code': row.affected_batch_code,
                'batch_id': row.affected_batch_id,
                'product_code': row.product_code,
                'product_name': row.product_name,
                'batch_quantity': float(row.batch_quantity),
                'quantity_affected': float(row.quantity_consumed),
                'manufacturing_date': row.manufacturing_date.isoformat() if row.manufacturing_date else None,
                'work_order_number': row.work_order_number,
                'trace_level': row.level
            })
            total_affected_batches += 1
        
        execution_time_ms = int((time.time() - start_time) * 1000)
        
        result = {
            'query_id': f"FT-{int(time.time())}",
            'execution_time_ms': execution_time_ms,
            'total_affected_batches': total_affected_batches,
            'results': list(trace_results.values()),
            'from_cache': False
        }
        
        # Cache the result
        set_cache(cache_key, result, ttl=3600)  # 1 hour
        
        return jsonify(result), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@traceability_bp.route('/backward', methods=['POST'])
def backward_traceability():
    """Perform backward traceability query - find all source materials used in target products"""
    start_time = time.time()
    
    try:
        data = request.get_json()
        
        if 'target_batch_codes' not in data:
            return jsonify({'error': 'Missing target_batch_codes'}), 400
        
        target_batch_codes = data['target_batch_codes']
        include_indirect = data.get('include_indirect', True)
        max_levels = data.get('max_levels', 10)
        
        # Generate cache key
        cache_key = get_cache_key(
            'backward_trace',
            batch_codes=','.join(sorted(target_batch_codes)),
            indirect=include_indirect,
            levels=max_levels
        )
        
        # Check cache first
        cached_result = get_from_cache(cache_key)
        if cached_result:
            cached_result['execution_time_ms'] = int((time.time() - start_time) * 1000)
            cached_result['from_cache'] = True
            return jsonify(cached_result), 200
        
        # Get target batch IDs
        target_batches = Batch.query.filter(Batch.batch_code.in_(target_batch_codes)).all()
        if not target_batches:
            return jsonify({'error': 'No target batches found'}), 404
        
        target_batch_ids = [b.id for b in target_batches]
        
        if include_indirect:
            # Use recursive CTE for multi-level backward traceability
            backward_trace_sql = text("""
                WITH RECURSIVE backward_trace AS (
                    -- Base case: direct parents of target batches
                    SELECT 
                        tl.child_batch_id,
                        tl.parent_batch_id,
                        tl.quantity_consumed,
                        tl.work_order_id,
                        1 as level,
                        CAST(tl.child_batch_id AS CHAR(1000)) as path
                    FROM traceability_links tl
                    WHERE tl.child_batch_id IN :target_batch_ids
                    
                    UNION ALL
                    
                    -- Recursive case: parents of parents
                    SELECT 
                        bt.child_batch_id,
                        tl.parent_batch_id,
                        tl.quantity_consumed,
                        tl.work_order_id,
                        bt.level + 1,
                        CONCAT(bt.path, ',', tl.child_batch_id)
                    FROM backward_trace bt
                    JOIN traceability_links tl ON bt.parent_batch_id = tl.child_batch_id
                    WHERE bt.level < :max_levels 
                    AND NOT FIND_IN_SET(tl.child_batch_id, bt.path)
                )
                SELECT DISTINCT
                    b_target.batch_code as target_batch_code,
                    b_source.batch_code as source_batch_code,
                    b_source.id as source_batch_id,
                    m.material_code as material_code,
                    m.material_name as material_name,
                    m.material_type,
                    bt.quantity_consumed,
                    b_source.manufacturing_date,
                    wo.work_order_number,
                    bt.level
                FROM backward_trace bt
                JOIN batches b_target ON bt.child_batch_id = b_target.id
                JOIN batches b_source ON bt.parent_batch_id = b_source.id
                JOIN materials m ON b_source.product_id = m.id
                LEFT JOIN work_orders wo ON bt.work_order_id = wo.id
                ORDER BY bt.level, b_source.manufacturing_date
            """)
            
            results = db.session.execute(backward_trace_sql, {
                'target_batch_ids': target_batch_ids,
                'max_levels': max_levels
            }).fetchall()
        else:
            # Direct parents only
            direct_trace_sql = text("""
                SELECT DISTINCT
                    b_target.batch_code as target_batch_code,
                    b_source.batch_code as source_batch_code,
                    b_source.id as source_batch_id,
                    m.material_code as material_code,
                    m.material_name as material_name,
                    m.material_type,
                    tl.quantity_consumed,
                    b_source.manufacturing_date,
                    wo.work_order_number,
                    1 as level
                FROM traceability_links tl
                JOIN batches b_target ON tl.child_batch_id = b_target.id
                JOIN batches b_source ON tl.parent_batch_id = b_source.id
                JOIN materials m ON b_source.product_id = m.id
                LEFT JOIN work_orders wo ON tl.work_order_id = wo.id
                WHERE tl.child_batch_id IN :target_batch_ids
                ORDER BY b_source.manufacturing_date
            """)
            
            results = db.session.execute(direct_trace_sql, {
                'target_batch_ids': target_batch_ids
            }).fetchall()
        
        # Organize results by target batch
        trace_results = {}
        
        for row in results:
            target_code = row.target_batch_code
            if target_code not in trace_results:
                trace_results[target_code] = {
                    'target_batch_code': target_code,
                    'source_materials': []
                }
            
            trace_results[target_code]['source_materials'].append({
                'batch_code': row.source_batch_code,
                'batch_id': row.source_batch_id,
                'material_code': row.material_code,
                'material_name': row.material_name,
                'material_type': row.material_type,
                'quantity_consumed': float(row.quantity_consumed),
                'manufacturing_date': row.manufacturing_date.isoformat() if row.manufacturing_date else None,
                'work_order_number': row.work_order_number,
                'trace_level': row.level
            })
        
        execution_time_ms = int((time.time() - start_time) * 1000)
        
        result = {
            'query_id': f"BT-{int(time.time())}",
            'execution_time_ms': execution_time_ms,
            'results': list(trace_results.values()),
            'from_cache': False
        }
        
        # Cache the result
        set_cache(cache_key, result, ttl=3600)  # 1 hour
        
        return jsonify(result), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@traceability_bp.route('/recall-analysis', methods=['POST'])
def recall_impact_analysis():
    """Perform comprehensive recall impact analysis"""
    start_time = time.time()
    
    try:
        data = request.get_json()
        
        if 'affected_batches' not in data:
            return jsonify({'error': 'Missing affected_batches'}), 400
        
        affected_batch_codes = data['affected_batches']
        recall_type = data.get('recall_type', 'FORWARD')  # FORWARD, BACKWARD, BOTH
        severity = data.get('severity', 'MEDIUM')
        
        # Get affected batch IDs
        affected_batches = Batch.query.filter(Batch.batch_code.in_(affected_batch_codes)).all()
        if not affected_batches:
            return jsonify({'error': 'No affected batches found'}), 404
        
        affected_batch_ids = [b.id for b in affected_batches]
        
        # Perform forward traceability to find all downstream products
        if recall_type in ['FORWARD', 'BOTH']:
            forward_sql = text("""
                WITH RECURSIVE forward_trace AS (
                    SELECT 
                        tl.parent_batch_id,
                        tl.child_batch_id,
                        tl.quantity_consumed,
                        1 as level
                    FROM traceability_links tl
                    WHERE tl.parent_batch_id IN :affected_batch_ids
                    
                    UNION ALL
                    
                    SELECT 
                        ft.parent_batch_id,
                        tl.child_batch_id,
                        tl.quantity_consumed,
                        ft.level + 1
                    FROM forward_trace ft
                    JOIN traceability_links tl ON ft.child_batch_id = tl.parent_batch_id
                    WHERE ft.level < 10
                )
                SELECT DISTINCT
                    b.id as batch_id,
                    b.batch_code,
                    b.quantity,
                    m.material_code as product_code,
                    m.material_name as product_name,
                    i.quantity_on_hand,
                    (b.quantity - COALESCE(i.quantity_on_hand, 0)) as shipped_quantity
                FROM forward_trace ft
                JOIN batches b ON ft.child_batch_id = b.id
                JOIN materials m ON b.product_id = m.id
                LEFT JOIN (
                    SELECT batch_id, SUM(quantity_on_hand) as quantity_on_hand
                    FROM inventory
                    GROUP BY batch_id
                ) i ON b.id = i.batch_id
            """)
            
            forward_results = db.session.execute(forward_sql, {
                'affected_batch_ids': affected_batch_ids
            }).fetchall()
        else:
            forward_results = []
        
        # Calculate impact summary
        total_affected_batches = len(affected_batches) + len(forward_results)
        total_affected_quantity = sum(b.quantity for b in affected_batches)
        total_inventory_on_hand = 0
        total_shipped_quantity = 0
        
        # Organize by product
        affected_products = {}
        
        # Add original affected batches
        for batch in affected_batches:
            product_code = batch.product.material_code
            if product_code not in affected_products:
                affected_products[product_code] = {
                    'product_code': product_code,
                    'product_name': batch.product.material_name,
                    'batches_affected': 0,
                    'quantity_affected': 0.0,
                    'inventory_on_hand': 0.0,
                    'shipped_quantity': 0.0
                }
            
            # Get inventory for this batch
            inventory_total = db.session.query(func.sum(db.session.query(Inventory.quantity_on_hand)))\
                .filter(Inventory.batch_id == batch.id).scalar() or 0
            
            affected_products[product_code]['batches_affected'] += 1
            affected_products[product_code]['quantity_affected'] += batch.quantity
            affected_products[product_code]['inventory_on_hand'] += float(inventory_total)
            affected_products[product_code]['shipped_quantity'] += batch.quantity - float(inventory_total)
        
        # Add forward trace results
        for row in forward_results:
            product_code = row.product_code
            if product_code not in affected_products:
                affected_products[product_code] = {
                    'product_code': product_code,
                    'product_name': row.product_name,
                    'batches_affected': 0,
                    'quantity_affected': 0.0,
                    'inventory_on_hand': 0.0,
                    'shipped_quantity': 0.0
                }
            
            affected_products[product_code]['batches_affected'] += 1
            affected_products[product_code]['quantity_affected'] += float(row.quantity)
            affected_products[product_code]['inventory_on_hand'] += float(row.quantity_on_hand or 0)
            affected_products[product_code]['shipped_quantity'] += float(row.shipped_quantity or 0)
            
            total_affected_quantity += float(row.quantity)
            total_inventory_on_hand += float(row.quantity_on_hand or 0)
            total_shipped_quantity += float(row.shipped_quantity or 0)
        
        # Generate recommended actions based on severity
        recommended_actions = []
        if severity == 'HIGH':
            recommended_actions = [
                "Immediately quarantine all affected inventory",
                "Issue urgent customer notifications",
                "Coordinate with regulatory authorities",
                "Initiate emergency response procedures",
                "Document all actions for regulatory compliance"
            ]
        elif severity == 'MEDIUM':
            recommended_actions = [
                "Quarantine all affected inventory",
                "Issue customer notifications",
                "Coordinate with quality assurance team",
                "Review and update quality procedures"
            ]
        else:
            recommended_actions = [
                "Review affected inventory",
                "Notify relevant stakeholders",
                "Investigate root cause"
            ]
        
        execution_time_ms = int((time.time() - start_time) * 1000)
        
        result = {
            'recall_id': f"RC-{int(time.time())}",
            'execution_time_ms': execution_time_ms,
            'analysis_summary': {
                'total_affected_batches': total_affected_batches,
                'total_affected_quantity': total_affected_quantity,
                'total_inventory_on_hand': total_inventory_on_hand,
                'total_shipped_quantity': total_shipped_quantity,
                'estimated_value': total_affected_quantity * 20.0,  # Simplified calculation
                'severity': severity
            },
            'affected_products': list(affected_products.values()),
            'recommended_actions': recommended_actions
        }
        
        return jsonify(result), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@traceability_bp.route('/batch-genealogy/<batch_code>', methods=['GET'])
def get_batch_genealogy(batch_code):
    """Get complete genealogy (parents and children) for a specific batch"""
    try:
        # Get the batch
        batch = Batch.query.filter_by(batch_code=batch_code).first()
        if not batch:
            return jsonify({'error': 'Batch not found'}), 404
        
        # Get parents (backward trace)
        parents_sql = text("""
            SELECT 
                b.batch_code,
                b.id,
                m.material_code,
                m.material_name,
                tl.quantity_consumed,
                wo.work_order_number
            FROM traceability_links tl
            JOIN batches b ON tl.parent_batch_id = b.id
            JOIN materials m ON b.product_id = m.id
            LEFT JOIN work_orders wo ON tl.work_order_id = wo.id
            WHERE tl.child_batch_id = :batch_id
        """)
        
        parents = db.session.execute(parents_sql, {'batch_id': batch.id}).fetchall()
        
        # Get children (forward trace)
        children_sql = text("""
            SELECT 
                b.batch_code,
                b.id,
                m.material_code,
                m.material_name,
                tl.quantity_consumed,
                wo.work_order_number
            FROM traceability_links tl
            JOIN batches b ON tl.child_batch_id = b.id
            JOIN materials m ON b.product_id = m.id
            LEFT JOIN work_orders wo ON tl.work_order_id = wo.id
            WHERE tl.parent_batch_id = :batch_id
        """)
        
        children = db.session.execute(children_sql, {'batch_id': batch.id}).fetchall()
        
        result = {
            'batch': {
                'batch_code': batch.batch_code,
                'product_code': batch.product.material_code,
                'product_name': batch.product.material_name,
                'quantity': batch.quantity,
                'manufacturing_date': batch.manufacturing_date.isoformat() if batch.manufacturing_date else None
            },
            'parents': [
                {
                    'batch_code': p.batch_code,
                    'material_code': p.material_code,
                    'material_name': p.material_name,
                    'quantity_consumed': float(p.quantity_consumed),
                    'work_order_number': p.work_order_number
                } for p in parents
            ],
            'children': [
                {
                    'batch_code': c.batch_code,
                    'material_code': c.material_code,
                    'material_name': c.material_name,
                    'quantity_consumed': float(c.quantity_consumed),
                    'work_order_number': c.work_order_number
                } for c in children
            ]
        }
        
        return jsonify(result), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

