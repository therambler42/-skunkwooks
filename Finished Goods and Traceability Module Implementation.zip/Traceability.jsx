import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Search, ArrowRight, ArrowLeft, AlertTriangle, Clock, Download } from 'lucide-react'
import axios from 'axios'

const Traceability = ({ apiBaseUrl }) => {
  const [activeTab, setActiveTab] = useState('forward')
  const [loading, setLoading] = useState(false)
  const [results, setResults] = useState(null)
  const [executionTime, setExecutionTime] = useState(null)
  
  // Forward traceability state
  const [forwardQuery, setForwardQuery] = useState({
    source_batch_codes: '',
    include_indirect: true,
    max_levels: 10
  })
  
  // Backward traceability state
  const [backwardQuery, setBackwardQuery] = useState({
    target_batch_codes: '',
    include_indirect: true,
    max_levels: 10
  })
  
  // Recall analysis state
  const [recallQuery, setRecallQuery] = useState({
    affected_batches: '',
    recall_type: 'FORWARD',
    severity: 'MEDIUM'
  })

  const performForwardTrace = async () => {
    try {
      setLoading(true)
      setResults(null)
      
      const batchCodes = forwardQuery.source_batch_codes
        .split(',')
        .map(code => code.trim())
        .filter(code => code.length > 0)
      
      if (batchCodes.length === 0) {
        alert('Please enter at least one source batch code')
        return
      }
      
      const response = await axios.post(`${apiBaseUrl}/traceability/forward`, {
        source_batch_codes: batchCodes,
        include_indirect: forwardQuery.include_indirect,
        max_levels: forwardQuery.max_levels
      })
      
      setResults(response.data)
      setExecutionTime(response.data.execution_time_ms)
      
    } catch (error) {
      console.error('Error performing forward trace:', error)
      alert('Error performing forward trace: ' + (error.response?.data?.error || error.message))
    } finally {
      setLoading(false)
    }
  }

  const performBackwardTrace = async () => {
    try {
      setLoading(true)
      setResults(null)
      
      const batchCodes = backwardQuery.target_batch_codes
        .split(',')
        .map(code => code.trim())
        .filter(code => code.length > 0)
      
      if (batchCodes.length === 0) {
        alert('Please enter at least one target batch code')
        return
      }
      
      const response = await axios.post(`${apiBaseUrl}/traceability/backward`, {
        target_batch_codes: batchCodes,
        include_indirect: backwardQuery.include_indirect,
        max_levels: backwardQuery.max_levels
      })
      
      setResults(response.data)
      setExecutionTime(response.data.execution_time_ms)
      
    } catch (error) {
      console.error('Error performing backward trace:', error)
      alert('Error performing backward trace: ' + (error.response?.data?.error || error.message))
    } finally {
      setLoading(false)
    }
  }

  const performRecallAnalysis = async () => {
    try {
      setLoading(true)
      setResults(null)
      
      const batchCodes = recallQuery.affected_batches
        .split(',')
        .map(code => code.trim())
        .filter(code => code.length > 0)
      
      if (batchCodes.length === 0) {
        alert('Please enter at least one affected batch code')
        return
      }
      
      const response = await axios.post(`${apiBaseUrl}/traceability/recall-analysis`, {
        affected_batches: batchCodes,
        recall_type: recallQuery.recall_type,
        severity: recallQuery.severity
      })
      
      setResults(response.data)
      setExecutionTime(response.data.execution_time_ms)
      
    } catch (error) {
      console.error('Error performing recall analysis:', error)
      alert('Error performing recall analysis: ' + (error.response?.data?.error || error.message))
    } finally {
      setLoading(false)
    }
  }

  const getSeverityBadgeColor = (severity) => {
    switch (severity) {
      case 'HIGH': return 'bg-red-100 text-red-800'
      case 'MEDIUM': return 'bg-yellow-100 text-yellow-800'
      case 'LOW': return 'bg-green-100 text-green-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const exportResults = () => {
    if (!results) return
    
    const dataStr = JSON.stringify(results, null, 2)
    const dataBlob = new Blob([dataStr], { type: 'application/json' })
    const url = URL.createObjectURL(dataBlob)
    const link = document.createElement('a')
    link.href = url
    link.download = `traceability_results_${Date.now()}.json`
    link.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Traceability & Recall</h1>
        {results && (
          <Button onClick={exportResults} variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export Results
          </Button>
        )}
      </div>

      {/* Performance Indicator */}
      {executionTime && (
        <Card className="border-green-200 bg-green-50">
          <CardContent className="pt-6">
            <div className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-green-600" />
              <span className="text-green-800 font-medium">
                Query executed in {executionTime}ms
                {executionTime < 2000 && (
                  <Badge className="ml-2 bg-green-100 text-green-800">
                    Performance Target Met (&lt;2s)
                  </Badge>
                )}
              </span>
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="forward" className="flex items-center space-x-2">
            <ArrowRight className="h-4 w-4" />
            <span>Forward Trace</span>
          </TabsTrigger>
          <TabsTrigger value="backward" className="flex items-center space-x-2">
            <ArrowLeft className="h-4 w-4" />
            <span>Backward Trace</span>
          </TabsTrigger>
          <TabsTrigger value="recall" className="flex items-center space-x-2">
            <AlertTriangle className="h-4 w-4" />
            <span>Recall Analysis</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="forward" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <ArrowRight className="h-5 w-5" />
                <span>Forward Traceability</span>
              </CardTitle>
              <p className="text-sm text-gray-600">
                Find all finished products that contain specific raw materials or components
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="source-batches">Source Batch Codes (comma-separated)</Label>
                <Textarea
                  id="source-batches"
                  placeholder="RM-BATCH-001, RM-BATCH-002"
                  value={forwardQuery.source_batch_codes}
                  onChange={(e) => setForwardQuery({...forwardQuery, source_batch_codes: e.target.value})}
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="include-indirect">Include Indirect Links</Label>
                  <Select 
                    value={forwardQuery.include_indirect.toString()} 
                    onValueChange={(value) => setForwardQuery({...forwardQuery, include_indirect: value === 'true'})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="true">Yes (Multi-level)</SelectItem>
                      <SelectItem value="false">No (Direct only)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="max-levels">Maximum Trace Levels</Label>
                  <Input
                    id="max-levels"
                    type="number"
                    min="1"
                    max="20"
                    value={forwardQuery.max_levels}
                    onChange={(e) => setForwardQuery({...forwardQuery, max_levels: parseInt(e.target.value)})}
                  />
                </div>
              </div>
              <Button onClick={performForwardTrace} disabled={loading} className="w-full">
                {loading ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Tracing...
                  </>
                ) : (
                  <>
                    <Search className="h-4 w-4 mr-2" />
                    Perform Forward Trace
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="backward" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <ArrowLeft className="h-5 w-5" />
                <span>Backward Traceability</span>
              </CardTitle>
              <p className="text-sm text-gray-600">
                Find all raw materials and components used to create specific finished products
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="target-batches">Target Batch Codes (comma-separated)</Label>
                <Textarea
                  id="target-batches"
                  placeholder="BATCH-2024-001, BATCH-2024-002"
                  value={backwardQuery.target_batch_codes}
                  onChange={(e) => setBackwardQuery({...backwardQuery, target_batch_codes: e.target.value})}
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="include-indirect-back">Include Indirect Links</Label>
                  <Select 
                    value={backwardQuery.include_indirect.toString()} 
                    onValueChange={(value) => setBackwardQuery({...backwardQuery, include_indirect: value === 'true'})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="true">Yes (Multi-level)</SelectItem>
                      <SelectItem value="false">No (Direct only)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="max-levels-back">Maximum Trace Levels</Label>
                  <Input
                    id="max-levels-back"
                    type="number"
                    min="1"
                    max="20"
                    value={backwardQuery.max_levels}
                    onChange={(e) => setBackwardQuery({...backwardQuery, max_levels: parseInt(e.target.value)})}
                  />
                </div>
              </div>
              <Button onClick={performBackwardTrace} disabled={loading} className="w-full">
                {loading ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Tracing...
                  </>
                ) : (
                  <>
                    <Search className="h-4 w-4 mr-2" />
                    Perform Backward Trace
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="recall" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <AlertTriangle className="h-5 w-5" />
                <span>Recall Impact Analysis</span>
              </CardTitle>
              <p className="text-sm text-gray-600">
                Analyze the complete impact of a potential recall scenario
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="affected-batches">Affected Batch Codes (comma-separated)</Label>
                <Textarea
                  id="affected-batches"
                  placeholder="RM-BATCH-001, BATCH-2024-001"
                  value={recallQuery.affected_batches}
                  onChange={(e) => setRecallQuery({...recallQuery, affected_batches: e.target.value})}
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="recall-type">Recall Type</Label>
                  <Select 
                    value={recallQuery.recall_type} 
                    onValueChange={(value) => setRecallQuery({...recallQuery, recall_type: value})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="FORWARD">Forward (Downstream)</SelectItem>
                      <SelectItem value="BACKWARD">Backward (Upstream)</SelectItem>
                      <SelectItem value="BOTH">Both Directions</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="severity">Severity Level</Label>
                  <Select 
                    value={recallQuery.severity} 
                    onValueChange={(value) => setRecallQuery({...recallQuery, severity: value})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="LOW">Low</SelectItem>
                      <SelectItem value="MEDIUM">Medium</SelectItem>
                      <SelectItem value="HIGH">High</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <Button onClick={performRecallAnalysis} disabled={loading} className="w-full">
                {loading ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Analyzing...
                  </>
                ) : (
                  <>
                    <AlertTriangle className="h-4 w-4 mr-2" />
                    Perform Recall Analysis
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Results Display */}
      {results && (
        <Card>
          <CardHeader>
            <CardTitle>Traceability Results</CardTitle>
            {results.from_cache && (
              <Badge className="w-fit bg-blue-100 text-blue-800">
                Cached Result
              </Badge>
            )}
          </CardHeader>
          <CardContent>
            {activeTab === 'forward' && results.results && (
              <div className="space-y-4">
                <div className="text-sm text-gray-600">
                  Found {results.total_affected_batches} affected batches
                </div>
                {results.results.map((sourceResult, index) => (
                  <div key={index} className="border rounded-lg p-4">
                    <h4 className="font-medium text-gray-900 mb-3">
                      Source: {sourceResult.source_batch_code}
                    </h4>
                    <div className="space-y-2">
                      {sourceResult.affected_products.map((product, pIndex) => (
                        <div key={pIndex} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                          <div>
                            <span className="font-medium">{product.batch_code}</span>
                            <span className="text-gray-600 ml-2">({product.product_code})</span>
                          </div>
                          <div className="text-sm text-gray-600">
                            Qty: {product.quantity_affected?.toLocaleString()}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'backward' && results.results && (
              <div className="space-y-4">
                {results.results.map((targetResult, index) => (
                  <div key={index} className="border rounded-lg p-4">
                    <h4 className="font-medium text-gray-900 mb-3">
                      Target: {targetResult.target_batch_code}
                    </h4>
                    <div className="space-y-2">
                      {targetResult.source_materials.map((material, mIndex) => (
                        <div key={mIndex} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                          <div>
                            <span className="font-medium">{material.batch_code}</span>
                            <span className="text-gray-600 ml-2">({material.material_code})</span>
                          </div>
                          <div className="text-sm text-gray-600">
                            Consumed: {material.quantity_consumed?.toLocaleString()}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'recall' && results.analysis_summary && (
              <div className="space-y-6">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <div className="text-2xl font-bold text-gray-900">
                      {results.analysis_summary.total_affected_batches}
                    </div>
                    <div className="text-sm text-gray-600">Affected Batches</div>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <div className="text-2xl font-bold text-gray-900">
                      {Math.round(results.analysis_summary.total_affected_quantity).toLocaleString()}
                    </div>
                    <div className="text-sm text-gray-600">Total Quantity</div>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <div className="text-2xl font-bold text-gray-900">
                      {Math.round(results.analysis_summary.total_inventory_on_hand).toLocaleString()}
                    </div>
                    <div className="text-sm text-gray-600">On Hand</div>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <div className="text-2xl font-bold text-gray-900">
                      ${Math.round(results.analysis_summary.estimated_value).toLocaleString()}
                    </div>
                    <div className="text-sm text-gray-600">Est. Value</div>
                  </div>
                </div>

                {results.affected_products && (
                  <div>
                    <h4 className="font-medium text-gray-900 mb-3">Affected Products</h4>
                    <div className="space-y-2">
                      {results.affected_products.map((product, index) => (
                        <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                          <div>
                            <span className="font-medium">{product.product_code}</span>
                            <span className="text-gray-600 ml-2">({product.batches_affected} batches)</span>
                          </div>
                          <div className="text-right text-sm">
                            <div>Affected: {Math.round(product.quantity_affected).toLocaleString()}</div>
                            <div className="text-gray-600">On Hand: {Math.round(product.inventory_on_hand).toLocaleString()}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {results.recommended_actions && (
                  <div>
                    <h4 className="font-medium text-gray-900 mb-3">Recommended Actions</h4>
                    <div className="space-y-2">
                      {results.recommended_actions.map((action, index) => (
                        <div key={index} className="flex items-center p-2 bg-yellow-50 border border-yellow-200 rounded">
                          <AlertTriangle className="h-4 w-4 text-yellow-600 mr-2 flex-shrink-0" />
                          <span className="text-yellow-800">{action}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}

export default Traceability

