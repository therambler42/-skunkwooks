from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class Material(db.Model):
    __tablename__ = 'materials'
    
    id = db.Column(db.Integer, primary_key=True)
    material_code = db.Column(db.String(50), unique=True, nullable=False, index=True)
    material_name = db.Column(db.String(200), nullable=False)
    material_type = db.Column(db.String(20), nullable=False)  # RAW_MATERIAL, FINISHED_GOOD, INTERMEDIATE
    unit_of_measure = db.Column(db.String(10), nullable=False)
    shelf_life_days = db.Column(db.Integer)
    requires_lot_tracking = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    work_orders = db.relationship('WorkOrder', backref='product', lazy=True)
    batches = db.relationship('Batch', backref='product', lazy=True)

class WorkOrder(db.Model):
    __tablename__ = 'work_orders'
    
    id = db.Column(db.Integer, primary_key=True)
    work_order_number = db.Column(db.String(50), unique=True, nullable=False, index=True)
    product_id = db.Column(db.Integer, db.ForeignKey('materials.id'), nullable=False)
    planned_quantity = db.Column(db.Float, nullable=False)
    actual_quantity = db.Column(db.Float)
    status = db.Column(db.String(20), nullable=False, default='CREATED', index=True)  # CREATED, IN_PROGRESS, COMPLETED, CANCELLED
    start_date = db.Column(db.DateTime)
    completion_date = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = db.Column(db.Integer)  # User ID
    completed_by = db.Column(db.Integer)  # User ID
    
    # Relationships
    batches = db.relationship('Batch', backref='work_order', lazy=True)
    traceability_links = db.relationship('TraceabilityLink', backref='work_order', lazy=True)

class Batch(db.Model):
    __tablename__ = 'batches'
    
    id = db.Column(db.Integer, primary_key=True)
    batch_code = db.Column(db.String(50), unique=True, nullable=False, index=True)
    lot_number = db.Column(db.String(50), nullable=False, index=True)
    work_order_id = db.Column(db.Integer, db.ForeignKey('work_orders.id'), nullable=True, index=True)
    product_id = db.Column(db.Integer, db.ForeignKey('materials.id'), nullable=False, index=True)
    quantity = db.Column(db.Float, nullable=False)
    manufacturing_date = db.Column(db.Date, nullable=False, index=True)
    expiration_date = db.Column(db.Date, index=True)
    status = db.Column(db.String(20), nullable=False, default='ACTIVE')  # ACTIVE, QUARANTINE, RELEASED, RECALLED
    quality_status = db.Column(db.String(20), nullable=False, default='PENDING')  # PENDING, PASSED, FAILED
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    inventory_records = db.relationship('Inventory', backref='batch', lazy=True)
    parent_links = db.relationship('TraceabilityLink', foreign_keys='TraceabilityLink.child_batch_id', backref='child_batch', lazy=True)
    child_links = db.relationship('TraceabilityLink', foreign_keys='TraceabilityLink.parent_batch_id', backref='parent_batch', lazy=True)

class Location(db.Model):
    __tablename__ = 'locations'
    
    id = db.Column(db.Integer, primary_key=True)
    location_code = db.Column(db.String(20), unique=True, nullable=False)
    location_name = db.Column(db.String(100), nullable=False)
    location_type = db.Column(db.String(20), nullable=False)  # WAREHOUSE, PRODUCTION, QUARANTINE
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    inventory_records = db.relationship('Inventory', backref='location', lazy=True)

class Inventory(db.Model):
    __tablename__ = 'inventory'
    
    id = db.Column(db.Integer, primary_key=True)
    batch_id = db.Column(db.Integer, db.ForeignKey('batches.id'), nullable=False, index=True)
    location_id = db.Column(db.Integer, db.ForeignKey('locations.id'), nullable=False, index=True)
    quantity_on_hand = db.Column(db.Float, nullable=False, default=0.0)
    quantity_allocated = db.Column(db.Float, nullable=False, default=0.0)
    quantity_available = db.Column(db.Float, nullable=False, default=0.0)
    last_transaction_date = db.Column(db.DateTime, default=datetime.utcnow)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Composite index for performance
    __table_args__ = (
        db.Index('idx_inventory_batch_location', 'batch_id', 'location_id'),
    )

class TraceabilityLink(db.Model):
    __tablename__ = 'traceability_links'
    
    id = db.Column(db.Integer, primary_key=True)
    parent_batch_id = db.Column(db.Integer, db.ForeignKey('batches.id'), nullable=False, index=True)
    child_batch_id = db.Column(db.Integer, db.ForeignKey('batches.id'), nullable=False, index=True)
    work_order_id = db.Column(db.Integer, db.ForeignKey('work_orders.id'), nullable=False, index=True)
    quantity_consumed = db.Column(db.Float, nullable=False)
    link_type = db.Column(db.String(20), nullable=False, default='DIRECT')  # DIRECT, REWORK, BLEND
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Performance indexes for traceability queries
    __table_args__ = (
        db.Index('idx_trace_forward', 'parent_batch_id', 'child_batch_id'),
        db.Index('idx_trace_backward', 'child_batch_id', 'parent_batch_id'),
        db.Index('idx_trace_workorder', 'work_order_id'),
    )

