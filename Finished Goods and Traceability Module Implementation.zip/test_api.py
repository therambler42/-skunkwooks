import unittest
import json
from datetime import datetime, date
from src.main import app
from src.models.database import db, Material, WorkOrder, Batch, Location, Inventory, TraceabilityLink

class TestWorkOrderAPI(unittest.TestCase):
    def setUp(self):
        """Set up test client and database"""
        app.config['TESTING'] = True
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        self.client = app.test_client()
        
        with app.app_context():
            db.create_all()
            self.create_test_data()
    
    def tearDown(self):
        """Clean up after tests"""
        with app.app_context():
            db.session.remove()
            db.drop_all()
    
    def create_test_data(self):
        """Create test data for testing"""
        # Create test material
        material = Material(
            material_code='TEST-WIDGET-001',
            material_name='Test Widget',
            material_type='FINISHED_GOOD',
            unit_of_measure='EA',
            shelf_life_days=180
        )
        db.session.add(material)
        
        # Create test location
        location = Location(
            location_code='TEST-WH-001',
            location_name='Test Warehouse',
            location_type='WAREHOUSE'
        )
        db.session.add(location)
        
        db.session.commit()
        
        self.test_material_id = material.id
        self.test_location_id = location.id
    
    def test_create_work_order(self):
        """Test creating a new work order"""
        data = {
            'work_order_number': 'TEST-WO-001',
            'product_id': self.test_material_id,
            'planned_quantity': 1000.0,
            'start_date': '2024-01-15T08:00:00Z'
        }
        
        response = self.client.post('/api/workorders/', 
                                  data=json.dumps(data),
                                  content_type='application/json')
        
        self.assertEqual(response.status_code, 201)
        result = json.loads(response.data)
        self.assertEqual(result['work_order_number'], 'TEST-WO-001')
        self.assertEqual(result['status'], 'CREATED')
    
    def test_create_duplicate_work_order(self):
        """Test creating a work order with duplicate number"""
        data = {
            'work_order_number': 'TEST-WO-001',
            'product_id': self.test_material_id,
            'planned_quantity': 1000.0
        }
        
        # Create first work order
        self.client.post('/api/workorders/', 
                        data=json.dumps(data),
                        content_type='application/json')
        
        # Try to create duplicate
        response = self.client.post('/api/workorders/', 
                                  data=json.dumps(data),
                                  content_type='application/json')
        
        self.assertEqual(response.status_code, 400)
        result = json.loads(response.data)
        self.assertIn('already exists', result['error'])
    
    def test_complete_work_order(self):
        """Test completing a work order"""
        # First create a work order
        create_data = {
            'work_order_number': 'TEST-WO-002',
            'product_id': self.test_material_id,
            'planned_quantity': 1000.0
        }
        
        create_response = self.client.post('/api/workorders/', 
                                         data=json.dumps(create_data),
                                         content_type='application/json')
        work_order = json.loads(create_response.data)
        
        # Complete the work order
        complete_data = {
            'actual_quantity': 950.0,
            'completion_date': '2024-01-15T16:00:00Z'
        }
        
        response = self.client.post(f'/api/workorders/{work_order["id"]}/complete',
                                  data=json.dumps(complete_data),
                                  content_type='application/json')
        
        self.assertEqual(response.status_code, 200)
        result = json.loads(response.data)
        self.assertEqual(result['work_order']['status'], 'COMPLETED')
        self.assertEqual(result['work_order']['actual_quantity'], 950.0)
        self.assertIn('batch', result)
        self.assertIn('inventory', result)
    
    def test_get_work_order(self):
        """Test retrieving work order details"""
        # Create a work order
        create_data = {
            'work_order_number': 'TEST-WO-003',
            'product_id': self.test_material_id,
            'planned_quantity': 1000.0
        }
        
        create_response = self.client.post('/api/workorders/', 
                                         data=json.dumps(create_data),
                                         content_type='application/json')
        work_order = json.loads(create_response.data)
        
        # Get work order details
        response = self.client.get(f'/api/workorders/{work_order["id"]}')
        
        self.assertEqual(response.status_code, 200)
        result = json.loads(response.data)
        self.assertEqual(result['work_order_number'], 'TEST-WO-003')
        self.assertIn('product', result)
    
    def test_list_work_orders(self):
        """Test listing work orders with filters"""
        # Create multiple work orders
        for i in range(3):
            data = {
                'work_order_number': f'TEST-WO-LIST-{i+1}',
                'product_id': self.test_material_id,
                'planned_quantity': 1000.0 + i * 100
            }
            self.client.post('/api/workorders/', 
                           data=json.dumps(data),
                           content_type='application/json')
        
        # List all work orders
        response = self.client.get('/api/workorders/')
        
        self.assertEqual(response.status_code, 200)
        result = json.loads(response.data)
        self.assertIn('work_orders', result)
        self.assertGreaterEqual(len(result['work_orders']), 3)
        
        # Test filtering by status
        response = self.client.get('/api/workorders/?status=CREATED')
        self.assertEqual(response.status_code, 200)
        result = json.loads(response.data)
        for wo in result['work_orders']:
            self.assertEqual(wo['status'], 'CREATED')

class TestInventoryAPI(unittest.TestCase):
    def setUp(self):
        """Set up test client and database"""
        app.config['TESTING'] = True
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        self.client = app.test_client()
        
        with app.app_context():
            db.create_all()
            self.create_test_data()
    
    def tearDown(self):
        """Clean up after tests"""
        with app.app_context():
            db.session.remove()
            db.drop_all()
    
    def create_test_data(self):
        """Create test data for testing"""
        # Create test material
        material = Material(
            material_code='TEST-WIDGET-001',
            material_name='Test Widget',
            material_type='FINISHED_GOOD',
            unit_of_measure='EA',
            shelf_life_days=180
        )
        db.session.add(material)
        
        # Create test location
        location = Location(
            location_code='TEST-WH-001',
            location_name='Test Warehouse',
            location_type='WAREHOUSE'
        )
        db.session.add(location)
        
        # Create test work order
        work_order = WorkOrder(
            work_order_number='TEST-WO-001',
            product_id=1,  # Will be set after material is created
            planned_quantity=1000.0,
            status='COMPLETED'
        )
        db.session.add(work_order)
        
        db.session.flush()  # Get IDs
        
        work_order.product_id = material.id
        
        # Create test batch
        batch = Batch(
            batch_code='TEST-BATCH-001',
            lot_number='TEST-LOT-001',
            work_order_id=work_order.id,
            product_id=material.id,
            quantity=1000.0,
            manufacturing_date=date.today(),
            status='RELEASED'
        )
        db.session.add(batch)
        
        db.session.flush()
        
        # Create test inventory
        inventory = Inventory(
            batch_id=batch.id,
            location_id=location.id,
            quantity_on_hand=1000.0,
            quantity_allocated=0.0,
            quantity_available=1000.0
        )
        db.session.add(inventory)
        
        db.session.commit()
        
        self.test_material_id = material.id
        self.test_location_id = location.id
        self.test_batch_id = batch.id
    
    def test_get_inventory_summary(self):
        """Test getting inventory summary"""
        response = self.client.get('/api/inventory/summary')
        
        self.assertEqual(response.status_code, 200)
        result = json.loads(response.data)
        self.assertIn('summary', result)
        self.assertIn('batches', result)
        self.assertGreater(len(result['batches']), 0)
    
    def test_get_batch_details(self):
        """Test getting batch details"""
        response = self.client.get(f'/api/inventory/batches/{self.test_batch_id}')
        
        self.assertEqual(response.status_code, 200)
        result = json.loads(response.data)
        self.assertEqual(result['batch_code'], 'TEST-BATCH-001')
        self.assertIn('product', result)
        self.assertIn('inventory_locations', result)
    
    def test_create_inventory_transaction(self):
        """Test creating inventory transactions"""
        # Test receipt transaction
        receipt_data = {
            'batch_id': self.test_batch_id,
            'location_id': self.test_location_id,
            'transaction_type': 'RECEIPT',
            'quantity': 100.0
        }
        
        response = self.client.post('/api/inventory/transactions',
                                  data=json.dumps(receipt_data),
                                  content_type='application/json')
        
        self.assertEqual(response.status_code, 200)
        result = json.loads(response.data)
        self.assertEqual(result['transaction_type'], 'RECEIPT')
        self.assertEqual(result['quantity_on_hand'], 1100.0)  # 1000 + 100
        
        # Test shipment transaction
        shipment_data = {
            'batch_id': self.test_batch_id,
            'location_id': self.test_location_id,
            'transaction_type': 'SHIPMENT',
            'quantity': 50.0
        }
        
        response = self.client.post('/api/inventory/transactions',
                                  data=json.dumps(shipment_data),
                                  content_type='application/json')
        
        self.assertEqual(response.status_code, 200)
        result = json.loads(response.data)
        self.assertEqual(result['transaction_type'], 'SHIPMENT')
        self.assertEqual(result['quantity_on_hand'], 1050.0)  # 1100 - 50

class TestTraceabilityAPI(unittest.TestCase):
    def setUp(self):
        """Set up test client and database"""
        app.config['TESTING'] = True
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        self.client = app.test_client()
        
        with app.app_context():
            db.create_all()
            self.create_test_data()
    
    def tearDown(self):
        """Clean up after tests"""
        with app.app_context():
            db.session.remove()
            db.drop_all()
    
    def create_test_data(self):
        """Create test data for traceability testing"""
        # Create materials
        raw_material = Material(
            material_code='RM-001',
            material_name='Raw Material A',
            material_type='RAW_MATERIAL',
            unit_of_measure='KG'
        )
        
        finished_good = Material(
            material_code='FG-001',
            material_name='Finished Good A',
            material_type='FINISHED_GOOD',
            unit_of_measure='EA'
        )
        
        db.session.add_all([raw_material, finished_good])
        db.session.flush()
        
        # Create work orders
        wo1 = WorkOrder(
            work_order_number='WO-001',
            product_id=finished_good.id,
            planned_quantity=100.0,
            status='COMPLETED'
        )
        db.session.add(wo1)
        db.session.flush()
        
        # Create batches
        rm_batch = Batch(
            batch_code='RM-BATCH-001',
            lot_number='RM-LOT-001',
            work_order_id=wo1.id,
            product_id=raw_material.id,
            quantity=50.0,
            manufacturing_date=date.today()
        )
        
        fg_batch = Batch(
            batch_code='FG-BATCH-001',
            lot_number='FG-LOT-001',
            work_order_id=wo1.id,
            product_id=finished_good.id,
            quantity=100.0,
            manufacturing_date=date.today()
        )
        
        db.session.add_all([rm_batch, fg_batch])
        db.session.flush()
        
        # Create traceability link
        trace_link = TraceabilityLink(
            parent_batch_id=rm_batch.id,
            child_batch_id=fg_batch.id,
            work_order_id=wo1.id,
            quantity_consumed=50.0
        )
        db.session.add(trace_link)
        
        db.session.commit()
        
        self.rm_batch_code = rm_batch.batch_code
        self.fg_batch_code = fg_batch.batch_code
    
    def test_forward_traceability(self):
        """Test forward traceability query"""
        data = {
            'source_batch_codes': [self.rm_batch_code],
            'include_indirect': True,
            'max_levels': 5
        }
        
        response = self.client.post('/api/traceability/forward',
                                  data=json.dumps(data),
                                  content_type='application/json')
        
        self.assertEqual(response.status_code, 200)
        result = json.loads(response.data)
        self.assertIn('results', result)
        self.assertIn('execution_time_ms', result)
        self.assertGreater(result['total_affected_batches'], 0)
    
    def test_backward_traceability(self):
        """Test backward traceability query"""
        data = {
            'target_batch_codes': [self.fg_batch_code],
            'include_indirect': True,
            'max_levels': 5
        }
        
        response = self.client.post('/api/traceability/backward',
                                  data=json.dumps(data),
                                  content_type='application/json')
        
        self.assertEqual(response.status_code, 200)
        result = json.loads(response.data)
        self.assertIn('results', result)
        self.assertIn('execution_time_ms', result)
    
    def test_recall_analysis(self):
        """Test recall impact analysis"""
        data = {
            'affected_batches': [self.rm_batch_code],
            'recall_type': 'FORWARD',
            'severity': 'HIGH'
        }
        
        response = self.client.post('/api/traceability/recall-analysis',
                                  data=json.dumps(data),
                                  content_type='application/json')
        
        self.assertEqual(response.status_code, 200)
        result = json.loads(response.data)
        self.assertIn('analysis_summary', result)
        self.assertIn('affected_products', result)
        self.assertIn('recommended_actions', result)
    
    def test_batch_genealogy(self):
        """Test batch genealogy query"""
        response = self.client.get(f'/api/traceability/batch-genealogy/{self.fg_batch_code}')
        
        self.assertEqual(response.status_code, 200)
        result = json.loads(response.data)
        self.assertIn('batch', result)
        self.assertIn('parents', result)
        self.assertIn('children', result)

if __name__ == '__main__':
    unittest.main()

