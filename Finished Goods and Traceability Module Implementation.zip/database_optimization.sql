-- Performance optimization SQL scripts for the traceability database

-- Create additional indexes for optimal query performance
CREATE INDEX IF NOT EXISTS idx_batches_manufacturing_date ON batches(manufacturing_date);
CREATE INDEX IF NOT EXISTS idx_batches_expiration_date ON batches(expiration_date);
CREATE INDEX IF NOT EXISTS idx_batches_status ON batches(status);
CREATE INDEX IF NOT EXISTS idx_batches_quality_status ON batches(quality_status);

-- Composite indexes for common query patterns
CREATE INDEX IF NOT EXISTS idx_batches_product_date ON batches(product_id, manufacturing_date);
CREATE INDEX IF NOT EXISTS idx_batches_status_date ON batches(status, manufacturing_date);

-- Inventory optimization indexes
CREATE INDEX IF NOT EXISTS idx_inventory_quantity_on_hand ON inventory(quantity_on_hand);
CREATE INDEX IF NOT EXISTS idx_inventory_last_transaction ON inventory(last_transaction_date);

-- Work order optimization indexes
CREATE INDEX IF NOT EXISTS idx_workorders_completion_date ON work_orders(completion_date);
CREATE INDEX IF NOT EXISTS idx_workorders_product_status ON work_orders(product_id, status);

-- Traceability performance indexes (critical for <2s requirement)
CREATE INDEX IF NOT EXISTS idx_trace_parent_workorder ON traceability_links(parent_batch_id, work_order_id);
CREATE INDEX IF NOT EXISTS idx_trace_child_workorder ON traceability_links(child_batch_id, work_order_id);
CREATE INDEX IF NOT EXISTS idx_trace_quantity ON traceability_links(quantity_consumed);

-- Covering indexes for common traceability queries
CREATE INDEX IF NOT EXISTS idx_trace_forward_covering ON traceability_links(parent_batch_id, child_batch_id, quantity_consumed, work_order_id);
CREATE INDEX IF NOT EXISTS idx_trace_backward_covering ON traceability_links(child_batch_id, parent_batch_id, quantity_consumed, work_order_id);

-- Materialized view for frequently accessed batch information
CREATE VIEW IF NOT EXISTS batch_summary AS
SELECT 
    b.id,
    b.batch_code,
    b.lot_number,
    b.quantity,
    b.manufacturing_date,
    b.expiration_date,
    b.status,
    b.quality_status,
    m.material_code,
    m.material_name,
    m.material_type,
    wo.work_order_number,
    COALESCE(inv.total_on_hand, 0) as total_inventory,
    COALESCE(inv.total_available, 0) as total_available
FROM batches b
JOIN materials m ON b.product_id = m.id
LEFT JOIN work_orders wo ON b.work_order_id = wo.id
LEFT JOIN (
    SELECT 
        batch_id,
        SUM(quantity_on_hand) as total_on_hand,
        SUM(quantity_available) as total_available
    FROM inventory
    GROUP BY batch_id
) inv ON b.id = inv.batch_id;

-- View for traceability performance monitoring
CREATE VIEW IF NOT EXISTS traceability_stats AS
SELECT 
    'forward_links' as metric,
    COUNT(*) as count,
    AVG(quantity_consumed) as avg_quantity
FROM traceability_links
UNION ALL
SELECT 
    'unique_parent_batches' as metric,
    COUNT(DISTINCT parent_batch_id) as count,
    NULL as avg_quantity
FROM traceability_links
UNION ALL
SELECT 
    'unique_child_batches' as metric,
    COUNT(DISTINCT child_batch_id) as count,
    NULL as avg_quantity
FROM traceability_links;

-- Analyze tables for query optimization
ANALYZE batches;
ANALYZE traceability_links;
ANALYZE inventory;
ANALYZE work_orders;
ANALYZE materials;

