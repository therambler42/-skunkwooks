from flask import Blueprint, request, jsonify, current_app
from src.models.database import db, WorkOrder, Batch, Inventory, Location, Material, TraceabilityLink
from datetime import datetime, date
import uuid

workorders_bp = Blueprint('workorders', __name__)

@workorders_bp.route('/', methods=['POST'])
def create_work_order():
    """Create a new work order"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['work_order_number', 'product_id', 'planned_quantity']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Check if work order number already exists
        existing_wo = WorkOrder.query.filter_by(work_order_number=data['work_order_number']).first()
        if existing_wo:
            return jsonify({'error': 'Work order number already exists'}), 400
        
        # Validate product exists
        product = Material.query.get(data['product_id'])
        if not product:
            return jsonify({'error': 'Product not found'}), 404
        
        # Create work order
        work_order = WorkOrder(
            work_order_number=data['work_order_number'],
            product_id=data['product_id'],
            planned_quantity=data['planned_quantity'],
            start_date=datetime.fromisoformat(data['start_date'].replace('Z', '+00:00')) if 'start_date' in data else None,
            created_by=data.get('created_by', 1)  # Default user ID
        )
        
        db.session.add(work_order)
        db.session.commit()
        
        return jsonify({
            'id': work_order.id,
            'work_order_number': work_order.work_order_number,
            'product_id': work_order.product_id,
            'planned_quantity': work_order.planned_quantity,
            'actual_quantity': work_order.actual_quantity,
            'status': work_order.status,
            'start_date': work_order.start_date.isoformat() if work_order.start_date else None,
            'completion_date': work_order.completion_date.isoformat() if work_order.completion_date else None,
            'created_at': work_order.created_at.isoformat(),
            'updated_at': work_order.updated_at.isoformat()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@workorders_bp.route('/<int:work_order_id>/complete', methods=['POST'])
def complete_work_order(work_order_id):
    """Complete a work order and post finished goods to inventory"""
    try:
        data = request.get_json()
        
        # Get work order
        work_order = WorkOrder.query.get(work_order_id)
        if not work_order:
            return jsonify({'error': 'Work order not found'}), 404
        
        if work_order.status == 'COMPLETED':
            return jsonify({'error': 'Work order already completed'}), 400
        
        # Validate required fields
        if 'actual_quantity' not in data:
            return jsonify({'error': 'Missing actual_quantity'}), 400
        
        # Generate unique batch code and lot number
        batch_code = f"BATCH-{datetime.now().strftime('%Y%m%d')}-{str(uuid.uuid4())[:8].upper()}"
        lot_number = f"LOT-{work_order.id}-{str(uuid.uuid4())[:6].upper()}"
        
        # Get default warehouse location
        warehouse = Location.query.filter_by(location_type='WAREHOUSE').first()
        if not warehouse:
            # Create default warehouse if it doesn't exist
            warehouse = Location(
                location_code='WH-001',
                location_name='Main Warehouse',
                location_type='WAREHOUSE'
            )
            db.session.add(warehouse)
            db.session.flush()
        
        # Calculate expiration date based on product shelf life
        manufacturing_date = date.today()
        expiration_date = None
        if work_order.product.shelf_life_days:
            from datetime import timedelta
            expiration_date = manufacturing_date + timedelta(days=work_order.product.shelf_life_days)
        
        # Create batch record
        batch = Batch(
            batch_code=batch_code,
            lot_number=lot_number,
            work_order_id=work_order.id,
            product_id=work_order.product_id,
            quantity=data['actual_quantity'],
            manufacturing_date=manufacturing_date,
            expiration_date=expiration_date,
            status='RELEASED',
            quality_status='PASSED'
        )
        db.session.add(batch)
        db.session.flush()
        
        # Create inventory record
        inventory = Inventory(
            batch_id=batch.id,
            location_id=warehouse.id,
            quantity_on_hand=data['actual_quantity'],
            quantity_allocated=0.0,
            quantity_available=data['actual_quantity']
        )
        db.session.add(inventory)
        
        # Update work order
        work_order.actual_quantity = data['actual_quantity']
        work_order.status = 'COMPLETED'
        work_order.completion_date = datetime.fromisoformat(data['completion_date'].replace('Z', '+00:00')) if 'completion_date' in data else datetime.utcnow()
        work_order.completed_by = data.get('completed_by', 1)
        
        # Create traceability links for raw materials (simplified for demo)
        # In a real system, this would link to actual material consumption records
        
        db.session.commit()
        
        return jsonify({
            'work_order': {
                'id': work_order.id,
                'status': work_order.status,
                'actual_quantity': work_order.actual_quantity,
                'completion_date': work_order.completion_date.isoformat()
            },
            'batch': {
                'id': batch.id,
                'batch_code': batch.batch_code,
                'lot_number': batch.lot_number,
                'quantity': batch.quantity,
                'manufacturing_date': batch.manufacturing_date.isoformat()
            },
            'inventory': {
                'id': inventory.id,
                'quantity_on_hand': inventory.quantity_on_hand,
                'location_id': inventory.location_id
            }
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@workorders_bp.route('/<int:work_order_id>', methods=['GET'])
def get_work_order(work_order_id):
    """Get work order details"""
    try:
        work_order = WorkOrder.query.get(work_order_id)
        if not work_order:
            return jsonify({'error': 'Work order not found'}), 404
        
        # Get associated batches
        batches = []
        for batch in work_order.batches:
            batches.append({
                'id': batch.id,
                'batch_code': batch.batch_code,
                'quantity': batch.quantity,
                'manufacturing_date': batch.manufacturing_date.isoformat() if batch.manufacturing_date else None,
                'status': batch.status
            })
        
        return jsonify({
            'id': work_order.id,
            'work_order_number': work_order.work_order_number,
            'product': {
                'id': work_order.product.id,
                'material_code': work_order.product.material_code,
                'material_name': work_order.product.material_name
            },
            'planned_quantity': work_order.planned_quantity,
            'actual_quantity': work_order.actual_quantity,
            'status': work_order.status,
            'start_date': work_order.start_date.isoformat() if work_order.start_date else None,
            'completion_date': work_order.completion_date.isoformat() if work_order.completion_date else None,
            'batches': batches
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@workorders_bp.route('/', methods=['GET'])
def list_work_orders():
    """List work orders with optional filtering"""
    try:
        # Get query parameters
        status = request.args.get('status')
        product_id = request.args.get('product_id', type=int)
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        # Build query
        query = WorkOrder.query
        
        if status:
            query = query.filter(WorkOrder.status == status)
        if product_id:
            query = query.filter(WorkOrder.product_id == product_id)
        
        # Order by creation date (newest first)
        query = query.order_by(WorkOrder.created_at.desc())
        
        # Paginate
        pagination = query.paginate(page=page, per_page=per_page, error_out=False)
        work_orders = pagination.items
        
        result = []
        for wo in work_orders:
            result.append({
                'id': wo.id,
                'work_order_number': wo.work_order_number,
                'product': {
                    'id': wo.product.id,
                    'material_code': wo.product.material_code,
                    'material_name': wo.product.material_name
                },
                'planned_quantity': wo.planned_quantity,
                'actual_quantity': wo.actual_quantity,
                'status': wo.status,
                'start_date': wo.start_date.isoformat() if wo.start_date else None,
                'completion_date': wo.completion_date.isoformat() if wo.completion_date else None,
                'created_at': wo.created_at.isoformat()
            })
        
        return jsonify({
            'work_orders': result,
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': pagination.total,
                'pages': pagination.pages,
                'has_next': pagination.has_next,
                'has_prev': pagination.has_prev
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

