#!/usr/bin/env python3
"""
K6 Load Testing Script for Traceability API
Tests the performance requirements for recall queries (<2s for 10k lots)
"""

import http from 'k6/http';
import { check, sleep } from 'k6';
import { Rate } from 'k6/metrics';

// Custom metrics
export let errorRate = new Rate('errors');

// Test configuration
export let options = {
  stages: [
    { duration: '30s', target: 10 },   // Ramp up to 10 users
    { duration: '1m', target: 20 },    // Stay at 20 users
    { duration: '30s', target: 50 },   // Ramp up to 50 users
    { duration: '2m', target: 50 },    // Stay at 50 users for 2 minutes
    { duration: '30s', target: 0 },    // Ramp down
  ],
  thresholds: {
    http_req_duration: ['p(95)<2000'], // 95% of requests must complete within 2s
    http_req_failed: ['rate<0.1'],     // Error rate must be less than 10%
    errors: ['rate<0.1'],              // Custom error rate
  },
};

// Base URL - update this to match your deployment
const BASE_URL = 'http://localhost:5001/api';

// Sample batch codes for testing
const SAMPLE_BATCH_CODES = [
  'RM-STEEL-0001', 'RM-STEEL-0002', 'RM-PLASTIC-0001', 'RM-PLASTIC-0002',
  'RM-COMPONENT-0001', 'RM-COMPONENT-0002', 'RM-CHEMICAL-0001',
  'BATCH-20240101-0001', 'BATCH-20240101-0002', 'BATCH-20240102-0001',
  'BATCH-20240102-0002', 'BATCH-20240103-0001', 'BATCH-20240103-0002',
  'INT-BATCH-20240104-001', 'INT-BATCH-20240104-002'
];

function getRandomBatchCodes(count = 3) {
  const shuffled = SAMPLE_BATCH_CODES.sort(() => 0.5 - Math.random());
  return shuffled.slice(0, count);
}

export default function () {
  // Test 1: Forward Traceability Query
  let forwardPayload = JSON.stringify({
    source_batch_codes: getRandomBatchCodes(2),
    include_indirect: true,
    max_levels: 10
  });

  let forwardResponse = http.post(`${BASE_URL}/traceability/forward`, forwardPayload, {
    headers: { 'Content-Type': 'application/json' },
  });

  let forwardSuccess = check(forwardResponse, {
    'forward trace status is 200': (r) => r.status === 200,
    'forward trace response time < 2s': (r) => r.timings.duration < 2000,
    'forward trace has results': (r) => {
      try {
        const body = JSON.parse(r.body);
        return body.results && Array.isArray(body.results);
      } catch (e) {
        return false;
      }
    },
  });

  if (!forwardSuccess) {
    errorRate.add(1);
  }

  sleep(1);

  // Test 2: Backward Traceability Query
  let backwardPayload = JSON.stringify({
    target_batch_codes: getRandomBatchCodes(2),
    include_indirect: true,
    max_levels: 10
  });

  let backwardResponse = http.post(`${BASE_URL}/traceability/backward`, backwardPayload, {
    headers: { 'Content-Type': 'application/json' },
  });

  let backwardSuccess = check(backwardResponse, {
    'backward trace status is 200': (r) => r.status === 200,
    'backward trace response time < 2s': (r) => r.timings.duration < 2000,
    'backward trace has results': (r) => {
      try {
        const body = JSON.parse(r.body);
        return body.results && Array.isArray(body.results);
      } catch (e) {
        return false;
      }
    },
  });

  if (!backwardSuccess) {
    errorRate.add(1);
  }

  sleep(1);

  // Test 3: Recall Analysis (most intensive query)
  let recallPayload = JSON.stringify({
    affected_batches: getRandomBatchCodes(1),
    recall_type: 'FORWARD',
    severity: 'HIGH'
  });

  let recallResponse = http.post(`${BASE_URL}/traceability/recall-analysis`, recallPayload, {
    headers: { 'Content-Type': 'application/json' },
  });

  let recallSuccess = check(recallResponse, {
    'recall analysis status is 200': (r) => r.status === 200,
    'recall analysis response time < 2s': (r) => r.timings.duration < 2000,
    'recall analysis has summary': (r) => {
      try {
        const body = JSON.parse(r.body);
        return body.analysis_summary && typeof body.analysis_summary === 'object';
      } catch (e) {
        return false;
      }
    },
  });

  if (!recallSuccess) {
    errorRate.add(1);
  }

  sleep(1);

  // Test 4: Inventory Summary (lighter query for baseline)
  let inventoryResponse = http.get(`${BASE_URL}/inventory/summary`);

  check(inventoryResponse, {
    'inventory summary status is 200': (r) => r.status === 200,
    'inventory summary response time < 1s': (r) => r.timings.duration < 1000,
  });

  sleep(1);

  // Test 5: Work Orders List (another baseline query)
  let workOrdersResponse = http.get(`${BASE_URL}/workorders/?per_page=20`);

  check(workOrdersResponse, {
    'work orders status is 200': (r) => r.status === 200,
    'work orders response time < 1s': (r) => r.timings.duration < 1000,
  });

  sleep(2);
}

