import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Plus, Search, Eye, CheckCircle, Clock, AlertCircle } from 'lucide-react'
import axios from 'axios'

const WorkOrders = ({ apiBaseUrl }) => {
  const [workOrders, setWorkOrders] = useState([])
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('ALL')
  const [showCreateDialog, setShowCreateDialog] = useState(false)
  const [showCompleteDialog, setShowCompleteDialog] = useState(false)
  const [selectedWorkOrder, setSelectedWorkOrder] = useState(null)
  const [newWorkOrder, setNewWorkOrder] = useState({
    work_order_number: '',
    product_id: '',
    planned_quantity: '',
    start_date: ''
  })
  const [completionData, setCompletionData] = useState({
    actual_quantity: '',
    completion_date: '',
    quality_notes: ''
  })

  useEffect(() => {
    fetchWorkOrders()
    fetchProducts()
  }, [])

  const fetchWorkOrders = async () => {
    try {
      setLoading(true)
      const response = await axios.get(`${apiBaseUrl}/workorders/`)
      setWorkOrders(response.data.work_orders || [])
    } catch (error) {
      console.error('Error fetching work orders:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchProducts = async () => {
    try {
      // For demo purposes, create some sample products
      setProducts([
        { id: 1, material_code: 'FG-WIDGET-001', material_name: 'Premium Widget' },
        { id: 2, material_code: 'FG-GADGET-002', material_name: 'Advanced Gadget' },
        { id: 3, material_code: 'FG-DEVICE-003', material_name: 'Smart Device' }
      ])
    } catch (error) {
      console.error('Error fetching products:', error)
    }
  }

  const createWorkOrder = async () => {
    try {
      const response = await axios.post(`${apiBaseUrl}/workorders/`, {
        ...newWorkOrder,
        product_id: parseInt(newWorkOrder.product_id),
        planned_quantity: parseFloat(newWorkOrder.planned_quantity)
      })
      
      setWorkOrders([response.data, ...workOrders])
      setShowCreateDialog(false)
      setNewWorkOrder({
        work_order_number: '',
        product_id: '',
        planned_quantity: '',
        start_date: ''
      })
    } catch (error) {
      console.error('Error creating work order:', error)
      alert('Error creating work order: ' + (error.response?.data?.error || error.message))
    }
  }

  const completeWorkOrder = async () => {
    try {
      const response = await axios.post(`${apiBaseUrl}/workorders/${selectedWorkOrder.id}/complete`, {
        ...completionData,
        actual_quantity: parseFloat(completionData.actual_quantity)
      })
      
      // Update the work order in the list
      setWorkOrders(workOrders.map(wo => 
        wo.id === selectedWorkOrder.id 
          ? { ...wo, status: 'COMPLETED', actual_quantity: parseFloat(completionData.actual_quantity) }
          : wo
      ))
      
      setShowCompleteDialog(false)
      setSelectedWorkOrder(null)
      setCompletionData({
        actual_quantity: '',
        completion_date: '',
        quality_notes: ''
      })
      
      alert(`Work order completed successfully! Batch created: ${response.data.batch.batch_code}`)
    } catch (error) {
      console.error('Error completing work order:', error)
      alert('Error completing work order: ' + (error.response?.data?.error || error.message))
    }
  }

  const getStatusIcon = (status) => {
    switch (status) {
      case 'COMPLETED': return <CheckCircle className="h-4 w-4 text-green-600" />
      case 'IN_PROGRESS': return <Clock className="h-4 w-4 text-blue-600" />
      case 'CREATED': return <AlertCircle className="h-4 w-4 text-yellow-600" />
      default: return <AlertCircle className="h-4 w-4 text-gray-600" />
    }
  }

  const getStatusBadgeColor = (status) => {
    switch (status) {
      case 'COMPLETED': return 'bg-green-100 text-green-800'
      case 'IN_PROGRESS': return 'bg-blue-100 text-blue-800'
      case 'CREATED': return 'bg-yellow-100 text-yellow-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const filteredWorkOrders = workOrders.filter(wo => {
    const matchesSearch = wo.work_order_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         wo.product.material_name.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === 'ALL' || wo.status === statusFilter
    return matchesSearch && matchesStatus
  })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Work Orders</h1>
        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogTrigger asChild>
            <Button className="flex items-center space-x-2">
              <Plus className="h-4 w-4" />
              <span>Create Work Order</span>
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Create New Work Order</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="wo-number">Work Order Number</Label>
                <Input
                  id="wo-number"
                  value={newWorkOrder.work_order_number}
                  onChange={(e) => setNewWorkOrder({...newWorkOrder, work_order_number: e.target.value})}
                  placeholder="WO-2024-001"
                />
              </div>
              <div>
                <Label htmlFor="product">Product</Label>
                <Select value={newWorkOrder.product_id} onValueChange={(value) => setNewWorkOrder({...newWorkOrder, product_id: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a product" />
                  </SelectTrigger>
                  <SelectContent>
                    {products.map(product => (
                      <SelectItem key={product.id} value={product.id.toString()}>
                        {product.material_code} - {product.material_name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="quantity">Planned Quantity</Label>
                <Input
                  id="quantity"
                  type="number"
                  value={newWorkOrder.planned_quantity}
                  onChange={(e) => setNewWorkOrder({...newWorkOrder, planned_quantity: e.target.value})}
                  placeholder="1000"
                />
              </div>
              <div>
                <Label htmlFor="start-date">Start Date</Label>
                <Input
                  id="start-date"
                  type="datetime-local"
                  value={newWorkOrder.start_date}
                  onChange={(e) => setNewWorkOrder({...newWorkOrder, start_date: e.target.value})}
                />
              </div>
              <Button onClick={createWorkOrder} className="w-full">
                Create Work Order
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search work orders..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Statuses</SelectItem>
                <SelectItem value="CREATED">Created</SelectItem>
                <SelectItem value="IN_PROGRESS">In Progress</SelectItem>
                <SelectItem value="COMPLETED">Completed</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Work Orders List */}
      <div className="grid gap-4">
        {loading ? (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
            <p className="mt-2 text-gray-600">Loading work orders...</p>
          </div>
        ) : filteredWorkOrders.length > 0 ? (
          filteredWorkOrders.map((workOrder) => (
            <Card key={workOrder.id} className="hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      {getStatusIcon(workOrder.status)}
                      <h3 className="text-lg font-semibold text-gray-900">
                        {workOrder.work_order_number}
                      </h3>
                      <Badge className={getStatusBadgeColor(workOrder.status)}>
                        {workOrder.status}
                      </Badge>
                    </div>
                    <p className="text-gray-600 mb-2">
                      <span className="font-medium">Product:</span> {workOrder.product.material_name}
                    </p>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <span className="text-gray-500">Planned:</span>
                        <p className="font-medium">{workOrder.planned_quantity?.toLocaleString()}</p>
                      </div>
                      <div>
                        <span className="text-gray-500">Actual:</span>
                        <p className="font-medium">{workOrder.actual_quantity?.toLocaleString() || 'N/A'}</p>
                      </div>
                      <div>
                        <span className="text-gray-500">Start Date:</span>
                        <p className="font-medium">
                          {workOrder.start_date ? new Date(workOrder.start_date).toLocaleDateString() : 'N/A'}
                        </p>
                      </div>
                      <div>
                        <span className="text-gray-500">Completion:</span>
                        <p className="font-medium">
                          {workOrder.completion_date ? new Date(workOrder.completion_date).toLocaleDateString() : 'N/A'}
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm">
                      <Eye className="h-4 w-4" />
                    </Button>
                    {workOrder.status !== 'COMPLETED' && (
                      <Button 
                        size="sm"
                        onClick={() => {
                          setSelectedWorkOrder(workOrder)
                          setCompletionData({
                            actual_quantity: workOrder.planned_quantity.toString(),
                            completion_date: new Date().toISOString().slice(0, 16),
                            quality_notes: ''
                          })
                          setShowCompleteDialog(true)
                        }}
                      >
                        Complete
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        ) : (
          <Card>
            <CardContent className="pt-6">
              <div className="text-center py-8">
                <ClipboardList className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">No work orders found</p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Complete Work Order Dialog */}
      <Dialog open={showCompleteDialog} onOpenChange={setShowCompleteDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Complete Work Order</DialogTitle>
          </DialogHeader>
          {selectedWorkOrder && (
            <div className="space-y-4">
              <div className="bg-gray-50 p-3 rounded-lg">
                <p className="font-medium">{selectedWorkOrder.work_order_number}</p>
                <p className="text-sm text-gray-600">{selectedWorkOrder.product.material_name}</p>
              </div>
              <div>
                <Label htmlFor="actual-quantity">Actual Quantity</Label>
                <Input
                  id="actual-quantity"
                  type="number"
                  value={completionData.actual_quantity}
                  onChange={(e) => setCompletionData({...completionData, actual_quantity: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="completion-date">Completion Date</Label>
                <Input
                  id="completion-date"
                  type="datetime-local"
                  value={completionData.completion_date}
                  onChange={(e) => setCompletionData({...completionData, completion_date: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="quality-notes">Quality Notes</Label>
                <Textarea
                  id="quality-notes"
                  value={completionData.quality_notes}
                  onChange={(e) => setCompletionData({...completionData, quality_notes: e.target.value})}
                  placeholder="Production completed successfully..."
                />
              </div>
              <Button onClick={completeWorkOrder} className="w-full">
                Complete Work Order
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

export default WorkOrders

