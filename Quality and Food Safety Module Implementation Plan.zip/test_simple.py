import pytest
import json
from datetime import datetime, date
import sys
import os

# Add the project root to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.main import app
from src.models.user import db, User, Recipe, CriticalControlPoint, Batch, BatchIngredient

@pytest.fixture
def client():
    """Create a test client for the Flask application"""
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    app.config['WTF_CSRF_ENABLED'] = False
    
    with app.test_client() as client:
        with app.app_context():
            db.create_all()
            
            # Create test data
            user = User(username='test_user', email='test@test.com', password_hash='hashed', role='operator')
            recipe = Recipe(name='Test Recipe', description='Test description', version='1.0')
            
            db.session.add(user)
            db.session.add(recipe)
            db.session.commit()
            
            ccp = CriticalControlPoint(
                recipe_id=recipe.id,
                step='Test Step',
                critical_limit_min=10.0,
                critical_limit_max=20.0,
                unit='°C'
            )
            
            batch = Batch(
                lot_number='TEST001',
                recipe_id=recipe.id,
                production_date=date.today(),
                quantity=100.0,
                unit='kg',
                status='hold',
                created_by=user.id
            )
            
            db.session.add(ccp)
            db.session.add(batch)
            db.session.commit()
            
            ingredient = BatchIngredient(
                batch_id=batch.id,
                ingredient_name='Test Ingredient',
                supplier='Test Supplier',
                lot_number='ING001',
                quantity=50.0,
                unit='kg'
            )
            
            db.session.add(ingredient)
            db.session.commit()
            
        yield client

def test_get_recipes(client):
    """Test getting all recipes"""
    response = client.get('/api/recipes')
    assert response.status_code == 200
    
    data = json.loads(response.data)
    assert 'recipes' in data
    assert len(data['recipes']) > 0
    assert data['recipes'][0]['name'] == 'Test Recipe'

def test_get_ccp_points(client):
    """Test getting CCP points"""
    response = client.get('/api/ccp/points')
    assert response.status_code == 200
    
    data = json.loads(response.data)
    assert 'ccps' in data
    assert len(data['ccps']) > 0
    assert data['ccps'][0]['step'] == 'Test Step'

def test_get_batches(client):
    """Test getting all batches"""
    response = client.get('/api/batches')
    assert response.status_code == 200
    
    data = json.loads(response.data)
    assert 'batches' in data
    assert len(data['batches']) > 0
    assert data['batches'][0]['lot_number'] == 'TEST001'

def test_forward_recall_query(client):
    """Test forward traceability query"""
    query_data = {
        'ingredient_lot': 'ING001',
        'supplier': 'Test Supplier'
    }
    
    response = client.post('/api/recall/forward',
                         data=json.dumps(query_data),
                         content_type='application/json')
    assert response.status_code == 200
    
    data = json.loads(response.data)
    assert 'affected_batches' in data
    assert 'total_batches' in data

def test_backward_recall_query(client):
    """Test backward traceability query"""
    query_data = {
        'lot_number': 'TEST001'
    }
    
    response = client.post('/api/recall/backward',
                         data=json.dumps(query_data),
                         content_type='application/json')
    assert response.status_code == 200
    
    data = json.loads(response.data)
    assert 'traceability_data' in data
    assert 'total_ingredients' in data

def test_fda_form_generation(client):
    """Test FDA Form 3911 PDF generation"""
    form_data = {
        'company_name': 'Test Company',
        'contact_person': 'Test Person',
        'phone': '555-1234',
        'email': 'test@company.com',
        'product_name': 'Test Product',
        'lot_numbers': ['TEST001'],
        'reason_for_recall': 'Quality issue',
        'distribution_pattern': 'Local',
        'quantity_distributed': '100 kg'
    }
    
    response = client.post('/api/recall/fda-form-3911',
                         data=json.dumps(form_data),
                         content_type='application/json')
    assert response.status_code == 200
    assert response.content_type == 'application/pdf'

def test_missing_required_fields(client):
    """Test API response to missing required fields"""
    incomplete_data = {
        'ccp_id': 1,
        'recipe_id': 1
    }
    
    response = client.post('/api/ccp/logs',
                         data=json.dumps(incomplete_data),
                         content_type='application/json')
    assert response.status_code == 400
    
    data = json.loads(response.data)
    assert 'error' in data

if __name__ == '__main__':
    pytest.main([__file__, '-v'])

