import pytest
import json
from datetime import datetime, date
from src.main import app
from src.models.user import db, User, Recipe, CriticalControlPoint, Batch, BatchIngredient, CCPLog

@pytest.fixture
def client():
    """Create a test client for the Flask application"""
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    
    with app.test_client() as client:
        with app.app_context():
            db.create_all()
            
            # Create test data
            user = User(username='test_user', email='test@test.com', password_hash='hashed', role='operator')
            recipe = Recipe(name='Test Recipe', description='Test description', version='1.0')
            
            db.session.add(user)
            db.session.add(recipe)
            db.session.commit()
            
            ccp = CriticalControlPoint(
                recipe_id=recipe.id,
                step='Test Step',
                critical_limit_min=10.0,
                critical_limit_max=20.0,
                unit='°C'
            )
            
            batch = Batch(
                lot_number='TEST001',
                recipe_id=recipe.id,
                production_date=date.today(),
                quantity=100.0,
                unit='kg',
                status='hold',
                created_by=user.id
            )
            
            db.session.add(ccp)
            db.session.add(batch)
            db.session.commit()
            
            ingredient = BatchIngredient(
                batch_id=batch.id,
                ingredient_name='Test Ingredient',
                supplier='Test Supplier',
                lot_number='ING001',
                quantity=50.0,
                unit='kg'
            )
            
            db.session.add(ingredient)
            db.session.commit()
            
        yield client

class TestRecipeAPI:
    """Test recipe-related API endpoints"""
    
    def test_get_recipes(self, client):
        """Test getting all recipes"""
        response = client.get('/api/recipes')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert 'recipes' in data
        assert len(data['recipes']) > 0
        assert data['recipes'][0]['name'] == 'Test Recipe'

class TestCCPAPI:
    """Test CCP-related API endpoints"""
    
    def test_get_ccp_points(self, client):
        """Test getting CCP points"""
        response = client.get('/api/ccp/points')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert 'ccps' in data
        assert len(data['ccps']) > 0
        assert data['ccps'][0]['step'] == 'Test Step'
    
    def test_create_ccp_log(self, client):
        """Test creating a CCP log entry"""
        # Get CCP and recipe IDs
        ccp_response = client.get('/api/ccp/points')
        ccp_data = json.loads(ccp_response.data)
        ccp_id = ccp_data['ccps'][0]['id']
        recipe_id = ccp_data['ccps'][0]['recipe_id']
        
        log_data = {
            'ccp_id': ccp_id,
            'recipe_id': recipe_id,
            'lot_number': 'TEST001',
            'log_value': 15.0,
            'user_id': 1,
            'notes': 'Test measurement',
            'signature_data': {
                'user_id': 1,
                'timestamp': datetime.now().isoformat(),
                'meaning': 'Test signature'
            }
        }
        
        response = client.post('/api/ccp/logs', 
                             data=json.dumps(log_data),
                             content_type='application/json')
        assert response.status_code == 201
        
        data = json.loads(response.data)
        assert 'id' in data
        assert data['status'] == 'in_spec'
    
    def test_get_ccp_logs(self, client):
        """Test getting CCP logs"""
        response = client.get('/api/ccp/logs')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert 'logs' in data

class TestBatchAPI:
    """Test batch-related API endpoints"""
    
    def test_get_batches(self, client):
        """Test getting all batches"""
        response = client.get('/api/batches')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert 'batches' in data
        assert len(data['batches']) > 0
        assert data['batches'][0]['lot_number'] == 'TEST001'
    
    def test_hold_batch(self, client):
        """Test putting a batch on hold"""
        # First get batch ID
        batch_response = client.get('/api/batches')
        batch_data = json.loads(batch_response.data)
        batch_id = batch_data['batches'][0]['id']
        
        hold_data = {
            'user_id': 1,
            'reason': 'Quality issue'
        }
        
        response = client.post(f'/api/batches/{batch_id}/hold',
                             data=json.dumps(hold_data),
                             content_type='application/json')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert 'message' in data
    
    def test_release_batch(self, client):
        """Test releasing a batch"""
        # First get batch ID
        batch_response = client.get('/api/batches')
        batch_data = json.loads(batch_response.data)
        batch_id = batch_data['batches'][0]['id']
        
        release_data = {
            'user_id': 1,
            'reason': 'Quality approved'
        }
        
        response = client.post(f'/api/batches/{batch_id}/release',
                             data=json.dumps(release_data),
                             content_type='application/json')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert 'message' in data

class TestRecallAPI:
    """Test recall and traceability API endpoints"""
    
    def test_forward_recall_query(self, client):
        """Test forward traceability query"""
        query_data = {
            'ingredient_lot': 'ING001',
            'supplier': 'Test Supplier'
        }
        
        response = client.post('/api/recall/forward',
                             data=json.dumps(query_data),
                             content_type='application/json')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert 'affected_batches' in data
        assert 'total_batches' in data
    
    def test_backward_recall_query(self, client):
        """Test backward traceability query"""
        query_data = {
            'lot_number': 'TEST001'
        }
        
        response = client.post('/api/recall/backward',
                             data=json.dumps(query_data),
                             content_type='application/json')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert 'traceability_data' in data
        assert 'total_ingredients' in data
    
    def test_impact_analysis(self, client):
        """Test recall impact analysis"""
        query_data = {
            'ingredient_lot': 'ING001',
            'supplier': 'Test Supplier'
        }
        
        response = client.post('/api/recall/impact-analysis',
                             data=json.dumps(query_data),
                             content_type='application/json')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert 'impact_summary' in data
        assert 'affected_batches' in data

class TestPDFAPI:
    """Test PDF generation API endpoints"""
    
    def test_fda_form_3911_generation(self, client):
        """Test FDA Form 3911 PDF generation"""
        form_data = {
            'company_name': 'Test Company',
            'contact_person': 'Test Person',
            'phone': '555-1234',
            'email': 'test@company.com',
            'product_name': 'Test Product',
            'lot_numbers': ['TEST001'],
            'reason_for_recall': 'Quality issue',
            'distribution_pattern': 'Local',
            'quantity_distributed': '100 kg'
        }
        
        response = client.post('/api/recall/fda-form-3911',
                             data=json.dumps(form_data),
                             content_type='application/json')
        assert response.status_code == 200
        assert response.content_type == 'application/pdf'
    
    def test_recall_readiness_report(self, client):
        """Test recall readiness report generation"""
        report_data = {
            'performance_metrics': {
                'query_time': 50,
                'total_records': 1000,
                'uptime': 99.9,
                'audit_coverage': 98.5
            }
        }
        
        response = client.post('/api/recall/readiness-report',
                             data=json.dumps(report_data),
                             content_type='application/json')
        assert response.status_code == 200
        assert response.content_type == 'application/pdf'

class TestAuditAPI:
    """Test audit and compliance API endpoints"""
    
    def test_get_audit_logs(self, client):
        """Test getting audit logs"""
        response = client.get('/api/audit/logs')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert 'audit_logs' in data
    
    def test_signature_verification(self, client):
        """Test signature verification"""
        verify_data = {
            'signature_hash': 'test_hash_123'
        }
        
        response = client.post('/api/audit/signature/verify',
                             data=json.dumps(verify_data),
                             content_type='application/json')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert 'valid' in data
    
    def test_compliance_report(self, client):
        """Test compliance report generation"""
        response = client.get('/api/audit/compliance-report?start_date=2024-01-01&end_date=2024-12-31')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert 'compliance_summary' in data

class TestErrorHandling:
    """Test error handling and edge cases"""
    
    def test_missing_required_fields(self, client):
        """Test API response to missing required fields"""
        # Test CCP log creation without required fields
        incomplete_data = {
            'ccp_id': 1,
            'recipe_id': 1
            # Missing lot_number, log_value, user_id, signature_data
        }
        
        response = client.post('/api/ccp/logs',
                             data=json.dumps(incomplete_data),
                             content_type='application/json')
        assert response.status_code == 400
        
        data = json.loads(response.data)
        assert 'error' in data
    
    def test_invalid_batch_id(self, client):
        """Test API response to invalid batch ID"""
        hold_data = {
            'user_id': 1,
            'reason': 'Test'
        }
        
        response = client.post('/api/batches/99999/hold',
                             data=json.dumps(hold_data),
                             content_type='application/json')
        assert response.status_code == 404
        
        data = json.loads(response.data)
        assert 'error' in data
    
    def test_invalid_lot_number(self, client):
        """Test backward traceability with invalid lot number"""
        query_data = {
            'lot_number': 'NONEXISTENT'
        }
        
        response = client.post('/api/recall/backward',
                             data=json.dumps(query_data),
                             content_type='application/json')
        assert response.status_code == 404
        
        data = json.loads(response.data)
        assert 'error' in data

if __name__ == '__main__':
    pytest.main([__file__, '-v', '--cov=src', '--cov-report=html', '--cov-report=term-missing'])

