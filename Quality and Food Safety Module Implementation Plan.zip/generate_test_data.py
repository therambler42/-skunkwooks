import random
from datetime import datetime, timedelta
from src.models.user import db, User, Recipe, CriticalControlPoint, Batch, BatchIngredient, CCPLog
from src.main import app

def generate_large_dataset():
    """Generate 10k+ batches and ingredients for performance testing"""
    
    with app.app_context():
        print("Starting large dataset generation...")
        
        # Get existing data
        recipes = Recipe.query.all()
        users = User.query.all()
        ccps = CriticalControlPoint.query.all()
        
        if not recipes or not users:
            print("Error: No recipes or users found. Run basic sample data creation first.")
            return
        
        # Generate 10,000 batches
        batch_count = 10000
        ingredient_suppliers = ['Supplier A', 'Supplier B', 'Supplier C', 'Supplier D', 'Supplier E']
        ingredient_names = ['Flour', 'Sugar', 'Eggs', 'Butter', 'Vanilla', 'Chocolate Chips', 'Milk', 'Salt']
        
        print(f"Generating {batch_count} batches...")
        
        batches_to_add = []
        ingredients_to_add = []
        ccp_logs_to_add = []
        
        for i in range(batch_count):
            # Generate batch
            recipe = random.choice(recipes)
            user = random.choice(users)
            production_date = datetime.now().date() - timedelta(days=random.randint(1, 365))
            
            batch = Batch(
                lot_number=f"LOT{i+1:06d}",
                recipe_id=recipe.id,
                production_date=production_date,
                expiry_date=production_date + timedelta(days=random.randint(30, 180)),
                quantity=random.randint(50, 500),
                unit='kg',
                status=random.choice(['hold', 'released', 'recalled']),
                created_by=user.id,
                created_at=datetime.now() - timedelta(days=random.randint(1, 365))
            )
            batches_to_add.append(batch)
            
            # Add batch to session to get ID (will be committed later)
            db.session.add(batch)
            if i % 1000 == 0:
                db.session.flush()  # Flush to get IDs without committing
                print(f"Generated {i+1} batches...")
        
        print("Committing batches...")
        db.session.commit()
        
        # Get all batch IDs
        all_batches = Batch.query.all()
        print(f"Total batches in database: {len(all_batches)}")
        
        # Generate ingredients for each batch (2-5 ingredients per batch)
        print("Generating batch ingredients...")
        for i, batch in enumerate(all_batches[-batch_count:]):  # Only for newly created batches
            num_ingredients = random.randint(2, 5)
            
            for j in range(num_ingredients):
                ingredient = BatchIngredient(
                    batch_id=batch.id,
                    ingredient_name=random.choice(ingredient_names),
                    supplier=random.choice(ingredient_suppliers),
                    lot_number=f"ING{random.randint(1000, 9999)}",
                    quantity=random.randint(1, 50),
                    unit='kg'
                )
                ingredients_to_add.append(ingredient)
            
            if i % 1000 == 0:
                print(f"Generated ingredients for {i+1} batches...")
        
        # Bulk insert ingredients
        print("Committing ingredients...")
        db.session.bulk_save_objects(ingredients_to_add)
        db.session.commit()
        
        # Generate CCP logs (multiple logs per batch)
        print("Generating CCP logs...")
        for i, batch in enumerate(all_batches[-batch_count:]):  # Only for newly created batches
            batch_ccps = [ccp for ccp in ccps if ccp.recipe_id == batch.recipe_id]
            
            for ccp in batch_ccps:
                # Generate 1-3 logs per CCP per batch
                num_logs = random.randint(1, 3)
                
                for k in range(num_logs):
                    # Generate value within or slightly outside critical limits
                    if ccp.critical_limit_min and ccp.critical_limit_max:
                        if random.random() < 0.9:  # 90% within limits
                            log_value = random.uniform(ccp.critical_limit_min, ccp.critical_limit_max)
                            status = 'in_spec'
                        else:  # 10% out of spec
                            if random.random() < 0.5:
                                log_value = ccp.critical_limit_min - random.uniform(1, 10)
                            else:
                                log_value = ccp.critical_limit_max + random.uniform(1, 10)
                            status = 'out_of_spec'
                    else:
                        log_value = random.uniform(50, 100)
                        status = 'in_spec'
                    
                    ccp_log = CCPLog(
                        ccp_id=ccp.id,
                        recipe_id=batch.recipe_id,
                        lot_number=batch.lot_number,
                        log_value=log_value,
                        user_id=random.choice(users).id,
                        timestamp=batch.created_at + timedelta(hours=random.randint(1, 8)),
                        status=status,
                        notes=f"Measurement {k+1} for batch {batch.lot_number}",
                        signature_hash=f"hash_{batch.id}_{ccp.id}_{k}"
                    )
                    ccp_logs_to_add.append(ccp_log)
            
            if i % 1000 == 0:
                print(f"Generated CCP logs for {i+1} batches...")
        
        # Bulk insert CCP logs
        print("Committing CCP logs...")
        db.session.bulk_save_objects(ccp_logs_to_add)
        db.session.commit()
        
        # Print final statistics
        total_batches = Batch.query.count()
        total_ingredients = BatchIngredient.query.count()
        total_ccp_logs = CCPLog.query.count()
        
        print(f"Dataset generation complete!")
        print(f"Total batches: {total_batches}")
        print(f"Total ingredients: {total_ingredients}")
        print(f"Total CCP logs: {total_ccp_logs}")

if __name__ == "__main__":
    generate_large_dataset()

