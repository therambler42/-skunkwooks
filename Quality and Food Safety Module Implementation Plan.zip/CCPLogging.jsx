import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Alert, AlertDescription } from '@/components/ui/alert.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table.jsx'
import { CheckCircle, AlertTriangle, Clock, PenTool } from 'lucide-react'
import ElectronicSignature from './ElectronicSignature.jsx'

const API_BASE = 'http://localhost:5001/api'

function CCPLogging({ user }) {
  const [recipes, setRecipes] = useState([])
  const [ccps, setCcps] = useState([])
  const [ccpLogs, setCcpLogs] = useState([])
  const [selectedRecipe, setSelectedRecipe] = useState('')
  const [selectedCcp, setSelectedCcp] = useState('')
  const [formData, setFormData] = useState({
    lot_number: '',
    log_value: '',
    notes: ''
  })
  const [showSignature, setShowSignature] = useState(false)
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState('')

  useEffect(() => {
    fetchRecipes()
    fetchCcpLogs()
  }, [])

  useEffect(() => {
    if (selectedRecipe) {
      fetchCcps(selectedRecipe)
    }
  }, [selectedRecipe])

  const fetchRecipes = async () => {
    try {
      const response = await fetch(`${API_BASE}/recipes`)
      const data = await response.json()
      setRecipes(data.recipes || [])
    } catch (error) {
      console.error('Error fetching recipes:', error)
    }
  }

  const fetchCcps = async (recipeId) => {
    try {
      const response = await fetch(`${API_BASE}/ccp/points?recipe_id=${recipeId}`)
      const data = await response.json()
      setCcps(data.ccps || [])
    } catch (error) {
      console.error('Error fetching CCPs:', error)
    }
  }

  const fetchCcpLogs = async () => {
    try {
      const response = await fetch(`${API_BASE}/ccp/logs?per_page=20`)
      const data = await response.json()
      setCcpLogs(data.logs || [])
    } catch (error) {
      console.error('Error fetching CCP logs:', error)
    }
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    
    if (!selectedRecipe || !selectedCcp || !formData.lot_number || !formData.log_value) {
      setMessage('Please fill in all required fields')
      return
    }

    setShowSignature(true)
  }

  const handleSignatureComplete = async (signatureData) => {
    setLoading(true)
    try {
      const response = await fetch(`${API_BASE}/ccp/logs`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ccp_id: parseInt(selectedCcp),
          recipe_id: parseInt(selectedRecipe),
          lot_number: formData.lot_number,
          log_value: parseFloat(formData.log_value),
          user_id: user.id,
          notes: formData.notes,
          signature_data: signatureData
        })
      })

      const result = await response.json()
      
      if (response.ok) {
        setMessage('CCP log entry created successfully')
        setFormData({ lot_number: '', log_value: '', notes: '' })
        setSelectedRecipe('')
        setSelectedCcp('')
        fetchCcpLogs()
      } else {
        setMessage(`Error: ${result.error}`)
      }
    } catch (error) {
      setMessage(`Error: ${error.message}`)
    } finally {
      setLoading(false)
      setShowSignature(false)
    }
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case 'in_spec':
        return <Badge className="bg-green-100 text-green-800"><CheckCircle className="w-3 h-3 mr-1" />In Spec</Badge>
      case 'out_of_spec':
        return <Badge className="bg-red-100 text-red-800"><AlertTriangle className="w-3 h-3 mr-1" />Out of Spec</Badge>
      case 'corrected':
        return <Badge className="bg-yellow-100 text-yellow-800"><Clock className="w-3 h-3 mr-1" />Corrected</Badge>
      default:
        return <Badge variant="secondary">{status}</Badge>
    }
  }

  const selectedCcpData = ccps.find(ccp => ccp.id === parseInt(selectedCcp))

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-gray-900">CCP Logging</h2>
        <p className="text-gray-600 mt-2">
          Log critical control point measurements with electronic signatures (21 CFR Part 11 compliant)
        </p>
      </div>

      {message && (
        <Alert>
          <AlertDescription>{message}</AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* CCP Logging Form */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <PenTool className="h-5 w-5 mr-2" />
              New CCP Log Entry
            </CardTitle>
            <CardDescription>
              Record critical control point measurements
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="recipe">Recipe</Label>
                <Select value={selectedRecipe} onValueChange={setSelectedRecipe}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a recipe" />
                  </SelectTrigger>
                  <SelectContent>
                    {recipes.map(recipe => (
                      <SelectItem key={recipe.id} value={recipe.id.toString()}>
                        {recipe.name} (v{recipe.version})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="ccp">Critical Control Point</Label>
                <Select value={selectedCcp} onValueChange={setSelectedCcp} disabled={!selectedRecipe}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a CCP" />
                  </SelectTrigger>
                  <SelectContent>
                    {ccps.map(ccp => (
                      <SelectItem key={ccp.id} value={ccp.id.toString()}>
                        {ccp.step}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedCcpData && (
                <div className="p-3 bg-blue-50 rounded-lg">
                  <h4 className="font-medium text-blue-900">Critical Limits</h4>
                  <p className="text-sm text-blue-700">
                    {selectedCcpData.critical_limit_min !== null && `Min: ${selectedCcpData.critical_limit_min}`}
                    {selectedCcpData.critical_limit_min !== null && selectedCcpData.critical_limit_max !== null && ' | '}
                    {selectedCcpData.critical_limit_max !== null && `Max: ${selectedCcpData.critical_limit_max}`}
                    {selectedCcpData.unit && ` ${selectedCcpData.unit}`}
                  </p>
                </div>
              )}

              <div>
                <Label htmlFor="lot_number">Lot Number *</Label>
                <Input
                  id="lot_number"
                  value={formData.lot_number}
                  onChange={(e) => setFormData({...formData, lot_number: e.target.value})}
                  placeholder="Enter lot number"
                  required
                />
              </div>

              <div>
                <Label htmlFor="log_value">Measured Value *</Label>
                <Input
                  id="log_value"
                  type="number"
                  step="0.01"
                  value={formData.log_value}
                  onChange={(e) => setFormData({...formData, log_value: e.target.value})}
                  placeholder="Enter measured value"
                  required
                />
              </div>

              <div>
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => setFormData({...formData, notes: e.target.value})}
                  placeholder="Optional notes or observations"
                  rows={3}
                />
              </div>

              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? 'Processing...' : 'Sign and Submit'}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Recent CCP Logs */}
        <Card>
          <CardHeader>
            <CardTitle>Recent CCP Logs</CardTitle>
            <CardDescription>
              Latest critical control point measurements
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {ccpLogs.length === 0 ? (
                <p className="text-gray-500 text-center py-4">No CCP logs found</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Lot</TableHead>
                      <TableHead>Value</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Time</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {ccpLogs.slice(0, 10).map(log => (
                      <TableRow key={log.id}>
                        <TableCell className="font-medium">{log.lot_number}</TableCell>
                        <TableCell>{log.log_value} {log.unit}</TableCell>
                        <TableCell>{getStatusBadge(log.status)}</TableCell>
                        <TableCell className="text-sm text-gray-500">
                          {new Date(log.timestamp).toLocaleString()}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Electronic Signature Modal */}
      {showSignature && (
        <ElectronicSignature
          user={user}
          data={formData}
          onComplete={handleSignatureComplete}
          onCancel={() => setShowSignature(false)}
        />
      )}
    </div>
  )
}

export default CCPLogging

