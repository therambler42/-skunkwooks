from flask import Blueprint, request, jsonify
from src.models.user import db, AuditLog, User
from datetime import datetime

audit_bp = Blueprint('audit', __name__)

@audit_bp.route('/audit/logs', methods=['GET'])
def get_audit_logs():
    """Get audit logs with filtering options"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 50, type=int)
        user_id = request.args.get('user_id', type=int)
        action = request.args.get('action')
        table_name = request.args.get('table_name')
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        query = AuditLog.query
        
        if user_id:
            query = query.filter(AuditLog.user_id == user_id)
        if action:
            query = query.filter(AuditLog.action == action)
        if table_name:
            query = query.filter(AuditLog.table_name == table_name)
        if start_date:
            query = query.filter(AuditLog.timestamp >= datetime.fromisoformat(start_date))
        if end_date:
            query = query.filter(AuditLog.timestamp <= datetime.fromisoformat(end_date))
            
        logs = query.order_by(AuditLog.timestamp.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        result = []
        for log in logs.items:
            result.append({
                'id': log.id,
                'user_id': log.user_id,
                'username': log.user.username,
                'action': log.action,
                'table_name': log.table_name,
                'record_id': log.record_id,
                'old_values': log.old_values,
                'new_values': log.new_values,
                'signature_hash': log.signature_hash,
                'timestamp': log.timestamp.isoformat(),
                'ip_address': log.ip_address
            })
        
        return jsonify({
            'audit_logs': result,
            'total': logs.total,
            'pages': logs.pages,
            'current_page': page
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@audit_bp.route('/audit/signature/verify', methods=['POST'])
def verify_signature():
    """Verify electronic signature hash"""
    try:
        data = request.get_json()
        signature_hash = data.get('signature_hash')
        
        if not signature_hash:
            return jsonify({'error': 'signature_hash is required'}), 400
        
        # Find audit log with this signature
        audit_log = AuditLog.query.filter_by(signature_hash=signature_hash).first()
        
        if not audit_log:
            return jsonify({
                'valid': False,
                'message': 'Signature not found in audit trail'
            })
        
        return jsonify({
            'valid': True,
            'audit_log': {
                'id': audit_log.id,
                'user_id': audit_log.user_id,
                'username': audit_log.user.username,
                'action': audit_log.action,
                'table_name': audit_log.table_name,
                'record_id': audit_log.record_id,
                'timestamp': audit_log.timestamp.isoformat(),
                'ip_address': audit_log.ip_address
            }
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@audit_bp.route('/audit/compliance-report', methods=['GET'])
def compliance_report():
    """Generate compliance report for 21 CFR Part 11"""
    try:
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        if not start_date or not end_date:
            return jsonify({'error': 'start_date and end_date are required'}), 400
        
        query = AuditLog.query.filter(
            AuditLog.timestamp >= datetime.fromisoformat(start_date),
            AuditLog.timestamp <= datetime.fromisoformat(end_date)
        )
        
        logs = query.all()
        
        # Generate compliance metrics
        total_actions = len(logs)
        signed_actions = len([log for log in logs if log.signature_hash])
        unique_users = len(set(log.user_id for log in logs))
        
        action_breakdown = {}
        table_breakdown = {}
        
        for log in logs:
            action_breakdown[log.action] = action_breakdown.get(log.action, 0) + 1
            table_breakdown[log.table_name] = table_breakdown.get(log.table_name, 0) + 1
        
        return jsonify({
            'compliance_summary': {
                'report_period': {
                    'start_date': start_date,
                    'end_date': end_date
                },
                'total_actions': total_actions,
                'signed_actions': signed_actions,
                'signature_compliance_rate': (signed_actions / total_actions * 100) if total_actions > 0 else 0,
                'unique_users': unique_users,
                'action_breakdown': action_breakdown,
                'table_breakdown': table_breakdown
            },
            'generated_at': datetime.utcnow().isoformat()
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

