import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Alert, AlertDescription } from '@/components/ui/alert.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Package, AlertTriangle, CheckCircle, Clock, Play, Pause } from 'lucide-react'

const API_BASE = 'http://localhost:5001/api'

function BatchManagement({ user }) {
  const [batches, setBatches] = useState([])
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState('')
  const [filters, setFilters] = useState({
    status: '',
    lot_number: '',
    start_date: '',
    end_date: ''
  })

  useEffect(() => {
    fetchBatches()
  }, [filters])

  const fetchBatches = async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      Object.entries(filters).forEach(([key, value]) => {
        if (value) params.append(key, value)
      })

      const response = await fetch(`${API_BASE}/batches?${params}`)
      const data = await response.json()
      setBatches(data.batches || [])
    } catch (error) {
      console.error('Error fetching batches:', error)
      setMessage('Error fetching batches')
    } finally {
      setLoading(false)
    }
  }

  const handleStatusChange = async (batchId, action, reason = '') => {
    setLoading(true)
    try {
      const response = await fetch(`${API_BASE}/batches/${batchId}/${action}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          user_id: user.id,
          reason: reason
        })
      })

      const result = await response.json()
      
      if (response.ok) {
        setMessage(result.message)
        fetchBatches()
      } else {
        setMessage(`Error: ${result.error}`)
      }
    } catch (error) {
      setMessage(`Error: ${error.message}`)
    } finally {
      setLoading(false)
    }
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case 'hold':
        return <Badge className="bg-yellow-100 text-yellow-800"><Pause className="w-3 h-3 mr-1" />Hold</Badge>
      case 'released':
        return <Badge className="bg-green-100 text-green-800"><CheckCircle className="w-3 h-3 mr-1" />Released</Badge>
      case 'recalled':
        return <Badge className="bg-red-100 text-red-800"><AlertTriangle className="w-3 h-3 mr-1" />Recalled</Badge>
      default:
        return <Badge variant="secondary">{status}</Badge>
    }
  }

  const getStatusCounts = () => {
    const counts = batches.reduce((acc, batch) => {
      acc[batch.status] = (acc[batch.status] || 0) + 1
      return acc
    }, {})
    return counts
  }

  const statusCounts = getStatusCounts()

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-gray-900">Batch Management</h2>
        <p className="text-gray-600 mt-2">
          Manage batch hold/release workflow and status tracking
        </p>
      </div>

      {message && (
        <Alert>
          <AlertDescription>{message}</AlertDescription>
        </Alert>
      )}

      {/* Status Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Batches</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{batches.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">On Hold</CardTitle>
            <Pause className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{statusCounts.hold || 0}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Released</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{statusCounts.released || 0}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Recalled</CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{statusCounts.recalled || 0}</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="batches" className="space-y-4">
        <TabsList>
          <TabsTrigger value="batches">Batch List</TabsTrigger>
          <TabsTrigger value="filters">Filters</TabsTrigger>
        </TabsList>

        <TabsContent value="filters" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Filter Batches</CardTitle>
              <CardDescription>
                Filter batches by status, lot number, or date range
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                  <Label htmlFor="status">Status</Label>
                  <Select value={filters.status} onValueChange={(value) => setFilters({...filters, status: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="All statuses" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">All statuses</SelectItem>
                      <SelectItem value="hold">Hold</SelectItem>
                      <SelectItem value="released">Released</SelectItem>
                      <SelectItem value="recalled">Recalled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="lot_number">Lot Number</Label>
                  <Input
                    id="lot_number"
                    value={filters.lot_number}
                    onChange={(e) => setFilters({...filters, lot_number: e.target.value})}
                    placeholder="Search lot number"
                  />
                </div>

                <div>
                  <Label htmlFor="start_date">Start Date</Label>
                  <Input
                    id="start_date"
                    type="date"
                    value={filters.start_date}
                    onChange={(e) => setFilters({...filters, start_date: e.target.value})}
                  />
                </div>

                <div>
                  <Label htmlFor="end_date">End Date</Label>
                  <Input
                    id="end_date"
                    type="date"
                    value={filters.end_date}
                    onChange={(e) => setFilters({...filters, end_date: e.target.value})}
                  />
                </div>
              </div>

              <div className="flex space-x-2 mt-4">
                <Button 
                  onClick={() => setFilters({ status: '', lot_number: '', start_date: '', end_date: '' })}
                  variant="outline"
                >
                  Clear Filters
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="batches" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Batch List</CardTitle>
              <CardDescription>
                Manage batch status and workflow
              </CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="text-center py-4">Loading batches...</div>
              ) : batches.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No batches found matching the current filters
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Lot Number</TableHead>
                      <TableHead>Recipe</TableHead>
                      <TableHead>Production Date</TableHead>
                      <TableHead>Quantity</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {batches.map(batch => (
                      <TableRow key={batch.id}>
                        <TableCell className="font-medium">{batch.lot_number}</TableCell>
                        <TableCell>{batch.recipe_name}</TableCell>
                        <TableCell>{new Date(batch.production_date).toLocaleDateString()}</TableCell>
                        <TableCell>{batch.quantity} {batch.unit}</TableCell>
                        <TableCell>{getStatusBadge(batch.status)}</TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            {batch.status === 'hold' && (
                              <Button
                                size="sm"
                                onClick={() => handleStatusChange(batch.id, 'release')}
                                disabled={loading}
                              >
                                <Play className="w-3 h-3 mr-1" />
                                Release
                              </Button>
                            )}
                            {batch.status === 'released' && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleStatusChange(batch.id, 'hold')}
                                disabled={loading}
                              >
                                <Pause className="w-3 h-3 mr-1" />
                                Hold
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

export default BatchManagement

