from flask import Blueprint, request, jsonify
from src.models.user import db, Batch, BatchIngredient, Recipe, User
from datetime import datetime, timedelta
from sqlalchemy import or_, and_

recall_bp = Blueprint('recall', __name__)

@recall_bp.route('/batches', methods=['GET'])
def get_batches():
    """Get batches with filtering and pagination"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 50, type=int)
        lot_number = request.args.get('lot_number')
        status = request.args.get('status')
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        query = Batch.query
        
        if lot_number:
            query = query.filter(Batch.lot_number.like(f'%{lot_number}%'))
        if status:
            query = query.filter(Batch.status == status)
        if start_date:
            query = query.filter(Batch.production_date >= datetime.fromisoformat(start_date).date())
        if end_date:
            query = query.filter(Batch.production_date <= datetime.fromisoformat(end_date).date())
            
        batches = query.order_by(Batch.production_date.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        result = []
        for batch in batches.items:
            result.append({
                'id': batch.id,
                'lot_number': batch.lot_number,
                'recipe_id': batch.recipe_id,
                'recipe_name': batch.recipe.name,
                'production_date': batch.production_date.isoformat(),
                'expiry_date': batch.expiry_date.isoformat() if batch.expiry_date else None,
                'quantity': batch.quantity,
                'unit': batch.unit,
                'status': batch.status,
                'created_by': batch.creator.username,
                'created_at': batch.created_at.isoformat()
            })
        
        return jsonify({
            'batches': result,
            'total': batches.total,
            'pages': batches.pages,
            'current_page': page
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@recall_bp.route('/batches/<int:batch_id>/hold', methods=['POST'])
def hold_batch():
    """Put a batch on hold"""
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        reason = data.get('reason', '')
        
        batch = Batch.query.get(batch_id)
        if not batch:
            return jsonify({'error': 'Batch not found'}), 404
        
        if batch.status == 'hold':
            return jsonify({'error': 'Batch is already on hold'}), 400
        
        batch.status = 'hold'
        db.session.commit()
        
        return jsonify({
            'message': f'Batch {batch.lot_number} placed on hold',
            'status': batch.status
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@recall_bp.route('/batches/<int:batch_id>/release', methods=['POST'])
def release_batch():
    """Release a batch from hold"""
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        reason = data.get('reason', '')
        
        batch = Batch.query.get(batch_id)
        if not batch:
            return jsonify({'error': 'Batch not found'}), 404
        
        if batch.status != 'hold':
            return jsonify({'error': 'Batch is not on hold'}), 400
        
        batch.status = 'released'
        db.session.commit()
        
        return jsonify({
            'message': f'Batch {batch.lot_number} released',
            'status': batch.status
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@recall_bp.route('/recall/forward', methods=['POST'])
def forward_recall_query():
    """Forward traceability - find where ingredients went"""
    try:
        data = request.get_json()
        ingredient_lot = data.get('ingredient_lot')
        supplier = data.get('supplier')
        
        if not ingredient_lot:
            return jsonify({'error': 'ingredient_lot is required'}), 400
        
        # Find all batches that used this ingredient lot
        query = db.session.query(Batch).join(BatchIngredient).filter(
            BatchIngredient.lot_number == ingredient_lot
        )
        
        if supplier:
            query = query.filter(BatchIngredient.supplier == supplier)
        
        affected_batches = query.all()
        
        result = []
        for batch in affected_batches:
            # Find the specific ingredient usage
            ingredient = BatchIngredient.query.filter_by(
                batch_id=batch.id,
                lot_number=ingredient_lot
            ).first()
            
            result.append({
                'batch_id': batch.id,
                'lot_number': batch.lot_number,
                'recipe_name': batch.recipe.name,
                'production_date': batch.production_date.isoformat(),
                'quantity': batch.quantity,
                'unit': batch.unit,
                'status': batch.status,
                'ingredient_name': ingredient.ingredient_name,
                'ingredient_quantity': ingredient.quantity,
                'ingredient_unit': ingredient.unit,
                'supplier': ingredient.supplier
            })
        
        return jsonify({
            'affected_batches': result,
            'total_batches': len(result),
            'query_time': datetime.utcnow().isoformat()
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@recall_bp.route('/recall/backward', methods=['POST'])
def backward_recall_query():
    """Backward traceability - find ingredient sources for a batch"""
    try:
        data = request.get_json()
        lot_number = data.get('lot_number')
        
        if not lot_number:
            return jsonify({'error': 'lot_number is required'}), 400
        
        # Find the batch
        batch = Batch.query.filter_by(lot_number=lot_number).first()
        if not batch:
            return jsonify({'error': 'Batch not found'}), 404
        
        # Get all ingredients for this batch
        ingredients = BatchIngredient.query.filter_by(batch_id=batch.id).all()
        
        result = {
            'batch_info': {
                'id': batch.id,
                'lot_number': batch.lot_number,
                'recipe_name': batch.recipe.name,
                'production_date': batch.production_date.isoformat(),
                'quantity': batch.quantity,
                'unit': batch.unit,
                'status': batch.status
            },
            'ingredients': []
        }
        
        for ingredient in ingredients:
            result['ingredients'].append({
                'ingredient_name': ingredient.ingredient_name,
                'supplier': ingredient.supplier,
                'lot_number': ingredient.lot_number,
                'quantity': ingredient.quantity,
                'unit': ingredient.unit
            })
        
        return jsonify({
            'traceability_data': result,
            'total_ingredients': len(ingredients),
            'query_time': datetime.utcnow().isoformat()
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@recall_bp.route('/recall/impact-analysis', methods=['POST'])
def recall_impact_analysis():
    """Comprehensive recall impact analysis"""
    try:
        data = request.get_json()
        ingredient_lot = data.get('ingredient_lot')
        supplier = data.get('supplier')
        date_range_start = data.get('date_range_start')
        date_range_end = data.get('date_range_end')
        
        if not ingredient_lot:
            return jsonify({'error': 'ingredient_lot is required'}), 400
        
        # Base query for affected batches
        query = db.session.query(Batch).join(BatchIngredient).filter(
            BatchIngredient.lot_number == ingredient_lot
        )
        
        if supplier:
            query = query.filter(BatchIngredient.supplier == supplier)
        
        if date_range_start:
            query = query.filter(Batch.production_date >= datetime.fromisoformat(date_range_start).date())
        
        if date_range_end:
            query = query.filter(Batch.production_date <= datetime.fromisoformat(date_range_end).date())
        
        affected_batches = query.all()
        
        # Calculate impact metrics
        total_quantity = sum(batch.quantity for batch in affected_batches)
        status_counts = {}
        recipe_counts = {}
        
        for batch in affected_batches:
            status_counts[batch.status] = status_counts.get(batch.status, 0) + 1
            recipe_name = batch.recipe.name
            recipe_counts[recipe_name] = recipe_counts.get(recipe_name, 0) + 1
        
        # Prepare detailed batch list
        batch_details = []
        for batch in affected_batches:
            batch_details.append({
                'lot_number': batch.lot_number,
                'recipe_name': batch.recipe.name,
                'production_date': batch.production_date.isoformat(),
                'quantity': batch.quantity,
                'unit': batch.unit,
                'status': batch.status,
                'expiry_date': batch.expiry_date.isoformat() if batch.expiry_date else None
            })
        
        return jsonify({
            'impact_summary': {
                'total_affected_batches': len(affected_batches),
                'total_quantity_affected': total_quantity,
                'status_breakdown': status_counts,
                'recipe_breakdown': recipe_counts,
                'analysis_date': datetime.utcnow().isoformat()
            },
            'affected_batches': batch_details,
            'search_criteria': {
                'ingredient_lot': ingredient_lot,
                'supplier': supplier,
                'date_range_start': date_range_start,
                'date_range_end': date_range_end
            }
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

