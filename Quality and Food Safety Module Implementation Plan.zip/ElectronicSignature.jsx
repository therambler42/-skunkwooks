import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog.jsx'
import { Alert, AlertDescription } from '@/components/ui/alert.jsx'
import { PenTool, Lock, User, Clock } from 'lucide-react'

function ElectronicSignature({ user, data, onComplete, onCancel }) {
  const [password, setPassword] = useState('')
  const [meaning, setMeaning] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')

    if (!password || !meaning) {
      setError('Password and signature meaning are required')
      return
    }

    setLoading(true)

    try {
      // Create signature data for 21 CFR Part 11 compliance
      const timestamp = new Date().toISOString()
      const signatureData = {
        user_id: user.id,
        username: user.username,
        timestamp: timestamp,
        meaning: meaning,
        data_signed: JSON.stringify(data),
        ip_address: 'client_ip', // Would be captured from request in real implementation
        password_hash: btoa(password) // In real implementation, this would be properly hashed
      }

      // Simulate password verification delay
      await new Promise(resolve => setTimeout(resolve, 1000))

      onComplete(signatureData)
    } catch (error) {
      setError('Signature failed: ' + error.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={true} onOpenChange={() => !loading && onCancel()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <PenTool className="h-5 w-5 mr-2" />
            Electronic Signature Required
          </DialogTitle>
          <DialogDescription>
            21 CFR Part 11 compliant electronic signature for CCP log entry
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* User Information */}
          <div className="p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center space-x-2 text-sm">
              <User className="h-4 w-4" />
              <span className="font-medium">{user.username}</span>
              <span className="text-gray-500">({user.role})</span>
            </div>
            <div className="flex items-center space-x-2 text-sm text-gray-500 mt-1">
              <Clock className="h-4 w-4" />
              <span>{new Date().toLocaleString()}</span>
            </div>
          </div>

          {/* Data Being Signed */}
          <div className="p-3 bg-blue-50 rounded-lg">
            <h4 className="font-medium text-blue-900 mb-2">Data to be signed:</h4>
            <div className="text-sm text-blue-700 space-y-1">
              <div>Lot Number: {data.lot_number}</div>
              <div>Measured Value: {data.log_value}</div>
              {data.notes && <div>Notes: {data.notes}</div>}
            </div>
          </div>

          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="meaning">Signature Meaning *</Label>
              <Textarea
                id="meaning"
                value={meaning}
                onChange={(e) => setMeaning(e.target.value)}
                placeholder="I certify that this CCP measurement is accurate and was performed according to established procedures..."
                rows={3}
                required
              />
              <p className="text-xs text-gray-500 mt-1">
                Describe the meaning of your signature for this action
              </p>
            </div>

            <div>
              <Label htmlFor="password">Password *</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password to sign"
                required
              />
              <div className="flex items-center mt-1 text-xs text-gray-500">
                <Lock className="h-3 w-3 mr-1" />
                Your password verifies your identity for this signature
              </div>
            </div>

            <div className="flex space-x-2 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={onCancel}
                disabled={loading}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={loading}
                className="flex-1"
              >
                {loading ? 'Signing...' : 'Sign Document'}
              </Button>
            </div>
          </form>

          <div className="text-xs text-gray-500 p-3 bg-yellow-50 rounded-lg">
            <strong>21 CFR Part 11 Notice:</strong> This electronic signature has the same legal 
            significance as a handwritten signature. By signing, you agree that this record 
            is authentic and accurate.
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

export default ElectronicSignature

