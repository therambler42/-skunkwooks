from flask import Blueprint, request, jsonify
from src.models.user import db, CCPLog, CriticalControlPoint, Recipe, User, AuditLog, create_signature_hash
from datetime import datetime
import json

ccp_bp = Blueprint('ccp', __name__)

@ccp_bp.route('/ccp/logs', methods=['GET'])
def get_ccp_logs():
    """Get CCP logs with filtering options"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 50, type=int)
        lot_number = request.args.get('lot_number')
        recipe_id = request.args.get('recipe_id', type=int)
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        query = CCPLog.query
        
        if lot_number:
            query = query.filter(CCPLog.lot_number.like(f'%{lot_number}%'))
        if recipe_id:
            query = query.filter(CCPLog.recipe_id == recipe_id)
        if start_date:
            query = query.filter(CCPLog.timestamp >= datetime.fromisoformat(start_date))
        if end_date:
            query = query.filter(CCPLog.timestamp <= datetime.fromisoformat(end_date))
            
        logs = query.order_by(CCPLog.timestamp.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        result = []
        for log in logs.items:
            result.append({
                'id': log.id,
                'ccp_id': log.ccp_id,
                'recipe_id': log.recipe_id,
                'lot_number': log.lot_number,
                'log_value': log.log_value,
                'user_id': log.user_id,
                'username': log.user.username,
                'timestamp': log.timestamp.isoformat(),
                'status': log.status,
                'notes': log.notes,
                'ccp_step': log.ccp.step,
                'critical_limit_min': log.ccp.critical_limit_min,
                'critical_limit_max': log.ccp.critical_limit_max,
                'unit': log.ccp.unit
            })
        
        return jsonify({
            'logs': result,
            'total': logs.total,
            'pages': logs.pages,
            'current_page': page
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@ccp_bp.route('/ccp/logs', methods=['POST'])
def create_ccp_log():
    """Create a new CCP log entry with electronic signature"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['ccp_id', 'recipe_id', 'lot_number', 'log_value', 'user_id', 'signature_data']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Get CCP to validate limits
        ccp = CriticalControlPoint.query.get(data['ccp_id'])
        if not ccp:
            return jsonify({'error': 'CCP not found'}), 404
        
        # Determine status based on critical limits
        log_value = float(data['log_value'])
        status = 'in_spec'
        
        if ccp.critical_limit_min is not None and log_value < ccp.critical_limit_min:
            status = 'out_of_spec'
        elif ccp.critical_limit_max is not None and log_value > ccp.critical_limit_max:
            status = 'out_of_spec'
        
        # Create signature hash for 21 CFR Part 11 compliance
        timestamp = datetime.utcnow()
        signature_hash = create_signature_hash(
            data['user_id'], 
            timestamp, 
            json.dumps(data['signature_data'])
        )
        
        # Create CCP log entry
        ccp_log = CCPLog(
            ccp_id=data['ccp_id'],
            recipe_id=data['recipe_id'],
            lot_number=data['lot_number'],
            log_value=log_value,
            user_id=data['user_id'],
            timestamp=timestamp,
            status=status,
            notes=data.get('notes', ''),
            signature_hash=signature_hash
        )
        
        db.session.add(ccp_log)
        
        # Create audit log entry
        audit_log = AuditLog(
            user_id=data['user_id'],
            action='CREATE',
            table_name='ccp_logs',
            record_id=0,  # Will be updated after commit
            new_values=json.dumps({
                'ccp_id': data['ccp_id'],
                'recipe_id': data['recipe_id'],
                'lot_number': data['lot_number'],
                'log_value': log_value,
                'status': status
            }),
            signature_hash=signature_hash,
            timestamp=timestamp,
            ip_address=request.remote_addr
        )
        
        db.session.add(audit_log)
        db.session.commit()
        
        # Update audit log with actual record ID
        audit_log.record_id = ccp_log.id
        db.session.commit()
        
        return jsonify({
            'id': ccp_log.id,
            'status': status,
            'signature_hash': signature_hash,
            'message': 'CCP log created successfully'
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@ccp_bp.route('/ccp/points', methods=['GET'])
def get_ccp_points():
    """Get all critical control points"""
    try:
        recipe_id = request.args.get('recipe_id', type=int)
        
        query = CriticalControlPoint.query
        if recipe_id:
            query = query.filter(CriticalControlPoint.recipe_id == recipe_id)
        
        ccps = query.all()
        
        result = []
        for ccp in ccps:
            result.append({
                'id': ccp.id,
                'recipe_id': ccp.recipe_id,
                'recipe_name': ccp.recipe.name,
                'step': ccp.step,
                'critical_limit_min': ccp.critical_limit_min,
                'critical_limit_max': ccp.critical_limit_max,
                'unit': ccp.unit,
                'monitoring_frequency': ccp.monitoring_frequency,
                'corrective_action': ccp.corrective_action
            })
        
        return jsonify({'ccps': result})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@ccp_bp.route('/ccp/points', methods=['POST'])
def create_ccp_point():
    """Create a new critical control point"""
    try:
        data = request.get_json()
        
        required_fields = ['recipe_id', 'step']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        ccp = CriticalControlPoint(
            recipe_id=data['recipe_id'],
            step=data['step'],
            critical_limit_min=data.get('critical_limit_min'),
            critical_limit_max=data.get('critical_limit_max'),
            unit=data.get('unit'),
            monitoring_frequency=data.get('monitoring_frequency'),
            corrective_action=data.get('corrective_action')
        )
        
        db.session.add(ccp)
        db.session.commit()
        
        return jsonify({
            'id': ccp.id,
            'message': 'CCP created successfully'
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@ccp_bp.route('/recipes', methods=['GET'])
def get_recipes():
    """Get all recipes"""
    try:
        recipes = Recipe.query.filter(Recipe.is_active == True).all()
        
        result = []
        for recipe in recipes:
            result.append({
                'id': recipe.id,
                'name': recipe.name,
                'description': recipe.description,
                'version': recipe.version,
                'created_at': recipe.created_at.isoformat()
            })
        
        return jsonify({'recipes': result})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

