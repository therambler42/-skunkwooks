import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Alert, AlertDescription } from '@/components/ui/alert.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table.jsx'
import { Search, ArrowRight, ArrowLeft, Download, Clock } from 'lucide-react'

const API_BASE = 'http://localhost:5001/api'

function RecallQuery() {
  const [forwardQuery, setForwardQuery] = useState({
    ingredient_lot: '',
    supplier: ''
  })
  const [backwardQuery, setBackwardQuery] = useState({
    lot_number: ''
  })
  const [impactQuery, setImpactQuery] = useState({
    ingredient_lot: '',
    supplier: '',
    date_range_start: '',
    date_range_end: ''
  })
  
  const [forwardResults, setForwardResults] = useState(null)
  const [backwardResults, setBackwardResults] = useState(null)
  const [impactResults, setImpactResults] = useState(null)
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState('')
  const [queryTime, setQueryTime] = useState(null)

  const handleForwardQuery = async (e) => {
    e.preventDefault()
    if (!forwardQuery.ingredient_lot) {
      setMessage('Ingredient lot number is required')
      return
    }

    setLoading(true)
    setMessage('')
    const startTime = Date.now()

    try {
      const response = await fetch(`${API_BASE}/recall/forward`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(forwardQuery)
      })

      const data = await response.json()
      const endTime = Date.now()
      setQueryTime(endTime - startTime)

      if (response.ok) {
        setForwardResults(data)
        setMessage(`Found ${data.total_batches} affected batches in ${endTime - startTime}ms`)
      } else {
        setMessage(`Error: ${data.error}`)
      }
    } catch (error) {
      setMessage(`Error: ${error.message}`)
    } finally {
      setLoading(false)
    }
  }

  const handleBackwardQuery = async (e) => {
    e.preventDefault()
    if (!backwardQuery.lot_number) {
      setMessage('Lot number is required')
      return
    }

    setLoading(true)
    setMessage('')
    const startTime = Date.now()

    try {
      const response = await fetch(`${API_BASE}/recall/backward`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(backwardQuery)
      })

      const data = await response.json()
      const endTime = Date.now()
      setQueryTime(endTime - startTime)

      if (response.ok) {
        setBackwardResults(data)
        setMessage(`Found ${data.total_ingredients} ingredients in ${endTime - startTime}ms`)
      } else {
        setMessage(`Error: ${data.error}`)
      }
    } catch (error) {
      setMessage(`Error: ${error.message}`)
    } finally {
      setLoading(false)
    }
  }

  const handleImpactAnalysis = async (e) => {
    e.preventDefault()
    if (!impactQuery.ingredient_lot) {
      setMessage('Ingredient lot number is required')
      return
    }

    setLoading(true)
    setMessage('')
    const startTime = Date.now()

    try {
      const response = await fetch(`${API_BASE}/recall/impact-analysis`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(impactQuery)
      })

      const data = await response.json()
      const endTime = Date.now()
      setQueryTime(endTime - startTime)

      if (response.ok) {
        setImpactResults(data)
        setMessage(`Impact analysis completed in ${endTime - startTime}ms`)
      } else {
        setMessage(`Error: ${data.error}`)
      }
    } catch (error) {
      setMessage(`Error: ${error.message}`)
    } finally {
      setLoading(false)
    }
  }

  const exportFDAForm = async () => {
    if (!impactResults) {
      setMessage('No impact analysis data available for export')
      return
    }

    try {
      const formData = {
        company_name: 'Food Safety Company', // Would come from user settings
        contact_person: 'Quality Manager',
        phone: '555-0123',
        email: 'quality@company.com',
        product_name: 'Multiple Products',
        lot_numbers: impactResults.affected_batches.map(batch => batch.lot_number),
        reason_for_recall: `Ingredient lot ${impactQuery.ingredient_lot} quality issue`,
        distribution_pattern: 'Regional distribution',
        quantity_distributed: `${impactResults.impact_summary.total_quantity_affected} units`,
        affected_batches: impactResults.affected_batches,
        health_hazard_class: 'Class II',
        corrective_action: 'Product recall and customer notification'
      }

      const response = await fetch(`${API_BASE}/recall/fda-form-3911`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData)
      })

      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.style.display = 'none'
        a.href = url
        a.download = `FDA_Form_3911_${new Date().toISOString().split('T')[0]}.pdf`
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        setMessage('FDA Form 3911 exported successfully')
      } else {
        setMessage('Error exporting FDA Form 3911')
      }
    } catch (error) {
      setMessage(`Error: ${error.message}`)
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-gray-900">Recall Query & Traceability</h2>
        <p className="text-gray-600 mt-2">
          Forward/backward traceability and recall impact analysis with performance optimization
        </p>
      </div>

      {message && (
        <Alert>
          <AlertDescription className="flex items-center">
            {queryTime && <Clock className="w-4 h-4 mr-2" />}
            {message}
          </AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="forward" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="forward">Forward Traceability</TabsTrigger>
          <TabsTrigger value="backward">Backward Traceability</TabsTrigger>
          <TabsTrigger value="impact">Impact Analysis</TabsTrigger>
        </TabsList>

        {/* Forward Traceability */}
        <TabsContent value="forward" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <ArrowRight className="h-5 w-5 mr-2" />
                Forward Traceability
              </CardTitle>
              <CardDescription>
                Find where ingredients went - trace from ingredient lot to finished products
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleForwardQuery} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="ingredient_lot">Ingredient Lot Number *</Label>
                    <Input
                      id="ingredient_lot"
                      value={forwardQuery.ingredient_lot}
                      onChange={(e) => setForwardQuery({...forwardQuery, ingredient_lot: e.target.value})}
                      placeholder="Enter ingredient lot number"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="supplier">Supplier (Optional)</Label>
                    <Input
                      id="supplier"
                      value={forwardQuery.supplier}
                      onChange={(e) => setForwardQuery({...forwardQuery, supplier: e.target.value})}
                      placeholder="Enter supplier name"
                    />
                  </div>
                </div>
                <Button type="submit" disabled={loading}>
                  <Search className="w-4 h-4 mr-2" />
                  {loading ? 'Searching...' : 'Trace Forward'}
                </Button>
              </form>

              {forwardResults && (
                <div className="mt-6 space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="text-lg font-semibold">Affected Batches</h3>
                    <Badge variant="outline">
                      {forwardResults.total_batches} batches found
                    </Badge>
                  </div>
                  
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Lot Number</TableHead>
                        <TableHead>Recipe</TableHead>
                        <TableHead>Production Date</TableHead>
                        <TableHead>Quantity</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Ingredient Used</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {forwardResults.affected_batches.map((batch, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-medium">{batch.lot_number}</TableCell>
                          <TableCell>{batch.recipe_name}</TableCell>
                          <TableCell>{new Date(batch.production_date).toLocaleDateString()}</TableCell>
                          <TableCell>{batch.quantity} {batch.unit}</TableCell>
                          <TableCell>
                            <Badge variant={batch.status === 'released' ? 'default' : 'secondary'}>
                              {batch.status}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {batch.ingredient_quantity} {batch.ingredient_unit} of {batch.ingredient_name}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Backward Traceability */}
        <TabsContent value="backward" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <ArrowLeft className="h-5 w-5 mr-2" />
                Backward Traceability
              </CardTitle>
              <CardDescription>
                Find ingredient sources - trace from finished product to raw materials
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleBackwardQuery} className="space-y-4">
                <div>
                  <Label htmlFor="lot_number">Finished Product Lot Number *</Label>
                  <Input
                    id="lot_number"
                    value={backwardQuery.lot_number}
                    onChange={(e) => setBackwardQuery({...backwardQuery, lot_number: e.target.value})}
                    placeholder="Enter finished product lot number"
                    required
                  />
                </div>
                <Button type="submit" disabled={loading}>
                  <Search className="w-4 h-4 mr-2" />
                  {loading ? 'Searching...' : 'Trace Backward'}
                </Button>
              </form>

              {backwardResults && (
                <div className="mt-6 space-y-4">
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <h3 className="text-lg font-semibold text-blue-900">Batch Information</h3>
                    <div className="grid grid-cols-2 gap-4 mt-2 text-sm">
                      <div>
                        <span className="font-medium">Lot Number:</span> {backwardResults.traceability_data.batch_info.lot_number}
                      </div>
                      <div>
                        <span className="font-medium">Recipe:</span> {backwardResults.traceability_data.batch_info.recipe_name}
                      </div>
                      <div>
                        <span className="font-medium">Production Date:</span> {new Date(backwardResults.traceability_data.batch_info.production_date).toLocaleDateString()}
                      </div>
                      <div>
                        <span className="font-medium">Quantity:</span> {backwardResults.traceability_data.batch_info.quantity} {backwardResults.traceability_data.batch_info.unit}
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold">Ingredient Sources</h3>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Ingredient</TableHead>
                          <TableHead>Supplier</TableHead>
                          <TableHead>Lot Number</TableHead>
                          <TableHead>Quantity Used</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {backwardResults.traceability_data.ingredients.map((ingredient, index) => (
                          <TableRow key={index}>
                            <TableCell className="font-medium">{ingredient.ingredient_name}</TableCell>
                            <TableCell>{ingredient.supplier}</TableCell>
                            <TableCell>{ingredient.lot_number}</TableCell>
                            <TableCell>{ingredient.quantity} {ingredient.unit}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Impact Analysis */}
        <TabsContent value="impact" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Search className="h-5 w-5 mr-2" />
                Recall Impact Analysis
              </CardTitle>
              <CardDescription>
                Comprehensive analysis of recall impact with FDA Form 3911 export
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleImpactAnalysis} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="impact_ingredient_lot">Ingredient Lot Number *</Label>
                    <Input
                      id="impact_ingredient_lot"
                      value={impactQuery.ingredient_lot}
                      onChange={(e) => setImpactQuery({...impactQuery, ingredient_lot: e.target.value})}
                      placeholder="Enter ingredient lot number"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="impact_supplier">Supplier (Optional)</Label>
                    <Input
                      id="impact_supplier"
                      value={impactQuery.supplier}
                      onChange={(e) => setImpactQuery({...impactQuery, supplier: e.target.value})}
                      placeholder="Enter supplier name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="date_range_start">Start Date (Optional)</Label>
                    <Input
                      id="date_range_start"
                      type="date"
                      value={impactQuery.date_range_start}
                      onChange={(e) => setImpactQuery({...impactQuery, date_range_start: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="date_range_end">End Date (Optional)</Label>
                    <Input
                      id="date_range_end"
                      type="date"
                      value={impactQuery.date_range_end}
                      onChange={(e) => setImpactQuery({...impactQuery, date_range_end: e.target.value})}
                    />
                  </div>
                </div>
                <div className="flex space-x-2">
                  <Button type="submit" disabled={loading}>
                    <Search className="w-4 h-4 mr-2" />
                    {loading ? 'Analyzing...' : 'Analyze Impact'}
                  </Button>
                  {impactResults && (
                    <Button type="button" variant="outline" onClick={() => exportFDAForm()}>
                      <Download className="w-4 h-4 mr-2" />
                      Export FDA Form 3911
                    </Button>
                  )}
                </div>
              </form>

              {impactResults && (
                <div className="mt-6 space-y-4">
                  {/* Impact Summary */}
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <Card>
                      <CardContent className="pt-6">
                        <div className="text-2xl font-bold">{impactResults.impact_summary.total_affected_batches}</div>
                        <p className="text-xs text-muted-foreground">Affected Batches</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="pt-6">
                        <div className="text-2xl font-bold">{impactResults.impact_summary.total_quantity_affected}</div>
                        <p className="text-xs text-muted-foreground">Total Quantity</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="pt-6">
                        <div className="text-2xl font-bold">{Object.keys(impactResults.impact_summary.recipe_breakdown).length}</div>
                        <p className="text-xs text-muted-foreground">Recipes Affected</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="pt-6">
                        <div className="text-2xl font-bold">{impactResults.impact_summary.status_breakdown.released || 0}</div>
                        <p className="text-xs text-muted-foreground">Released Batches</p>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Status Breakdown */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Card>
                      <CardHeader>
                        <CardTitle>Status Breakdown</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          {Object.entries(impactResults.impact_summary.status_breakdown).map(([status, count]) => (
                            <div key={status} className="flex justify-between">
                              <span className="capitalize">{status.replace('_', ' ')}</span>
                              <Badge variant="outline">{count}</Badge>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle>Recipe Breakdown</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          {Object.entries(impactResults.impact_summary.recipe_breakdown).map(([recipe, count]) => (
                            <div key={recipe} className="flex justify-between">
                              <span className="truncate">{recipe}</span>
                              <Badge variant="outline">{count}</Badge>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Affected Batches Table */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Affected Batches Detail</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Lot Number</TableHead>
                            <TableHead>Recipe</TableHead>
                            <TableHead>Production Date</TableHead>
                            <TableHead>Quantity</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Expiry Date</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {impactResults.affected_batches.map((batch, index) => (
                            <TableRow key={index}>
                              <TableCell className="font-medium">{batch.lot_number}</TableCell>
                              <TableCell>{batch.recipe_name}</TableCell>
                              <TableCell>{new Date(batch.production_date).toLocaleDateString()}</TableCell>
                              <TableCell>{batch.quantity} {batch.unit}</TableCell>
                              <TableCell>
                                <Badge variant={batch.status === 'released' ? 'default' : 'secondary'}>
                                  {batch.status}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                {batch.expiry_date ? new Date(batch.expiry_date).toLocaleDateString() : 'N/A'}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </CardContent>
                  </Card>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

export default RecallQuery

