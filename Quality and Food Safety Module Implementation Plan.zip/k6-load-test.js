import http from 'k6/http';
import { check, sleep } from 'k6';
import { Rate } from 'k6/metrics';

// Custom metrics
const errorRate = new Rate('errors');

export const options = {
  stages: [
    { duration: '30s', target: 10 },  // Ramp up to 10 users
    { duration: '1m', target: 20 },   // Stay at 20 users
    { duration: '30s', target: 50 },  // Ramp up to 50 users
    { duration: '2m', target: 50 },   // Stay at 50 users
    { duration: '30s', target: 0 },   // Ramp down
  ],
  thresholds: {
    http_req_duration: ['p(95)<2000'], // 95% of requests must complete below 2s
    errors: ['rate<0.1'], // Error rate must be below 10%
  },
};

const BASE_URL = 'http://localhost:5001/api';

// Sample ingredient lots for testing
const ingredientLots = [
  'ING1234', 'ING5678', 'ING9012', 'ING3456', 'ING7890',
  'ING2468', 'ING1357', 'ING8642', 'ING9753', 'ING1111'
];

// Sample lot numbers for testing
const lotNumbers = [
  'LOT001000', 'LOT002000', 'LOT003000', 'LOT004000', 'LOT005000',
  'LOT006000', 'LOT007000', 'LOT008000', 'LOT009000', 'LOT010000'
];

export default function () {
  // Test forward traceability
  const forwardPayload = JSON.stringify({
    ingredient_lot: ingredientLots[Math.floor(Math.random() * ingredientLots.length)],
    supplier: 'Supplier A'
  });

  const forwardResponse = http.post(`${BASE_URL}/recall/forward`, forwardPayload, {
    headers: { 'Content-Type': 'application/json' },
  });

  check(forwardResponse, {
    'forward query status is 200': (r) => r.status === 200,
    'forward query response time < 2s': (r) => r.timings.duration < 2000,
    'forward query has affected_batches': (r) => {
      try {
        const body = JSON.parse(r.body);
        return body.hasOwnProperty('affected_batches');
      } catch (e) {
        return false;
      }
    },
  }) || errorRate.add(1);

  sleep(1);

  // Test backward traceability
  const backwardPayload = JSON.stringify({
    lot_number: lotNumbers[Math.floor(Math.random() * lotNumbers.length)]
  });

  const backwardResponse = http.post(`${BASE_URL}/recall/backward`, backwardPayload, {
    headers: { 'Content-Type': 'application/json' },
  });

  check(backwardResponse, {
    'backward query status is 200': (r) => r.status === 200,
    'backward query response time < 2s': (r) => r.timings.duration < 2000,
    'backward query has traceability_data': (r) => {
      try {
        const body = JSON.parse(r.body);
        return body.hasOwnProperty('traceability_data');
      } catch (e) {
        return false;
      }
    },
  }) || errorRate.add(1);

  sleep(1);

  // Test impact analysis
  const impactPayload = JSON.stringify({
    ingredient_lot: ingredientLots[Math.floor(Math.random() * ingredientLots.length)],
    supplier: 'Supplier B',
    date_range_start: '2024-01-01',
    date_range_end: '2025-12-31'
  });

  const impactResponse = http.post(`${BASE_URL}/recall/impact-analysis`, impactPayload, {
    headers: { 'Content-Type': 'application/json' },
  });

  check(impactResponse, {
    'impact analysis status is 200': (r) => r.status === 200,
    'impact analysis response time < 2s': (r) => r.timings.duration < 2000,
    'impact analysis has summary': (r) => {
      try {
        const body = JSON.parse(r.body);
        return body.hasOwnProperty('impact_summary');
      } catch (e) {
        return false;
      }
    },
  }) || errorRate.add(1);

  sleep(1);

  // Test batch listing
  const batchResponse = http.get(`${BASE_URL}/batches?per_page=50`);

  check(batchResponse, {
    'batch listing status is 200': (r) => r.status === 200,
    'batch listing response time < 2s': (r) => r.timings.duration < 2000,
    'batch listing has batches': (r) => {
      try {
        const body = JSON.parse(r.body);
        return body.hasOwnProperty('batches') && Array.isArray(body.batches);
      } catch (e) {
        return false;
      }
    },
  }) || errorRate.add(1);

  sleep(1);
}

