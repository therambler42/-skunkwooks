# Test Configuration
import os
import sys

# Add the project root to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Test imports
try:
    from src.models.user import User, Recipe, Batch
    from src.main import app
    print("✓ All imports successful")
    print("✓ Test environment ready")
except ImportError as e:
    print(f"✗ Import error: {e}")
    sys.exit(1)

