import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Alert, AlertDescription } from '@/components/ui/alert.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Shield, FileText, Download, Eye, CheckCircle } from 'lucide-react'

const API_BASE = 'http://localhost:5001/api'

function AuditLogs() {
  const [auditLogs, setAuditLogs] = useState([])
  const [complianceReport, setComplianceReport] = useState(null)
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState('')
  const [filters, setFilters] = useState({
    user_id: '',
    action: '',
    table_name: '',
    start_date: '',
    end_date: ''
  })
  const [reportDates, setReportDates] = useState({
    start_date: '',
    end_date: ''
  })

  useEffect(() => {
    fetchAuditLogs()
  }, [filters])

  const fetchAuditLogs = async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      Object.entries(filters).forEach(([key, value]) => {
        if (value) params.append(key, value)
      })

      const response = await fetch(`${API_BASE}/audit/logs?${params}`)
      const data = await response.json()
      setAuditLogs(data.audit_logs || [])
    } catch (error) {
      console.error('Error fetching audit logs:', error)
      setMessage('Error fetching audit logs')
    } finally {
      setLoading(false)
    }
  }

  const generateComplianceReport = async () => {
    if (!reportDates.start_date || !reportDates.end_date) {
      setMessage('Please select start and end dates for the compliance report')
      return
    }

    setLoading(true)
    try {
      const params = new URLSearchParams({
        start_date: reportDates.start_date,
        end_date: reportDates.end_date
      })

      const response = await fetch(`${API_BASE}/audit/compliance-report?${params}`)
      const data = await response.json()
      
      if (response.ok) {
        setComplianceReport(data)
        setMessage('Compliance report generated successfully')
      } else {
        setMessage(`Error: ${data.error}`)
      }
    } catch (error) {
      setMessage(`Error: ${error.message}`)
    } finally {
      setLoading(false)
    }
  }

  const verifySignature = async (signatureHash) => {
    try {
      const response = await fetch(`${API_BASE}/audit/signature/verify`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ signature_hash: signatureHash })
      })

      const data = await response.json()
      
      if (response.ok) {
        if (data.valid) {
          setMessage(`Signature verified: ${data.audit_log.username} at ${new Date(data.audit_log.timestamp).toLocaleString()}`)
        } else {
          setMessage('Signature verification failed: ' + data.message)
        }
      } else {
        setMessage(`Error: ${data.error}`)
      }
    } catch (error) {
      setMessage(`Error: ${error.message}`)
    }
  }

  const getActionBadge = (action) => {
    const colors = {
      'CREATE': 'bg-green-100 text-green-800',
      'UPDATE': 'bg-blue-100 text-blue-800',
      'DELETE': 'bg-red-100 text-red-800',
      'READ': 'bg-gray-100 text-gray-800'
    }
    return (
      <Badge className={colors[action] || 'bg-gray-100 text-gray-800'}>
        {action}
      </Badge>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-gray-900">Audit Logs & Compliance</h2>
        <p className="text-gray-600 mt-2">
          View audit trail and compliance reporting (21 CFR Part 11)
        </p>
      </div>

      {message && (
        <Alert>
          <AlertDescription>{message}</AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="logs" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="logs">Audit Logs</TabsTrigger>
          <TabsTrigger value="compliance">Compliance Report</TabsTrigger>
          <TabsTrigger value="verification">Signature Verification</TabsTrigger>
        </TabsList>

        {/* Audit Logs */}
        <TabsContent value="logs" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <FileText className="h-5 w-5 mr-2" />
                Audit Trail
              </CardTitle>
              <CardDescription>
                Complete audit trail of all system activities
              </CardDescription>
            </CardHeader>
            <CardContent>
              {/* Filters */}
              <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
                <div>
                  <Label htmlFor="action">Action</Label>
                  <Select value={filters.action} onValueChange={(value) => setFilters({...filters, action: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="All actions" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">All actions</SelectItem>
                      <SelectItem value="CREATE">Create</SelectItem>
                      <SelectItem value="UPDATE">Update</SelectItem>
                      <SelectItem value="DELETE">Delete</SelectItem>
                      <SelectItem value="READ">Read</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="table_name">Table</Label>
                  <Select value={filters.table_name} onValueChange={(value) => setFilters({...filters, table_name: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="All tables" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">All tables</SelectItem>
                      <SelectItem value="ccp_logs">CCP Logs</SelectItem>
                      <SelectItem value="batches">Batches</SelectItem>
                      <SelectItem value="users">Users</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="start_date">Start Date</Label>
                  <Input
                    id="start_date"
                    type="date"
                    value={filters.start_date}
                    onChange={(e) => setFilters({...filters, start_date: e.target.value})}
                  />
                </div>

                <div>
                  <Label htmlFor="end_date">End Date</Label>
                  <Input
                    id="end_date"
                    type="date"
                    value={filters.end_date}
                    onChange={(e) => setFilters({...filters, end_date: e.target.value})}
                  />
                </div>

                <div className="flex items-end">
                  <Button 
                    onClick={() => setFilters({ user_id: '', action: '', table_name: '', start_date: '', end_date: '' })}
                    variant="outline"
                    className="w-full"
                  >
                    Clear Filters
                  </Button>
                </div>
              </div>

              {/* Audit Logs Table */}
              {loading ? (
                <div className="text-center py-4">Loading audit logs...</div>
              ) : auditLogs.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No audit logs found matching the current filters
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Timestamp</TableHead>
                      <TableHead>User</TableHead>
                      <TableHead>Action</TableHead>
                      <TableHead>Table</TableHead>
                      <TableHead>Record ID</TableHead>
                      <TableHead>Signature</TableHead>
                      <TableHead>IP Address</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {auditLogs.map(log => (
                      <TableRow key={log.id}>
                        <TableCell className="text-sm">
                          {new Date(log.timestamp).toLocaleString()}
                        </TableCell>
                        <TableCell className="font-medium">{log.username}</TableCell>
                        <TableCell>{getActionBadge(log.action)}</TableCell>
                        <TableCell>{log.table_name}</TableCell>
                        <TableCell>{log.record_id}</TableCell>
                        <TableCell>
                          {log.signature_hash ? (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => verifySignature(log.signature_hash)}
                            >
                              <Shield className="w-3 h-3 mr-1" />
                              Verify
                            </Button>
                          ) : (
                            <span className="text-gray-400">No signature</span>
                          )}
                        </TableCell>
                        <TableCell className="text-sm text-gray-500">{log.ip_address}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Compliance Report */}
        <TabsContent value="compliance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <CheckCircle className="h-5 w-5 mr-2" />
                21 CFR Part 11 Compliance Report
              </CardTitle>
              <CardDescription>
                Generate compliance reports for regulatory audits
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="report_start_date">Report Start Date</Label>
                    <Input
                      id="report_start_date"
                      type="date"
                      value={reportDates.start_date}
                      onChange={(e) => setReportDates({...reportDates, start_date: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="report_end_date">Report End Date</Label>
                    <Input
                      id="report_end_date"
                      type="date"
                      value={reportDates.end_date}
                      onChange={(e) => setReportDates({...reportDates, end_date: e.target.value})}
                    />
                  </div>
                  <div className="flex items-end">
                    <Button onClick={generateComplianceReport} disabled={loading} className="w-full">
                      <FileText className="w-4 h-4 mr-2" />
                      Generate Report
                    </Button>
                  </div>
                </div>

                {complianceReport && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <Card>
                        <CardContent className="pt-6">
                          <div className="text-2xl font-bold">{complianceReport.compliance_summary.total_actions}</div>
                          <p className="text-xs text-muted-foreground">Total Actions</p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="pt-6">
                          <div className="text-2xl font-bold">{complianceReport.compliance_summary.signed_actions}</div>
                          <p className="text-xs text-muted-foreground">Signed Actions</p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="pt-6">
                          <div className="text-2xl font-bold">
                            {complianceReport.compliance_summary.signature_compliance_rate.toFixed(1)}%
                          </div>
                          <p className="text-xs text-muted-foreground">Compliance Rate</p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="pt-6">
                          <div className="text-2xl font-bold">{complianceReport.compliance_summary.unique_users}</div>
                          <p className="text-xs text-muted-foreground">Active Users</p>
                        </CardContent>
                      </Card>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Card>
                        <CardHeader>
                          <CardTitle>Action Breakdown</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            {Object.entries(complianceReport.compliance_summary.action_breakdown).map(([action, count]) => (
                              <div key={action} className="flex justify-between">
                                <span>{action}</span>
                                <Badge variant="outline">{count}</Badge>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader>
                          <CardTitle>Table Activity</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            {Object.entries(complianceReport.compliance_summary.table_breakdown).map(([table, count]) => (
                              <div key={table} className="flex justify-between">
                                <span>{table}</span>
                                <Badge variant="outline">{count}</Badge>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    </div>

                    <div className="flex justify-end">
                      <Button variant="outline">
                        <Download className="w-4 h-4 mr-2" />
                        Export Report
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Signature Verification */}
        <TabsContent value="verification" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Shield className="h-5 w-5 mr-2" />
                Electronic Signature Verification
              </CardTitle>
              <CardDescription>
                Verify the authenticity of electronic signatures
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 bg-blue-50 rounded-lg">
                  <h4 className="font-medium text-blue-900 mb-2">How to verify signatures:</h4>
                  <ol className="text-sm text-blue-700 space-y-1 list-decimal list-inside">
                    <li>Find the signature hash from the audit logs table above</li>
                    <li>Click the "Verify" button next to any signature</li>
                    <li>The system will validate the signature against the audit trail</li>
                    <li>Results will show the original signer and timestamp</li>
                  </ol>
                </div>

                <div className="p-4 bg-yellow-50 rounded-lg">
                  <h4 className="font-medium text-yellow-900 mb-2">21 CFR Part 11 Compliance:</h4>
                  <p className="text-sm text-yellow-700">
                    All electronic signatures are cryptographically secured and linked to their respective 
                    records. The audit trail maintains the integrity of signed documents and provides 
                    non-repudiation as required by FDA regulations.
                  </p>
                </div>

                <div className="text-center py-8 text-gray-500">
                  <Eye className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                  <p>Use the "Verify" buttons in the Audit Logs tab to verify specific signatures</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

export default AuditLogs

