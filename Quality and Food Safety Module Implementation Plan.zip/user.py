from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import hashlib

db = SQLAlchemy()

class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(50), nullable=False, default='operator')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)

    def __repr__(self):
        return f'<User {self.username}>'

class Recipe(db.Model):
    __tablename__ = 'recipes'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    version = db.Column(db.String(20), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)

class CriticalControlPoint(db.Model):
    __tablename__ = 'critical_control_points'
    
    id = db.Column(db.Integer, primary_key=True)
    recipe_id = db.Column(db.Integer, db.ForeignKey('recipes.id'), nullable=False)
    step = db.Column(db.String(200), nullable=False)
    critical_limit_min = db.Column(db.Float)
    critical_limit_max = db.Column(db.Float)
    unit = db.Column(db.String(50))
    monitoring_frequency = db.Column(db.String(100))
    corrective_action = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    recipe = db.relationship('Recipe', backref=db.backref('ccps', lazy=True))

class CCPLog(db.Model):
    __tablename__ = 'ccp_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    ccp_id = db.Column(db.Integer, db.ForeignKey('critical_control_points.id'), nullable=False)
    recipe_id = db.Column(db.Integer, db.ForeignKey('recipes.id'), nullable=False)
    lot_number = db.Column(db.String(100), nullable=False, index=True)
    log_value = db.Column(db.Float, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    status = db.Column(db.String(20), nullable=False, default='in_spec')  # in_spec, out_of_spec, corrected
    notes = db.Column(db.Text)
    signature_hash = db.Column(db.String(255))  # For 21 CFR Part 11 compliance
    
    ccp = db.relationship('CriticalControlPoint', backref=db.backref('logs', lazy=True))
    recipe = db.relationship('Recipe', backref=db.backref('ccp_logs', lazy=True))
    user = db.relationship('User', backref=db.backref('ccp_logs', lazy=True))

class Batch(db.Model):
    __tablename__ = 'batches'
    
    id = db.Column(db.Integer, primary_key=True)
    lot_number = db.Column(db.String(100), unique=True, nullable=False, index=True)
    recipe_id = db.Column(db.Integer, db.ForeignKey('recipes.id'), nullable=False)
    production_date = db.Column(db.Date, nullable=False, index=True)
    expiry_date = db.Column(db.Date)
    quantity = db.Column(db.Float, nullable=False)
    unit = db.Column(db.String(20), nullable=False)
    status = db.Column(db.String(20), nullable=False, default='hold')  # hold, released, recalled
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    recipe = db.relationship('Recipe', backref=db.backref('batches', lazy=True))
    creator = db.relationship('User', backref=db.backref('created_batches', lazy=True))

class BatchIngredient(db.Model):
    __tablename__ = 'batch_ingredients'
    
    id = db.Column(db.Integer, primary_key=True)
    batch_id = db.Column(db.Integer, db.ForeignKey('batches.id'), nullable=False)
    ingredient_name = db.Column(db.String(200), nullable=False)
    supplier = db.Column(db.String(200))
    lot_number = db.Column(db.String(100), index=True)
    quantity = db.Column(db.Float, nullable=False)
    unit = db.Column(db.String(20), nullable=False)
    
    batch = db.relationship('Batch', backref=db.backref('ingredients', lazy=True))

class AuditLog(db.Model):
    __tablename__ = 'audit_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    action = db.Column(db.String(100), nullable=False)
    table_name = db.Column(db.String(100), nullable=False)
    record_id = db.Column(db.Integer, nullable=False)
    old_values = db.Column(db.Text)
    new_values = db.Column(db.Text)
    signature_hash = db.Column(db.String(255))
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    ip_address = db.Column(db.String(45))
    
    user = db.relationship('User', backref=db.backref('audit_logs', lazy=True))

def create_signature_hash(user_id, timestamp, data):
    """Create a hash for electronic signature compliance"""
    signature_string = f"{user_id}:{timestamp.isoformat()}:{data}"
    return hashlib.sha256(signature_string.encode()).hexdigest()

