import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp, TrendingDown, AlertCircle, Calendar } from 'lucide-react';

const API_BASE_URL = 'https://4zmhqivcl8ox.manus.space';

const ForecastingDashboard = () => {
  const [selectedIngredient, setSelectedIngredient] = useState('tomatoes');
  const [forecastData, setForecastData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [ingredients, setIngredients] = useState([]);

  const fetchIngredients = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/forecast/ingredients`);
      const data = await response.json();
      
      if (data.success) {
        setIngredients(data.data);
      }
    } catch (err) {
      console.error('Failed to fetch ingredients:', err);
      // Mock ingredients for demo
      setIngredients([
        { id: 1, name: 'tomatoes' },
        { id: 2, name: 'mozzarella cheese' },
        { id: 3, name: 'romaine lettuce' },
      ]);
    }
  };

  const fetchForecast = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await fetch(`${API_BASE_URL}/forecast/cost`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-User-ID': 'demo-user',
        },
        body: JSON.stringify({
          ingredient_id: selectedIngredient,
          use_cache: true,
        }),
      });

      const data = await response.json();
      
      if (data.success) {
        setForecastData(data.data);
      } else {
        throw new Error(data.error || 'Failed to fetch forecast');
      }
    } catch (err) {
      setError(err.message);
      // Mock forecast data for demo
      setForecastData({
        ingredient_id: selectedIngredient,
        mae_score: 3.2,
        model_version: '1.0.0',
        forecasts: {
          '30_day': {
            average_cost: 2.65,
            trend: 'increasing',
            predictions: Array.from({ length: 30 }, (_, i) => ({
              ds: new Date(Date.now() + i * 24 * 60 * 60 * 1000).toISOString(),
              yhat: 2.5 + Math.sin(i / 5) * 0.3 + i * 0.01,
              yhat_lower: 2.3 + Math.sin(i / 5) * 0.3 + i * 0.01,
              yhat_upper: 2.7 + Math.sin(i / 5) * 0.3 + i * 0.01,
            })),
          },
          '60_day': {
            average_cost: 2.78,
            trend: 'increasing',
          },
          '90_day': {
            average_cost: 2.89,
            trend: 'increasing',
          },
        },
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchIngredients();
  }, []);

  useEffect(() => {
    if (selectedIngredient) {
      fetchForecast();
    }
  }, [selectedIngredient]);

  const formatChartData = (predictions) => {
    return predictions?.map(pred => ({
      date: new Date(pred.ds).toLocaleDateString(),
      price: pred.yhat,
      lower: pred.yhat_lower,
      upper: pred.yhat_upper,
    })) || [];
  };

  const getTrendIcon = (trend) => {
    return trend === 'increasing' ? (
      <TrendingUp className="h-4 w-4 text-red-500" />
    ) : (
      <TrendingDown className="h-4 w-4 text-green-500" />
    );
  };

  const getTrendColor = (trend) => {
    return trend === 'increasing' ? 'text-red-600' : 'text-green-600';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Cost Forecasting</h2>
          <p className="text-gray-600">AI-powered ingredient cost predictions using Prophet</p>
        </div>
        <div className="flex items-center space-x-4">
          <Select value={selectedIngredient} onValueChange={setSelectedIngredient}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Select ingredient" />
            </SelectTrigger>
            <SelectContent>
              {ingredients.map((ingredient) => (
                <SelectItem key={ingredient.id || ingredient.name} value={ingredient.name}>
                  {ingredient.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button onClick={fetchForecast} disabled={loading}>
            {loading ? 'Loading...' : 'Refresh Forecast'}
          </Button>
        </div>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-center space-x-2">
            <AlertCircle className="h-5 w-5 text-red-500" />
            <p className="text-red-800">Error: {error}</p>
          </div>
          <p className="text-red-600 text-sm mt-1">Showing demo data instead.</p>
        </div>
      )}

      {forecastData && (
        <>
          {/* Model Performance */}
          <Card>
            <CardHeader>
              <CardTitle>Model Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <p className="text-sm text-gray-600">Mean Absolute Error</p>
                  <p className={`text-2xl font-bold ${forecastData.mae_score <= 5 ? 'text-green-600' : 'text-red-600'}`}>
                    {forecastData.mae_score?.toFixed(1)}%
                  </p>
                  <p className="text-xs text-gray-500">
                    {forecastData.mae_score <= 5 ? '✓ Meets target (≤5%)' : '⚠ Exceeds target (≤5%)'}
                  </p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-gray-600">Model Version</p>
                  <p className="text-2xl font-bold text-blue-600">{forecastData.model_version}</p>
                  <p className="text-xs text-gray-500">Prophet ML Model</p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-gray-600">Ingredient</p>
                  <p className="text-2xl font-bold text-purple-600 capitalize">{forecastData.ingredient_id}</p>
                  <p className="text-xs text-gray-500">Selected for forecasting</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Forecast Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {['30_day', '60_day', '90_day'].map((period) => {
              const forecast = forecastData.forecasts[period];
              if (!forecast) return null;
              
              return (
                <Card key={period}>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">
                      {period.replace('_', '-').toUpperCase()} Forecast
                    </CardTitle>
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center space-x-2">
                      <div className="text-2xl font-bold">
                        ${forecast.average_cost?.toFixed(2) || 'N/A'}
                      </div>
                      {forecast.trend && (
                        <div className="flex items-center space-x-1">
                          {getTrendIcon(forecast.trend)}
                          <span className={`text-sm ${getTrendColor(forecast.trend)}`}>
                            {forecast.trend}
                          </span>
                        </div>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Average cost per unit
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Price Forecast Chart */}
          <Card>
            <CardHeader>
              <CardTitle>30-Day Price Forecast</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={formatChartData(forecastData.forecasts['30_day']?.predictions)}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip 
                    formatter={(value, name) => [
                      `$${value?.toFixed(2)}`, 
                      name === 'price' ? 'Predicted Price' : 
                      name === 'lower' ? 'Lower Bound' : 'Upper Bound'
                    ]}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="lower" 
                    stroke="#e5e7eb" 
                    strokeDasharray="5 5"
                    dot={false}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="upper" 
                    stroke="#e5e7eb" 
                    strokeDasharray="5 5"
                    dot={false}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="price" 
                    stroke="#3b82f6" 
                    strokeWidth={2}
                    dot={{ fill: '#3b82f6', strokeWidth: 2, r: 3 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Forecast Details */}
          <Card>
            <CardHeader>
              <CardTitle>Forecast Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold mb-3">Price Trends</h4>
                  <div className="space-y-2">
                    {Object.entries(forecastData.forecasts).map(([period, forecast]) => (
                      <div key={period} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                        <span className="text-sm font-medium">
                          {period.replace('_', '-').toUpperCase()}
                        </span>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm">${forecast.average_cost?.toFixed(2)}</span>
                          {forecast.trend && getTrendIcon(forecast.trend)}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold mb-3">Model Information</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Algorithm:</span>
                      <span className="font-medium">Facebook Prophet</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Seasonality:</span>
                      <span className="font-medium">Weekly, Monthly, Quarterly</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Confidence Interval:</span>
                      <span className="font-medium">80%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Last Updated:</span>
                      <span className="font-medium">
                        {new Date().toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
};

export default ForecastingDashboard;

