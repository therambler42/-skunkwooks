import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { MessageCircle, BarChart3, TrendingUp, Brain } from 'lucide-react'
import ChatbotSidebar from './components/ChatbotSidebar'
import CreditDashboard from './components/CreditDashboard'
import ForecastingDashboard from './components/ForecastingDashboard'
import './App.css'

function App() {
  const [isChatbotOpen, setIsChatbotOpen] = useState(false)

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <Brain className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-xl font-bold text-gray-900">AI & Forecasting Layer</h1>
                <p className="text-sm text-gray-600">Cost Forecasting & Ask Skunk Chatbot</p>
              </div>
            </div>
            <Button 
              onClick={() => setIsChatbotOpen(true)}
              className="flex items-center space-x-2"
            >
              <MessageCircle className="h-4 w-4" />
              <span>Ask Skunk</span>
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="forecasting" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="forecasting" className="flex items-center space-x-2">
              <TrendingUp className="h-4 w-4" />
              <span>Cost Forecasting</span>
            </TabsTrigger>
            <TabsTrigger value="credits" className="flex items-center space-x-2">
              <BarChart3 className="h-4 w-4" />
              <span>Credit Dashboard</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="forecasting" className="space-y-6">
            <ForecastingDashboard />
          </TabsContent>

          <TabsContent value="credits" className="space-y-6">
            <CreditDashboard />
          </TabsContent>
        </Tabs>

        {/* Feature Overview Cards */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <TrendingUp className="h-5 w-5 text-blue-600" />
                <span>Cost Forecasting</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 text-sm">
                AI-powered ingredient cost predictions using Facebook Prophet. 
                Get 30/60/90-day forecasts with MAE ≤ 5% accuracy target.
              </p>
              <div className="mt-4 space-y-2">
                <div className="flex items-center text-xs text-gray-500">
                  <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                  Prophet ML Algorithm
                </div>
                <div className="flex items-center text-xs text-gray-500">
                  <span className="w-2 h-2 bg-blue-500 rounded-full mr-2"></span>
                  Seasonal Trend Analysis
                </div>
                <div className="flex items-center text-xs text-gray-500">
                  <span className="w-2 h-2 bg-purple-500 rounded-full mr-2"></span>
                  Confidence Intervals
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <MessageCircle className="h-5 w-5 text-green-600" />
                <span>Ask Skunk Chatbot</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 text-sm">
                Intelligent chatbot with vector search over organizational data. 
                Get answers about recipes, ingredients, and suppliers with 85%+ accuracy.
              </p>
              <div className="mt-4 space-y-2">
                <div className="flex items-center text-xs text-gray-500">
                  <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                  Vector Search
                </div>
                <div className="flex items-center text-xs text-gray-500">
                  <span className="w-2 h-2 bg-orange-500 rounded-full mr-2"></span>
                  Allergen Alerts
                </div>
                <div className="flex items-center text-xs text-gray-500">
                  <span className="w-2 h-2 bg-blue-500 rounded-full mr-2"></span>
                  Substitution Suggestions
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <BarChart3 className="h-5 w-5 text-purple-600" />
                <span>Credit Tracking</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 text-sm">
                Comprehensive credit usage monitoring and analytics. 
                Track AI service consumption with detailed breakdowns and trends.
              </p>
              <div className="mt-4 space-y-2">
                <div className="flex items-center text-xs text-gray-500">
                  <span className="w-2 h-2 bg-blue-500 rounded-full mr-2"></span>
                  Real-time Tracking
                </div>
                <div className="flex items-center text-xs text-gray-500">
                  <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                  Usage Analytics
                </div>
                <div className="flex items-center text-xs text-gray-500">
                  <span className="w-2 h-2 bg-purple-500 rounded-full mr-2"></span>
                  Cost Optimization
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Chatbot Sidebar */}
      <ChatbotSidebar 
        isOpen={isChatbotOpen} 
        onClose={() => setIsChatbotOpen(false)} 
      />
    </div>
  )
}

export default App

