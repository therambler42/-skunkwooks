class VectorEmbedding(db.Model):
    __tablename__ = 'vector_embeddings'
    
    id = db.Column(db.Integer, primary_key=True)
    content_type = db.Column(db.String(100), nullable=False)
    content_id = db.Column(db.String(255), nullable=False)
    content_text = db.Column(db.Text, nullable=False)
    embedding = db.Column(db.JSON)  # Store as JSON for SQLite compatibility
    metadata = db.Column(db.JSON)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'content_type': self.content_type,
            'content_id': self.content_id,
            'content_text': self.content_text,
            'metadata': self.metadata,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }

class ChatbotInteraction(db.Model):
    __tablename__ = 'chatbot_interactions'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(255), nullable=False)
    query = db.Column(db.Text, nullable=False)
    response = db.Column(db.Text, nullable=False)
    confidence_score = db.Column(db.Numeric(4, 3))
    response_time_ms = db.Column(db.Integer)
    feedback_rating = db.Column(db.Integer)
    allergen_alerts = db.Column(db.JSON)
    substitution_suggestions = db.Column(db.JSON)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'query': self.query,
            'response': self.response,
            'confidence_score': float(self.confidence_score) if self.confidence_score else None,
            'response_time_ms': self.response_time_ms,
            'feedback_rating': self.feedback_rating,
            'allergen_alerts': self.allergen_alerts,
            'substitution_suggestions': self.substitution_suggestions,
            'timestamp': self.timestamp.isoformat()
        }

