import numpy as np
import json
import logging
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime
import uuid
from src.services.manus_proxy import ManusAPIProxy

class VectorSearchService:
    """
    Vector search service for organizational data using embeddings.
    Supports semantic search over recipes, ingredients, and suppliers.
    """
    
    def __init__(self, db_session=None, manus_proxy=None):
        self.logger = logging.getLogger(__name__)
        self.db_session = db_session
        self.manus_proxy = manus_proxy or ManusAPIProxy(db_session)
        
        # Sample organizational data for demo
        self.sample_data = self._load_sample_data()
    
    def _load_sample_data(self) -> Dict[str, List[Dict]]:
        """Load sample organizational data for demonstration."""
        return {
            'recipes': [
                {
                    'id': 'recipe_001',
                    'name': 'Classic Margherita Pizza',
                    'description': 'Traditional Italian pizza with tomato sauce, mozzarella, and fresh basil',
                    'ingredients': ['tomato sauce', 'mozzarella cheese', 'fresh basil', 'pizza dough', 'olive oil'],
                    'allergens': ['gluten', 'dairy'],
                    'category': 'pizza',
                    'prep_time': 30,
                    'cook_time': 15
                },
                {
                    'id': 'recipe_002',
                    'name': 'Chicken Caesar Salad',
                    'description': 'Fresh romaine lettuce with grilled chicken, parmesan, and caesar dressing',
                    'ingredients': ['romaine lettuce', 'grilled chicken breast', 'parmesan cheese', 'caesar dressing', 'croutons'],
                    'allergens': ['dairy', 'eggs'],
                    'category': 'salad',
                    'prep_time': 15,
                    'cook_time': 10
                },
                {
                    'id': 'recipe_003',
                    'name': 'Vegetarian Pasta Primavera',
                    'description': 'Colorful pasta with seasonal vegetables in a light cream sauce',
                    'ingredients': ['penne pasta', 'bell peppers', 'zucchini', 'cherry tomatoes', 'cream sauce', 'parmesan'],
                    'allergens': ['gluten', 'dairy'],
                    'category': 'pasta',
                    'prep_time': 20,
                    'cook_time': 25
                }
            ],
            'ingredients': [
                {
                    'id': 'ing_001',
                    'name': 'tomato sauce',
                    'category': 'sauce',
                    'allergens': [],
                    'nutritional_info': {'calories_per_100g': 29, 'protein': 1.6, 'carbs': 7.0, 'fat': 0.2},
                    'substitutes': ['marinara sauce', 'crushed tomatoes'],
                    'storage': 'refrigerated',
                    'shelf_life_days': 7
                },
                {
                    'id': 'ing_002',
                    'name': 'mozzarella cheese',
                    'category': 'dairy',
                    'allergens': ['dairy'],
                    'nutritional_info': {'calories_per_100g': 280, 'protein': 22, 'carbs': 2.2, 'fat': 22},
                    'substitutes': ['vegan mozzarella', 'cashew cheese'],
                    'storage': 'refrigerated',
                    'shelf_life_days': 14
                },
                {
                    'id': 'ing_003',
                    'name': 'romaine lettuce',
                    'category': 'vegetable',
                    'allergens': [],
                    'nutritional_info': {'calories_per_100g': 17, 'protein': 1.2, 'carbs': 3.3, 'fat': 0.3},
                    'substitutes': ['iceberg lettuce', 'spinach', 'arugula'],
                    'storage': 'refrigerated',
                    'shelf_life_days': 5
                }
            ],
            'suppliers': [
                {
                    'id': 'sup_001',
                    'name': 'Fresh Farm Produce Co.',
                    'specialties': ['vegetables', 'herbs', 'organic produce'],
                    'contact': {'phone': '555-0123', 'email': 'orders@freshfarm.com'},
                    'delivery_areas': ['downtown', 'midtown', 'suburbs'],
                    'min_order': 50.00,
                    'delivery_time': '24-48 hours'
                },
                {
                    'id': 'sup_002',
                    'name': 'Artisan Dairy Solutions',
                    'specialties': ['cheese', 'dairy products', 'specialty items'],
                    'contact': {'phone': '555-0456', 'email': 'sales@artisandairy.com'},
                    'delivery_areas': ['citywide'],
                    'min_order': 75.00,
                    'delivery_time': '48-72 hours'
                }
            ]
        }
    
    def index_content(self, content_type: str, content_id: str, text: str, metadata: Dict = None) -> bool:
        """
        Index content by generating embeddings and storing in database.
        
        Args:
            content_type: Type of content ('recipe', 'ingredient', 'supplier')
            content_id: Unique identifier for the content
            text: Text content to index
            metadata: Additional metadata to store
            
        Returns:
            Boolean indicating success
        """
        try:
            # Generate embedding for the text
            embedding_result = self.manus_proxy.call_embedding(
                text=text,
                user_id='system',
                session_id=f'indexing_{content_type}_{content_id}'
            )
            
            if not embedding_result['success']:
                self.logger.error(f"Failed to generate embedding for {content_type}:{content_id}")
                return False
            
            embedding = embedding_result['embedding']
            
            # Store in database (mock implementation for now)
            if self.db_session:
                from src.models.forecasting import VectorEmbedding
                
                # Check if embedding already exists
                existing = self.db_session.query(VectorEmbedding).filter_by(
                    content_type=content_type,
                    content_id=content_id
                ).first()
                
                if existing:
                    # Update existing embedding
                    existing.content_text = text
                    existing.embedding = embedding
                    existing.content_metadata = metadata or {}
                    existing.updated_at = datetime.utcnow()
                else:
                    # Create new embedding
                    new_embedding = VectorEmbedding(
                        content_type=content_type,
                        content_id=content_id,
                        content_text=text,
                        embedding=embedding,
                        content_metadata=metadata or {}
                    )
                    self.db_session.add(new_embedding)
                
                self.db_session.commit()
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error indexing content {content_type}:{content_id}: {str(e)}")
            if self.db_session:
                self.db_session.rollback()
            return False
    
    def search(self, query: str, content_types: List[str] = None, limit: int = 5) -> List[Dict]:
        """
        Perform semantic search over indexed content.
        
        Args:
            query: Search query text
            content_types: List of content types to search (default: all)
            limit: Maximum number of results to return
            
        Returns:
            List of search results with similarity scores
        """
        try:
            # Generate embedding for query
            query_embedding_result = self.manus_proxy.call_embedding(
                text=query,
                user_id='search',
                session_id=f'search_{uuid.uuid4()}'
            )
            
            if not query_embedding_result['success']:
                self.logger.error("Failed to generate query embedding")
                return []
            
            query_embedding = np.array(query_embedding_result['embedding'])
            
            # For demo purposes, use sample data with mock embeddings
            results = []
            
            for content_type, items in self.sample_data.items():
                if content_types and content_type not in content_types:
                    continue
                
                for item in items:
                    # Create searchable text from item
                    if content_type == 'recipes':
                        text = f"{item['name']} {item['description']} {' '.join(item['ingredients'])}"
                    elif content_type == 'ingredients':
                        text = f"{item['name']} {item['category']} {' '.join(item.get('substitutes', []))}"
                    elif content_type == 'suppliers':
                        text = f"{item['name']} {' '.join(item['specialties'])}"
                    else:
                        continue
                    
                    # Generate mock embedding for comparison
                    mock_embedding = self._generate_mock_embedding(text)
                    
                    # Calculate similarity (cosine similarity)
                    similarity = self._cosine_similarity(query_embedding, mock_embedding)
                    
                    results.append({
                        'content_type': content_type,
                        'content_id': item['id'],
                        'content': item,
                        'similarity': float(similarity),
                        'text': text
                    })
            
            # Sort by similarity and return top results
            results.sort(key=lambda x: x['similarity'], reverse=True)
            return results[:limit]
            
        except Exception as e:
            self.logger.error(f"Error performing search: {str(e)}")
            return []
    
    def get_allergen_alerts(self, ingredients: List[str]) -> List[Dict]:
        """
        Generate allergen alerts for a list of ingredients.
        
        Args:
            ingredients: List of ingredient names
            
        Returns:
            List of allergen alerts
        """
        alerts = []
        
        for ingredient_name in ingredients:
            # Find ingredient in sample data
            for ingredient in self.sample_data['ingredients']:
                if ingredient['name'].lower() == ingredient_name.lower():
                    if ingredient['allergens']:
                        alerts.append({
                            'ingredient': ingredient_name,
                            'allergens': ingredient['allergens'],
                            'severity': 'high' if 'nuts' in ingredient['allergens'] else 'medium'
                        })
                    break
        
        return alerts
    
    def get_substitution_suggestions(self, ingredient: str, dietary_restrictions: List[str] = None) -> List[Dict]:
        """
        Get substitution suggestions for an ingredient.
        
        Args:
            ingredient: Ingredient name to find substitutes for
            dietary_restrictions: List of dietary restrictions to consider
            
        Returns:
            List of substitution suggestions
        """
        suggestions = []
        
        # Find ingredient in sample data
        for ing in self.sample_data['ingredients']:
            if ing['name'].lower() == ingredient.lower():
                for substitute in ing.get('substitutes', []):
                    # Check if substitute meets dietary restrictions
                    substitute_info = self._find_ingredient_info(substitute)
                    
                    if dietary_restrictions:
                        allergens = substitute_info.get('allergens', [])
                        if any(restriction in allergens for restriction in dietary_restrictions):
                            continue
                    
                    suggestions.append({
                        'substitute': substitute,
                        'reason': 'Similar flavor profile and texture',
                        'allergens': substitute_info.get('allergens', []),
                        'availability': 'common'
                    })
                break
        
        return suggestions
    
    def _generate_mock_embedding(self, text: str) -> np.ndarray:
        """Generate deterministic mock embedding for text."""
        # Use hash of text to generate reproducible embedding
        np.random.seed(hash(text) % (2**32))
        return np.random.normal(0, 1, 1536)
    
    def _cosine_similarity(self, a: np.ndarray, b: np.ndarray) -> float:
        """Calculate cosine similarity between two vectors."""
        return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))
    
    def _find_ingredient_info(self, ingredient_name: str) -> Dict:
        """Find ingredient information by name."""
        for ingredient in self.sample_data['ingredients']:
            if ingredient['name'].lower() == ingredient_name.lower():
                return ingredient
        return {}
    
    def index_all_sample_data(self) -> Dict[str, int]:
        """Index all sample data for demonstration."""
        indexed_counts = {'recipes': 0, 'ingredients': 0, 'suppliers': 0}
        
        # Index recipes
        for recipe in self.sample_data['recipes']:
            text = f"{recipe['name']} {recipe['description']} {' '.join(recipe['ingredients'])}"
            if self.index_content('recipe', recipe['id'], text, recipe):
                indexed_counts['recipes'] += 1
        
        # Index ingredients
        for ingredient in self.sample_data['ingredients']:
            text = f"{ingredient['name']} {ingredient['category']} {' '.join(ingredient.get('substitutes', []))}"
            if self.index_content('ingredient', ingredient['id'], text, ingredient):
                indexed_counts['ingredients'] += 1
        
        # Index suppliers
        for supplier in self.sample_data['suppliers']:
            text = f"{supplier['name']} {' '.join(supplier['specialties'])}"
            if self.index_content('supplier', supplier['id'], text, supplier):
                indexed_counts['suppliers'] += 1
        
        return indexed_counts

