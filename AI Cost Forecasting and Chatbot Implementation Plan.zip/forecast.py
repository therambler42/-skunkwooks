from flask import Blueprint, request, jsonify
from flask_cors import cross_origin
from src.services.forecasting_service import CostForecastingService
from src.models.forecasting import db, CreditUsage, ForecastCache, Ingredient
from datetime import datetime, timedelta
import logging
import uuid

forecast_bp = Blueprint('forecast', __name__)
forecasting_service = CostForecastingService()
logger = logging.getLogger(__name__)

@forecast_bp.route('/cost', methods=['POST'])
@cross_origin()
def forecast_cost():
    """
    Generate cost forecasts for ingredients.
    
    Expected JSON payload:
    {
        "ingredient_id": "string",
        "historical_data": [
            {"date": "2024-01-01", "cost": 10.50},
            {"date": "2024-01-02", "cost": 10.75}
        ],
        "use_cache": true (optional, default: true),
        "force_refresh": false (optional, default: false)
    }
    
    Returns:
    {
        "success": true,
        "data": {
            "ingredient_id": "string",
            "forecasts": {
                "30_day": {...},
                "60_day": {...},
                "90_day": {...}
            },
            "mae_score": 2.5,
            "model_version": "1.0.0"
        }
    }
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No JSON data provided'
            }), 400
        
        ingredient_id = data.get('ingredient_id')
        historical_data = data.get('historical_data')
        use_cache = data.get('use_cache', True)
        force_refresh = data.get('force_refresh', False)
        
        if not ingredient_id:
            return jsonify({
                'success': False,
                'error': 'ingredient_id is required'
            }), 400
        
        # Check cache first (if enabled and not forcing refresh)
        if use_cache and not force_refresh:
            cached_forecast = check_forecast_cache(ingredient_id)
            if cached_forecast:
                # Log credit usage for cached request
                log_credit_usage(
                    user_id=request.headers.get('X-User-ID', 'anonymous'),
                    service_type='forecasting_cached',
                    credits_consumed=0.1,
                    request_details={'ingredient_id': ingredient_id, 'cache_hit': True}
                )
                
                return jsonify({
                    'success': True,
                    'data': cached_forecast,
                    'cached': True
                })
        
        # If no historical data provided, try to get from database or generate sample
        if not historical_data:
            # Try to get from database
            ingredient = Ingredient.query.filter_by(name=ingredient_id).first()
            if not ingredient:
                # Generate sample data for demo purposes
                logger.warning(f"No historical data found for {ingredient_id}, generating sample data")
                historical_data = forecasting_service.generate_sample_data(ingredient_id)
            else:
                return jsonify({
                    'success': False,
                    'error': 'No historical data available for this ingredient'
                }), 400
        
        # Validate historical data format
        if not isinstance(historical_data, list) or len(historical_data) < 15:  # Reduced requirement
            return jsonify({
                'success': False,
                'error': 'Historical data must be a list with at least 15 data points'
            }), 400
        
        # Validate data structure
        for item in historical_data[:5]:  # Check first 5 items
            if not isinstance(item, dict) or 'date' not in item or 'cost' not in item:
                return jsonify({
                    'success': False,
                    'error': 'Each historical data item must have "date" and "cost" fields'
                }), 400
        
        # Generate forecast
        forecast_result = forecasting_service.forecast_ingredient_cost(
            ingredient_id=ingredient_id,
            historical_data=historical_data
        )
        
        # Check if MAE meets acceptance criteria (<=5%)
        if forecast_result['mae_score'] > 5.0:
            logger.warning(f"MAE score {forecast_result['mae_score']}% exceeds 5% threshold for {ingredient_id}")
        
        # Cache the result
        if use_cache:
            cache_forecast_result(ingredient_id, forecast_result)
        
        # Log credit usage
        log_credit_usage(
            user_id=request.headers.get('X-User-ID', 'anonymous'),
            service_type='forecasting',
            credits_consumed=1.0,
            request_details={
                'ingredient_id': ingredient_id,
                'data_points': len(historical_data),
                'mae_score': forecast_result['mae_score']
            }
        )
        
        return jsonify({
            'success': True,
            'data': forecast_result,
            'cached': False
        })
        
    except ValueError as e:
        logger.error(f"Validation error in forecast_cost: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400
        
    except Exception as e:
        logger.error(f"Unexpected error in forecast_cost: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Internal server error occurred'
        }), 500

@forecast_bp.route('/ingredients', methods=['GET'])
@cross_origin()
def get_ingredients():
    """
    Get list of available ingredients for forecasting.
    """
    try:
        ingredients = Ingredient.query.all()
        return jsonify({
            'success': True,
            'data': [ingredient.to_dict() for ingredient in ingredients]
        })
    except Exception as e:
        logger.error(f"Error fetching ingredients: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to fetch ingredients'
        }), 500

@forecast_bp.route('/cache/<ingredient_id>', methods=['DELETE'])
@cross_origin()
def clear_forecast_cache(ingredient_id):
    """
    Clear cached forecasts for a specific ingredient.
    """
    try:
        deleted_count = ForecastCache.query.filter_by(ingredient_id=ingredient_id).delete()
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'Cleared {deleted_count} cached forecasts for {ingredient_id}'
        })
    except Exception as e:
        logger.error(f"Error clearing cache for {ingredient_id}: {str(e)}")
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': 'Failed to clear cache'
        }), 500

@forecast_bp.route('/health', methods=['GET'])
@cross_origin()
def health_check():
    """
    Health check endpoint for the forecasting service.
    """
    return jsonify({
        'success': True,
        'service': 'cost-forecasting',
        'version': forecasting_service.model_version,
        'timestamp': datetime.utcnow().isoformat(),
        'status': 'healthy'
    })

def check_forecast_cache(ingredient_id: str):
    """
    Check if valid cached forecast exists for ingredient.
    """
    try:
        # Look for non-expired cache entries
        cached_forecasts = ForecastCache.query.filter(
            ForecastCache.ingredient_id == ingredient_id,
            ForecastCache.expires_at > datetime.utcnow()
        ).all()
        
        if not cached_forecasts:
            return None
        
        # Combine all forecast types into single result
        result = {
            'ingredient_id': ingredient_id,
            'forecasts': {},
            'cached': True,
            'cache_timestamp': None
        }
        
        for cache_entry in cached_forecasts:
            result['forecasts'][cache_entry.forecast_type] = cache_entry.forecast_data
            result['mae_score'] = float(cache_entry.mae_score) if cache_entry.mae_score else None
            result['model_version'] = cache_entry.model_version
            if not result['cache_timestamp'] or cache_entry.created_at > result['cache_timestamp']:
                result['cache_timestamp'] = cache_entry.created_at.isoformat()
        
        return result if len(result['forecasts']) > 0 else None
        
    except Exception as e:
        logger.error(f"Error checking forecast cache: {str(e)}")
        return None

def cache_forecast_result(ingredient_id: str, forecast_result: dict):
    """
    Cache forecast results in database.
    """
    try:
        # Set cache expiration (24 hours from now)
        expires_at = datetime.utcnow() + timedelta(hours=24)
        
        # Cache each forecast period separately
        for period, forecast_data in forecast_result['forecasts'].items():
            cache_entry = ForecastCache(
                ingredient_id=ingredient_id,
                forecast_type=period,
                forecast_data=forecast_data,
                model_version=forecast_result['model_version'],
                mae_score=forecast_result['mae_score'],
                expires_at=expires_at
            )
            db.session.add(cache_entry)
        
        db.session.commit()
        logger.info(f"Cached forecast results for {ingredient_id}")
        
    except Exception as e:
        logger.error(f"Error caching forecast results: {str(e)}")
        db.session.rollback()

def log_credit_usage(user_id: str, service_type: str, credits_consumed: float, request_details: dict):
    """
    Log credit usage for tracking and billing.
    """
    try:
        usage_log = CreditUsage(
            user_id=user_id,
            service_type=service_type,
            credits_consumed=credits_consumed,
            request_details=request_details,
            session_id=str(uuid.uuid4())
        )
        db.session.add(usage_log)
        db.session.commit()
        
    except Exception as e:
        logger.error(f"Error logging credit usage: {str(e)}")
        db.session.rollback()

