from flask_sqlalchemy import SQLAlchemy
import json
from datetime import datetime

db = SQLAlchemy()

class CreditUsage(db.Model):
    __tablename__ = 'credits_usage'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(255), nullable=False)
    service_type = db.Column(db.String(100), nullable=False)
    credits_consumed = db.Column(db.Numeric(10, 4), nullable=False)
    request_details = db.Column(db.JSON)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    session_id = db.Column(db.String(255))
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'service_type': self.service_type,
            'credits_consumed': float(self.credits_consumed),
            'request_details': self.request_details,
            'timestamp': self.timestamp.isoformat(),
            'session_id': self.session_id
        }

class ForecastCache(db.Model):
    __tablename__ = 'forecast_cache'
    
    id = db.Column(db.Integer, primary_key=True)
    ingredient_id = db.Column(db.String(255), nullable=False)
    forecast_type = db.Column(db.String(50), nullable=False)
    forecast_data = db.Column(db.JSON, nullable=False)
    model_version = db.Column(db.String(100))
    mae_score = db.Column(db.Numeric(8, 4))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime)
    
    def to_dict(self):
        return {
            'id': self.id,
            'ingredient_id': self.ingredient_id,
            'forecast_type': self.forecast_type,
            'forecast_data': self.forecast_data,
            'model_version': self.model_version,
            'mae_score': float(self.mae_score) if self.mae_score else None,
            'created_at': self.created_at.isoformat(),
            'expires_at': self.expires_at.isoformat() if self.expires_at else None
        }

class Ingredient(db.Model):
    __tablename__ = 'ingredients'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False, unique=True)
    category = db.Column(db.String(100))
    allergens = db.Column(db.JSON)
    cost_per_unit = db.Column(db.Numeric(10, 4))
    unit_type = db.Column(db.String(50))
    supplier_id = db.Column(db.String(255))
    nutritional_info = db.Column(db.JSON)
    substitutes = db.Column(db.JSON)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'category': self.category,
            'allergens': self.allergens,
            'cost_per_unit': float(self.cost_per_unit) if self.cost_per_unit else None,
            'unit_type': self.unit_type,
            'supplier_id': self.supplier_id,
            'nutritional_info': self.nutritional_info,
            'substitutes': self.substitutes,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }

class VectorEmbedding(db.Model):
    __tablename__ = 'vector_embeddings'
    
    id = db.Column(db.Integer, primary_key=True)
    content_type = db.Column(db.String(100), nullable=False)
    content_id = db.Column(db.String(255), nullable=False)
    content_text = db.Column(db.Text, nullable=False)
    embedding = db.Column(db.JSON)  # Store as JSON for SQLite compatibility
    content_metadata = db.Column(db.JSON)  # Renamed from metadata to avoid conflict
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'content_type': self.content_type,
            'content_id': self.content_id,
            'content_text': self.content_text,
            'content_metadata': self.content_metadata,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }

class ChatbotInteraction(db.Model):
    __tablename__ = 'chatbot_interactions'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(255), nullable=False)
    query = db.Column(db.Text, nullable=False)
    response = db.Column(db.Text, nullable=False)
    confidence_score = db.Column(db.Numeric(4, 3))
    response_time_ms = db.Column(db.Integer)
    feedback_rating = db.Column(db.Integer)
    allergen_alerts = db.Column(db.JSON)
    substitution_suggestions = db.Column(db.JSON)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'query': self.query,
            'response': self.response,
            'confidence_score': float(self.confidence_score) if self.confidence_score else None,
            'response_time_ms': self.response_time_ms,
            'feedback_rating': self.feedback_rating,
            'allergen_alerts': self.allergen_alerts,
            'substitution_suggestions': self.substitution_suggestions,
            'timestamp': self.timestamp.isoformat()
        }

