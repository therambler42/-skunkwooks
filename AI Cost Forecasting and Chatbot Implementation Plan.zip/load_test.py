import time
import json
import statistics
from concurrent.futures import ThreadPoolExecutor
import threading
import requests

class LoadTester:
    """Load testing utility for the forecasting service."""
    
    def __init__(self, base_url='http://localhost:5001'):
        self.base_url = base_url
        self.results = []
        self.lock = threading.Lock()
    
    def test_endpoint(self, endpoint, method='GET', data=None, headers=None):
        """Test a single endpoint and record response time."""
        start_time = time.time()
        
        try:
            if method == 'GET':
                response = requests.get(f"{self.base_url}{endpoint}", headers=headers, timeout=30)
            elif method == 'POST':
                response = requests.post(f"{self.base_url}{endpoint}", 
                                       json=data, headers=headers, timeout=30)
            
            end_time = time.time()
            response_time = (end_time - start_time) * 1000  # Convert to milliseconds
            
            with self.lock:
                self.results.append({
                    'endpoint': endpoint,
                    'method': method,
                    'status_code': response.status_code,
                    'response_time_ms': response_time,
                    'success': response.status_code == 200,
                    'timestamp': time.time()
                })
            
            return response.status_code == 200
            
        except Exception as e:
            end_time = time.time()
            response_time = (end_time - start_time) * 1000
            
            with self.lock:
                self.results.append({
                    'endpoint': endpoint,
                    'method': method,
                    'status_code': 0,
                    'response_time_ms': response_time,
                    'success': False,
                    'error': str(e),
                    'timestamp': time.time()
                })
            
            return False
    
    def run_concurrent_tests(self, test_config, concurrent_users=10, duration_seconds=60):
        """Run concurrent load tests."""
        print(f"Starting load test with {concurrent_users} concurrent users for {duration_seconds} seconds")
        
        start_time = time.time()
        end_time = start_time + duration_seconds
        
        def worker():
            while time.time() < end_time:
                for test in test_config:
                    if time.time() >= end_time:
                        break
                    
                    self.test_endpoint(
                        endpoint=test['endpoint'],
                        method=test.get('method', 'GET'),
                        data=test.get('data'),
                        headers=test.get('headers')
                    )
                    
                    # Small delay between requests
                    time.sleep(0.1)
        
        # Start concurrent workers
        with ThreadPoolExecutor(max_workers=concurrent_users) as executor:
            futures = [executor.submit(worker) for _ in range(concurrent_users)]
            
            # Wait for all workers to complete
            for future in futures:
                future.result()
        
        return self.analyze_results()
    
    def analyze_results(self):
        """Analyze load test results."""
        if not self.results:
            return {'error': 'No results to analyze'}
        
        # Calculate statistics
        response_times = [r['response_time_ms'] for r in self.results]
        success_count = sum(1 for r in self.results if r['success'])
        total_requests = len(self.results)
        
        # Group by endpoint
        endpoint_stats = {}
        for result in self.results:
            endpoint = result['endpoint']
            if endpoint not in endpoint_stats:
                endpoint_stats[endpoint] = {
                    'requests': 0,
                    'successes': 0,
                    'response_times': []
                }
            
            endpoint_stats[endpoint]['requests'] += 1
            if result['success']:
                endpoint_stats[endpoint]['successes'] += 1
            endpoint_stats[endpoint]['response_times'].append(result['response_time_ms'])
        
        # Calculate per-endpoint statistics
        for endpoint, stats in endpoint_stats.items():
            times = stats['response_times']
            stats['avg_response_time'] = statistics.mean(times)
            stats['min_response_time'] = min(times)
            stats['max_response_time'] = max(times)
            stats['p95_response_time'] = statistics.quantiles(times, n=20)[18] if len(times) > 1 else times[0]
            stats['success_rate'] = (stats['successes'] / stats['requests']) * 100
        
        return {
            'summary': {
                'total_requests': total_requests,
                'successful_requests': success_count,
                'failed_requests': total_requests - success_count,
                'success_rate': (success_count / total_requests) * 100,
                'avg_response_time': statistics.mean(response_times),
                'min_response_time': min(response_times),
                'max_response_time': max(response_times),
                'p95_response_time': statistics.quantiles(response_times, n=20)[18] if len(response_times) > 1 else response_times[0],
                'requests_per_second': total_requests / (max(r['timestamp'] for r in self.results) - min(r['timestamp'] for r in self.results))
            },
            'endpoint_stats': endpoint_stats,
            'raw_results': self.results
        }

def run_forecasting_load_test():
    """Run load tests specifically for the forecasting service."""
    tester = LoadTester()
    
    # Define test scenarios
    test_config = [
        {
            'endpoint': '/forecast/health',
            'method': 'GET'
        },
        {
            'endpoint': '/forecast/cost',
            'method': 'POST',
            'data': {
                'ingredient_id': 'tomatoes',
                'use_cache': True
            },
            'headers': {'X-User-ID': 'load-test-user'}
        },
        {
            'endpoint': '/forecast/cost',
            'method': 'POST',
            'data': {
                'ingredient_id': 'mozzarella_cheese',
                'use_cache': False
            },
            'headers': {'X-User-ID': 'load-test-user'}
        },
        {
            'endpoint': '/api/proxy/health',
            'method': 'GET'
        },
        {
            'endpoint': '/chatbot/health',
            'method': 'GET'
        },
        {
            'endpoint': '/chatbot/search',
            'method': 'POST',
            'data': {
                'query': 'pizza recipes',
                'content_types': ['recipes'],
                'limit': 5
            }
        }
    ]
    
    # Run load test
    results = tester.run_concurrent_tests(
        test_config=test_config,
        concurrent_users=5,  # Start with moderate load
        duration_seconds=30   # Shorter duration for testing
    )
    
    return results

def run_chatbot_accuracy_test():
    """Test chatbot accuracy with predefined queries."""
    
    base_url = 'http://localhost:5001'
    
    # Test queries with expected response characteristics
    test_queries = [
        {
            'query': 'What ingredients are in a Margherita pizza?',
            'expected_keywords': ['tomato', 'mozzarella', 'basil'],
            'category': 'recipe_ingredients'
        },
        {
            'query': 'What can I substitute for mozzarella cheese?',
            'expected_keywords': ['vegan', 'cashew', 'substitute'],
            'category': 'substitution'
        },
        {
            'query': 'What allergens are in mozzarella cheese?',
            'expected_keywords': ['dairy'],
            'category': 'allergens'
        },
        {
            'query': 'Tell me about Fresh Farm Produce Co.',
            'expected_keywords': ['vegetables', 'organic', 'supplier'],
            'category': 'supplier_info'
        },
        {
            'query': 'What vegetables are good for salads?',
            'expected_keywords': ['lettuce', 'romaine', 'vegetable'],
            'category': 'ingredient_category'
        }
    ]
    
    results = []
    
    for test in test_queries:
        try:
            response = requests.post(f"{base_url}/chatbot/ask-skunk",
                                   json={
                                       'query': test['query'],
                                       'context': {}
                                   },
                                   headers={'X-User-ID': 'accuracy-test-user'},
                                   timeout=30)
            
            if response.status_code == 200:
                data = response.json()
                if data['success']:
                    response_text = data['response'].lower()
                    
                    # Check if expected keywords are present
                    keyword_matches = sum(1 for keyword in test['expected_keywords'] 
                                        if keyword.lower() in response_text)
                    
                    accuracy_score = (keyword_matches / len(test['expected_keywords'])) * 100
                    
                    results.append({
                        'query': test['query'],
                        'category': test['category'],
                        'response': data['response'],
                        'expected_keywords': test['expected_keywords'],
                        'keyword_matches': keyword_matches,
                        'accuracy_score': accuracy_score,
                        'confidence_score': data.get('confidence_score', 0),
                        'response_time_ms': data.get('response_time_ms', 0),
                        'allergen_alerts': len(data.get('allergen_alerts', [])),
                        'substitution_suggestions': len(data.get('substitution_suggestions', [])),
                        'success': True
                    })
                else:
                    results.append({
                        'query': test['query'],
                        'category': test['category'],
                        'error': data.get('error', 'Unknown error'),
                        'success': False
                    })
            else:
                results.append({
                    'query': test['query'],
                    'category': test['category'],
                    'error': f'HTTP {response.status_code}',
                    'success': False
                })
                
        except Exception as e:
            results.append({
                'query': test['query'],
                'category': test['category'],
                'error': str(e),
                'success': False
            })
    
    # Calculate overall accuracy
    successful_tests = [r for r in results if r['success']]
    if successful_tests:
        overall_accuracy = statistics.mean([r['accuracy_score'] for r in successful_tests])
        avg_confidence = statistics.mean([r['confidence_score'] for r in successful_tests])
        avg_response_time = statistics.mean([r['response_time_ms'] for r in successful_tests])
    else:
        overall_accuracy = 0
        avg_confidence = 0
        avg_response_time = 0
    
    return {
        'overall_accuracy': overall_accuracy,
        'avg_confidence_score': avg_confidence,
        'avg_response_time_ms': avg_response_time,
        'total_tests': len(test_queries),
        'successful_tests': len(successful_tests),
        'failed_tests': len(test_queries) - len(successful_tests),
        'meets_accuracy_target': overall_accuracy >= 85,
        'detailed_results': results
    }

if __name__ == '__main__':
    print("Starting comprehensive testing...")
    
    # Run load tests
    print("\n=== LOAD TESTING ===")
    load_results = run_forecasting_load_test()
    print(f"Load Test Results:")
    print(f"- Total Requests: {load_results['summary']['total_requests']}")
    print(f"- Success Rate: {load_results['summary']['success_rate']:.1f}%")
    print(f"- Avg Response Time: {load_results['summary']['avg_response_time']:.1f}ms")
    print(f"- P95 Response Time: {load_results['summary']['p95_response_time']:.1f}ms")
    print(f"- Requests/Second: {load_results['summary']['requests_per_second']:.1f}")
    
    # Run accuracy tests
    print("\n=== CHATBOT ACCURACY TESTING ===")
    accuracy_results = run_chatbot_accuracy_test()
    print(f"Chatbot Accuracy Results:")
    print(f"- Overall Accuracy: {accuracy_results['overall_accuracy']:.1f}%")
    print(f"- Meets Target (≥85%): {'✓' if accuracy_results['meets_accuracy_target'] else '✗'}")
    print(f"- Avg Confidence Score: {accuracy_results['avg_confidence_score']:.2f}")
    print(f"- Avg Response Time: {accuracy_results['avg_response_time_ms']:.1f}ms")
    print(f"- Successful Tests: {accuracy_results['successful_tests']}/{accuracy_results['total_tests']}")
    
    # Save detailed results
    with open('/home/ubuntu/ai-forecasting-layer/tests/load_test_results.json', 'w') as f:
        json.dump(load_results, f, indent=2)
    
    with open('/home/ubuntu/ai-forecasting-layer/tests/accuracy_test_results.json', 'w') as f:
        json.dump(accuracy_results, f, indent=2)
    
    print(f"\nDetailed results saved to:")
    print(f"- /home/ubuntu/ai-forecasting-layer/tests/load_test_results.json")
    print(f"- /home/ubuntu/ai-forecasting-layer/tests/accuracy_test_results.json")

