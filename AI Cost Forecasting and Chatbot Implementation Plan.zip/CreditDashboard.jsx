import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';
import { CreditCard, TrendingUp, Users, Activity, RefreshCw } from 'lucide-react';

const API_BASE_URL = 'https://4zmhqivcl8ox.manus.space';

const CreditDashboard = () => {
  const [creditSummary, setCreditSummary] = useState(null);
  const [userCredits, setUserCredits] = useState({});
  const [selectedPeriod, setSelectedPeriod] = useState('7');
  const [selectedUser, setSelectedUser] = useState('demo-user');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchCreditSummary = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await fetch(`${API_BASE_URL}/api/proxy/credits/summary?days=${selectedPeriod}&limit=10`);
      const data = await response.json();
      
      if (data.success) {
        setCreditSummary(data);
      } else {
        throw new Error(data.error || 'Failed to fetch credit summary');
      }
    } catch (err) {
      setError(err.message);
      // Mock data for demo
      setCreditSummary({
        success: true,
        period_days: parseInt(selectedPeriod),
        total_credits: 156.75,
        total_users: 12,
        top_users: [
          { user_id: 'demo-user', total_credits: 45.2, request_count: 89 },
          { user_id: 'admin-user', total_credits: 32.1, request_count: 67 },
          { user_id: 'test-user', total_credits: 28.5, request_count: 45 },
        ],
        usage_by_service: {
          'gpt_gpt_3_5_turbo': { total_credits: 89.3, request_count: 156 },
          'forecasting': { total_credits: 34.2, request_count: 34 },
          'embedding_text_embedding_ada_002': { total_credits: 23.1, request_count: 78 },
          'forecasting_cached': { total_credits: 10.15, request_count: 101 },
        }
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchUserCredits = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/proxy/credits/${selectedUser}?days=${selectedPeriod}`);
      const data = await response.json();
      
      if (data.success) {
        setUserCredits(data);
      } else {
        throw new Error(data.error || 'Failed to fetch user credits');
      }
    } catch (err) {
      // Mock data for demo
      setUserCredits({
        success: true,
        user_id: selectedUser,
        total_credits: 45.2,
        usage_by_service: {
          'gpt_gpt_3_5_turbo': { total_credits: 25.3, request_count: 42 },
          'forecasting': { total_credits: 12.1, request_count: 12 },
          'embedding_text_embedding_ada_002': { total_credits: 5.8, request_count: 23 },
          'forecasting_cached': { total_credits: 2.0, request_count: 20 },
        },
        total_requests: 97
      });
    }
  };

  useEffect(() => {
    fetchCreditSummary();
    fetchUserCredits();
  }, [selectedPeriod, selectedUser]);

  const formatServiceName = (serviceName) => {
    const serviceMap = {
      'gpt_gpt_3_5_turbo': 'GPT-3.5 Turbo',
      'gpt_gpt_4': 'GPT-4',
      'forecasting': 'Cost Forecasting',
      'forecasting_cached': 'Forecasting (Cached)',
      'embedding_text_embedding_ada_002': 'Text Embeddings',
    };
    return serviceMap[serviceName] || serviceName;
  };

  const getServiceColor = (serviceName) => {
    const colorMap = {
      'gpt_gpt_3_5_turbo': '#3b82f6',
      'gpt_gpt_4': '#8b5cf6',
      'forecasting': '#10b981',
      'forecasting_cached': '#06b6d4',
      'embedding_text_embedding_ada_002': '#f59e0b',
    };
    return colorMap[serviceName] || '#6b7280';
  };

  // Prepare chart data
  const serviceUsageData = creditSummary ? Object.entries(creditSummary.usage_by_service).map(([service, data]) => ({
    name: formatServiceName(service),
    credits: data.total_credits,
    requests: data.request_count,
    color: getServiceColor(service),
  })) : [];

  const topUsersData = creditSummary ? creditSummary.top_users.map(user => ({
    name: user.user_id,
    credits: user.total_credits,
    requests: user.request_count,
  })) : [];

  // Mock time series data for demonstration
  const timeSeriesData = [
    { date: '2024-06-01', credits: 12.5 },
    { date: '2024-06-02', credits: 18.2 },
    { date: '2024-06-03', credits: 15.8 },
    { date: '2024-06-04', credits: 22.1 },
    { date: '2024-06-05', credits: 19.7 },
    { date: '2024-06-06', credits: 25.3 },
    { date: '2024-06-07', credits: 23.9 },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Credit Usage Dashboard</h2>
          <p className="text-gray-600">Monitor AI service credit consumption and usage patterns</p>
        </div>
        <div className="flex items-center space-x-4">
          <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1">Last 24h</SelectItem>
              <SelectItem value="7">Last 7 days</SelectItem>
              <SelectItem value="30">Last 30 days</SelectItem>
              <SelectItem value="90">Last 90 days</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={fetchCreditSummary} disabled={loading} variant="outline">
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-800">Error: {error}</p>
          <p className="text-red-600 text-sm mt-1">Showing demo data instead.</p>
        </div>
      )}

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Credits</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {creditSummary ? creditSummary.total_credits.toFixed(2) : '0.00'}
            </div>
            <p className="text-xs text-muted-foreground">
              Last {selectedPeriod} days
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {creditSummary ? creditSummary.total_users : '0'}
            </div>
            <p className="text-xs text-muted-foreground">
              Users with activity
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Credits/User</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {creditSummary && creditSummary.total_users > 0 
                ? (creditSummary.total_credits / creditSummary.total_users).toFixed(2)
                : '0.00'
              }
            </div>
            <p className="text-xs text-muted-foreground">
              Per active user
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Most Used Service</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {serviceUsageData.length > 0 ? serviceUsageData[0].name : 'N/A'}
            </div>
            <p className="text-xs text-muted-foreground">
              {serviceUsageData.length > 0 ? `${serviceUsageData[0].credits.toFixed(1)} credits` : 'No data'}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Credit Usage Over Time */}
        <Card>
          <CardHeader>
            <CardTitle>Credit Usage Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={timeSeriesData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="credits" stroke="#3b82f6" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Service Usage Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Usage by Service</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={serviceUsageData}
                  cx="50%"
                  cy="50%"
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="credits"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {serviceUsageData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Users */}
        <Card>
          <CardHeader>
            <CardTitle>Top Users by Credit Usage</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {topUsersData.map((user, index) => (
                <div key={user.name} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <Badge variant="outline">#{index + 1}</Badge>
                    <div>
                      <p className="font-medium">{user.name}</p>
                      <p className="text-sm text-gray-600">{user.requests} requests</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold">{user.credits.toFixed(2)}</p>
                    <p className="text-sm text-gray-600">credits</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Service Breakdown */}
        <Card>
          <CardHeader>
            <CardTitle>Service Usage Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {serviceUsageData.map((service) => (
                <div key={service.name} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div 
                      className="w-4 h-4 rounded-full" 
                      style={{ backgroundColor: service.color }}
                    ></div>
                    <div>
                      <p className="font-medium">{service.name}</p>
                      <p className="text-sm text-gray-600">{service.requests} requests</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold">{service.credits.toFixed(2)}</p>
                    <p className="text-sm text-gray-600">credits</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* User-specific Details */}
      <Card>
        <CardHeader>
          <CardTitle>User Credit Details</CardTitle>
          <div className="flex items-center space-x-4">
            <Select value={selectedUser} onValueChange={setSelectedUser}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="demo-user">demo-user</SelectItem>
                <SelectItem value="admin-user">admin-user</SelectItem>
                <SelectItem value="test-user">test-user</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          {userCredits.success && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-semibold text-blue-900">Total Credits</h4>
                <p className="text-2xl font-bold text-blue-700">{userCredits.total_credits?.toFixed(2) || '0.00'}</p>
              </div>
              <div className="bg-green-50 p-4 rounded-lg">
                <h4 className="font-semibold text-green-900">Total Requests</h4>
                <p className="text-2xl font-bold text-green-700">{userCredits.total_requests || 0}</p>
              </div>
              <div className="bg-purple-50 p-4 rounded-lg">
                <h4 className="font-semibold text-purple-900">Avg Credits/Request</h4>
                <p className="text-2xl font-bold text-purple-700">
                  {userCredits.total_requests > 0 
                    ? (userCredits.total_credits / userCredits.total_requests).toFixed(3)
                    : '0.000'
                  }
                </p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default CreditDashboard;

