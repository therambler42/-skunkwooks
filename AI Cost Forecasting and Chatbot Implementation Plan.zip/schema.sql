-- Database schema for AI & Forecasting Layer

-- Credits tracking table
CREATE TABLE IF NOT EXISTS credits_usage (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    service_type VARCHAR(100) NOT NULL, -- 'gpt', 'forecasting', 'vector_search'
    credits_consumed DECIMAL(10,4) NOT NULL,
    request_details JSONB,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    session_id VARCHAR(255),
    INDEX idx_user_timestamp (user_id, timestamp),
    INDEX idx_service_type (service_type),
    INDEX idx_timestamp (timestamp)
);

-- Vector embeddings storage for organizational data
CREATE TABLE IF NOT EXISTS vector_embeddings (
    id SERIAL PRIMARY KEY,
    content_type VARCHAR(100) NOT NULL, -- 'recipe', 'ingredient', 'supplier'
    content_id VARCHAR(255) NOT NULL,
    content_text TEXT NOT NULL,
    embedding vector(1536), -- OpenAI embedding dimension
    metadata JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_content_type (content_type),
    INDEX idx_content_id (content_id)
);

-- Enable pgvector extension
CREATE EXTENSION IF NOT EXISTS vector;

-- Forecasting data cache
CREATE TABLE IF NOT EXISTS forecast_cache (
    id SERIAL PRIMARY KEY,
    ingredient_id VARCHAR(255) NOT NULL,
    forecast_type VARCHAR(50) NOT NULL, -- '30_day', '60_day', '90_day'
    forecast_data JSONB NOT NULL,
    model_version VARCHAR(100),
    mae_score DECIMAL(8,4),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP,
    INDEX idx_ingredient_type (ingredient_id, forecast_type),
    INDEX idx_expires_at (expires_at)
);

-- User interaction logs for chatbot
CREATE TABLE IF NOT EXISTS chatbot_interactions (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    query TEXT NOT NULL,
    response TEXT NOT NULL,
    confidence_score DECIMAL(4,3),
    response_time_ms INTEGER,
    feedback_rating INTEGER CHECK (feedback_rating >= 1 AND feedback_rating <= 5),
    allergen_alerts JSONB,
    substitution_suggestions JSONB,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_timestamp (user_id, timestamp),
    INDEX idx_confidence (confidence_score),
    INDEX idx_timestamp (timestamp)
);

-- Ingredients master data
CREATE TABLE IF NOT EXISTS ingredients (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE,
    category VARCHAR(100),
    allergens JSONB, -- Array of allergen types
    cost_per_unit DECIMAL(10,4),
    unit_type VARCHAR(50), -- 'kg', 'lbs', 'liters', etc.
    supplier_id VARCHAR(255),
    nutritional_info JSONB,
    substitutes JSONB, -- Array of substitute ingredient IDs
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_name (name),
    INDEX idx_category (category),
    INDEX idx_supplier (supplier_id)
);

-- Recipes data
CREATE TABLE IF NOT EXISTS recipes (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    ingredients JSONB NOT NULL, -- Array of {ingredient_id, quantity, unit}
    instructions TEXT,
    allergen_warnings JSONB,
    nutritional_summary JSONB,
    cost_estimate DECIMAL(10,4),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_name (name),
    INDEX idx_cost (cost_estimate)
);

-- Suppliers data
CREATE TABLE IF NOT EXISTS suppliers (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    contact_info JSONB,
    specialties JSONB, -- Array of ingredient categories
    reliability_score DECIMAL(3,2), -- 0.00 to 5.00
    average_delivery_time INTEGER, -- days
    payment_terms VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_name (name),
    INDEX idx_reliability (reliability_score)
);

