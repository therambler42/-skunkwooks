import sys
import os
import requests
import json
import logging
from datetime import datetime
from typing import Dict, Any, Optional
import uuid

# Add Manus API client path
sys.path.append('/opt/.manus/.sandbox-runtime')

try:
    from data_api import ApiClient
    MANUS_API_AVAILABLE = True
except ImportError:
    MANUS_API_AVAILABLE = False
    logging.warning("Manus API client not available, using mock implementation")

class ManusAPIProxy:
    """
    Proxy service for Manus API calls with centralized credit tracking.
    Handles GPT calls and other AI services through Manus platform.
    """
    
    def __init__(self, db_session=None):
        self.logger = logging.getLogger(__name__)
        self.db_session = db_session
        
        if MANUS_API_AVAILABLE:
            self.client = ApiClient()
        else:
            self.client = None
            
        # Credit costs per service type
        self.credit_costs = {
            'gpt-3.5-turbo': 0.1,
            'gpt-4': 0.5,
            'gpt-4-turbo': 0.3,
            'text-embedding-ada-002': 0.05,
            'text-davinci-003': 0.2
        }
    
    def call_gpt(self, 
                 messages: list, 
                 model: str = 'gpt-3.5-turbo',
                 user_id: str = 'anonymous',
                 session_id: Optional[str] = None,
                 **kwargs) -> Dict[str, Any]:
        """
        Make GPT API call through Manus proxy with credit tracking.
        
        Args:
            messages: List of message objects for GPT
            model: GPT model to use
            user_id: User identifier for credit tracking
            session_id: Optional session identifier
            **kwargs: Additional parameters for GPT API
            
        Returns:
            Dictionary with response and credit information
        """
        try:
            if session_id is None:
                session_id = str(uuid.uuid4())
            
            # Calculate estimated credits
            estimated_credits = self._estimate_credits(messages, model)
            
            # Log pre-request credit usage
            self._log_credit_usage(
                user_id=user_id,
                service_type=f'gpt_{model.replace("-", "_")}',
                credits_consumed=estimated_credits,
                session_id=session_id,
                request_details={
                    'model': model,
                    'message_count': len(messages),
                    'estimated': True
                }
            )
            
            if self.client and MANUS_API_AVAILABLE:
                # Use actual Manus API
                response = self._call_manus_gpt(messages, model, **kwargs)
            else:
                # Use mock response for development
                response = self._mock_gpt_response(messages, model)
            
            # Calculate actual credits used (if available in response)
            actual_credits = response.get('credits_used', estimated_credits)
            
            # Log actual credit usage
            self._log_credit_usage(
                user_id=user_id,
                service_type=f'gpt_{model.replace("-", "_")}',
                credits_consumed=actual_credits,
                session_id=session_id,
                request_details={
                    'model': model,
                    'message_count': len(messages),
                    'response_tokens': response.get('usage', {}).get('total_tokens', 0),
                    'estimated': False
                }
            )
            
            return {
                'success': True,
                'response': response,
                'credits_used': actual_credits,
                'session_id': session_id
            }
            
        except Exception as e:
            self.logger.error(f"Error in GPT API call: {str(e)}")
            return {
                'success': False,
                'error': str(e),
                'credits_used': 0,
                'session_id': session_id
            }
    
    def call_embedding(self,
                      text: str,
                      model: str = 'text-embedding-ada-002',
                      user_id: str = 'anonymous',
                      session_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Generate text embeddings through Manus API.
        
        Args:
            text: Text to embed
            model: Embedding model to use
            user_id: User identifier
            session_id: Optional session identifier
            
        Returns:
            Dictionary with embedding and credit information
        """
        try:
            if session_id is None:
                session_id = str(uuid.uuid4())
            
            credits_used = self.credit_costs.get(model, 0.05)
            
            if self.client and MANUS_API_AVAILABLE:
                # Use actual Manus API for embeddings
                response = self._call_manus_embedding(text, model)
            else:
                # Use mock embedding for development
                response = self._mock_embedding_response(text, model)
            
            # Log credit usage
            self._log_credit_usage(
                user_id=user_id,
                service_type=f'embedding_{model.replace("-", "_")}',
                credits_consumed=credits_used,
                session_id=session_id,
                request_details={
                    'model': model,
                    'text_length': len(text)
                }
            )
            
            return {
                'success': True,
                'embedding': response.get('embedding', []),
                'credits_used': credits_used,
                'session_id': session_id
            }
            
        except Exception as e:
            self.logger.error(f"Error in embedding API call: {str(e)}")
            return {
                'success': False,
                'error': str(e),
                'credits_used': 0,
                'session_id': session_id
            }
    
    def get_credit_usage(self, user_id: str, days: int = 30) -> Dict[str, Any]:
        """
        Get credit usage statistics for a user.
        
        Args:
            user_id: User identifier
            days: Number of days to look back
            
        Returns:
            Dictionary with usage statistics
        """
        try:
            if not self.db_session:
                return {'error': 'Database session not available'}
            
            from src.models.forecasting import CreditUsage
            from datetime import timedelta
            
            # Calculate date range
            end_date = datetime.utcnow()
            start_date = end_date - timedelta(days=days)
            
            # Query credit usage
            usage_records = self.db_session.query(CreditUsage).filter(
                CreditUsage.user_id == user_id,
                CreditUsage.timestamp >= start_date,
                CreditUsage.timestamp <= end_date
            ).all()
            
            # Aggregate by service type
            usage_by_service = {}
            total_credits = 0
            
            for record in usage_records:
                service = record.service_type
                credits = float(record.credits_consumed)
                
                if service not in usage_by_service:
                    usage_by_service[service] = {
                        'total_credits': 0,
                        'request_count': 0,
                        'last_used': None
                    }
                
                usage_by_service[service]['total_credits'] += credits
                usage_by_service[service]['request_count'] += 1
                
                if (usage_by_service[service]['last_used'] is None or 
                    record.timestamp > usage_by_service[service]['last_used']):
                    usage_by_service[service]['last_used'] = record.timestamp
                
                total_credits += credits
            
            return {
                'success': True,
                'user_id': user_id,
                'period_days': days,
                'total_credits': total_credits,
                'usage_by_service': usage_by_service,
                'total_requests': len(usage_records)
            }
            
        except Exception as e:
            self.logger.error(f"Error getting credit usage: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def _call_manus_gpt(self, messages: list, model: str, **kwargs) -> Dict[str, Any]:
        """Call actual Manus API for GPT."""
        try:
            # Construct API call parameters
            api_params = {
                'messages': messages,
                'model': model,
                **kwargs
            }
            
            # Make API call through Manus client
            response = self.client.call_api('OpenAI/chat_completions', query=api_params)
            
            return response
            
        except Exception as e:
            self.logger.error(f"Manus GPT API error: {str(e)}")
            raise
    
    def _call_manus_embedding(self, text: str, model: str) -> Dict[str, Any]:
        """Call actual Manus API for embeddings."""
        try:
            api_params = {
                'input': text,
                'model': model
            }
            
            response = self.client.call_api('OpenAI/embeddings', query=api_params)
            
            return response
            
        except Exception as e:
            self.logger.error(f"Manus embedding API error: {str(e)}")
            raise
    
    def _mock_gpt_response(self, messages: list, model: str) -> Dict[str, Any]:
        """Generate mock GPT response for development."""
        return {
            'choices': [{
                'message': {
                    'role': 'assistant',
                    'content': f'Mock response from {model} for {len(messages)} messages. This is a development placeholder.'
                },
                'finish_reason': 'stop'
            }],
            'usage': {
                'prompt_tokens': sum(len(msg.get('content', '')) for msg in messages) // 4,
                'completion_tokens': 50,
                'total_tokens': sum(len(msg.get('content', '')) for msg in messages) // 4 + 50
            },
            'model': model
        }
    
    def _mock_embedding_response(self, text: str, model: str) -> Dict[str, Any]:
        """Generate mock embedding response for development."""
        import numpy as np
        
        # Generate deterministic mock embedding based on text hash
        np.random.seed(hash(text) % (2**32))
        embedding = np.random.normal(0, 1, 1536).tolist()  # OpenAI embedding dimension
        
        return {
            'embedding': embedding,
            'model': model,
            'usage': {
                'prompt_tokens': len(text) // 4,
                'total_tokens': len(text) // 4
            }
        }
    
    def _estimate_credits(self, messages: list, model: str) -> float:
        """Estimate credit cost for GPT request."""
        # Simple estimation based on message length and model
        total_chars = sum(len(msg.get('content', '')) for msg in messages)
        base_cost = self.credit_costs.get(model, 0.1)
        
        # Scale by message length (rough approximation)
        estimated_tokens = total_chars // 4
        credit_multiplier = max(1.0, estimated_tokens / 1000)
        
        return base_cost * credit_multiplier
    
    def _log_credit_usage(self, user_id: str, service_type: str, credits_consumed: float, 
                         session_id: str, request_details: Dict[str, Any]):
        """Log credit usage to database."""
        try:
            if not self.db_session:
                return
            
            from src.models.forecasting import CreditUsage
            
            usage_log = CreditUsage(
                user_id=user_id,
                service_type=service_type,
                credits_consumed=credits_consumed,
                request_details=request_details,
                session_id=session_id
            )
            
            self.db_session.add(usage_log)
            self.db_session.commit()
            
        except Exception as e:
            self.logger.error(f"Error logging credit usage: {str(e)}")
            if self.db_session:
                self.db_session.rollback()

