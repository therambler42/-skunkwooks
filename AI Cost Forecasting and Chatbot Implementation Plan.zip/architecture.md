# AI & Forecasting Layer Architecture

## System Overview
This project implements a comprehensive AI & Forecasting Layer with the following components:

### Backend Services
1. **Cost Forecasting Microservice** (Flask + Prophet)
   - REST API endpoint: `/forecast/cost`
   - 30/60/90-day predictions per ingredient
   - MAE target: <= 5%

2. **Manus API Proxy**
   - Centralized GPT call management
   - Credit tracking and usage monitoring
   - Rate limiting and cost optimization

3. **Vector Search Service** (Postgres + pgvector)
   - Organizational data indexing (recipes, ingredients, suppliers)
   - Semantic search capabilities
   - Real-time query processing

### Frontend Components
1. **Ask Skunk Chatbot Sidebar**
   - React-based conversational interface
   - Vector search integration
   - Allergen alerts and substitution suggestions
   - 85% accuracy target

2. **Credit Usage Dashboard**
   - Admin interface for credit monitoring
   - Daily/weekly/monthly usage analytics
   - Real-time consumption tracking

### Database Schema
- **Credits tracking table**
- **Vector embeddings storage**
- **Forecasting data cache**
- **User interaction logs**

## Technology Stack
- **Backend**: Flask, Prophet, PostgreSQL with pgvector
- **Frontend**: React, Tailwind CSS, shadcn/ui
- **AI/ML**: Manus API, Prophet forecasting, Vector embeddings
- **Deployment**: Docker, CI/CD pipeline, Staging environment

## API Endpoints
- `POST /forecast/cost` - Cost forecasting
- `POST /chat/ask-skunk` - Chatbot queries
- `GET /credits/usage` - Credit consumption data
- `POST /api/proxy/gpt` - Manus API proxy

## Acceptance Criteria
✅ Forecast MAE <= 5% on backtest sample
✅ Chatbot answers >= 85% of test queries correctly  
✅ Credit dashboard displays accurate consumption data

