import pandas as pd
import numpy as np
from prophet import Prophet
from datetime import datetime, timedelta
import logging
from typing import Dict, List, Tuple, Optional
import json

class CostForecastingService:
    """
    Cost forecasting service using Facebook Prophet for time series prediction.
    Provides 30/60/90-day cost predictions for ingredients.
    """
    
    def __init__(self):
        self.model_version = "1.0.0"
        self.logger = logging.getLogger(__name__)
        
    def prepare_data(self, historical_data: List[Dict]) -> pd.DataFrame:
        """
        Prepare historical cost data for Prophet model.
        
        Args:
            historical_data: List of dicts with 'date' and 'cost' keys
            
        Returns:
            DataFrame formatted for Prophet (ds, y columns)
        """
        df = pd.DataFrame(historical_data)
        df['ds'] = pd.to_datetime(df['date'])
        df['y'] = df['cost'].astype(float)
        
        # Remove outliers using IQR method
        Q1 = df['y'].quantile(0.25)
        Q3 = df['y'].quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        
        df = df[(df['y'] >= lower_bound) & (df['y'] <= upper_bound)]
        
        return df[['ds', 'y']].sort_values('ds')
    
    def create_model(self, seasonality_mode: str = 'multiplicative') -> Prophet:
        """
        Create and configure Prophet model for cost forecasting.
        
        Args:
            seasonality_mode: 'additive' or 'multiplicative'
            
        Returns:
            Configured Prophet model
        """
        model = Prophet(
            seasonality_mode=seasonality_mode,
            yearly_seasonality=True,
            weekly_seasonality=True,
            daily_seasonality=False,
            changepoint_prior_scale=0.05,  # Controls flexibility of trend changes
            seasonality_prior_scale=10.0,   # Controls flexibility of seasonality
            interval_width=0.8,             # Uncertainty intervals
            growth='linear'                 # Linear growth trend
        )
        
        # Add custom seasonalities for food industry
        model.add_seasonality(name='monthly', period=30.5, fourier_order=5)
        model.add_seasonality(name='quarterly', period=91.25, fourier_order=8)
        
        return model
    
    def train_model(self, df: pd.DataFrame) -> Prophet:
        """
        Train Prophet model on historical data.
        
        Args:
            df: DataFrame with 'ds' and 'y' columns
            
        Returns:
            Trained Prophet model
        """
        model = self.create_model()
        model.fit(df)
        return model
    
    def generate_forecast(self, model: Prophet, periods: int = 90) -> pd.DataFrame:
        """
        Generate future predictions using trained model.
        
        Args:
            model: Trained Prophet model
            periods: Number of days to forecast
            
        Returns:
            DataFrame with forecast results
        """
        future = model.make_future_dataframe(periods=periods)
        forecast = model.predict(future)
        
        return forecast
    
    def calculate_mae(self, actual: pd.Series, predicted: pd.Series) -> float:
        """
        Calculate Mean Absolute Error for model validation.
        
        Args:
            actual: Actual values
            predicted: Predicted values
            
        Returns:
            MAE score as percentage
        """
        mae = np.mean(np.abs(actual - predicted))
        mape = np.mean(np.abs((actual - predicted) / actual)) * 100
        return mape
    
    def backtest_model(self, df: pd.DataFrame, test_days: int = 15) -> Tuple[float, Dict]:
        """
        Perform backtesting to validate model accuracy.
        
        Args:
            df: Historical data DataFrame
            test_days: Number of days to use for testing (reduced for smaller datasets)
            
        Returns:
            Tuple of (MAE score, detailed metrics)
        """
        if len(df) < test_days + 15:  # Reduced minimum requirement
            # For very small datasets, use a smaller test period
            test_days = max(5, len(df) // 3)
            
        if len(df) < test_days + 10:
            raise ValueError("Insufficient data for backtesting")
        
        # Split data
        train_df = df[:-test_days].copy()
        test_df = df[-test_days:].copy()
        
        # Train model on training data
        model = self.train_model(train_df)
        
        # Generate forecast for test period
        future = model.make_future_dataframe(periods=test_days)
        forecast = model.predict(future)
        
        # Get predictions for test period
        test_predictions = forecast[-test_days:]['yhat'].values
        test_actual = test_df['y'].values
        
        # Calculate metrics
        mae = self.calculate_mae(test_actual, test_predictions)
        rmse = np.sqrt(np.mean((test_actual - test_predictions) ** 2))
        
        metrics = {
            'mae_percentage': mae,
            'rmse': rmse,
            'test_period_days': test_days,
            'training_data_points': len(train_df),
            'test_data_points': len(test_df)
        }
        
        return mae, metrics
    
    def forecast_ingredient_cost(self, ingredient_id: str, historical_data: List[Dict]) -> Dict:
        """
        Generate cost forecasts for a specific ingredient.
        
        Args:
            ingredient_id: Unique identifier for ingredient
            historical_data: Historical cost data
            
        Returns:
            Dictionary with 30/60/90-day forecasts and metrics
        """
        try:
            # Prepare data
            df = self.prepare_data(historical_data)
            
            if len(df) < 30:
                raise ValueError("Insufficient historical data (minimum 30 data points required)")
            
            # Perform backtesting
            mae_score, backtest_metrics = self.backtest_model(df)
            
            # Train final model on all data
            model = self.train_model(df)
            
            # Generate 90-day forecast
            forecast = self.generate_forecast(model, periods=90)
            
            # Extract predictions for different periods
            last_historical_date = df['ds'].max()
            forecast_future = forecast[forecast['ds'] > last_historical_date]
            
            # Get 30/60/90-day predictions
            predictions_30 = forecast_future.head(30)
            predictions_60 = forecast_future.head(60)
            predictions_90 = forecast_future.head(90)
            
            result = {
                'ingredient_id': ingredient_id,
                'model_version': self.model_version,
                'mae_score': mae_score,
                'backtest_metrics': backtest_metrics,
                'forecasts': {
                    '30_day': {
                        'period_start': predictions_30['ds'].min().isoformat(),
                        'period_end': predictions_30['ds'].max().isoformat(),
                        'predictions': predictions_30[['ds', 'yhat', 'yhat_lower', 'yhat_upper']].to_dict('records'),
                        'average_cost': float(predictions_30['yhat'].mean()),
                        'trend': 'increasing' if predictions_30['yhat'].iloc[-1] > predictions_30['yhat'].iloc[0] else 'decreasing'
                    },
                    '60_day': {
                        'period_start': predictions_60['ds'].min().isoformat(),
                        'period_end': predictions_60['ds'].max().isoformat(),
                        'predictions': predictions_60[['ds', 'yhat', 'yhat_lower', 'yhat_upper']].to_dict('records'),
                        'average_cost': float(predictions_60['yhat'].mean()),
                        'trend': 'increasing' if predictions_60['yhat'].iloc[-1] > predictions_60['yhat'].iloc[0] else 'decreasing'
                    },
                    '90_day': {
                        'period_start': predictions_90['ds'].min().isoformat(),
                        'period_end': predictions_90['ds'].max().isoformat(),
                        'predictions': predictions_90[['ds', 'yhat', 'yhat_lower', 'yhat_upper']].to_dict('records'),
                        'average_cost': float(predictions_90['yhat'].mean()),
                        'trend': 'increasing' if predictions_90['yhat'].iloc[-1] > predictions_90['yhat'].iloc[0] else 'decreasing'
                    }
                },
                'generated_at': datetime.utcnow().isoformat(),
                'data_quality': {
                    'historical_data_points': len(df),
                    'date_range_days': (df['ds'].max() - df['ds'].min()).days,
                    'outliers_removed': len(historical_data) - len(df)
                }
            }
            
            return result
            
        except Exception as e:
            self.logger.error(f"Error forecasting for ingredient {ingredient_id}: {str(e)}")
            raise
    
    def generate_sample_data(self, ingredient_id: str, days: int = 365) -> List[Dict]:
        """
        Generate sample historical data for testing purposes.
        
        Args:
            ingredient_id: Ingredient identifier
            days: Number of days of sample data
            
        Returns:
            List of sample data points
        """
        np.random.seed(42)  # For reproducible results
        
        base_date = datetime.now() - timedelta(days=days)
        dates = [base_date + timedelta(days=i) for i in range(days)]
        
        # Generate realistic cost data with trend and seasonality
        base_cost = 10.0
        trend = np.linspace(0, 2, days)  # Gradual price increase
        seasonal = 2 * np.sin(2 * np.pi * np.arange(days) / 365.25)  # Yearly seasonality
        weekly = 0.5 * np.sin(2 * np.pi * np.arange(days) / 7)  # Weekly seasonality
        noise = np.random.normal(0, 0.5, days)  # Random noise
        
        costs = base_cost + trend + seasonal + weekly + noise
        costs = np.maximum(costs, 1.0)  # Ensure positive costs
        
        return [
            {
                'date': date.strftime('%Y-%m-%d'),
                'cost': round(cost, 2)
            }
            for date, cost in zip(dates, costs)
        ]

