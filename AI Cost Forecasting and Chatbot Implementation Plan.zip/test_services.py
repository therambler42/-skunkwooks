import unittest
import json
import sys
import os
from unittest.mock import patch, MagicMock
from datetime import datetime, timedelta

# Add src to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from src.main import app
from src.models.forecasting import db
from src.services.forecasting_service import CostForecastingService

class TestForecastingService(unittest.TestCase):
    """Unit tests for the forecasting service."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.app = app
        self.app.config['TESTING'] = True
        self.app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        self.client = self.app.test_client()
        
        with self.app.app_context():
            db.create_all()
    
    def tearDown(self):
        """Clean up after tests."""
        with self.app.app_context():
            db.session.remove()
            db.drop_all()
    
    def test_health_endpoint(self):
        """Test the health check endpoint."""
        response = self.client.get('/forecast/health')
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertTrue(data['success'])
        self.assertEqual(data['service'], 'cost-forecasting')
    
    def test_generate_sample_data(self):
        """Test sample data generation."""
        service = CostForecastingService()
        data = service.generate_sample_data('test_ingredient', days=30)
        
        self.assertEqual(len(data), 30)
        self.assertIn('ds', data[0])
        self.assertIn('y', data[0])
        
        # Check data types
        for point in data:
            self.assertIsInstance(point['ds'], str)
            self.assertIsInstance(point['y'], (int, float))
    
    def test_forecast_generation(self):
        """Test forecast generation with Prophet."""
        service = CostForecastingService()
        
        # Generate sample data
        historical_data = service.generate_sample_data('test_ingredient', days=60)
        
        # Generate forecast
        forecast_result = service.generate_forecast(historical_data, periods=30)
        
        self.assertIsNotNone(forecast_result)
        self.assertIn('forecast', forecast_result)
        self.assertIn('model', forecast_result)
        
        forecast = forecast_result['forecast']
        self.assertEqual(len(forecast), 30)
        
        # Check forecast structure
        for point in forecast:
            self.assertIn('ds', point)
            self.assertIn('yhat', point)
            self.assertIn('yhat_lower', point)
            self.assertIn('yhat_upper', point)
    
    def test_backtest_model(self):
        """Test model backtesting."""
        service = CostForecastingService()
        
        # Generate sample data with more points for backtesting
        historical_data = service.generate_sample_data('test_ingredient', days=90)
        
        # Run backtest
        mae_score = service.backtest_model(historical_data, test_size=0.2)
        
        self.assertIsNotNone(mae_score)
        self.assertIsInstance(mae_score, float)
        self.assertGreaterEqual(mae_score, 0)
    
    def test_cost_forecast_endpoint_with_sample_data(self):
        """Test the cost forecast endpoint with sample data generation."""
        response = self.client.post('/forecast/cost', 
                                  json={'ingredient_id': 'test_ingredient', 'use_cache': False},
                                  headers={'X-User-ID': 'test-user'})
        
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertTrue(data['success'])
        self.assertIn('data', data)
        
        forecast_data = data['data']
        self.assertIn('ingredient_id', forecast_data)
        self.assertIn('forecasts', forecast_data)
        self.assertIn('mae_score', forecast_data)
        
        # Check forecast periods
        forecasts = forecast_data['forecasts']
        self.assertIn('30_day', forecasts)
        self.assertIn('60_day', forecasts)
        self.assertIn('90_day', forecasts)
    
    def test_cost_forecast_endpoint_validation(self):
        """Test input validation for cost forecast endpoint."""
        # Test missing ingredient_id
        response = self.client.post('/forecast/cost', 
                                  json={},
                                  headers={'X-User-ID': 'test-user'})
        
        self.assertEqual(response.status_code, 400)
        
        data = json.loads(response.data)
        self.assertFalse(data['success'])
        self.assertIn('error', data)
    
    def test_cost_forecast_endpoint_missing_user_id(self):
        """Test cost forecast endpoint without user ID header."""
        response = self.client.post('/forecast/cost', 
                                  json={'ingredient_id': 'test_ingredient'})
        
        self.assertEqual(response.status_code, 400)
        
        data = json.loads(response.data)
        self.assertFalse(data['success'])
        self.assertIn('error', data)

class TestAPIProxy(unittest.TestCase):
    """Unit tests for the API proxy service."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.app = app
        self.app.config['TESTING'] = True
        self.app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        self.client = self.app.test_client()
        
        with self.app.app_context():
            db.create_all()
    
    def tearDown(self):
        """Clean up after tests."""
        with self.app.app_context():
            db.session.remove()
            db.drop_all()
    
    def test_api_proxy_health(self):
        """Test API proxy health endpoint."""
        response = self.client.get('/api/proxy/health')
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertTrue(data['success'])
        self.assertEqual(data['service'], 'manus-api-proxy')
    
    @patch('src.services.manus_proxy.requests.post')
    def test_gpt_proxy_endpoint(self, mock_post):
        """Test GPT proxy endpoint with mocked response."""
        # Mock successful GPT response
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            'choices': [{'message': {'content': 'Test response'}}],
            'usage': {'total_tokens': 50}
        }
        mock_post.return_value = mock_response
        
        response = self.client.post('/api/proxy/gpt',
                                  json={
                                      'messages': [{'role': 'user', 'content': 'Hello'}],
                                      'model': 'gpt-3.5-turbo'
                                  },
                                  headers={'X-User-ID': 'test-user'})
        
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertTrue(data['success'])
        self.assertIn('response', data)
    
    def test_gpt_proxy_validation(self):
        """Test GPT proxy input validation."""
        # Test missing messages
        response = self.client.post('/api/proxy/gpt',
                                  json={'model': 'gpt-3.5-turbo'},
                                  headers={'X-User-ID': 'test-user'})
        
        self.assertEqual(response.status_code, 400)
        
        data = json.loads(response.data)
        self.assertFalse(data['success'])
        self.assertIn('error', data)

class TestChatbot(unittest.TestCase):
    """Unit tests for the chatbot service."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.app = app
        self.app.config['TESTING'] = True
        self.app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        self.client = self.app.test_client()
        
        with self.app.app_context():
            db.create_all()
    
    def tearDown(self):
        """Clean up after tests."""
        with self.app.app_context():
            db.session.remove()
            db.drop_all()
    
    def test_chatbot_health(self):
        """Test chatbot health endpoint."""
        response = self.client.get('/chatbot/health')
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertTrue(data['success'])
        self.assertEqual(data['service'], 'ask-skunk-chatbot')
    
    def test_vector_search_endpoint(self):
        """Test vector search endpoint."""
        response = self.client.post('/chatbot/search',
                                  json={
                                      'query': 'pizza recipes',
                                      'content_types': ['recipes'],
                                      'limit': 5
                                  })
        
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertTrue(data['success'])
        self.assertIn('results', data)
        self.assertIsInstance(data['results'], list)
    
    def test_index_data_endpoint(self):
        """Test data indexing endpoint."""
        response = self.client.post('/chatbot/index-data')
        
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertTrue(data['success'])
        self.assertIn('indexed_counts', data)
    
    @patch('src.services.manus_proxy.ManusAPIProxy.call_gpt')
    @patch('src.services.manus_proxy.ManusAPIProxy.call_embedding')
    def test_ask_skunk_endpoint(self, mock_embedding, mock_gpt):
        """Test Ask Skunk chatbot endpoint with mocked responses."""
        # Mock embedding response
        mock_embedding.return_value = {
            'success': True,
            'embedding': [0.1] * 1536
        }
        
        # Mock GPT response
        mock_gpt.return_value = {
            'success': True,
            'response': {
                'choices': [{'message': {'content': 'Test chatbot response'}}]
            }
        }
        
        response = self.client.post('/chatbot/ask-skunk',
                                  json={
                                      'query': 'What ingredients can I substitute for mozzarella?',
                                      'context': {'dietary_restrictions': ['dairy-free']}
                                  },
                                  headers={'X-User-ID': 'test-user'})
        
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertTrue(data['success'])
        self.assertIn('response', data)
        self.assertIn('allergen_alerts', data)
        self.assertIn('substitution_suggestions', data)
        self.assertIn('confidence_score', data)

if __name__ == '__main__':
    # Run all tests
    unittest.main(verbosity=2)

