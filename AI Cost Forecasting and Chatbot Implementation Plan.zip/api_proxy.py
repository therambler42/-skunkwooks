from flask import Blueprint, request, jsonify
from flask_cors import cross_origin
from src.services.manus_proxy import ManusAPIProxy
from src.models.forecasting import db
from datetime import datetime
import logging

api_proxy_bp = Blueprint('api_proxy', __name__)
logger = logging.getLogger(__name__)

# Initialize Manus API proxy
manus_proxy = ManusAPIProxy(db_session=db.session)

@api_proxy_bp.route('/gpt', methods=['POST'])
@cross_origin()
def proxy_gpt():
    """
    Proxy GPT API calls through Manus with credit tracking.
    
    Expected JSON payload:
    {
        "messages": [
            {"role": "user", "content": "Hello, how are you?"}
        ],
        "model": "gpt-3.5-turbo",
        "temperature": 0.7,
        "max_tokens": 150
    }
    
    Returns:
    {
        "success": true,
        "response": {...},
        "credits_used": 0.1,
        "session_id": "uuid"
    }
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No JSON data provided'
            }), 400
        
        messages = data.get('messages', [])
        model = data.get('model', 'gpt-3.5-turbo')
        user_id = request.headers.get('X-User-ID', 'anonymous')
        session_id = data.get('session_id')
        
        if not messages:
            return jsonify({
                'success': False,
                'error': 'Messages array is required'
            }), 400
        
        # Extract additional GPT parameters
        gpt_params = {
            'temperature': data.get('temperature', 0.7),
            'max_tokens': data.get('max_tokens', 150),
            'top_p': data.get('top_p', 1.0),
            'frequency_penalty': data.get('frequency_penalty', 0.0),
            'presence_penalty': data.get('presence_penalty', 0.0)
        }
        
        # Make GPT call through proxy
        result = manus_proxy.call_gpt(
            messages=messages,
            model=model,
            user_id=user_id,
            session_id=session_id,
            **gpt_params
        )
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"Error in GPT proxy: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Internal server error occurred'
        }), 500

@api_proxy_bp.route('/embedding', methods=['POST'])
@cross_origin()
def proxy_embedding():
    """
    Proxy embedding API calls through Manus with credit tracking.
    
    Expected JSON payload:
    {
        "text": "Text to embed",
        "model": "text-embedding-ada-002"
    }
    
    Returns:
    {
        "success": true,
        "embedding": [...],
        "credits_used": 0.05,
        "session_id": "uuid"
    }
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No JSON data provided'
            }), 400
        
        text = data.get('text', '')
        model = data.get('model', 'text-embedding-ada-002')
        user_id = request.headers.get('X-User-ID', 'anonymous')
        session_id = data.get('session_id')
        
        if not text:
            return jsonify({
                'success': False,
                'error': 'Text is required'
            }), 400
        
        # Make embedding call through proxy
        result = manus_proxy.call_embedding(
            text=text,
            model=model,
            user_id=user_id,
            session_id=session_id
        )
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"Error in embedding proxy: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Internal server error occurred'
        }), 500

@api_proxy_bp.route('/credits/<user_id>', methods=['GET'])
@cross_origin()
def get_user_credits(user_id):
    """
    Get credit usage statistics for a user.
    
    Query parameters:
    - days: Number of days to look back (default: 30)
    
    Returns:
    {
        "success": true,
        "user_id": "user123",
        "total_credits": 15.5,
        "usage_by_service": {...},
        "total_requests": 42
    }
    """
    try:
        days = request.args.get('days', 30, type=int)
        
        if days < 1 or days > 365:
            return jsonify({
                'success': False,
                'error': 'Days parameter must be between 1 and 365'
            }), 400
        
        result = manus_proxy.get_credit_usage(user_id=user_id, days=days)
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"Error getting user credits: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Internal server error occurred'
        }), 500

@api_proxy_bp.route('/credits/summary', methods=['GET'])
@cross_origin()
def get_credits_summary():
    """
    Get overall credit usage summary across all users.
    
    Query parameters:
    - days: Number of days to look back (default: 7)
    - limit: Maximum number of top users to return (default: 10)
    
    Returns:
    {
        "success": true,
        "period_days": 7,
        "total_credits": 150.5,
        "total_users": 25,
        "top_users": [...],
        "usage_by_service": {...}
    }
    """
    try:
        days = request.args.get('days', 7, type=int)
        limit = request.args.get('limit', 10, type=int)
        
        if days < 1 or days > 365:
            return jsonify({
                'success': False,
                'error': 'Days parameter must be between 1 and 365'
            }), 400
        
        if limit < 1 or limit > 100:
            return jsonify({
                'success': False,
                'error': 'Limit parameter must be between 1 and 100'
            }), 400
        
        from src.models.forecasting import CreditUsage
        from datetime import datetime, timedelta
        from sqlalchemy import func
        
        # Calculate date range
        end_date = datetime.utcnow()
        start_date = end_date - timedelta(days=days)
        
        # Get total credits and user count
        total_query = db.session.query(
            func.sum(CreditUsage.credits_consumed).label('total_credits'),
            func.count(func.distinct(CreditUsage.user_id)).label('total_users')
        ).filter(
            CreditUsage.timestamp >= start_date,
            CreditUsage.timestamp <= end_date
        ).first()
        
        total_credits = float(total_query.total_credits) if total_query.total_credits else 0
        total_users = total_query.total_users if total_query.total_users else 0
        
        # Get top users by credit usage
        top_users_query = db.session.query(
            CreditUsage.user_id,
            func.sum(CreditUsage.credits_consumed).label('total_credits'),
            func.count(CreditUsage.id).label('request_count')
        ).filter(
            CreditUsage.timestamp >= start_date,
            CreditUsage.timestamp <= end_date
        ).group_by(CreditUsage.user_id).order_by(
            func.sum(CreditUsage.credits_consumed).desc()
        ).limit(limit).all()
        
        top_users = [
            {
                'user_id': user.user_id,
                'total_credits': float(user.total_credits),
                'request_count': user.request_count
            }
            for user in top_users_query
        ]
        
        # Get usage by service type
        service_usage_query = db.session.query(
            CreditUsage.service_type,
            func.sum(CreditUsage.credits_consumed).label('total_credits'),
            func.count(CreditUsage.id).label('request_count')
        ).filter(
            CreditUsage.timestamp >= start_date,
            CreditUsage.timestamp <= end_date
        ).group_by(CreditUsage.service_type).all()
        
        usage_by_service = {
            service.service_type: {
                'total_credits': float(service.total_credits),
                'request_count': service.request_count
            }
            for service in service_usage_query
        }
        
        return jsonify({
            'success': True,
            'period_days': days,
            'total_credits': total_credits,
            'total_users': total_users,
            'top_users': top_users,
            'usage_by_service': usage_by_service
        })
        
    except Exception as e:
        logger.error(f"Error getting credits summary: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Internal server error occurred'
        }), 500

@api_proxy_bp.route('/health', methods=['GET'])
@cross_origin()
def health_check():
    """
    Health check endpoint for the API proxy service.
    """
    return jsonify({
        'success': True,
        'service': 'manus-api-proxy',
        'version': '1.0.0',
        'timestamp': datetime.utcnow().isoformat(),
        'status': 'healthy',
        'manus_api_available': manus_proxy.client is not None
    })

